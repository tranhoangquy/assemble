from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, hashlib, zipfile, subprocess, shutil

P=Path(__file__).resolve().parent
ROOT=P.parents[2]
B=P.parent
def load(p): return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(4*1024*1024),b''): h.update(block)
 return h.hexdigest()
def save(n,v): (P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def run(cmd): return subprocess.run(cmd,check=True,capture_output=True,text=True).stdout
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',22)
small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
big=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',28)

# Check original files before composing any delivery archive.
v=load(P/'VALIDATION.json')
assert v['inventory']==dict(parts=20,hardwareAccessories=100,tools=3,steps=19)
assert not v['exterior']['failures'] and v['exterior']['checks']==77
assert v['contacts']['maxGap']<1e-6 and v['contacts']['woodPositiveOverlaps']==0
assert v['F']['backingMisses']==0 and v['F']['hostApproachObstructions']==0
assert v['propagatedS8']['backingMisses']==0
assert not v['access']['unrelatedCandidates'] and v['access']['minHeadExterior']>=-1e-6
assert all(v['motion'][k] for k in ['deterministic','retention','finite'])
assert all(r['sourceHardware']==r['actualCounts'] for r in load(P/'ALL-19-STEP-REGRESSION.json'))

frames=P/'frames'
manifest=load(frames/'selected-diagnostic-manifest.json')
assert len(manifest)==576
for g in ['S10','S12']:
 names=sorted(f.name for f in frames.glob(g+'-frame-*.png'))
 assert names==[f'{g}-frame-{i:06d}.png' for i in range(288)]
 camera=[]
 for name in names:
  with Image.open(frames/name) as im: im.load(); assert im.size==(1280,720)
  row=next(r for r in manifest if r['name']==name)
  assert not row.get('networkRequests')
  camera.append(row['camera'])
 assert all(x==camera[0] for x in camera)
for path in [frames/'offline-network.json',P/'review-stills/offline-network.json']:
 n=load(path); assert n['offline'] and not n['attemptedRequests']

# Actual encoded proofs, not an image-only storyboard.
media=[]
for g in ['S10','S12']:
 path=P/f'PRODUCT03-{g}-F-nonliteral-proof-v1-720p.mp4'
 if not path.exists():
  run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-framerate','24','-i',str(frames/(g+'-frame-%06d.png')),'-frames:v','288','-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart','-an',str(path)])
 media.append(path)
concat=P/'evidence/concat.txt'
concat.write_text(''.join("file '../"+f.name+"'\n" for f in media))
combined=P/'PRODUCT03-F-nonliteral-proofs-v1-720p.mp4'
if not combined.exists():
 run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-f','concat','-safe','0','-i',str(concat),'-c','copy','-movflags','+faststart',str(combined)])
media.append(combined)
mediaQA=[]
for i,path in enumerate(media):
 data=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(path)]))
 assert len(data['streams'])==1
 s=data['streams'][0]; expected=288 if i<2 else 576
 assert s['codec_type']=='video' and s['width']==1280 and s['height']==720
 assert s['r_frame_rate']=='24/1' and int(s['nb_read_frames'])==expected
 assert abs(float(data['format']['duration'])-expected/24)<.001
 run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(path),'-f','null','-'])
 mediaQA.append(dict(file=path.name,sha256=sha(path),bytes=path.stat().st_size,frames=expected,duration=expected/24,fps=24,audioStreams=0,fullDecode='PASS'))
save('MEDIA-QA.json',dict(result='PASS',frames=576,fullyDecodedPNGs=576,media=mediaQA,camera='Fixed within each12s proof; direct cut separates S10/S12',offline='All requests aborted; attemptedRequests0'))

# Quick-look JPEGs stay below 2048px. ZIP preserves original review bytes.
im=Image.new('RGB',(1920,1230),'#f4f1e9');d=ImageDraw.Draw(im)
d.text((24,12),'HUMAN B / NONLITERAL F — BEFORE / AFTER',font=big,fill='#292c2f')
for row,g in enumerate(['S10','S12']):
 for col,which in enumerate(['before','after']):
  a=Image.open(P/f'review-stills/{g}-{which}.png').convert('RGB').resize((960,540))
  y=70+row*575;im.paste(a,(col*960,y))
  d.text((col*960+18,y-26),g+' / '+('PREVIOUS F HOLD' if col==0 else 'RECONSTRUCTED CONTACT; DRIVER WITHDRAWN'),font=small,fill='#805534')
d.text((24,1210),'Visible board/S8 changes are declared. No OEM receiving geometry or physical-fit approval.',font=small,fill='#805534')
im.save(P/'01-F-BEFORE-AFTER.jpg',quality=94)
im=Image.new('RGB',(1920,1230),'#f4f1e9');d=ImageDraw.Draw(im)
d.text((24,12),'CONTINUOUS LOCAL PROOF / ENGAGE → INSERT → SEAT',font=big,fill='#292c2f')
for row,g in enumerate(['S10','S12']):
 for col,which in enumerate(['engaged','inserting','seated']):
  a=Image.open(P/f'review-stills/{g}-{which}.png').convert('RGB').resize((640,360))
  y=80+row*420;im.paste(a,(col*640,y))
  d.text((col*640+12,y-27),g+' / '+which.upper(),font=small,fill='#805534')
for col,g in enumerate(['S10','S12']):
 a=Image.open(P/f'review-stills/{g}-context.png').convert('RGB');a.thumbnail((600,338));im.paste(a,(col*960+340,870))
 d.text((col*960+15,905),g+' CONTEXT',font=font,fill='#292c2f')
 d.text((col*960+15,950),'Prior parts retained.',font=small,fill='#62594f')
 d.text((col*960+15,985),'Rig remains inverted.',font=small,fill='#62594f')
im.save(P/'02-F-MOTION-AND-CONTEXT.jpg',quality=94)

# Explicit stock/shaft section; illustrative coordinates only, no bore drawn.
im=Image.new('RGB',(1600,920),'#f4f1e9');d=ImageDraw.Draw(im)
d.text((24,15),'F LAP SECTION / DECLARED NONLITERAL RECONSTRUCTION',font=big,fill='#292c2f')
d.text((24,60),'Unmeasured display units.18 metal +7 shaft penetration into wood; rear face and front EDGE differ.',font=font,fill='#805534')
for col,rear in enumerate([True,False]):
 x0=30+col*790;y=180
 d.text((x0,y-45),('S10 rear4 →13 / outward−Z' if rear else 'S12 front3 →15 / outward+Z'),font=font,fill='#292c2f')
 # Diagram along the screw insertion axis, exterior→interior left→right.
 d.rectangle((x0+240,y,x0+420,y+230),fill='#454b4e',outline='#292c2f',width=2)
 d.rectangle((x0+420,y,x0+600,y+230),fill='#b68d69',outline='#292c2f',width=2)
 d.line((x0+240,y+115,x0+490,y+115),fill='#cbd0d3',width=18)
 d.ellipse((x0+225,y+85,x0+245,y+145),fill='#cbd0d3',outline='#646b71',width=2)
 d.line((x0+40,y+115,x0+215,y+115),fill='#7d868a',width=8)
 d.polygon([(x0+215,y+115),(x0+195,y+102),(x0+195,y+128)],fill='#7d868a')
 for dx,label in [(255,'18 metal'),(435,'18 wood' if rear else '346 wood run*')]: d.text((x0+dx,y+245),label,font=small,fill='#292c2f')
 d.text((x0+10,y+320),'Head on exterior plane: gap0',font=font,fill='#292c2f')
 d.text((x0+10,y+360),'Full shaft25: metal18 + wood7',font=font,fill='#292c2f')
 d.text((x0+10,y+400),'Wood far-face remainder'+('11' if rear else '339; edge entry*'),font=font,fill='#292c2f')
 d.text((x0+10,y+455),'RAW SOLID OVERLAP retained;',font=font,fill='#a4552a')
 d.text((x0+10,y+490),'no receiver/bore/thread is modeled.',font=font,fill='#a4552a')
d.text((24,760),'*Front wood run compressed in this diagram.15 thicknessY18; F enters its unverified front EDGE.',font=font,fill='#292c2f')
d.text((24,805),'This describes the rendered model only. It does not establish the actual OEM F axis, retention, hand access or fit.',font=font,fill='#805534')
d.text((24,850),'Earlier lower-face interpretation and all negative evidence remain preserved.',font=font,fill='#805534')
im.save(P/'03-F-LAP-DISCLOSURE.jpg',quality=95)

deltas=load(P/'GEOMETRY-PLACEMENT-DELTAS.json')['rows']
lines=['# F reconstruction — approximation and propagation ledger','','All values below are unmeasured DISPLAY UNITS, not OEM dimensions. This is the human-authorized B proposal. Previous sources and meshes are immutable.','',
'|Component|Before position|After position|Before bounds size|After bounds size|','|---|---|---|---|---|']
for r in deltas:
 def size(s):return [round(b-a,6) for a,b in zip(s['bounds']['min'],s['bounds']['max'])]
 lines.append('|'+r['id']+'|'+str(r['before']['position'])+'|'+str(r['after']['position'])+'|'+str(size(r['before']))+'|'+str(size(r['after']))+'|')
lines+=['','## Basis and limitations','',
'- F8 quantity and rear4/front3 step association: local manual PDFp1,p8 S10,p9 S12. Source F nominal Ø4×25L; no source-confirmed global axis or receiver. Alignment-before-tightening retained.',
'- HumanB permits declared nonliteral visible reconstruction. It does not add documentary evidence. Rear F now outward−Z and front F outward+Z, head planesZ±295,Y744. Metal3/4 and obstacle submeshes are unchanged.',
'-13 extends downward toY735 and moves inward: backZ−277 touches rear4 insideZ−277.15 lowers toY735–753 and its front endsZ277 against front3 insideZ277. Eight full25-unit F shafts span18 metal +7 wood. No hidden hole, thread, receiver or connecting bar is created.',
'-9/10/11/12 and13/15 are resized/repositioned only to propagate the revised visible mating planes without positive wood overlap. Their actual sizes remain unknown. All grain/materials are reused.',
'- Seven13 D heads move toZ−277, ten15 D heads toY735. S8 D10 now use three depth-rail positions into9 and two front-post positions into10 per side. This mapping is explicitly nonliteral; it is not an OEM receiving-hole claim.',
'- ToolM cross blades are narrowed to1×4×1 with existing rotations so they fit the existing modeled cross recess. No screw slot is added. Modeled recess margins .148/.232 and backing clearance .45 are display-model diagnostics, not manufacturer driver dimensions.',
'- Existing front/rear frame/lattice stock,6 and14 are unchanged. OEM inventory, source-step count and dependency order remain unchanged. Other accepted source files are not rewritten.',
'- All77 exterior ray checks preserve existing provisional seating. Thirteen face contacts and36 wood-pair candidates are checked; this is a targeted regression, not whole-product physical certification.',
'- Raw Fshaft/solid metal/solid wood penetrations remain in RAW-ACCESS-AND-CONTACT-CLASSIFICATION.json. They are symbolic unresolved receiver interactions, never a physical collision PASS.',
'- C13/C14 exact end allocation, S18 I/J source conflict, hidden receiving details, actual dimensions, torque, tool/hand access and support safety remain unresolved. No production-gate upgrade is implied.']
(P/'APPROXIMATION-AND-PROPAGATION-LEDGER.md').write_text('\n'.join(lines)+'\n')

protected=load(B/'phase-a-v1/evidence/protected-baseline.json')
assert all((ROOT/f).exists() and sha(ROOT/f)==h for f,h in protected.items())
historical=[]
for file in B.glob('*/REVIEW-DELIVERY-MANIFEST.json'):
 if file.parent==P:continue
 for row in load(file):
  f=Path(row['path']);f=f if f.is_absolute() else file.parent/f
  assert sha(f)==row['sha256'],str(f)
  historical.append(dict(revision=file.parent.name,file=f.name,match=True))
fingerprints=[]
for revision in ['rail-fit-correction-v1','p0-connections-v1']:
 for f,h in load(B/revision/'SOURCE-FINGERPRINTS.json')['files'].items():
  assert sha(ROOT/f)==h;fingerprints.append(f)
for f,h in load(B/'phase-d-illustrative-v2/FROZEN-BLOCKING-SHA256.json')['files'].items():
 path=ROOT/f if f.startswith('src/') else B/f
 assert sha(path)==h;fingerprints.append(f)
assert sha(B/'phase-d-illustrative-v2/PRODUCT03-illustrative-assembly-blocking-v2-720p.mp4')=='0b1948907daaea92ec8cad5a7edd239fde7f11a12ebf6f6c7dfc8c32334456bc'
save('PROTECTED-ASSET-VERIFICATION.json',dict(status='PASS',protectedPaths=len(protected),changes=0,historicalDeliveries=historical,frozenSourceChecks=len(fingerprints),prior158sVideo='UNCHANGED',Product01='UNCHANGED',JULIETTE='UNCHANGED'))
save('SOURCE-FINGERPRINTS.json',dict(files={str(f.relative_to(ROOT)):sha(f) for f in (ROOT/'src/products/product03-pet-crate-w114586144/f-illustrative-proof-v1').glob('*.ts')},genericRendererSha256=sha(ROOT/'scripts/render-mechanism-diagnostics.ts')))
shutil.copyfile(B/'f-evidence-study-v1/02-OEM-FULL-PAGE-CONTEXT.jpg',P/'04-OEM-CONTEXT.jpg')
(P/'DIRECTOR-REVIEW.md').write_text('''# PRODUCT03 — HUMAN B / F NONLITERAL PROOF V1

Review ID: PRODUCT03-F-ILLUSTRATIVE-PROOF-V1-20261022

The human explicitly selected B in Codex: a declared nonliteral illustrative F reconstruction, local proof + actual Assemble review only. This is NOT new OEM evidence. Please review the two actual12s motion proofs and revised visible lap/contact proposal. No full158s render, final Long/Short or audio is authorized.

## Proposed visible result

RearS10: F4 from exterior rear4 into reconstructed13. FrontS12: F4 from exterior front3 into the reconstructed FRONT EDGE of15. Existing frame3/4 stock and obstacles stay intact. All8 heads seat on exterior planes (gap0); metal/wood visible mating faces touch (gap0). Full25-unit shaft remains:18 modeled metal then7 modeled wood. Rear13 has18 along the axis,11 remaining; front15 has346 along the axis,339 remaining, with18 thickness perpendicular to that edge entry. This edge fastening is explicitly NONLITERAL and has no verified receiver or retention. Axes/backing reconstruction is prominently labeled throughout both clips.

The clips continuously show identification, driver approach, engagement, insertion, symbolic rotation, driver withdrawal and retained contact. One F exemplar per group; the other3 are already seated as an explicitly isolated repetition proof. Parts remain installed within each clip. The rig is inverted at the source assembly stage. These are two separate focused proofs, not a full assembly continuity film.

## Declared propagation

Eight wood instances9/10/11/12/13/15 resize/reposition to preserve the revised contacts. Seven13 D placements, ten15 D placements and tenS8 D placements propagate. The JSON includes before/after bounds, positions and normals for all43 changed registry entries. The Markdown ledger explains every class of change. ToolM existing cross blades are narrowed to fit the existing modeled recess; no hidden receiver or new screw slot is created. Walnut, metal, source inventory/dependencies and unaffected metal/6/14 are retained.

## Local QA

-20 components,100 hardware/accessory units+3 tools; all19 source-step counts reconcile under the still-open provisionalS18 I/J mapping.
-77 exterior fastener seating checks; no missing host hit.13 retained face-contact checks gap0;36 wood-pair AABBs with0 positive-volume overlaps. All8 F backing rays and10 propagatedS8 backing rays hit their declared targets.
-289 samples per proof: tool, full shaft and head versus every visible installed mesh. No unrelated positive AABB candidate. All raw Fshaft/stock overlaps are retained and explicitly classified UNMODELED RECEIVER, not a physical PASS. Existing modeled driver cross-slot clearances are reported separately.
-1441 transform samples per proof; arbitrary/backward seek repeatable, finite transforms, installed visibility retained. Fixed camera per clip; continuous quintic approach/withdrawal.3 focused tests and scoped TypeScript pass.
-576 contiguous720p PNGs decoded;2×12s24fps proofs plus24s compilation, all full-decoded and silent. Offline renderer aborted all network requests;0 attempted HTTP requests.
-938 protected paths match; prior review deliveries, accepted source fingerprints and frozen158s video/source match. Product01 and JULIETTE preserved.

## Unresolved / requested decision

Approve, revise or reject this F VISUAL ILLUSTRATION only. Global F axis, actual receiver/retention and actual dimensions remain unconfirmed. Raw shaft/stock solid overlaps remain unresolved physical limitations. No human hand/tool certification, torque, fit, load or safety claim. C13/C14 andI/J remain open. Human final acceptance is not granted.

Please inspect actual MP4s and full original-byte ZIP. Give an explicit scoped decision on visible seating/backing, tool engagement/access representation, cascading contacts and continuous motion. Do not authorize a full blocking/final render: that exceeds this humanB boundary. If accepted, close this local proof milestone and identify remaining issues without starting new production. No acknowledgement will be sent after your final stop decision.
''')

files=['DIRECTOR-REVIEW.md','HUMAN-AUTHORIZATION.json','APPROXIMATION-AND-PROPAGATION-LEDGER.md','GEOMETRY-PLACEMENT-DELTAS.json','ALL-77-EXTERIOR-CHECKS.json','CONTACT-AND-BACKING-CHECKS.json','RAW-ACCESS-AND-CONTACT-CLASSIFICATION.json','ALL-19-STEP-REGRESSION.json','VALIDATION.json','MEDIA-QA.json','PROTECTED-ASSET-VERIFICATION.json','SOURCE-FINGERPRINTS.json',*[f.name for f in media],*[f'{i:02d}-{name}.jpg' for i,name in [(1,'F-BEFORE-AFTER'),(2,'F-MOTION-AND-CONTEXT'),(3,'F-LAP-DISCLOSURE'),(4,'OEM-CONTEXT')]],'evidence/tests.log','evidence/typecheck.log','frames/offline-network.json','review-stills/selected-diagnostic-manifest.json']
files += [str(f.relative_to(P)) for f in sorted((P/'review-stills').glob('*.png'))]
payload=[dict(path=n,bytes=(P/n).stat().st_size,sha256=sha(P/n)) for n in files]
save('PAYLOAD-SHA256.json',payload)
z=P/'PRODUCT03-F-nonliteral-proof-v1-review.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as a:
 for n in files+['PAYLOAD-SHA256.json']:a.write(P/n,n)
with zipfile.ZipFile(z) as a:assert all(hashlib.sha256(a.read(r['path'])).hexdigest()==r['sha256'] for r in payload)
delivery=[z,combined,P/'DIRECTOR-REVIEW.md',P/'01-F-BEFORE-AFTER.jpg',P/'02-F-MOTION-AND-CONTEXT.jpg',P/'03-F-LAP-DISCLOSURE.jpg']
save('REVIEW-DELIVERY-MANIFEST.json',[dict(path=str(f),bytes=f.stat().st_size,sha256=sha(f)) for f in delivery])
(P/'DELIVERY-SHA256.txt').write_text(''.join(f'{sha(f)}  {f.name}\n' for f in delivery))
print(json.dumps(dict(zip=z.name,sha256=sha(z),payloads=len(payload),media=mediaQA,protected=len(protected)),indent=2))
