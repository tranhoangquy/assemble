# F reconstruction — approximation and propagation ledger

All values below are unmeasured DISPLAY UNITS, not OEM dimensions. This is the human-authorized B proposal. Previous sources and meshes are immutable.

|Component|Before position|After position|Before bounds size|After bounds size|
|---|---|---|---|---|
|part-12-1|[0, 838, -60]|[0, 829, -60]|[1116, 134, 18]|[1116, 152, 18]|
|part-10-1|[-567, 838, 0]|[-567, 829, 13.5]|[18, 134, 554]|[18, 152, 545]|
|part-10-2|[567, 838, 0]|[567, 829, 13.5]|[18, 134, 554]|[18, 152, 545]|
|part-11-1|[-189, 838, 113]|[-189, 829, 113]|[18, 134, 328]|[18, 152, 328]|
|part-11-2|[189, 838, 113]|[189, 829, 113]|[18, 134, 328]|[18, 152, 328]|
|part-9-1|[0, 914, 9]|[0, 914, 18]|[1152, 18, 572]|[1152, 18, 554]|
|part-13-1|[0, 868.5, -286]|[0, 859.5, -268]|[1152, 231, 18]|[1152, 249, 18]|
|part-15-1|[0, 762, 113]|[0, 744, 104]|[1152, 18, 364]|[1152, 18, 346]|
|hardware-D-13|[-558, 914, -295]|[-558, 914, -277]|[9.0, 9.0, 46.8]|[9.0, 9.0, 46.8]|
|hardware-D-14|[0, 914, -295]|[0, 914, -277]|[9.0, 9.0, 46.8]|[9.0, 9.0, 46.8]|
|hardware-D-15|[558, 914, -295]|[558, 914, -277]|[9.0, 9.0, 46.8]|[9.0, 9.0, 46.8]|
|hardware-D-16|[-567, 800, -295]|[-567, 800, -277]|[9.0, 9.0, 46.8]|[9.0, 9.0, 46.8]|
|hardware-D-17|[-567, 876, -295]|[-567, 876, -277]|[9.0, 9.0, 46.8]|[9.0, 9.0, 46.8]|
|hardware-D-18|[567, 800, -295]|[567, 800, -277]|[9.0, 9.0, 46.8]|[9.0, 9.0, 46.8]|
|hardware-D-19|[567, 876, -295]|[567, 876, -277]|[9.0, 9.0, 46.8]|[9.0, 9.0, 46.8]|
|hardware-D-20|[-567, 753, -20]|[-567, 735, -20]|[9.0, 46.8, 9.0]|[9.0, 46.8, 9.0]|
|hardware-D-21|[-567, 753, 245]|[-567, 735, 245]|[9.0, 46.8, 9.0]|[9.0, 46.8, 9.0]|
|hardware-D-22|[-189, 753, -20]|[-189, 735, -20]|[9.0, 46.8, 9.0]|[9.0, 46.8, 9.0]|
|hardware-D-23|[-189, 753, 245]|[-189, 735, 245]|[9.0, 46.8, 9.0]|[9.0, 46.8, 9.0]|
|hardware-D-24|[189, 753, -20]|[189, 735, -20]|[9.0, 46.8, 9.0]|[9.0, 46.8, 9.0]|
|hardware-D-25|[189, 753, 245]|[189, 735, 245]|[9.0, 46.8, 9.0]|[9.0, 46.8, 9.0]|
|hardware-D-26|[567, 753, -20]|[567, 735, -20]|[9.0, 46.8, 9.0]|[9.0, 46.8, 9.0]|
|hardware-D-27|[567, 753, 245]|[567, 735, 245]|[9.0, 46.8, 9.0]|[9.0, 46.8, 9.0]|
|hardware-D-28|[-350, 753, -60]|[-350, 735, -60]|[9.0, 46.8, 9.0]|[9.0, 46.8, 9.0]|
|hardware-D-29|[350, 753, -60]|[350, 735, -60]|[9.0, 46.8, 9.0]|[9.0, 46.8, 9.0]|
|hardware-D-30|[-594, 800, -286]|[-594, 914, -230]|[46.8, 9.0, 9.0]|[46.8, 9.0, 9.0]|
|hardware-D-31|[-594, 876, -286]|[-594, 914, 0]|[46.8, 9.0, 9.0]|[46.8, 9.0, 9.0]|
|hardware-D-32|[-594, 954, -286]|[-594, 914, 230]|[46.8, 9.0, 9.0]|[46.8, 9.0, 9.0]|
|hardware-D-33|[-594, 762, 282]|[-594, 800, 282]|[46.8, 9.0, 9.0]|[46.8, 9.0, 9.0]|
|hardware-D-34|[-594, 914, 282]|[-594, 876, 282]|[46.8, 9.0, 9.0]|[46.8, 9.0, 9.0]|
|hardware-D-35|[594, 800, -286]|[594, 914, -230]|[46.8, 9.0, 9.0]|[46.8, 9.0, 9.0]|
|hardware-D-36|[594, 876, -286]|[594, 914, 0]|[46.8, 9.0, 9.0]|[46.8, 9.0, 9.0]|
|hardware-D-37|[594, 954, -286]|[594, 914, 230]|[46.8, 9.0, 9.0]|[46.8, 9.0, 9.0]|
|hardware-D-38|[594, 762, 282]|[594, 800, 282]|[46.8, 9.0, 9.0]|[46.8, 9.0, 9.0]|
|hardware-D-39|[594, 914, 282]|[594, 876, 282]|[46.8, 9.0, 9.0]|[46.8, 9.0, 9.0]|
|hardware-F-1|[-450, 735, -286]|[-450, 744, -295]|[7.2, 26.8, 7.2]|[7.2, 7.2, 26.8]|
|hardware-F-2|[-150, 735, -286]|[-150, 744, -295]|[7.2, 26.8, 7.2]|[7.2, 7.2, 26.8]|
|hardware-F-3|[150, 735, -286]|[150, 744, -295]|[7.2, 26.8, 7.2]|[7.2, 7.2, 26.8]|
|hardware-F-4|[450, 735, -286]|[450, 744, -295]|[7.2, 26.8, 7.2]|[7.2, 7.2, 26.8]|
|hardware-F-5|[-450, 735, 286]|[-450, 744, 295]|[7.2, 26.8, 7.2]|[7.2, 7.2, 26.8]|
|hardware-F-6|[-150, 735, 286]|[-150, 744, 295]|[7.2, 26.8, 7.2]|[7.2, 7.2, 26.8]|
|hardware-F-7|[150, 735, 286]|[150, 744, 295]|[7.2, 26.8, 7.2]|[7.2, 7.2, 26.8]|
|hardware-F-8|[450, 735, 286]|[450, 744, 295]|[7.2, 26.8, 7.2]|[7.2, 7.2, 26.8]|

## Basis and limitations

- F8 quantity and rear4/front3 step association: local manual PDFp1,p8 S10,p9 S12. Source F nominal Ø4×25L; no source-confirmed global axis or receiver. Alignment-before-tightening retained.
- HumanB permits declared nonliteral visible reconstruction. It does not add documentary evidence. Rear F now outward−Z and front F outward+Z, head planesZ±295,Y744. Metal3/4 and obstacle submeshes are unchanged.
-13 extends downward toY735 and moves inward: backZ−277 touches rear4 insideZ−277.15 lowers toY735–753 and its front endsZ277 against front3 insideZ277. Eight full25-unit F shafts span18 metal +7 wood. No hidden hole, thread, receiver or connecting bar is created.
-9/10/11/12 and13/15 are resized/repositioned only to propagate the revised visible mating planes without positive wood overlap. Their actual sizes remain unknown. All grain/materials are reused.
- Seven13 D heads move toZ−277, ten15 D heads toY735. S8 D10 now use three depth-rail positions into9 and two front-post positions into10 per side. This mapping is explicitly nonliteral; it is not an OEM receiving-hole claim.
- ToolM cross blades are narrowed to1×4×1 with existing rotations so they fit the existing modeled cross recess. No screw slot is added. Modeled recess margins .148/.232 and backing clearance .45 are display-model diagnostics, not manufacturer driver dimensions.
- Existing front/rear frame/lattice stock,6 and14 are unchanged. OEM inventory, source-step count and dependency order remain unchanged. Other accepted source files are not rewritten.
- All77 exterior ray checks preserve existing provisional seating. Thirteen face contacts and36 wood-pair candidates are checked; this is a targeted regression, not whole-product physical certification.
- Raw Fshaft/solid metal/solid wood penetrations remain in RAW-ACCESS-AND-CONTACT-CLASSIFICATION.json. They are symbolic unresolved receiver interactions, never a physical collision PASS.
- C13/C14 exact end allocation, S18 I/J source conflict, hidden receiving details, actual dimensions, torque, tool/hand access and support safety remain unresolved. No production-gate upgrade is implied.
