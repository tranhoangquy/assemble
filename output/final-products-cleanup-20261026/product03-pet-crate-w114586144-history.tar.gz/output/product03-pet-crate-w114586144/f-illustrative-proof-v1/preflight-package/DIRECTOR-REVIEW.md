# PRODUCT03 — HUMAN B / F NONLITERAL PROOF V1

Review ID: PRODUCT03-F-ILLUSTRATIVE-PROOF-V1-20261022

The human explicitly selected B in Codex: a declared nonliteral illustrative F reconstruction, local proof + actual Assemble review only. This is NOT new OEM evidence. Please review the two actual12s motion proofs and revised visible lap/contact proposal. No full158s render, final Long/Short or audio is authorized.

## Proposed visible result

RearS10: F4 from exterior rear4 into reconstructed13. FrontS12: F4 from exterior front3 into reconstructed15. Existing frame3/4 stock and obstacles stay intact. All8 heads seat on exterior planes (gap0); metal/wood visible mating faces touch (gap0). Full25-unit shaft remains:18 modeled metal then7 modeled wood,11 to the far face. Axes/backing reconstruction is NONLITERAL, prominently labeled throughout both clips.

The clips continuously show identification, driver approach, engagement, insertion, symbolic rotation, driver withdrawal and retained contact. One F exemplar per group; the other3 are already seated as an explicitly isolated repetition proof. Parts remain installed within each clip. The rig is inverted at the source assembly stage. These are two separate focused proofs, not a full assembly continuity film.

## Declared propagation

Eight wood instances9/10/11/12/13/15 resize/reposition to preserve the revised contacts. Seven13 D placements, ten15 D placements and tenS8 D placements propagate. The JSON includes before/after bounds, positions and normals for all43 changed registry entries. The Markdown ledger explains every class of change. ToolM existing cross blades are narrowed to fit the existing modeled recess; no hidden receiver or new screw slot is created. Walnut, metal, source inventory/dependencies and unaffected metal/6/14 are retained.

## Local QA

-20 components,100 hardware/accessory units+3 tools; all19 source-step counts reconcile under the still-open provisionalS18 I/J mapping.
-77 exterior fastener seating checks; no missing host hit.13 retained face-contact checks gap0;36 wood-pair AABBs with0 positive-volume overlaps. All8 F backing rays and10 propagatedS8 backing rays hit their declared targets.
-289 samples per proof: tool, full shaft and head versus every visible installed mesh. No unrelated positive AABB candidate. All raw Fshaft/stock overlaps are retained and explicitly classified UNMODELED RECEIVER, not a physical PASS. Existing modeled driver cross-slot clearances are reported separately.
-1441 transform samples per proof; arbitrary/backward seek repeatable, finite transforms, installed visibility retained. Fixed camera per clip; continuous quintic approach/withdrawal.3 focused tests and scoped TypeScript pass.
-576 contiguous720p PNGs decoded;2×12s24fps proofs plus24s compilation, all full-decoded and silent. Offline renderer aborted all network requests;0 attempted HTTP requests.
-938 protected paths match; prior review deliveries, accepted source fingerprints and frozen158s video/source match. Product01 and JULIETTE preserved.

## Unresolved / requested decision

Approve, revise or reject this F VISUAL ILLUSTRATION only. Global F axis, actual receiver/retention and actual dimensions remain unconfirmed. Raw shaft/stock solid overlaps remain unresolved physical limitations. No human hand/tool certification, torque, fit, load or safety claim. C13/C14 andI/J remain open. Human final acceptance is not granted.

Please inspect actual MP4s and full original-byte ZIP. Give an explicit scoped decision on visible seating/backing, tool engagement/access representation, cascading contacts and continuous motion. Do not authorize a full blocking/final render: that exceeds this humanB boundary. If accepted, close this local proof milestone and identify remaining issues without starting new production. No acknowledgement will be sent after your final stop decision.
