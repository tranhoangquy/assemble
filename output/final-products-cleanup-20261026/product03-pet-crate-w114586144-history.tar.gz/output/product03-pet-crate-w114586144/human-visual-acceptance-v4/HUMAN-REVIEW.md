# READY FOR HUMAN FINAL REVIEW — NOT YET ACCEPTED

[Long V5 — 278 seconds, 720p](PRODUCT03-Long-V5-278s-SILENT-720p.mp4)

[Short V3 — 59 seconds, native1080×1920](PRODUCT03-Short-V3-59s-SILENT-1080x1920.mp4)

Both are silent. Creative Director received both actual MP4s and evidence through the existing Assemble conversation and explicitly gave INTERNAL VISUAL PASS / AUTHORIZE FINAL HUMAN REVIEW PACKAGE. No further internal revision was requested. The human alone accepts these films.

Four hinges now each show two OEM E frame screws plus two separately tracked human-approved illustrative door screws,16shown total. The eight additional screws do not change the OEM103 hardware/tools or E8 inventory. OEM attachment remains UNVERIFIED and door FUNCTION HOLD. No opening/closing or physical retention certification is implied.

Long changes the hinge sequence and only the approved later static holds, keeping278s. The accepted247–249source camera bridge stays at1×. Short shows one complete representative four-screw hinge, explicitly omits three repeats, retains door7 during door8 and retains OPEN/POSE_ONLY/HOLD disclosures, keeping59s. Finished-hook screws/labels are updated.

Technical QA:8340Long +1770Short frames; native profiles,30fps,noaudio,full decode,all PTS,faststart,inputfreezes and seek/reset PASS.6252earlyLong and1278earlyShort native frames match prior films exactly; all102C16native frames unchanged.51066protected prior paths unchanged. Product01/JULIETTE, prior films and historical evidence preserved.

Agent inspected52decoded final-MP4 samples plus native preflight. Director directly inspected17Long and12Short extracted frames, contact sheets/QA/hash, and disclosed sampled review rather than continuous playback. Director credited full decode/PTS/regression to Codex QA rather than claiming independent reruns.

K22/10 UNMEASURED; F NONLITERAL; C13/C14 andI/J OPEN; S17/S18 POSE_ONLY; S19pads/door HOLD; historical raw collision FAIL remain. See LIMITATIONS.md, FULL-FILM-QA.json and actual director-approval/ response. No audio, publication, or human final acceptance is claimed.
