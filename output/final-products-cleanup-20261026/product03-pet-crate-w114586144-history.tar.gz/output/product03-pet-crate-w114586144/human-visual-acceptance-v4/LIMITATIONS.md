# Product03 limitations retained

The film is an unmeasured illustrative assembly study.

- DOOR-SIDE FASTENERS: HUMAN-APPROVED ILLUSTRATION — eight separate actors, not OEM E.
- OEM ATTACHMENT DETAILS: UNVERIFIED.
- DOOR FUNCTION: HOLD; no opening/closing or retention claim.
- OEM hardware/tools103, including E8; additional human illustrative screws8.
- K22/10 UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN.
- S17/S18 POSE_ONLY; S19 N pads HELD/NOT INSTALLED and door HOLD.
- Historical raw collision FAIL and physical fit/access/retention limitations remain.
- No certified bores, threads, torque, load capacity, wall compatibility or tool/hand access.
- No audio or publication. Human alone accepts both films.
