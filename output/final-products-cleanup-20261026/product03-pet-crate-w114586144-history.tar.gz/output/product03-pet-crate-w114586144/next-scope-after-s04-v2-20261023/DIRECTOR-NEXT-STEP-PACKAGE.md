GÓI TRIỂN KHAI

Milestone: PRODUCT03-P0-TEACHING-CONTINUITY-AUDIT-V1
Priority: P0
Status: AUTHORIZED — READ-ONLY ANALYSIS / PLANNING ONLY

1. Mục tiêu

Đánh giá tính liên tục và khả năng truyền đạt thao tác lắp ráp của S05–S16 trên baseline V2 278 giây.

Xác định chính xác những đoạn cần proof chuyển động trước khi có thể đề xuất dựng phim đầy đủ.

Không mở lại các milestone đã PASS.

2. Baseline và nguồn bắt buộc

Đọc từ local project:

Frozen Phase D V1 để hiểu các lỗi giật và thao tác thiếu thực tế từng bị human từ chối; không dùng làm baseline hình học hiện hành.

Accepted Phase B/C geometry và các focused correction đã PASS.

Accepted F nonliteral proof.

Frozen COMPACT264 V1.

Accepted S04 two-bolt 28s proof.

Accepted S04 Integration V2 278s — baseline chính.

OEM manual 13 trang, đặc biệt những trang tương ứng S05–S16.

AssemblyGraph, operation map, evaluator V2, camera-cut register, collision classifications, assumption ledger và QA hiện có.

Không yêu cầu upload lại những bằng chứng đã bàn giao.

3. Timestamps V2 cần kiểm tra
Bước	Khoảng thời gian
S05	69–85s
S06	85–104s
S07	104–112s
S08	112–132s
S09	132–144s
S10	144–154s
S11	154–164s
S12	164–173s
S13	173–189s
S14	189–203s
S15	203–209s
S16	209–228s

Các mốc chỉ dùng để đọc và phân tích V2, không được tự sửa ngân sách thời lượng.

4. Nhiệm vụ
A. Connection teaching audit

Với từng bước S05–S16, xác định:

Chi tiết nào xuất hiện hoặc được đưa vào vị trí.

Mặt nào tiếp xúc trước.

Vít/phụ kiện nào được lắp, số lượng bao nhiêu.

Dụng cụ nào xuất hiện và thực hiện hành động gì.

Trạng thái hoàn thành được giữ như thế nào.

Người xem có đủ bằng chứng thị giác để hiểu quan hệ lắp ráp hay không.

Không đồng nhất số lượng đúng với khả năng hướng dẫn đạt.

B. Continuity audit

Phân tích:

Ranh giới giữa các bước.

Vị trí, hướng và trạng thái chi tiết trước/sau cắt dựng.

Các thao tác xoay hoặc định hướng lại cụm.

Đường tiếp cận của chi tiết, vít và dụng cụ.

Hiện tượng xuất hiện/biến mất bất hợp lý.

Khả năng nhầm lẫn giữa initial seating và final tightening.

C. Rủi ro thị giác và cơ khí

Phân loại riêng:

P0 — Blocking: sai quan hệ lắp ráp, reset trạng thái, xuyên vật thể đã xác minh, thao tác không thể hiểu hoặc mâu thuẫn bằng chứng nguồn.

P1 — Important: thao tác quá nhanh, che điểm tiếp xúc, chuyển camera gây khó hiểu, dụng cụ khó nhìn.

P2 — Polish: framing, khoảng nghỉ, bố cục và nhịp thẩm mỹ.

Phân biệt rõ lỗi đã xác minh, nghi vấn cần motion proof và giới hạn vật lý chưa thể kiểm chứng.

D. Proof selection

Đề xuất tối đa ba đoạn proof chuyển động ngắn có giá trị phát hiện lỗi cao nhất.

Mỗi đoạn phải có:

Bước và timestamp.

Lý do cần kiểm tra.

Các đối tượng phải xuất hiện.

Góc nhìn và điểm tiếp xúc cần quan sát.

Điều kiện PASS/FAIL.

Ước lượng thời lượng và chi phí render offline.

Chỉ lập kế hoạch. Chưa render.

5. Deliverables

TEACHING-CONTINUITY-MATRIX.md — ma trận S05–S16.

P0-P2-FINDINGS.md — phát hiện có bằng chứng, mức độ và tác động.

BOUNDARY-AND-CUT-REGISTER.md — danh sách ranh giới/cắt dựng cần lưu ý.

TARGETED-PROOF-PLAN.md — tối đa ba proof đề xuất.

ASSUMPTION-AND-HOLD-REGISTER.md — giữ nguyên các giới hạn nguồn.

DIRECTOR-REVIEW.md — kết luận và quyết định cần xin ở vòng sau.

Đóng gói kèm manifest SHA256 nếu tạo evidence ZIP.

6. Acceptance Criteria

Bao phủ đủ 12 bước S05–S16.

Mỗi phát hiện có step, timestamp, đối tượng và bằng chứng local tương ứng.

Không suy diễn lỗi chuyển động chỉ từ endpoint tĩnh.

Không coi báo cáo QA phần mềm là chứng nhận chất lượng hình ảnh.

Phân biệt P0/P1/P2 nhất quán.

Đề xuất proof cụ thể, không phải yêu cầu render lại toàn bộ.

Không sửa file source hoặc tài sản đã đóng băng.

Không làm thay đổi trạng thái PASS của S04 V2.

7. Business Rules và giới hạn

K22/10 vẫn UNMEASURED.

F vẫn nonliteral.

C13/C14 và I/J vẫn OPEN.

S17/S18 pose-only; S19 pads/door HOLD.

Không xác nhận receiver, retention, torque hoặc hand/tool access.

Không nghiên cứu Internet hoặc sử dụng dịch vụ ngoài Assemble.

Không thay đổi Product #01 hoặc JULIETTE.

8. Edge Cases bắt buộc

Seek ở ngay trước và sau một boundary.

Chi tiết đã lắp nhưng tạm thời nằm ngoài khung hình.

Prepared feet đi theo cụm host khi đổi tư thế.

Vít F minh họa xuất hiện trong điều kiện receiver chưa xác minh.

Chuyển camera che mất điểm tiếp xúc.

Bản lề/cửa được mô phỏng chuyển động nhưng không có chứng nhận cơ khí.

Đoạn vít lặp rút gọn nhưng không làm mất số lượng hoặc trạng thái.

9. Câu hỏi còn mở

Đoạn nào thực sự cần motion proof mới?

Những thiếu sót nào có thể giải quyết bằng framing/timing mà không sửa hình học?

Có phát hiện P0 mới nào buộc phải giữ HOLD trước khi dựng phim?

10. Stop gate

Sau khi hoàn thành read-only audit và proof plan:

Nộp gói review thực tế cho Creative Director và STOP.

Không tự triển khai các proof đã đề xuất.

Không sửa animation, geometry, camera, evaluator hoặc timeline.

Không render phim 278 giây, Long/Short, audio hay mastering.

Nếu cần triển khai tiếp, phải có phạm vi mới do human cho phép.