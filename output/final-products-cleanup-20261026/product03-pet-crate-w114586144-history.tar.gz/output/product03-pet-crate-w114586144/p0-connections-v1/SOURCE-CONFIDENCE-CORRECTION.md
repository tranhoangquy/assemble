# Source-confidence correction — F axes

The earlier rail audit stated that the historical F +Y axis contradicted the OEM inverted exposed access. That wording over-read the separately oriented inset. It is withdrawn as an OEM-confirmed world-axis conclusion.

Confirmed: the source assigns F4 at the rear association inS10 and F4 at the front association inS12, with explicit firm tightening after alignment. The old model also has a real5-display-unit rear head gap.

Not confirmed: a global product-space +Y,−Y orZ normal solely from the inset orientation. The current−Y candidate supplies a correct modeled head face, but its straight approach hits existing lower frame/lattice submeshes. This proves a limitation of the candidate model/path, not that the actual OEM product is impossible to assemble.

Do not resolve this by clipping shafts, excluding the lower bar, inventing a bore or silently removing frame geometry. The source geometry/axis interpretation needs a focused Director decision. A source-supported lap connection on a front/rear face is a competing interpretation requiring review, not implemented as fact.

S05/S06 role descriptions and D backing allocations are also proposals based on multiple local views, not new manufacturer specifications. Historical files remain unchanged; this correction is additive.
