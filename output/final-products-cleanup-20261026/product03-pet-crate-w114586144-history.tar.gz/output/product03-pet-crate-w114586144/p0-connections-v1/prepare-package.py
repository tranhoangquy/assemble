from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,zipfile,math,shutil
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'output/product03-pet-crate-w114586144';P=Path(__file__).resolve().parent
def load(p):return json.loads(Path(p).read_text())
def save(n,v):(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for x in iter(lambda:f.read(4*1024*1024),b''):h.update(x)
 return h.hexdigest()
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17)
def sheet(name,items,tile=(800,450),cols=2):
 w,h=tile;im=Image.new('RGB',(w*cols,(h+34)*math.ceil(len(items)/cols)),'#eeeae2');d=ImageDraw.Draw(im)
 for i,(path,text)in enumerate(items):
  x=i%cols*w;y=i//cols*(h+34);a=Image.open(path).convert('RGB');a.thumbnail((w,h));im.paste(a,(x+(w-a.width)//2,y+(h-a.height)//2));d.text((x+10,y+h+7),text,font=font,fill='#302b26')
 im.save(P/name,quality=93)
stills=P/'review-stills'
sheet('01-WOOD-BEFORE-AFTER.jpg',[(stills/f'{g}-{state}.png',f'{g} / {state.upper()} — unmeasured exterior proposal')for g in ['S02','S05','S06']for state in ['before','after']],(640,360))
sheet('02-FRAME-FLOOR-BEFORE-AFTER.jpg',[(stills/f'{g}-{state}.png',f'{g} / {state.upper()}')for g in ['S08','S15']for state in ['before','after']])
sheet('03-F-ACCESS-STOP.jpg',[(stills/f'{g}-{state}.png',f'{g} / {state.upper()} — full approach NOT demonstrated')for g in ['S10','S12']for state in ['before','after']])
sheet('04-MOTION-SAMPLES.jpg',[(P/f'frames/{g}-frame-{i:06d}.png',f'{g} / {i/24:.1f}s — fixed camera within each clip')for g in ['S02','S05','S06','S08','S15']for i in [48,168]],(640,360))
# Documentary pages for source-role and axis review. Original PDF is also included.
pages=BASE/'phase-a-v1/evidence/pages'
sheet('05-OEM-SOURCE-VIEWS.jpg',[(pages/f'page-{i:02d}.png',f'LOCAL OEM PDF p{i}')for i in [4,5,6,7,8,9]],(500,707))
source=BASE/'phase-a-v1/source/human-provided-pet-crate-manual.pdf';shutil.copyfile(source,P/'human-provided-pet-crate-manual.pdf')

# Check all protected/historical evidence, including the newly accepted rail proof.
protected=load(BASE/'phase-a-v1/evidence/protected-baseline.json');mismatches=[]
for rel,h in protected.items():
 if not(ROOT/rel).exists()or sha(ROOT/rel)!=h:mismatches.append(rel)
review_checks=[]
for mf in BASE.glob('*/REVIEW-DELIVERY-MANIFEST.json'):
 if mf.parent==P:continue
 for row in load(mf):
  p=Path(row['path']);p=p if p.is_absolute()else mf.parent/p
  review_checks.append({'revision':mf.parent.name,'file':p.name,'match':p.exists()and sha(p)==row['sha256']})
rail_source=load(BASE/'rail-fit-correction-v1/SOURCE-FINGERPRINTS.json')['files']
rail_source_matches=all(sha(ROOT/f)==h for f,h in rail_source.items())
assert not mismatches and all(x['match']for x in review_checks) and rail_source_matches
save('PROTECTED-ASSET-VERIFICATION.json',{'status':'PASS','protectedPaths':len(protected),'changes':0,'historicalReviewChecks':review_checks,'acceptedRailSourceUnchanged':rail_source_matches,'sourcePdfSha256':sha(source)})

v=load(P/'VALIDATION.json');matrix=load(P/'ALL-19-STEP-REGRESSION.json')
assert v['exterior']['proposalFailures']==0 and v['meshContacts']['maxAbsoluteDifference']==0
assert v['woodPairs']['proposalOverlaps']==0 and v['backingAxes']['misses']==0
assert all(x['hardware']==x['actualCounts']for x in matrix)
assert (P/'evidence/typecheck-final.log').read_text()==''
assert '3 passed' in(P/'evidence/tests.log').read_text()

assumptions={
 'authority':'Actual Assemble rail review PASS exterior only; next focused P0 corrections requested. Human P0 override remains controlling.',
 'units':'All product coordinates are display units, not OEM mm or measured sizes.',
 'sourceConfirmed':['19-step order','20 numbered instances','A–O source inventory','D39/C18/E8/F8/B4 etc counts','12 connects10 and11 in S1/S2','13 added withD7 inS5','15 added withD10 inS6','F4 perS10/S12 and alignment-before-firm-tightening rule','14 rests on supports without new hardware'],
 'visualProposals':{
  '12':'Transverse connector moved from rear edgeZ−270 to interiorZ−60, consistent with its mid-depth association inS1/S2 views. Exact depth position remains inferred.',
  '10':'Two sides18×134×554;centresX±567,Y838,Z0. Height134 follows the accepted visible band/floor contact study, not an OEM measurement.',
  '11':'Two dividers18×134×328;centresX±189,Y838,Z113. Rear endsZ−51 meet12 inner face instead of crossing it.',
  '9':'1152×18×572 atY914,Z9; rear edge−277 meets13, underside905 meets10/11.',
  '13':'1152×231×18 atY868.5,Z−286. Rear closure/upstand interpretation joins9/10 rather than floating above them. Precise proportions and7-D backing assignment (3 to9,2 to each10) are inferred.',
  '15':'1152×18×364 atY762,Z113. Front-section floor/closure interpretation, with10-D proposed backing:2 per10/11 plus2 into12. Extent/role and allocation need visual Director review; not an OEM claim.',
  'S08':'Five proposed D locations per side on existing pipe faces;three toward13 andtwo toward15/9. All10 actual axes reach proposed wood. Exact receiver coordinates unverified; no holes added.',
  '14':'CentreY88→80 so underside71 rests on6 top71. No new fastener.',
  'F':'Static exterior candidate uses lower faceY735, outward−Y. Near head seating0, but full straight approach is blocked in THIS provisional geometry. World-axis interpretation is not OEM-confirmed.',
 },
 'unresolved':['C13/C14 end allocation','I/J identity conflict','exact source world-axis forF in independently oriented insets','F path and tool/hand access','manufacturer dimensions','hidden bores/threads/receivers','support/human handling','certified hinge/pet/load fit'],
 'prohibitedRepresentation':'No full production or hidden receiving geometry; no statement that software contacts certify installation.'}
save('ASSUMPTION-REGISTER.json',assumptions)

(P/'SOURCE-CONFIDENCE-CORRECTION.md').write_text('''# Source-confidence correction — F axes

The earlier rail audit stated that the historical F +Y axis contradicted the OEM inverted exposed access. That wording over-read the separately oriented inset. It is withdrawn as an OEM-confirmed world-axis conclusion.

Confirmed: the source assigns F4 at the rear association inS10 and F4 at the front association inS12, with explicit firm tightening after alignment. The old model also has a real5-display-unit rear head gap.

Not confirmed: a global product-space +Y,−Y orZ normal solely from the inset orientation. The current−Y candidate supplies a correct modeled head face, but its straight approach hits existing lower frame/lattice submeshes. This proves a limitation of the candidate model/path, not that the actual OEM product is impossible to assemble.

Do not resolve this by clipping shafts, excluding the lower bar, inventing a bore or silently removing frame geometry. The source geometry/axis interpretation needs a focused Director decision. A source-supported lap connection on a front/rear face is a competing interpretation requiring review, not implemented as fact.

S05/S06 role descriptions and D backing allocations are also proposals based on multiple local views, not new manufacturer specifications. Historical files remain unchanged; this correction is additive.
''')

lines=['# Product03 — all19-step geometry/fastener regression','',
 'Source type/count/order is documentary. Exact world coordinates, dimensions, face normals and backing allocations are visual proposals. No concealed bore or engaged thread is represented.','',
 '|Step / PDF|Source inventory|Current exterior result and remaining limits|','|---|---|---|']
statuses={1:'D4 source association retained; contact to proposed interior12. Exact receiver unknown.',2:'11/12 overlap18→0; actual end planesZ−51 coincide; continuous exemplar proof.',3:'9 underside905 meets10/11 top905; coordinates unmeasured.',4:'B4 seats on K annuli; bracket thickness is not misclassified as a gap. Receiver/tool access unknown.',5:'13 contacts9/10 rear edgesZ−277;7-D proposed backing3+2+2. Role/proportions/assignment require review.',6:'15 top771 contacts10/11/12 bottoms771;10-D backing proposed8+2; no OEM coordinate claim.',7:'A5 preserved; prepared5 remains staged untilS14. Hidden threads/support unknown.',8:'All10 D axes now hit existing side stock and proposed wood backing; six old misses removed. Precise mapping inferred.',9:'Accepted4 bands and exterior between-side fit retained. C4 exact coordinates still illustrative.',10:'F4 near-face seating0; full straight approach blocked in candidate geometry. STOP F motion; world-axis not confirmed.',11:'Accepted3 ladder geometry retained; two proposed end heights712/744. Exact C coordinates inferred.',12:'F4 near-face seating0; full straight approach blocked. STOP; see source-confidence correction.',13:'Accepted6/4 exterior contact retained. C4 allocation still UNVERIFIED.',14:'C6 count retained; end allocation still UNVERIFIED. Prepared5 retained at final contact.',15:'14 underside71 contacts all four6 top71; old10-unit support gap removed. No screw added.',16:'E8 seats on existing hinge leaf annuli; no new hinge pin or receiver. Physical access unknown.',17:'G2/H2/J2 external proposal retained; no stud receiving method invented.',18:'G2/H2/I2 provisional; source summaryJ vs insetI conflict remains OPEN.',19:'N4 accessory association retained; no additional screws, no new door motion limits.'}
for row in matrix:lines.append(f"|{row['step']} / p{row['pdf']}|"+'; '.join(f'{k}×{n}'for k,n in row['hardware'].items())+f"|{statuses[int(row['step'][1:])]}|")
lines+=['', 'Actual triangle-ray audit77/77 near exterior seats meet the software review criterion|gap|≤0.4 display unit. The13 intended mesh-bound contact differences are0. All36 wood pairs have no positive-volume AABB intersections; old model had2. These are geometric visual results, not manufacturing tolerances or installation certification.',
 '', 'The18 proposed D8/F backing rays reach actual wood geometry within the visual shaft envelope. This is not evidence of a receiving hole/thread. Source allocations remain inferred.',
 '', 'All8 F routes are retained as BLOCKED in the long-axis test. Same-OEM lower frame submeshes are included. A near seating PASS does not override a path FAIL. No F installation sequence has been produced.',
 '', 'Five clips8s each show S02/S05/S06/S08/S15, each with a fixed camera and retained components. The40s compilation has clearly labeled group cuts; it is not a continuous full assembly narrative. No158s blocking rerender or Long/Short/audio was generated.']
(P/'ALL-19-STEP-AUDIT.md').write_text('\n'.join(lines)+'\n')

(P/'DIRECTOR-REVIEW.md').write_text(f'''# PRODUCT03 — P0 CONNECTION CORRECTION V1

Review ID: PRODUCT03-P0-CONNECTIONS-V1-20261021

Outcome: PARTIAL CORRECTION PROPOSALS; F ACCESS HOLD. Whole PhaseD remains P0 FAIL. This package follows the actual Director PASS for the isolated rail6/frame4 correction and the requested next connection groups. Human final acceptance remains pending.

## Actual deliverables

Five silent native720p/24fps8-second continuous proofs: S02, S05, S06, S08 and S15. Each has192 decoded frames and one fixed camera; each starts with the active part visible in staging, approaches continuously, holds contact and retains previous components. Full symbolic shafts remain; no clipping. The40-second review compilation joins these five clearly labeled groups by stream copy. It is not another full assembly film.

Three before/after sheets, source views and actual13-page manual;19-step audit; all77 screw near-face checks; actual13 mesh-contact measurements;36 wood-pair checks;18 proposed backing-axis checks; deterministic-seek/retention QA; F obstruction register and protected hashes. Before stills reconstruct frozen old geometry with clipping disabled; initial material-fault preflight stills are excluded.

## Corrections proposed

- S02: move12 to an interior depth position inferred fromS1/S2 views and trim11 to its contact face. Remove the18-unit overlap. Position and dimensions remain unmeasured proposals.
- S05/S06: reconstruct13 as a rear closure/upstand contacting9/10, and15 as the front-section lower closure/floor contacting10/11/12. Seven-D andten-D backing ownership is explicit inference (not OEM-confirmed). Full dimensions are recorded in the assumption register.
- S08: use existing square-pipe faces and10 proposed backing axes; six old misses removed. No new bores, receivers or structural parts.
- S15: lower14 by8 display units to actual6 support height; preserve no-fastener source semantics.
- Preserve accepted3/4/6 factory-band/contact correction, hardware inventory,19-step dependency order, hinge exterior baseline and historical raw limitations.

Actual computed results:77 near exterior checks with0 misses/offset failures,13 mesh contact differences0,36 wood pairs with0 positive-volume overlaps (old2),18 proposed backing-axis hits. Tests3/3 PASS; deterministic backward/forward seeks, finite transforms and retained visibility PASS. These do not certify hidden receiving geometry or human access.

## Explicit F stop and source-confidence correction

The−Y F candidate seats at the visible lower face, but all8 full straight approaches hit existing lower band/lattice submeshes. Hits occur41 display units before rear seats and32 before front seats in the60-unit test. No F insertion/tool animation is rendered.

Important correction: the earlier audit treated inset orientation as proof of a world-space F axis. That confidence was too strong and is withdrawn; the actual source association/count is confirmed, the global normal is not. A blocked provisional path does not prove an OEM design defect. See SOURCE-CONFIDENCE-CORRECTION.md and the original PDF p8/p9. No pair exclusion, shaft clipping or silent stock removal is used to clear this.

## Requested decision

Review the actual videos, before/after and source PDF. Accept or revise the controlled exterior13/15/12 reconstruction and other correction groups. Separately determine whether the local views support a front/rear-face lap interpretation for F, or leave this sequence explicitly unresolved; do not infer a global axis from an independently rotated inset. Authorize only a narrow source/geometry correction supported by those views. No complete blocking render may resume while F access/axis or source-contradicting visible geometry remains unresolved.

Protected938 paths, all{len(review_checks)} historical delivery payloads and accepted rail source fingerprints match. No general Internet, new source acquisition, paid services, Product01/JULIETTE edits, audio or final films. Source PDF SHA256{sha(source)}.
''')

save('PROOF-QA.json',{'review':'PRODUCT03-P0-CONNECTIONS-V1-20261021','status':'PARTIAL / F ACCESS HOLD',
 'inventory':v['inventory'],'19stepInventoryReconciliation':True,'exterior':v['exterior'],'meshContacts':v['meshContacts'],'woodPairs':v['woodPairs'],'backingAxes':v['backingAxes'],
 'Faccess':v['F_access'],'software':{k:v['software'][k]for k in['deterministic','retained','finite','samplesPerClip','clips']},
 'focusedTests':'3/3 PASS; actual Vitest log','typecheck':'PASS; scoped source/scripts, historical output snapshots excluded',
 'videoQA':'Five verified8s,192-frame720p24fps silent clips; full decode PASS; compilation40s960 frames stream-copied',
 'preflight':'Initial material-array bug and validation syntax/type errors preserved in local logs/stills; corrected before review. Accepted inputs:review-stills andframes.',
 'worldAxisConfidence':'F normal NOT OEM-confirmed; earlier stronger assertion withdrawn additively',
 'physicalFit':'NOT_CERTIFIED; no blind bores, threads, receivers, access or support certification','wholeProduct':'P0 FAIL remains; full production not authorized'})

files=['DIRECTOR-REVIEW.md','ALL-19-STEP-AUDIT.md','SOURCE-CONFIDENCE-CORRECTION.md','ASSUMPTION-REGISTER.json','PROOF-QA.json','VALIDATION.json',
 'ALL-77-FASTENERS-BEFORE-AFTER.json','ALL-19-STEP-REGRESSION.json','GEOMETRY-CONTACTS.json','ACTUAL-MESH-CONTACT-MEASUREMENTS.json','ALL-WOOD-PAIR-OVERLAPS.json',
 'PROPOSED-BACKING-AXES.json','F-ACCESS-STOP.json','VIDEO-FRAME-QA.json','COMBINED-PROOF-QA.json','PROTECTED-ASSET-VERIFICATION.json','human-provided-pet-crate-manual.pdf',
 '01-WOOD-BEFORE-AFTER.jpg','02-FRAME-FLOOR-BEFORE-AFTER.jpg','03-F-ACCESS-STOP.jpg','04-MOTION-SAMPLES.jpg','05-OEM-SOURCE-VIEWS.jpg','frames/offline-network.json',
 'PRODUCT03-P0-focused-proofs-v1-720p.mp4']+[f'PRODUCT03-{g}-connection-proof-v1.mp4'for g in['S02','S05','S06','S08','S15']]
manifest=[{'path':n,'bytes':(P/n).stat().st_size,'sha256':sha(P/n)}for n in files]
save('PAYLOAD-SHA256.json',manifest)
z=P/'PRODUCT03-P0-connections-v1-review.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED)as a:
 for n in files+['PAYLOAD-SHA256.json']:a.write(P/n,n)
with zipfile.ZipFile(z)as a:
 assert all(hashlib.sha256(a.read(row['path'])).hexdigest()==row['sha256']for row in manifest)
delivery=[z,P/'PRODUCT03-P0-focused-proofs-v1-720p.mp4',P/'DIRECTOR-REVIEW.md',P/'01-WOOD-BEFORE-AFTER.jpg',P/'02-FRAME-FLOOR-BEFORE-AFTER.jpg',P/'03-F-ACCESS-STOP.jpg']
save('REVIEW-DELIVERY-MANIFEST.json',[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}for p in delivery])
(P/'DELIVERY-SHA256.txt').write_text(''.join(f'{sha(p)}  {p.name}\n'for p in delivery))
save('SOURCE-FINGERPRINTS.json',{'files':{str(f.relative_to(ROOT)):sha(f)for f in(ROOT/'src/products/product03-pet-crate-w114586144/p0-connections-v1').glob('*.ts')},'acceptedRailSourceUnchanged':True})
print(json.dumps({'zip':z.name,'zipSha256':sha(z),'payloads':len(manifest),'videoSha256':sha(P/'PRODUCT03-P0-focused-proofs-v1-720p.mp4'),'protected':938,'historicalReviewPayloads':len(review_checks)},indent=2))
