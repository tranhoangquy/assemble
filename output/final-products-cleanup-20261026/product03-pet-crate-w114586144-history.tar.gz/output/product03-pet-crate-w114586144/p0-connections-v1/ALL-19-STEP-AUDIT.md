# Product03 — all19-step geometry/fastener regression

Source type/count/order is documentary. Exact world coordinates, dimensions, face normals and backing allocations are visual proposals. No concealed bore or engaged thread is represented.

|Step / PDF|Source inventory|Current exterior result and remaining limits|
|---|---|---|
|S01 / p4|D×4|D4 source association retained; contact to proposed interior12. Exact receiver unknown.|
|S02 / p4|D×4|11/12 overlap18→0; actual end planesZ−51 coincide; continuous exemplar proof.|
|S03 / p5|D×4|9 underside905 meets10/11 top905; coordinates unmeasured.|
|S04 / p5|B×4; K×2|B4 seats on K annuli; bracket thickness is not misclassified as a gap. Receiver/tool access unknown.|
|S05 / p6|D×7|13 contacts9/10 rear edgesZ−277;7-D proposed backing3+2+2. Role/proportions/assignment require review.|
|S06 / p6|D×10|15 top771 contacts10/11/12 bottoms771;10-D backing proposed8+2; no OEM coordinate claim.|
|S07 / p7|A×5|A5 preserved; prepared5 remains staged untilS14. Hidden threads/support unknown.|
|S08 / p7|D×10|All10 D axes now hit existing side stock and proposed wood backing; six old misses removed. Precise mapping inferred.|
|S09 / p8|C×4|Accepted4 bands and exterior between-side fit retained. C4 exact coordinates still illustrative.|
|S10 / p8|F×4|F4 near-face seating0; full straight approach blocked in candidate geometry. STOP F motion; world-axis not confirmed.|
|S11 / p9|C×4|Accepted3 ladder geometry retained; two proposed end heights712/744. Exact C coordinates inferred.|
|S12 / p9|F×4|F4 near-face seating0; full straight approach blocked. STOP; see source-confidence correction.|
|S13 / p10|C×4|Accepted6/4 exterior contact retained. C4 allocation still UNVERIFIED.|
|S14 / p10|C×6|C6 count retained; end allocation still UNVERIFIED. Prepared5 retained at final contact.|
|S15 / p11||14 underside71 contacts all four6 top71; old10-unit support gap removed. No screw added.|
|S16 / p11|E×8|E8 seats on existing hinge leaf annuli; no new hinge pin or receiver. Physical access unknown.|
|S17 / p12|G×2; H×2; J×2|G2/H2/J2 external proposal retained; no stud receiving method invented.|
|S18 / p12|G×2; H×2; I×2|G2/H2/I2 provisional; source summaryJ vs insetI conflict remains OPEN.|
|S19 / p13|N×4|N4 accessory association retained; no additional screws, no new door motion limits.|

Actual triangle-ray audit77/77 near exterior seats meet the software review criterion|gap|≤0.4 display unit. The13 intended mesh-bound contact differences are0. All36 wood pairs have no positive-volume AABB intersections; old model had2. These are geometric visual results, not manufacturing tolerances or installation certification.

The18 proposed D8/F backing rays reach actual wood geometry within the visual shaft envelope. This is not evidence of a receiving hole/thread. Source allocations remain inferred.

All8 F routes are retained as BLOCKED in the long-axis test. Same-OEM lower frame submeshes are included. A near seating PASS does not override a path FAIL. No F installation sequence has been produced.

Five clips8s each show S02/S05/S06/S08/S15, each with a fixed camera and retained components. The40s compilation has clearly labeled group cuts; it is not a continuous full assembly narrative. No158s blocking rerender or Long/Short/audio was generated.
