# Motion and deterministic-seek QA

Historical D2: 9/18 step boundaries show camera position/target jumps exceeding1 display unit across0.0002s. Actual values and timestamps are in LEGACY-CAMERA-CONTINUITY.json. This is an edit discontinuity test, not a hardware tolerance.

Historical binary product/hardware introductions: 119. The0→visible changes are recorded with timestamps and staging offsets. Symbolic L/M tool introductions also use abrupt visibility and require revised approach/withdrawal choreography. Historical transform-repeatability tests did not catch these visual defects.

New12-second proof:24fps,288 native720p frames. One fixed camera throughout, no show/hide, no cuts, no resets. Rail approaches2–5s, holds installed thereafter. C approaches6.5–9.5s, then holds. Both are visible from0s. Quintic smootherstep gives continuous position/velocity and zero endpoint velocity; no thread pitch or torque is asserted.

Numerical audit:2881 samples at240Hz; finite transforms, retained visibility and backward/forward seek hashes PASS. Maximum rail speed 53.12473, screw speed 29.99985 display units/s. The camera state is identical in all288 actual rendered frames. Full shaft retained, clipping planes0. New focused tests2/2 PASS; source/scripts TypeScript check PASS. See logs and JSON.

Remaining full-timeline motion correction: replace step-index camera resets with continuous shot keyframes; stage introductions before approach; add visible tool withdrawal; retime only affected operations. No new full158s render has been made.

Physical support, hidden engagement and access are NOT certified. This focused visual-motion PASS cannot upgrade them.
