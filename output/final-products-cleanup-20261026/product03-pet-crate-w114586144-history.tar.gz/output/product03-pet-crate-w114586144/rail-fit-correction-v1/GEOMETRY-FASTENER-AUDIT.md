# Product03 — geometry and fastener audit, all19 steps

Latest human P0 override supersedes historical D2 PASS. This audit does not authorize a complete render. Every coordinate below is an UNMEASURED DISPLAY UNIT, never an OEM millimetre measurement.

CONFIRMED labels apply to source type/count/qualitative association only. All exact positions, panel thicknesses, cross-sections, lengths, stock spacings and insertion depths are illustrative.

|Step / PDF|Source type/count, exterior face and target|Actual model finding / disposition|Result|
|---|---|---|---|
|S01 / p4|CONFIRMED D4; source p4. Exterior of 10 toward 12 ends.|Legacy side/connector contact at X±558; D1–4 exterior planes meet. Dimensions/hidden receiver inferred.|WARN|
|S02 / p4|CONFIRMED D4; p4. Through 12 toward dividers11.|11 depth reaches Z−279 while 12 occupies −279…−261:18-unit overlap. End contact needs revision; no receiving feature invented.|FAIL|
|S03 / p5|CONFIRMED D4; p5. Broad face9 toward10.|9 underside905 matches10/11 top905. D9–12 seat top923. Panel dimensions remain proposals.|WARN|
|S04 / p5|CONFIRMED B4/K2; p5. Two perpendicular axes.|B plane is2 units outside wood because K is2 thick. Annular mesh rays confirm K seating0; not a gap defect. Receiver/access unknown.|WARN|
|S05 / p6|CONFIRMED D7; p6. Through13 toward exposed module edges.|Current13 is a short upstand; source shows a closure against module edges. Seven backing targets and panel role/proportion remain P0, not justified by head-plane contact.|FAIL|
|S06 / p6|CONFIRMED D10; p6. Through15 toward module partitions/end panels.|15 contacts10/11 atY745, but opposite backing/screw ownership must be reconstructed together with12/13; current five-pair pattern not OEM-confirmed.|FAIL|
|S07 / p7|CONFIRMED A5; p7. Four side-frame feet + center5 carrier.|Retain5 staged untilS14. Foot/stem hidden thread and human support unverified. A is not a BCDEF head-plane ray.|WARN|
|S08 / p7|CONFIRMED D10; p7. Outer square-pipe faces to module; inverted setup.|D31/32/34/36/37/39 have no host mesh on declared insertion axes. Current side/frame placements cannot be accepted.|FAIL|
|S09 / p8|CONFIRMED C4; p8. Side-post exteriors to4 ends.|Old4 outer width1170 vs side inner width1152 gives9-unit overlap per side. Focus proposal trims4 to1152 exterior; end bores remain unknown.|FAIL→FOCUSED_PROPOSAL|
|S10 / p8|CONFIRMED F4; p8. Exposed rear association face; tighten after alignment.|F1–4 float5 units above old4 surface. Current +Y outward becomes downward in source-inverted state, contradicting drawn exposed access. Rebuild association/axis; do not merely clip shafts.|FAIL|
|S11 / p9|CONFIRMED C4; p9. Two spaced end connections per side to3.|Old3 single bar omits source-visible ladder band; C5–8 y706/718 crowds one bar. Focus adds factory band silhouette only; final C heights still pending.|FAIL→FOCUSED_PROPOSAL|
|S12 / p9|CONFIRMED F4; p9. Front association; align then tighten.|Current y721 +Y axis seats a mesh plane but source-inverted exposed face is opposite. Backing/depth and F5–8 axis remain P0.|FAIL|
|S13 / p10|CONFIRMED C4 / rails6×4; p10. End receiver depicted.|C9–12 miss old4 entirely. Focus adds source-visible4 band, sets6 center62 and length554 to touch inner depth planes. Four rear-end allocation remains HYPOTHESIS.|FOCUSED_EXTERIOR_PROPOSAL|
|S14 / p10|CONFIRMED C6; p10. Introduce prepared5; preserve tab direction.|Old6/5 depth overlap3 and center-height offset2. Focus corrects rail dimensions; exact four opposite6 ends + two5 ends remains UNVERIFIED. No new allocation claim.|WARN_UNRESOLVED|
|S15 / p11|CONFIRMED no hardware; p11. Upright14 placement.|Old14 underside79 vs6 top69 leaves10-unit support gap; corrected6 top71 still leaves8 if14 unchanged. Floor/door heights need coordinated correction before complete render.|FAIL|
|S16 / p11|CONFIRMED E8; p11. Four factory hinges, twoE each.|E1–8 on visible hinge leaf annuli atZ296.5: gap0. Side-only ray gives1.5, the legitimate leaf thickness. Hidden receiver/hinge axis and access remain illustrative.|WARN|
|S17 / p12|CONFIRMED G2/H2/J2; p12. Stud→H→J→G external order.|External stack proposal retained. Stud/anchor unknown; tab-release/35° door pose not OEM limits.|WARN|
|S18 / p12|SOURCE CONFLICT; p12 insetI vs summaryJ; G2/H2.|Provisional lowerI2 reconciles inventory; not an OEM correction or resolved identity.|WARN_UNRESOLVED|
|S19 / p13|CONFIRMED N4; p13; optional EVA pad wording.|Inside-door association plausible; exact coordinates/contact not certified. No screw, no invented fastening.|WARN|

The77 B–F instances all have individual entries in LEGACY-FASTENER-RAY-AUDIT.json: 10 axis misses and 4 exterior seating offsets after checking B against K and E against hinge leaves, rather than incorrectly treating bracket thickness as a gap.

The same source19-step order and inventory remain unchanged in the historical timeline. This focused proof does not claim all19 steps have been corrected.

## Geometry scope and remaining assumptions

- Corrected in isolated proof: visible factory bands of4; source-visible second band of3;4 exterior width between side inner planes; four6 rails centre/length; C head underside kept exterior. Factory bands remain submeshes of the same OEM ID, not new listed parts.
- Proposed coordinates:4 lower/upper bandY62/744;6 Y62,length554,endsZ±277;4 outsideX±576. Exact band count/spacing, proportions and cross-section are display assumptions, not measured source facts.
- Original4 mesh lower outer edgeY104 and6 upper edgeY69 have35 units of vertical separation at the depth crossing. C13 exterior axes atY60 do not hit4 at all. The new lower band supplies an actual contact plane, rather than moving only a screw or suppressing a collision pair.
- New6 ends meet proposed4/5 inner depth faces atZ±277; no3-unit overlap remains. At S13,5 is not installed, so the free end/support procedure is unresolved. No hand/fixture is shown and no physical support PASS is claimed.
- Cabinet/door panel roles, lower-floor support, F source axes and six D8 targets remain P0 in the full model. Their source contradictions are disclosed above; a clean isolated joint cannot clear them.
- There are no new holes, threads, inserts, connecting bars, hidden receivers or precise OEM dimensions. The added visible frame bands are depicted factory structure, not a claim of welded-joint or receiver specification.
- Smooth full C shaft remains present. An opaque real frame naturally occludes it. Clipping is disabled. Its symbolic penetration of unmodeled solid stock is NOT a validated bore or physical engagement. No collision PASS is claimed.
- Source ambiguity C13/C14 and I/J remains OPEN. No engineering certification, human hand/tool access, load or pet fit claim.
