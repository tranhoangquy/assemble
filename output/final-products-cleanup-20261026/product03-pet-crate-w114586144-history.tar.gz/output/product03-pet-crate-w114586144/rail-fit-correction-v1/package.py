from pathlib import Path
import json, hashlib, zipfile
P=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
probe=json.loads((P/'FFPROBE.json').read_text());video=[s for s in probe['streams'] if s['codec_type']=='video']
assert len(video)==1 and len(probe['streams'])==1
s=video[0];assert s['width']==1280 and s['height']==720 and int(s['nb_read_frames'])==288
assert abs(float(probe['format']['duration'])-12)<.000001
assert (P/'evidence/full-decode.log').read_text()==''
qa={'frameInput':'PASS;288 contiguous fully decoded native1280x720 PNGs',
 'video':'PASS;12 seconds;24fps;288 H264 frames; silent;full decode exit0',
 'typecheck':'PASS; source/scripts scoped TypeScript check exit0; historical output snapshots excluded',
 'focusedTests':'PASS;2/2 Vitest tests, observed actual tool result;4.65s',
 'determinism':'PASS; backwards/forwards arbitrary seeks;2881 transform samples',
 'camera':'PASS; fixed camera in actual288-frame render manifest',
 'clipping':'DISABLED; no shaft clipping or hidden receivers',
 'wholeProduct':'FAIL; remaining P0 listed in all19-step audit; no new full158s render',
 'physicalFit':'NOT_CERTIFIED; receiver engagement/access/support unknown; C13/C14 and I/J unresolved',
 'agentVisualReview':'Actual staged/contact/hold PNGs, before/after, source excerpts inspected; motion contact sheet generated',
 'directorReview':'PENDING actual Assemble response',
 'network':'Offline rendering; attempted HTTP requests0. Only authorized existing Assemble handoff permitted.'}
(P/'PROOF-QA.json').write_text(json.dumps(qa,indent=2)+'\n')
files=[
 'PRODUCT03-rail-connection-proof-v1-720p.mp4','FOCUSED-CORRECTION-REVIEW.md','GEOMETRY-FASTENER-AUDIT.md','MOTION-QA.md',
 'BEFORE-AFTER.jpg','MOTION-CONTACT-SHEET.jpg','OEM-EVIDENCE.jpg','HISTORICAL-19-ENDPOINTS.jpg',
 'NUMERICAL-QA.json','BEFORE-AFTER-MEASUREMENTS.json','LEGACY-FASTENER-RAY-AUDIT.json','LEGACY-CAMERA-CONTINUITY.json',
 'LEGACY-VISIBILITY-DISCONTINUITIES.json','PROTECTED-ASSET-VERIFICATION.json','FRAME-INPUT-QA.json','PROOF-QA.json',
 'HUMAN-REVISION-AUTHORITY.json','FFPROBE.json',
 'stills/before-contact.png','stills/after-staged.png','stills/after-rail-contact.png','stills/after-screw-contact.png','stills/after-overview.png',
 'frames-r2/offline-network.json']
manifest=[{'path':f,'bytes':(P/f).stat().st_size,'sha256':sha(P/f)} for f in files]
(P/'PAYLOAD-SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=P/'PRODUCT03-rail-fit-correction-v1-review.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for f in files+['PAYLOAD-SHA256.json']:z.write(P/f,f)
with zipfile.ZipFile(archive) as z:
 for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
delivery=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in [archive,P/'PRODUCT03-rail-connection-proof-v1-720p.mp4',P/'FOCUSED-CORRECTION-REVIEW.md',P/'BEFORE-AFTER.jpg',P/'OEM-EVIDENCE.jpg']]
(P/'REVIEW-DELIVERY-MANIFEST.json').write_text(json.dumps(delivery,indent=2)+'\n')
(P/'DELIVERY-SHA256.txt').write_text('\n'.join(f"{r['sha256']}  {r['path']}" for r in delivery)+'\n')
print(json.dumps(delivery,indent=2))
