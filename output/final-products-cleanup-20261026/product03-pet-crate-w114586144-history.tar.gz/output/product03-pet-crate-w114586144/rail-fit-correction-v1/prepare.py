from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, hashlib, math, re

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'output/product03-pet-crate-w114586144'
OUT=Path(__file__).resolve().parent
def load(p): return json.loads(Path(p).read_text())
def save(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',20)
small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',16)

# Validate actual, fresh frame inputs before encoding.
frames=sorted((OUT/'frames-r2').glob('frame-*.png'))
assert len(frames)==288,len(frames)
for i,p in enumerate(frames):
 assert p.name==f'frame-{i:06d}.png'
 with Image.open(p) as im:
  assert im.size==(1280,720)
  im.load()
manifest=load(OUT/'frames-r2/selected-diagnostic-manifest.json')
assert len(manifest)==288
assert len({json.dumps(x['camera'],sort_keys=True) for x in manifest})==1
assert all(not x['networkRequests'] for x in manifest)
assert all(x['state']['clippingPlanes']==0 for x in manifest)
save('FRAME-INPUT-QA.json',{'status':'PASS','frames':288,'fps':24,'duration':12,'nativeSize':[1280,720],
 'contiguous':True,'fullPngDecode':True,'camera':'IDENTICAL all288 frames; no cuts or jumps','clippingPlanes':0,
 'visibility':'All included nodes visible throughout; no binary introductions','networkRequests':0})

# Historical camera discontinuities from the actual old preview implementation.
legacy=load(OUT/'evidence/legacy-camera-boundaries/selected-diagnostic-manifest.json')
camera_rows=[]
for i in range(0,len(legacy),2):
 a,b=legacy[i:i+2]
 delta=math.dist(a['camera']['position'],b['camera']['position'])
 target_delta=math.dist(a['camera']['target'],b['camera']['target'])
 camera_rows.append({'step':b['state']['step'],'time':(a['time']+b['time'])/2,'epsilonWindowSeconds':.0002,
  'positionJumpDisplayUnits':delta,'targetJumpDisplayUnits':target_delta,
  'result':'FAIL_DISCONTINUITY' if max(delta,target_delta)>1 else 'NO_LARGE_BOUNDARY_JUMP',
  'criterion':'1 display unit across0.0002s is a diagnostic jump flag, not a physical tolerance'})
save('LEGACY-CAMERA-CONTINUITY.json',camera_rows)

# Immutable baseline checks plus all historical delivery manifests and D2 frozen sources.
checks=load(BASE/'phase-a-v1/evidence/protected-baseline.json')
results=[]
for rel,wanted in checks.items():
 p=ROOT/rel; actual=sha(p) if p.exists() else None
 results.append({'path':rel,'expected':wanted,'actual':actual,'match':actual==wanted})
old_reviews=[]
for mf in BASE.glob('*/REVIEW-DELIVERY-MANIFEST.json'):
 if mf.parent==OUT:continue
 for row in load(mf):
  if not isinstance(row,dict) or 'path' not in row:continue
  p=Path(row['path']);actual=sha(p) if p.exists() else None
  old_reviews.append({'revision':mf.parent.name,'file':p.name,'match':actual==row['sha256']})
frozen=[]
for rel,wanted in load(BASE/'phase-d-illustrative-v2/FROZEN-BLOCKING-SHA256.json')['files'].items():
 p=ROOT/rel if rel.startswith('src/') else BASE/rel
 frozen.append({'file':rel,'match':p.exists() and sha(p)==wanted})
video=BASE/'phase-d-illustrative-v2/PRODUCT03-illustrative-assembly-blocking-v2-720p.mp4'
video_match=sha(video)=='0b1948907daaea92ec8cad5a7edd239fde7f11a12ebf6f6c7dfc8c32334456bc'
assert all(r['match'] for r in results+old_reviews+frozen) and video_match
save('PROTECTED-ASSET-VERIFICATION.json',{'status':'PASS','protectedManifestPaths':len(results),'changed':0,
 'historicalReviewFiles':len(old_reviews),'historicalReviewMatches':all(r['match'] for r in old_reviews),
 'D2FrozenFiles':frozen,'D2ActualVideoHashMatches':video_match,
 'sourcePdfSha256':sha(BASE/'phase-a-v1/source/human-provided-pet-crate-manual.pdf'),
 'historicalReviewChecks':old_reviews})

def sheet(name,items,cols=2,tile=(800,450)):
 rows=math.ceil(len(items)/cols); w,h=tile
 canvas=Image.new('RGB',(w*cols,(h+36)*rows),'#eeeae2');d=ImageDraw.Draw(canvas)
 for i,(p,label) in enumerate(items):
  im=Image.open(p).convert('RGB');im.thumbnail((w,h));x=i%cols*w;y=i//cols*(h+36)
  canvas.paste(im,(x+(w-im.width)//2,y+(h-im.height)//2));d.text((x+12,y+h+7),label,font=small,fill='#302b26')
 canvas.save(OUT/name,quality=92)
sheet('BEFORE-AFTER.jpg',[(OUT/'stills/before-contact.png','BEFORE: old geometry, clipping disabled'),
 (OUT/'stills/after-screw-contact.png','AFTER: real frame contact; C allocation still unverified'),
 (OUT/'stills/after-staged.png','1.5s / both parts visible before approach'),
 (OUT/'stills/after-rail-contact.png','5.8s / contact retained while C is staged')])
sheet('MOTION-CONTACT-SHEET.jpg',[(frames[round(t*24)],f'{t:.1f}s / continuous camera, no cuts') for t in [0,2,3,5,6.5,8,9.5,11.9]])
sheet('HISTORICAL-19-ENDPOINTS.jpg',[(BASE/f'phase-d-illustrative-v2/stills/S{i:02d}-endpoint.png',f'S{i:02d} / historical rejected D2') for i in range(1,20)],4,(400,225))

# Documentary excerpts, preserved source pages stay untouched.
source=Image.new('RGB',(1600,1100),'white');d=ImageDraw.Draw(source)
pages=BASE/'phase-a-v1/evidence/pages'
items=[('page-03.png',(830,90,1090,475),(20,50),'PDF p3 / factory frame 4'),
 ('page-10.png',(680,200,1030,580),(570,50),'PDF p10 / S13 inset'),
 ('page-03.png',(550,90,810,480),(1100,50),'PDF p3 / ladder rail 3'),
 ('page-10.png',(25,135,690,600),(20,600),'PDF p10 / S13 spatial relationship')]
for page,crop,pos,label in items:
 im=Image.open(pages/page).crop(crop);im.thumbnail((780 if pos[1]>500 else 470,430))
 source.paste(im,pos);d.text((pos[0],pos[1]-28),label,font=font,fill='black')
d.text((830,650),'Confirmed: visible factory bands and C ×4.',font=font,fill='black')
d.text((830,690),'Not confirmed: dimensions, exact end allocation,',font=font,fill='black')
d.text((830,720),'spacing, bore, thread, internal engagement.',font=font,fill='black')
source.save(OUT/'OEM-EVIDENCE.jpg',quality=94)

notes=[
 ('CONFIRMED D4; source p4. Exterior of 10 toward 12 ends.','Legacy side/connector contact at X±558; D1–4 exterior planes meet. Dimensions/hidden receiver inferred.','WARN'),
 ('CONFIRMED D4; p4. Through 12 toward dividers11.','11 depth reaches Z−279 while 12 occupies −279…−261:18-unit overlap. End contact needs revision; no receiving feature invented.','FAIL'),
 ('CONFIRMED D4; p5. Broad face9 toward10.','9 underside905 matches10/11 top905. D9–12 seat top923. Panel dimensions remain proposals.','WARN'),
 ('CONFIRMED B4/K2; p5. Two perpendicular axes.','B plane is2 units outside wood because K is2 thick. Annular mesh rays confirm K seating0; not a gap defect. Receiver/access unknown.','WARN'),
 ('CONFIRMED D7; p6. Through13 toward exposed module edges.','Current13 is a short upstand; source shows a closure against module edges. Seven backing targets and panel role/proportion remain P0, not justified by head-plane contact.','FAIL'),
 ('CONFIRMED D10; p6. Through15 toward module partitions/end panels.','15 contacts10/11 atY745, but opposite backing/screw ownership must be reconstructed together with12/13; current five-pair pattern not OEM-confirmed.','FAIL'),
 ('CONFIRMED A5; p7. Four side-frame feet + center5 carrier.','Retain5 staged untilS14. Foot/stem hidden thread and human support unverified. A is not a BCDEF head-plane ray.','WARN'),
 ('CONFIRMED D10; p7. Outer square-pipe faces to module; inverted setup.','D31/32/34/36/37/39 have no host mesh on declared insertion axes. Current side/frame placements cannot be accepted.','FAIL'),
 ('CONFIRMED C4; p8. Side-post exteriors to4 ends.','Old4 outer width1170 vs side inner width1152 gives9-unit overlap per side. Focus proposal trims4 to1152 exterior; end bores remain unknown.','FAIL→FOCUSED_PROPOSAL'),
 ('CONFIRMED F4; p8. Exposed rear association face; tighten after alignment.','F1–4 float5 units above old4 surface. Current +Y outward becomes downward in source-inverted state, contradicting drawn exposed access. Rebuild association/axis; do not merely clip shafts.','FAIL'),
 ('CONFIRMED C4; p9. Two spaced end connections per side to3.','Old3 single bar omits source-visible ladder band; C5–8 y706/718 crowds one bar. Focus adds factory band silhouette only; final C heights still pending.','FAIL→FOCUSED_PROPOSAL'),
 ('CONFIRMED F4; p9. Front association; align then tighten.','Current y721 +Y axis seats a mesh plane but source-inverted exposed face is opposite. Backing/depth and F5–8 axis remain P0.','FAIL'),
 ('CONFIRMED C4 / rails6×4; p10. End receiver depicted.','C9–12 miss old4 entirely. Focus adds source-visible4 band, sets6 center62 and length554 to touch inner depth planes. Four rear-end allocation remains HYPOTHESIS.','FOCUSED_EXTERIOR_PROPOSAL'),
 ('CONFIRMED C6; p10. Introduce prepared5; preserve tab direction.','Old6/5 depth overlap3 and center-height offset2. Focus corrects rail dimensions; exact four opposite6 ends + two5 ends remains UNVERIFIED. No new allocation claim.','WARN_UNRESOLVED'),
 ('CONFIRMED no hardware; p11. Upright14 placement.','Old14 underside79 vs6 top69 leaves10-unit support gap; corrected6 top71 still leaves8 if14 unchanged. Floor/door heights need coordinated correction before complete render.','FAIL'),
 ('CONFIRMED E8; p11. Four factory hinges, twoE each.','E1–8 on visible hinge leaf annuli atZ296.5: gap0. Side-only ray gives1.5, the legitimate leaf thickness. Hidden receiver/hinge axis and access remain illustrative.','WARN'),
 ('CONFIRMED G2/H2/J2; p12. Stud→H→J→G external order.','External stack proposal retained. Stud/anchor unknown; tab-release/35° door pose not OEM limits.','WARN'),
 ('SOURCE CONFLICT; p12 insetI vs summaryJ; G2/H2.','Provisional lowerI2 reconciles inventory; not an OEM correction or resolved identity.','WARN_UNRESOLVED'),
 ('CONFIRMED N4; p13; optional EVA pad wording.','Inside-door association plausible; exact coordinates/contact not certified. No screw, no invented fastening.','WARN')]
audit=load(OUT/'LEGACY-FASTENER-RAY-AUDIT.json');num=load(OUT/'NUMERICAL-QA.json')
lines=['# Product03 — geometry and fastener audit, all19 steps','',
 'Latest human P0 override supersedes historical D2 PASS. This audit does not authorize a complete render. Every coordinate below is an UNMEASURED DISPLAY UNIT, never an OEM millimetre measurement.','',
 'CONFIRMED labels apply to source type/count/qualitative association only. All exact positions, panel thicknesses, cross-sections, lengths, stock spacings and insertion depths are illustrative.','',
 '|Step / PDF|Source type/count, exterior face and target|Actual model finding / disposition|Result|','|---|---|---|---|']
pages_by_step=[4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13]
for i,(source_note,finding,status) in enumerate(notes):lines.append(f'|S{i+1:02d} / p{pages_by_step[i]}|{source_note}|{finding}|{status}|')
lines+=['',f'The77 B–F instances all have individual entries in LEGACY-FASTENER-RAY-AUDIT.json: {num["legacy"]["axisMisses"]} axis misses and {num["legacy"]["seatingOffsets"]} exterior seating offsets after checking B against K and E against hinge leaves, rather than incorrectly treating bracket thickness as a gap.',
 '', 'The same source19-step order and inventory remain unchanged in the historical timeline. This focused proof does not claim all19 steps have been corrected.',
 '', '## Geometry scope and remaining assumptions','',
 '- Corrected in isolated proof: visible factory bands of4; source-visible second band of3;4 exterior width between side inner planes; four6 rails centre/length; C head underside kept exterior. Factory bands remain submeshes of the same OEM ID, not new listed parts.',
 '- Proposed coordinates:4 lower/upper bandY62/744;6 Y62,length554,endsZ±277;4 outsideX±576. Exact band count/spacing, proportions and cross-section are display assumptions, not measured source facts.',
 '- Original4 mesh lower outer edgeY104 and6 upper edgeY69 have35 units of vertical separation at the depth crossing. C13 exterior axes atY60 do not hit4 at all. The new lower band supplies an actual contact plane, rather than moving only a screw or suppressing a collision pair.',
 '- New6 ends meet proposed4/5 inner depth faces atZ±277; no3-unit overlap remains. At S13,5 is not installed, so the free end/support procedure is unresolved. No hand/fixture is shown and no physical support PASS is claimed.',
 '- Cabinet/door panel roles, lower-floor support, F source axes and six D8 targets remain P0 in the full model. Their source contradictions are disclosed above; a clean isolated joint cannot clear them.',
 '- There are no new holes, threads, inserts, connecting bars, hidden receivers or precise OEM dimensions. The added visible frame bands are depicted factory structure, not a claim of welded-joint or receiver specification.',
 '- Smooth full C shaft remains present. An opaque real frame naturally occludes it. Clipping is disabled. Its symbolic penetration of unmodeled solid stock is NOT a validated bore or physical engagement. No collision PASS is claimed.',
 '- Source ambiguity C13/C14 and I/J remains OPEN. No engineering certification, human hand/tool access, load or pet fit claim.']
(OUT/'GEOMETRY-FASTENER-AUDIT.md').write_text('\n'.join(lines)+'\n')

jumps=[r for r in camera_rows if r['result']=='FAIL_DISCONTINUITY']
(OUT/'MOTION-QA.md').write_text(f'''# Motion and deterministic-seek QA

Historical D2: {len(jumps)}/18 step boundaries show camera position/target jumps exceeding1 display unit across0.0002s. Actual values and timestamps are in LEGACY-CAMERA-CONTINUITY.json. This is an edit discontinuity test, not a hardware tolerance.

Historical binary product/hardware introductions: {num['legacy']['binaryIntroductions']}. The0→visible changes are recorded with timestamps and staging offsets. Symbolic L/M tool introductions also use abrupt visibility and require revised approach/withdrawal choreography. Historical transform-repeatability tests did not catch these visual defects.

New12-second proof:24fps,288 native720p frames. One fixed camera throughout, no show/hide, no cuts, no resets. Rail approaches2–5s, holds installed thereafter. C approaches6.5–9.5s, then holds. Both are visible from0s. Quintic smootherstep gives continuous position/velocity and zero endpoint velocity; no thread pitch or torque is asserted.

Numerical audit:2881 samples at240Hz; finite transforms, retained visibility and backward/forward seek hashes PASS. Maximum rail speed {num['tests']['maxRailSpeed']:.5f}, screw speed {num['tests']['maxScrewSpeed']:.5f} display units/s. The camera state is identical in all288 actual rendered frames. Full shaft retained, clipping planes0. New focused tests2/2 PASS; source/scripts TypeScript check PASS. See logs and JSON.

Remaining full-timeline motion correction: replace step-index camera resets with continuous shot keyframes; stage introductions before approach; add visible tool withdrawal; retime only affected operations. No new full158s render has been made.

Physical support, hidden engagement and access are NOT certified. This focused visual-motion PASS cannot upgrade them.
''')

(OUT/'FOCUSED-CORRECTION-REVIEW.md').write_text(f'''# PRODUCT03 — RAIL FIT CORRECTION V1

Review ID: PRODUCT03-RAIL-FIT-CORRECTION-V1-20261021

Result: focused exterior correction proof prepared; whole-product P0 FAIL remains. Historical D2 creative approval is superseded by the human override. No complete blocking rerender or final Long/Short is authorized by this package.

## Concrete correction

Old floor rails6 floated clear of rear frame4; C13 entered empty space. The old simplified4 omitted source-visible factory ladder bands. The new isolated proposal restores those visible bands under OEM ID4, aligns6 to the contact plane and removes the3-unit depth overlap with the proposed front/rear support planes. Four proposed rear C axes now hit real4 exterior geometry with zero head-plane gap. All sizes are display assumptions, not manufacturer measurements; C end allocation remains unverified.

BEFORE-AFTER.jpg compares the same camera and unclipped complete screw geometry. The BEFORE is a controlled reconstruction from frozen historical model geometry with clipping disabled, not a falsely relabeled old video frame. The original actual rejected19 endpoints are separately included.

The12s24fps continuous proof shows approach, contact, C exterior seating and retained installed rail. It is an exterior visual proposal only. Full screw shaft remains present with no clipping; hidden thread/bore/engagement, torque and tool access are unknown. Free-end support is not modeled. All included parts are visible at the start; no camera cut or popping introduction conceals the operation.

## Whole-model audit

19/19 OEM steps accounted for.77 screws individually ray-tested against actual meshes. After checking legitimate K/hinge-leaf thickness, {num['legacy']['axisMisses']} axes miss their named host and {num['legacy']['seatingOffsets']} have seating offsets. Other P0 findings include divider/connector overlap,13/15 role/backing mismatch, missing3 factory band, inverted F access axes, D8 target misses and unsupported floor14. They remain visible in GEOMETRY-FASTENER-AUDIT.md; this package does not clear them or certify installation.

Motion audit detects {len(jumps)}/18 camera boundary discontinuities plus119 binary introductions in D2. The focused proof replaces these locally with one fixed camera and continuous quintic motion. Deterministic seeking and visual continuity are separately tested.

## Source and preservation

Only the human-provided13-page local manual was used. SHA25670873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29. Source excerpts are documentary crops; originals unchanged. Protected938 paths, prior review payloads and D2 frozen sources/video match their hashes. No Product01/JULIETTE/source overwrite, general browsing, paid service, audio or complete video production.

## Director request

Review the actual12sMP4, before/after, source evidence, all19-step audit and QA. Decide explicitly whether this isolated exterior joint proposal is acceptable within controlled illustrative mode, or requires a focused revision. C13/C14 must remain labeled UNVERIFIED. Do not authorize a complete blocking rerender while remaining whole-model P0 defects are unresolved. Human final acceptance remains pending.
''')

before_state=load(OUT/'evidence/CURRENT-PROJECT-STATE-before.json')
before_state.update({'phase_D':'FAIL — HUMAN P0 OVERRIDE; historical approvals superseded',
 'latest_human_directive':'PRODUCT03-PHASE-D-ILLUSTRATIVE-V1-20261020 revised decision; human supplied, not browser response',
 'current_milestone':'PRODUCT03-RAIL-FIT-CORRECTION-V1-20261021 — focused correction review',
 'phase_E_F':'NOT_AUTHORIZED',
 'next_milestone':'Focused Director review only; no complete blocking render until explicit review and remaining P0 resolution',
 'report':'rail-fit-correction-v1/FOCUSED-CORRECTION-REVIEW.md',
 'director_decision':'PENDING actual browser handoff/response for focused correction',
 'whole_product_geometry':'P0 FAIL remains; see19-step geometry/fastener audit',
 'human_final_acceptance':'NOT_GRANTED'})
(BASE/'CURRENT-PROJECT-STATE.json').write_text(json.dumps(before_state,indent=2,ensure_ascii=False)+'\n')
save('HUMAN-REVISION-AUTHORITY.json',{'provenance':'Direct human message in Codex, not browser-retrieved Director response',
 'decision':'FAIL — P0 ASSEMBLY VISUAL ACCURACY','supersedes':'All earlier camera/pacing-only and D2 visual approvals',
 'authorized':'Local geometry/fastener audit and focused correction motion proof; actual Assemble review',
 'forbidden':'Complete158s rerender before focused review, final Long/Short/audio, general internet, paid services, Product01/JULIETTE edits'})
print(json.dumps({'frameInput':'PASS','protected':len(results),'historicalReviews':len(old_reviews),'cameraJumps':len(jumps),'auditSteps':19},indent=2))
