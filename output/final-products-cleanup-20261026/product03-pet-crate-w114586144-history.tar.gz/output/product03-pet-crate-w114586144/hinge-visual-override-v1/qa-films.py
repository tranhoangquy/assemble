from pathlib import Path
import hashlib,json,subprocess,struct,math
from PIL import Image,ImageDraw
p=Path(__file__).resolve().parent;sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();result={};dest=p/'full-actual-review';dest.mkdir(exist_ok=True)
for portrait,folder,name,count,duration in [(False,'full-long-v5','PRODUCT03-Long-V5-278s-SILENT-720p.mp4',8340,278),(True,'full-short-v3','PRODUCT03-Short-V3-59s-SILENT-1080x1920.mp4',1770,59)]:
 f=p/folder/name
 if not f.exists():continue
 j=json.loads((p/folder/'COMPLETED-JOB.json').read_text());frames=Path(j['frameDirectory']);assert len(list(frames.glob('frame-*.png')))==count
 probe=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(f)]));v=probe['streams'][0];assert len(probe['streams'])==1 and int(v['nb_read_frames'])==count and abs(float(probe['format']['duration'])-duration)<1e-6 and v['codec_name']=='h264' and v['pix_fmt']=='yuv420p' and v['r_frame_rate']=='30/1'
 assert (v['width'],v['height'])==((1080,1920)if portrait else(1280,720))
 run=subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(f),'-f','null','-'],capture_output=True);assert run.returncode==0 and not run.stderr
 pts=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-select_streams','v:0','-show_entries','frame=pts_time','-of','json',str(f)]))['frames'];assert len(pts)==count and all(abs(float(a['pts_time'])-i/30)<1e-6 for i,a in enumerate(pts))
 # MP4 top-level box order, not a substring guess.
 boxes=[];data=f.read_bytes();pos=0
 while pos<len(data):
  n,kind=struct.unpack('>I4s',data[pos:pos+8]);head=8
  if n==1:n=struct.unpack('>Q',data[pos+8:pos+16])[0];head=16
  if n==0:n=len(data)-pos
  assert n>=head;boxes.append(kind.decode('ascii'));pos+=n
 assert boxes.index('moov')<boxes.index('mdat')
 rows=[json.loads(x)for x in(p/folder/'CAPTURE-TELEMETRY.ndjson').read_text().splitlines()];assert len(rows)==count
 for i,a in enumerate(rows):
  t=a['telemetry'];assert a['metric']['pass']and t['ready']and not t['contextLost']and t['glError']==0 and t['oemRegistry']==123;assert t['drawingBuffer']==([1080,1920]if portrait else[1280,720]);assert abs(t['shortTime'if portrait else'time']-i/30)<1e-8
 assert sum(a['visible']for a in rows[-1]['telemetry']['illustrations'])==8 and all(a['state']=='ILLUSTRATED_SEATED'for a in rows[-1]['telemetry']['illustrations'])
 prior=json.loads((p.parent/('human-3-image-correction-v1/short-v2-r3/silent-render-r2'if portrait else'final-camera-fix-v1/capture-r3/full-long-v4')/'COMPLETED-JOB.json').read_text());old=Path(prior['frameDirectory']);indices=list(range(60,1338))if portrait else list(range(6252));diff=[i for i in indices if sha(frames/f'frame-{i:06d}.png')!=sha(old/f'frame-{i:06d}.png')];assert not diff,repr(diff[:10])
 c16=[]if portrait else list(range(math.ceil(197.25*30),math.ceil(200.65*30)));assert all(sha(frames/f'frame-{i:06d}.png')==sha(old/f'frame-{i:06d}.png')for i in c16)
 for n,h in json.loads((p/folder/'INPUT-FREEZE.json').read_text())['files'].items():
  if n!='BUNDLE':assert sha(n)==h,n
 net=json.loads((p/folder/'OFFLINE-NETWORK-QA.json').read_text());assert net['externalRequestsTransmitted']==0
 times=[0,12,31.8,44.6,46.6,48.5,50.5,51.2,52.1,53.8,54.3666666667,54.4,55.5,56.4,57.5,58.9]if portrait else[4.3,41,52,109,115,176,190,198.5,208.5,211.5,213.5,215,216,218.3,220.5,222,223.5,226,228,230,232,234,236,238,240,243.9,244,254,263,264,265,267.9,268,273.9,274,277.9]
 selected=sorted(set(round(t*30)for t in times));sub=dest/('short'if portrait else'long');sub.mkdir(exist_ok=True)
 expr='+'.join(f'eq(n\\,{i})'for i in selected)
 if not(sub/'decoded-000.png').exists():subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(f),'-vf','select='+expr,'-fps_mode','passthrough','-start_number','0','-n',str(sub/'decoded-%03d.png')],check=True)
 records=[{'file':f'decoded-{k:03}.png','frame':n,'time':n/30}for k,n in enumerate(selected)];(sub/'FRAMES.json').write_text(json.dumps(records,indent=2))
 w,h=(216,410)if portrait else(426,265);cols=4 if portrait else 3;pages=[]
 for page in range((len(records)+11)//12):
  part=records[page*12:page*12+12];im=Image.new('RGB',(w*cols,h*((len(part)+cols-1)//cols)),'#f5f1e8');draw=ImageDraw.Draw(im)
  for k,a in enumerate(part):
   x=k%cols*w;y=k//cols*h;frame=Image.open(sub/a['file']).convert('RGB');frame.thumbnail((w,h-25));im.paste(frame,(x,y+25));draw.text((x+5,y+5),f"ACTUAL {a['time']:.3f}s / f{a['frame']}",fill='black')
  sheet=p/f"FULL-{'SHORT'if portrait else'LONG'}-SHEET-{page+1:02}.jpg";im.save(sheet);pages.append(str(sheet))
 ledger=[json.loads(x)for x in(p/folder/'COW-STORAGE-LEDGER.ndjson').read_text().splitlines()];assert all(a['freshCaptureVerified']and a['noHardLink']and a['clonefileReturned']==0 for a in ledger)
 result[folder]={'path':str(f),'sha256':sha(f),'frames':count,'duration':duration,'width':v['width'],'height':v['height'],'fps':30,'audio':False,'fullDecode':'PASS','PTS':'PASS','faststart':'PASS','nativeAllFramesContextAndPresence':'PASS','inputFreeze':'PASS','unchangedNativeFramesCompared':len(indices),'unchangedNativeFramesDifferences':diff,'C16NativeIdentityFrames':len(c16),'freshlyCapturedCOWIdenticalFrames':len(ledger),'finalAdditionalIllustrations':8,'OEMHardwareTools':103,'OEM_E':8,'additionalIllustrations':8,'finalIllustratedHingeScrews':16,'actualDecodedSamples':len(records),'contactSheets':pages,'reviewMethod':'Actual decoded MP4 samples + all-frame telemetry/PTS/decode; not continuous perceptual playback or physical fit certification'}
(p/'FULL-FILM-QA.json').write_text(json.dumps({'status':'PASS'if len(result)==2 else'LONG PASS / SHORT PENDING','movies':result,'limits':{'K22/10':'UNMEASURED','F':'NONLITERAL','C13/C14':'OPEN','I/J':'OPEN','S17/S18':'POSE_ONLY','S19':'pads/door HOLD','historicalRawCollision':'FAIL preserved','doorSideFasteners':'HUMAN-APPROVED ILLUSTRATION','OEMAttachmentDetails':'UNVERIFIED','doorFunction':'HOLD'},'humanFinalAcceptance':False},indent=2));print(json.dumps(result,indent=2))
