from pathlib import Path
import json,subprocess,hashlib
from PIL import Image,ImageDraw
p=Path(__file__).resolve().parent;reports={}
for folder,name,dur,count in [('four-hinges-proof','PRODUCT03-HINGE-FOUR-HINGES-PROOF-V1.mp4',35.5,1065),('portrait-proof','PRODUCT03-HINGE-PORTRAIT-PROOF-V1.mp4',8.1,243)]:
 f=p/folder/name
 if not f.exists():continue
 probe=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(f)]));v=probe['streams'][0];assert len(probe['streams'])==1 and int(v['nb_read_frames'])==count and abs(float(probe['format']['duration'])-dur)<1e-6
 d=subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(f),'-f','null','-'],capture_output=True);assert not d.returncode and not d.stderr
 pts=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-select_streams','v:0','-show_entries','frame=pts_time','-of','json',str(f)]))['frames'];assert all(abs(float(a['pts_time'])-i/30)<1e-6 for i,a in enumerate(pts))
 tele=[json.loads(l)['telemetry']for l in(p/folder/'CAPTURE-TELEMETRY.ndjson').read_text().splitlines()];assert len(tele)==count and all(a['ready']and not a['contextLost']and a['glError']==0 and a['oemRegistry']==123 for a in tele)
 # Full captured-frame telemetry: count/crop checks, separate from physical access.
 crop=[]
 for i,a in enumerate(tele):
  current=a['current'];tool=a['tool'];h=1920 if folder=='portrait-proof'else 720;w=1080 if h==1920 else 1280
  for obj in [current,tool]:
   if obj and obj.get('visible')and obj.get('box'):
    x0,y0,x1,y1=obj['box']
    if not(0<=x0<=x1<=w and 0<=y0<=y1<=h):crop.append({'frame':i,'id':current['id']if current else None,'box':obj['box']})
 reports[folder]={'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'duration':dur,'frames':count,'width':v['width'],'height':v['height'],'fps':30,'audio':False,'fullDecode':'PASS','PTS':'PASS','context':'PASS','cropWarnings':crop,'finalVisibleIllustrations':tele[-1]['illustratedVisible'],'finalSeatedIllustrations':tele[-1]['illustratedSeated']}
 assert not crop,repr(crop[:5])
 if folder=='four-hinges-proof':assert tele[-1]['illustratedSeated']==8
 else:assert tele[-1]['illustratedSeated']==2
(p/'PROOF-CAPTURE-QA.json').write_text(json.dumps({'status':'PASS'if len(reports)==2 else'LANDSCAPE PASS / PORTRAIT PENDING','movies':reports,'noPhysicalCertification':True,'sourceCurrentHardware':'During added pause this is OEM source context; defer next E until pause ends. currentIllustration/clock.block define actual active instruction.'},indent=2))
# Same-source/same-camera before-after of all four interfaces.
canvas=Image.new('RGB',(1280,4*385),'#f5f1e8');dr=ImageDraw.Draw(canvas)
for i in range(4):
 for k,mode in enumerate(['BEFORE','AFTER']):
  im=Image.open(p/f'before-after-r2/{mode}-hinge-{i+1}.png').convert('RGB');canvas.paste(im.resize((640,360)),(k*640,i*385+25));dr.text((k*640+10,i*385+5),f'{mode} / Hinge{i+1} / source227.900000 / same camera',fill='black')
canvas.save(p/'FOUR-HINGES-BEFORE-AFTER.jpg')
# Actual MP4 decoded action frames, not merely source diagnostics.
f=p/'four-hinges-proof/PRODUCT03-HINGE-FOUR-HINGES-PROOF-V1.mp4';dest=p/'actual-review';dest.mkdir(exist_ok=True);records=json.loads((p/'ACTOR-CONTACT-REGRESSION-QA.json').read_text())['contacts'];frames=sorted(set(round((r['start']-208.5+offset)*30)for r in records for offset in[.08,.6,1.15,1.7]))
def expression(a):
 if len(a)==1:return f'eq(n\\,{a[0]})'
 n=len(a)//2;return '('+expression(a[:n])+'+'+expression(a[n:])+')'
if not(dest/'decoded-000.png').exists():subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(f),'-vf','select='+expression(frames),'-fps_mode','passthrough','-start_number','0','-n',str(dest/'decoded-%03d.png')],check=True)
(dest/'FRAMES.json').write_text(json.dumps({'source':str(f),'frames':[{'file':f'decoded-{k:03}.png','frame':n,'proofTime':n/30}for k,n in enumerate(frames)],'method':'Actual MP4 sampled decode, not continuous playback claim'},indent=2))
for page in range(4):
 out=Image.new('RGB',(1280,4*385),'#f5f1e8');draw=ImageDraw.Draw(out)
 for i,(k,n)in enumerate(list(enumerate(frames))[page*8:(page+1)*8]):
  x=i%2*640;y=i//2*385;out.paste(Image.open(dest/f'decoded-{k:03}.png').convert('RGB').resize((640,360)),(x,y+25));draw.text((x+10,y+5),f'ACTUAL MP4 proof {n/30:.6f}s / frame{n}',fill='black')
 out.save(p/f'ACTUAL-MOTION-SHEET-{page+1:02}.jpg')
print(json.dumps(reports,indent=2))
