"""Storage optimization only AFTER fresh capture + exact bytes match. No skipped rendering."""
from pathlib import Path
import ctypes,os,sys,hashlib,json,time
new,old=map(Path,sys.argv[1:3]);start,end=map(int,sys.argv[3:5]);ledger=Path(sys.argv[5]);assert new.resolve()!=old.resolve() and 'hinge-visual-override-v1' in str(new.resolve())
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib',use_errno=True);clone=lib.clonefile;clone.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_int];clone.restype=ctypes.c_int
with ledger.open('a')as log:
 for i in range(start,end):
  a=new/f'frame-{i:06d}.png';b=old/f'frame-{i:06d}.png'
  if not(a.is_file()and b.is_file()):continue
  fresh=a.read_bytes();previous=b.read_bytes()
  if fresh!=previous:continue
  digest=hashlib.sha256(fresh).hexdigest();tmp=a.with_suffix('.cow-tmp');ret=clone(os.fsencode(b),os.fsencode(tmp),0)
  if ret:raise OSError(ctypes.get_errno(),os.strerror(ctypes.get_errno()))
  assert tmp.stat().st_ino!=b.stat().st_ino and hashlib.sha256(tmp.read_bytes()).hexdigest()==digest and hashlib.sha256(a.read_bytes()).hexdigest()==digest
  os.utime(tmp,ns=(time.time_ns(),time.time_ns()));os.replace(tmp,a)
  log.write(json.dumps({'frame':i,'sha256':digest,'source':str(b),'target':str(a),'freshCaptureVerified':True,'clonefileReturned':0,'noHardLink':True})+'\n')
