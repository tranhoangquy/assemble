# PRODUCT03 — HUMAN-APPROVED HINGE 4-SCREW OVERRIDE

Request: BOUNDED PROOF REVIEW + EXPLICIT278s/59s TIMING DECISION. No full movies rendered yet.

Human authorization attached. OEM remains20 numbered components +103hardware/tools. Existing E8 frame screws retained, not duplicated. Eight separate `illustration-hinge-door-*` actors add two door-side screws per hinge, four hinges total16shown screws. Extra actors are outside OEM registry/catalog: OEM registry123 unchanged, separate8=131 visual actors. See FASTENER-ACCOUNTING.json.

Only four door-leaf visible hole patterns restored under HUMAN ILLUSTRATION authority, matching current external leaf envelope. No hidden door bore/thread/receiver invented. Additional screw silhouettes clone the existing E prototype as visual approximations, not8new OEM E. Seating on modeled leaf face matches numerically; full shafts enter existing door mesh symbolically. Tool M reused, no extra tool or door rotation. Existing E8 final placements/counts unchanged; hinge approach distances bounded606→60 and tool650→140display-units for visible local staging. No mechanical certification.

Exact on-screen statuses: DOOR-SIDE FASTENERS: HUMAN-APPROVED ILLUSTRATION / OEM ATTACHMENT DETAILS: UNVERIFIED / DOOR FUNCTION: HOLD.

Actual continuous four-hinge proof35.5s/1065frames/1280×720/30fps, plus native portrait8.1s/243frames/1080×1920 showing one complete four-screw hinge. No audio. Before/after all four at source227.900000, identical native cameras (BEFORE is frozen V4 geometry re-evaluated, not a claim of old MP4 byte identity). Actual-MP4 sampled action frames/contact sheets included. Fixed camera throughout each four-screw sequence; clear labeled cuts only after completion/before next hinge. Native frustum checks no crop warnings. Agent review is sampled actual frames + full technical decode, not continuous playback claim.

QA:4332 nonhinge root comparisons unchanged;184 tool-vs-leaf plane checks clear; arbitrary backward seek PASS; OEM registry/counts unchanged; all16 shown endpoints accounted. This is visual/tool-plane testing, not hand-access/physical-fit/drive/retention certification. All OPEN/HOLD/rawcollisionFAIL preserved. Scoped source/harness typecheck PASS.

## Proposed Long V5 —278s

Add4×4s pauses after each E pair: two new1.8s cycles +0.4s verification, total16s. Preserve ALL existing OEM motion speeds and order. S17 shifts228→244; S18 shifts238→254. Alignment starts263. Keep original247–249 camera bridge2s unchanged; shorten ONLY static249–262 hold13→3s, giving alignment263–268 (5s). N sequence268–274 (source262–268), unchanged6s motion. Static final study10→4s, ends278. Correct implementation proposal: clock-option-278-r2.ts; the earlier unused clock.ts long mapping would speed the camera bridge and MUST NOT be used for production.

## Proposed Short V3 —59s

Preserve0–44.6s. Door7placement44.6–46.6 unchanged. Representative hinge46.6–54.4 (7.8s): existing E1/E2 full source speed +new two1.8s cycles +short final hold. Door8placement54.4–56.4, door7 retained; explicitly declare other3hinges omitted/seeLong. Remove the two POSE_ONLY G/H and I/J interstitial cards (not installation); retain their OPEN/POSE_ONLY limitation in final caption. N HOLD card56.4–57.133333 unchanged0.733333s; static hero57.133333–59 (1.866667s). Hook/final states show all16illustrated screws with the required authority/HOLD labels. Short MUST change because both hinge sequence and finished appearance are affected.

Please explicitly approve/revise visual proof AND these timing plans before full LongV5/ShortV3. No unapproved total-duration change, no audio/publication/research/Product01/JULIETTE changes. Human sole final approver.
