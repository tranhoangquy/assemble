# GÓI TRIỂN KHAI — PRODUCT #03
## HINGE 4-SCREW VISUAL OVERRIDE / HUMAN APPROVED

**Trạng thái:** APPROVED FOR IMPLEMENTATION  
**Người quyết định nghiệp vụ:** Human  
**Người review:** ChatGPT Creative Director  
**Người triển khai:** Codex

### 1. Mục tiêu

Sửa duy nhất phần bản lề cửa trong Product #03 để người xem thấy rõ mỗi bản lề được bắt vít vào cả khung cố định và cánh cửa.

Mỗi bản lề có bốn vít được minh họa, chia đều hai phía.

Không làm lại những phần đã được duyệt.

### 2. Requirement đã chốt

- Có 4 bản lề, gồm 2 bản lề trên mỗi cánh cửa.
- Mỗi bản lề thể hiện 2 vít ở lá phía khung và 2 vít ở lá phía cánh cửa.
- Tổng cộng 16 vít được minh họa.
- Giữ nguyên 8 vít E phía khung hiện có.
- Bổ sung 8 vít minh họa phía cửa, có actor ID và trạng thái riêng, không đánh đồng với 8 vít E thuộc danh mục OEM.
- Khôi phục hoặc tạo vị trí vít phía cánh cửa phù hợp với hình học bản lề hiện tại.
- Thể hiện đầy đủ thao tác đưa vít vào vị trí, tiếp cận bằng dụng cụ, bắt vít và rút dụng cụ ở cả hai phía.
- Camera phải cho thấy rõ cả vị trí bắt vít trên khung lẫn trên cánh cửa.
- Không làm phát sinh thao tác lắp mới ngoài phạm vi bản lề.

### 3. Business Rules

**BR-01 — Phân biệt OEM và minh họa**

Tài liệu OEM liệt kê E ×8. Tám vít phía cánh cửa được bổ sung theo quyết định minh họa của human, không được khai báo là vít OEM đã xác minh.

**BR-02 — Không khẳng định cơ khí**

Việc thể hiện vít đi vào lá bản lề và cánh cửa không chứng minh lỗ nhận vít, ren, chiều sâu ăn vít, khả năng chịu lực hoặc độ bền liên kết.

**BR-03 — Không nâng cấp trạng thái chức năng**

Phải giữ rõ giới hạn:

- `DOOR-SIDE FASTENERS: HUMAN-APPROVED ILLUSTRATION`
- `OEM ATTACHMENT DETAILS: UNVERIFIED`
- `DOOR FUNCTION: HOLD`

Không tự chuyển sang trạng thái cửa hoạt động được hoặc lắp đặt đạt chuẩn.

**BR-04 — Quản lý số lượng**

Giữ nguyên danh mục OEM gồm 103 đơn vị hardware/tools đã ghi nhận. Theo dõi riêng 8 vít minh họa bổ sung. Không âm thầm thay đổi số lượng OEM thành 111.

**BR-05 — Không thay đổi sản phẩm**

Không chỉnh kích thước, vật liệu, bố cục, cơ cấu cửa hoặc các chi tiết ngoài bản lề.

### 4. Acceptance Criteria

**AC-01 — Hình ảnh**

- Cả 4 bản lề đều có đủ 4 vít.
- Hai vít phía khung và hai vít phía cửa được thể hiện rõ.
- Không có vít lơ lửng, xuyên sai hướng hoặc biến mất bất thường.
- Camera không che khuất thao tác quan trọng.

**AC-02 — Animation**

- Vít phía cửa được đưa đến đúng vị trí minh họa.
- Dụng cụ tiếp cận và rút ra hợp lý về mặt hình ảnh.
- Không có thao tác bắt vít giả tạo bằng cách làm vít đột ngột xuất hiện ở trạng thái hoàn tất.
- Không làm phát sinh chuyển động mở cửa hoặc khẳng định chức năng bản lề.

**AC-03 — Bằng chứng**

Trước khi render phim hoàn chỉnh, Codex phải cung cấp:

- Proof BEFORE/AFTER.
- Video liên tục thể hiện thao tác trên cả hai phía bản lề.
- Cận cảnh kiểm tra cả 4 bản lề.
- Bảng đối chiếu 8 vít OEM và 8 vít minh họa.
- Báo cáo actor/state, camera và regression QA.

**AC-04 — Regression**

Không thay đổi camera C16 đã PASS, chân A1–A5, đệm N1–N4 hoặc các cảnh không liên quan.

### 5. Edge Cases bắt buộc

- Vít phía cửa bị che khi cánh cửa ở vị trí hiện tại.
- Dụng cụ xuyên qua cánh cửa hoặc lá bản lề.
- Hai lá bản lề bị thể hiện sai phía.
- Vít mới vô tình được tính là vít E OEM.
- Các vít phía khung bị lắp lại hoặc xuất hiện hai lần.
- Chuyển camera quá nhanh khiến không nhìn rõ thao tác.
- Thêm tám thao tác khiến nhịp phim không còn đủ thời gian.
- Long và Short không đồng nhất về trạng thái bản lề.

Nếu không đủ thời lượng để minh họa rõ, Codex phải đề xuất điều chỉnh cục bộ và trình Director review; không tự thay đổi tổng thời lượng phim.

### 6. Ràng buộc

- Bắt đầu từ Long V4 và Short V2 đã được review.
- Long giữ mục tiêu 278 giây; Short giữ 59 giây.
- Short chỉ thay đổi nếu có cảnh bản lề chịu ảnh hưởng hoặc trạng thái bản lề cần cập nhật.
- Không sửa camera C16.
- Không thêm âm thanh.
- Không truy cập Internet ngoài phạm vi ChatGPT Web Assemble đã được phép.
- Không công bố, không sử dụng dịch vụ trả phí.
- Không chỉnh Product #01 hoặc JULIETTE.

### 7. Không được thay đổi

- Tài liệu OEM gốc.
- Các bản phim cũ và bằng chứng đã khóa.
- Số lượng phụ kiện OEM.
- Ba bản sửa đã PASS trước đó, ngoại trừ hình học lá bản lề phía cửa trong phạm vi yêu cầu mới.
- Các trạng thái K UNMEASURED, F NONLITERAL, C13/C14 và I/J OPEN, S17/S18 POSE_ONLY, S19 HOLD và raw collision FAIL.

### 8. Câu hỏi còn mở

- Tọa độ chính xác của hai vít phía cửa trên mỗi bản lề chưa được OEM xác minh.
- Cấu trúc nhận vít và khả năng giữ cửa thực tế chưa được xác minh.
- Cần đánh giá liệu nhịp phim hiện tại có đủ để thể hiện rõ các thao tác bổ sung hay không.

Codex được tự chọn bố cục hình ảnh hợp lý trong phạm vi minh họa, nhưng phải ghi rõ các quyết định chưa có chứng cứ OEM.

### 9. Quy trình triển khai

1. Audit actor và timeline bản lề hiện tại.
2. Xây dựng phương án bổ sung 8 vít minh họa phía cửa.
3. Tạo bounded proof với đầy đủ bốn bản lề.
4. Gửi proof và QA trực tiếp cho ChatGPT Creative Director trong Assemble.
5. Nếu Director PASS, tích hợp vào Long V5 và Short V3 nếu Short cần thay đổi; nếu Short không cần thay đổi, giữ Short V2 và giải thích bằng chứng.
6. Render, QA và gửi Director review phim hoàn chỉnh.
7. Bàn giao cho human nghiệm thu cuối cùng.

Không yêu cầu human xác nhận từng bước. Chỉ dừng nếu xuất hiện quyết định nghiệp vụ mới ngoài phạm vi được ủy quyền.

**Final gate: HUMAN FINAL ACCEPTANCE REQUIRED.**