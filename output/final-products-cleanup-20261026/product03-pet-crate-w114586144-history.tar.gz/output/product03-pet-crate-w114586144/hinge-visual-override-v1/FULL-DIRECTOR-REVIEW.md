# PRODUCT03 — LONG V5 / SHORT V3 — FULL FILM REVIEW

Request: explicit internal visual review of both actual complete silent MP4s after the BOUNDED VISUAL PROOF PASS. Human final acceptance remains pending. Please inspect actual videos, not metadata alone; state the actual review method and any limits. No web research, purchases, external uploads, or mechanical-confidence upgrade.

## Implementation

Only the human-approved hinge override and Director-approved timing/editorial integration changed. Four hinges each show two existing OEM E frame screws and two separately tracked human-illustration door screws: E8 remains E8; OEM hardware/tools remains103; additional illustrations8. No hidden receiving bore, thread, retention, torque, tool/hand-access certification, or functioning-door claim. No door opening/closing.

Long V5: native1280×720/30fps,278s,8340frames. Four4s added hinge blocks include complete screw approach, tool approach, illustrative insertion and withdrawal. All OEM motion durations retained. Accepted clock-option-278-r2 used; source247–249 camera bridge remains2s at global263–265. Only static source249–262 shortened13→3s and source268–278 static study10→4s. S17global244; S18global254; alignment263–268; N268–274; hero274–278. Review end-label reading time in context: three authority/status labels remain visible from208.5 onwards, not only in the final4s.

Short V3: native1080×1920/30fps,59s,1770frames. Early assembly2–44.6s is native-PNG byte-identical to ShortV2. Finished hook0–2s updated to show all16screws and authority labels. Door7:44.6–46.6; complete representative four-screw hinge46.6–54.4; door8:54.4–56.4 with door7 retained and “Other3hinges omitted · seeLong”; N HOLD56.4–57.133333; hero57.133333–59. The two G/H,I/J POSE_ONLY cards are omitted as approved, with explicit G/H,I/J POSE_ONLY/OPEN, C13/C14 OPEN, F nonliteral disclosures at the ending. Authority label is separated from the unchanged N pad label. Review caption readability and tool/hinge visibility at native portrait size.

## Actual QA

- All10110frames freshly captured through the existing shared resumable ExportJobManager, no skipped rendering or older checkpoint substitution.
- Full native-sequence validation, all-frame context/subject presence, expected dimensions,PTS=i/30, full MP4decode,faststart,noaudio,input-freeze:PASS.
-6252 pre-hinge Long PNGs match frozenLongV4 byte-for-byte;102 C16 frames197.266667–200.633333s match exactly.
-1278 Short PNGs2–44.566667s match frozenShortV2 byte-for-byte.
-2850 non-hinge root comparisons; reverse seek/reset state identity PASS. Separate native preflight forward/backward pixel identity PASS.
-At final state OEM E8 and separate8 human screws are retained; OEM103 unchanged. Door7 retained during door8. Four A/N source poses and previous corrections preserved.
-51066 protected prior paths:0changes. Both bounded proof source-freezes unchanged. Product01/JULIETTE and all prior films/history preserved.
-Actual MP4 decoded visual sampling:36 Long frames and16 Short frames, sheets included. Agent has inspected these samples, not claimed continuous perceptual playback or certified physical installation.
-Storage: after every fresh completed capture chunk, only PNGs proven byte-identical to old baselines were replaced with independent APFS copy-on-write clones. Separate inode, same bytes/checkpoint SHA, no hardlinks, no old file modifications; no capture skipped. Ledger retained locally.

## Unchanged limitations

DOOR-SIDE FASTENERS: HUMAN-APPROVED ILLUSTRATION

OEM ATTACHMENT DETAILS: UNVERIFIED

DOOR FUNCTION: HOLD

K22/10 UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN; S17/S18 POSE_ONLY; S19 pads/door HOLD; historical raw collision FAIL preserved. Product remains an unmeasured illustrative assembly study, not certified fit/installation/access/load.

## Requested decision

Please explicitly PASS or identify targeted revisions for each complete film, particularly hinge/tool continuity, all16retained screws, Short repeated-hinge omission disclosure, labels and final holds. Internal PASS authorizes packaging for **READY FOR HUMAN FINAL REVIEW — NOT YET ACCEPTED** only. Human alone accepts the films; no audio/publication authorized.
