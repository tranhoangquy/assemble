# S04 motion / two-bolt teaching proof

Two14s native720p24fps clips, left then right, combined28s. Same fixed camera throughout each clip; one explicit forward cut. Right scene retains completed left K/B1/B2. Six structural parts and12 D from sourceS3 remain installed. No complete timeline rerender.

K stages55 units in front and35 below, moves into its corner, contacts both fixed wood faces at2.2s; contact hold until2.7. B1 runs2.7–7.2; B2 runs7.7–12.2; both retained to14. Right repeats for B3/B4.

Each bolt: bring through the open front; align its tip to the visible K opening; contact hold; bring L from the open bay; engage; initial symbolic feed/60° illustrative key stroke; exterior seat hold; withdraw along the axis, then down through the open bay. The stroke is not a torque/turn-count specification. The tool is removed only after fully outside the fixed camera. No hand, support fixture or hidden grip is fabricated. Source requires alignment before final tightening; this proof does not certify final retention.

L is the existing source-listed M4 key, not a new driver. Existing B hex drive has across-flats~4.1569 and key across-flats4, giving~0.07846 ideal side-plane margin. Recess fit is a display-model result; no actual OEM tool/socket tolerance claim.

SourceS04 quantity/order association is respected; order of the two B within each K is a disclosed illustrative choice, not a manufacturer-specified screw sequence. Same for the shown working orientation, support and approach curves.
