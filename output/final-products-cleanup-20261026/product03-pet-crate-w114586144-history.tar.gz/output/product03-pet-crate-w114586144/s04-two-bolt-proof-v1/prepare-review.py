from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import hashlib,json,subprocess,zipfile,shutil,collections
P=Path(__file__).resolve().parent;B=P.parent;ROOT=P.parents[2]
def load(p):return json.loads(Path(p).read_text())
def save(n,v):(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True).stdout
qa=load(P/'S04-PAIR-AND-MOTION-QA.json');assert not qa['unresolved']
for r in qa['results']:
 assert r['retained'] and r['finite'] and r['deterministic'] and r['earlyHardware']==0 and r['headBoundsSeparated']
 assert r['maxToolAxisError']<1e-6 and abs(r['KtoTopGap'])<1e-6 and abs(r['KtoDividerGap'])<1e-6
 assert all(v['gap']==0 and v['visible'] for v in r['final'])
assert '2 passed' in (P/'evidence/tests-final.log').read_text()
assert not (P/'evidence/typecheck-frozen.log').read_text().strip()
assert all(r['outside'] for r in load(P/'VISIBILITY-BOUNDARIES.json')['rows'])
deltas=load(P/'BASELINE-DELTA.json')['entries'];assert {r['id'] for r in deltas if not r['geometryMatch']}=={'hardware-K-1','hardware-K-2'}
assert {r['id'] for r in deltas if not r['positionMatch']}=={'hardware-K-1','hardware-K-2',*[f'hardware-B-{i}' for i in range(1,5)]}
media=[];frames=[]
for side in ['left','right']:
 d=P/f'final-frames-{side}';manifest=load(d/'selected-diagnostic-manifest.json');assert len(manifest)==336
 expected=[f'{side}-frame-{i:06d}.png' for i in range(336)];assert [r['name'] for r in manifest]==expected
 assert not load(d/'offline-network.json')['attemptedRequests'];assert all(not r['networkRequests'] for r in manifest)
 assert all(r['camera']==manifest[0]['camera'] for r in manifest)
 for n in expected:
  f=d/n
  with Image.open(f) as im:im.load();assert im.size==(1280,720)
  frames.append(dict(path=str(f.relative_to(P)),sha256=sha(f),bytes=f.stat().st_size))
 f=P/f'PRODUCT03-S04-{side}-two-bolts-v1-720p.mp4'
 run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-framerate','24','-i',str(d/(side+'-frame-%06d.png')),'-frames:v','336','-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-an','-movflags','+faststart',str(f)])
 media.append(f)
concat=P/'evidence/concat.txt';concat.write_text(''.join("file '../"+f.name+"'\n" for f in media))
combined=P/'PRODUCT03-S04-two-bolts-proof-v1-720p.mp4'
run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-f','concat','-safe','0','-i',str(concat),'-c','copy','-movflags','+faststart',str(combined)])
media.append(combined);mediaQA=[]
for f,seconds in zip(media,[14,14,28]):
 info=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(f)]));assert len(info['streams'])==1;s=info['streams'][0]
 assert s['width']==1280 and s['height']==720 and s['r_frame_rate']=='24/1' and int(s['nb_read_frames'])==seconds*24 and abs(float(info['format']['duration'])-seconds)<.001
 run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(f),'-f','null','-'])
 mediaQA.append(dict(path=f.name,bytes=f.stat().st_size,sha256=sha(f),seconds=seconds,frames=seconds*24,audioStreams=0,fullDecode='PASS'))
save('MEDIA-QA.json',dict(media=mediaQA,pngFrames=672,allPNGDecode='PASS',camera='Fixed within each14s clip; one explicit forward cut left→right. Left K/B1/B2 retained in right scene.',offline='Both final fresh jobs complete;0 attempted requests. Earlier preflight captures preserved separately, never mixed into final sequence.'))
save('VIDEO-FRAME-MANIFEST.json',frames)
stills=P/'stills-frozen';assert len(load(stills/'selected-diagnostic-manifest.json'))==16 and not load(stills/'offline-network.json')['attemptedRequests']
for f in stills.glob('*.png'):
 with Image.open(f) as im:im.load();assert im.size==(1280,720)
source=B/'phase-a-v1/source/human-provided-pet-crate-manual.pdf';assert sha(source)=='70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29'
shutil.copyfile(B/'phase-a-v1/evidence/pages/page-05.png',P/'evidence/OEM-PDF-P05.png')
shutil.copyfile(B/'phase-a-v1/evidence/pages/page-03.png',P/'evidence/OEM-PDF-P03.png')
shutil.copyfile(B/'timeline-integration-v1/checkpoints/S04-head-clash-left.png',P/'evidence/OLD-UNGUARDED-HEAD-CLASH.png')
old=B/'timeline-integration-v1/PRODUCT03-S04-integration-diagnostic-v1-720p.mp4';assert sha(old)=='b94715eb910aa8a2d01d2ee148fb69bd3a7958f8ce0e6738d0cc48495086d897'
run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-ss','6.9','-i',str(old),'-frames:v','1',str(P/'evidence/ACTUAL-OLD-ONE-BOLT.png')])
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',22);small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17);big=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',29)
im=Image.new('RGB',(1920,810),'#f3efe6');d=ImageDraw.Draw(im);d.text((22,10),'S04 / OLD GUARDED ONE-BOLT PROOF → NEW TWO-BOLT VISUAL PROPOSAL',font=big,fill='#292c2f')
for col,path in enumerate([P/'evidence/ACTUAL-OLD-ONE-BOLT.png',stills/'left-stage-7.png']):
 im.paste(Image.open(path).convert('RGB').resize((960,540)),(960*col,80));d.text((960*col+20,50),'BEFORE / actual old MP4; B2 held' if col==0 else 'AFTER / B1+B2 retained; no bolt geometry resize',font=font,fill='#805534')
d.text((22,650),'Existing K visible proportions18→22 display units; width18, thickness2 and2 visible holes retained. NOT measured OEM dimensions.',font=small,fill='#805534')
d.text((22,685),'B1/B2 and mirrored B3/B4 no longer intersect in actual mesh-vertex bounds. Hidden wood receivers remain unknown.',font=font,fill='#805534')
d.text((22,735),'This is an explicitly unmeasured exterior visual proposal, not certified assembly/tool access or a complete film.',font=font,fill='#805534');im.save(P/'01-BEFORE-AFTER.jpg',quality=95)
im=Image.new('RGB',(1920,1250),'#f3efe6');d=ImageDraw.Draw(im);d.text((22,10),'BOTH K BRACKETS / CONTACT → FIRST B → SECOND B → BOTH RETAINED',font=big,fill='#292c2f')
for row,side in enumerate(['left','right']):
 for col,index in enumerate([1,4,5,7]):
  x=col*480;y=80+row*570;im.paste(Image.open(stills/f'{side}-stage-{index}.png').convert('RGB').resize((480,270)),(x,y));d.text((x+10,y-25),side.upper()+' / '+['K CONTACT','FIRST B RETAINED','SECOND B ALIGNMENT','BOTH B RETAINED'][col],font=small,fill='#805534')
 d.text((22,y+300),'Six sourceS3 structural parts and twelve D remain fixed. Right shot retains the completed left K/B1/B2.',font=font,fill='#805534')
im.save(P/'02-TWO-BOLT-SEQUENCE.jpg',quality=94)

protected=load(B/'phase-a-v1/evidence/protected-baseline.json');assert all((ROOT/f).exists() and sha(ROOT/f)==h for f,h in protected.items())
historical=[]
for manifest in B.glob('*/REVIEW-DELIVERY-MANIFEST.json'):
 if manifest.parent==P:continue
 for r in load(manifest):
  f=Path(r['path']);f=f if f.is_absolute() else manifest.parent/f;assert sha(f)==r['sha256'];historical.append(dict(revision=manifest.parent.name,file=f.name,match=True))
frozen=[]
for rev,name in [('f-illustrative-proof-v1','FROZEN-LOCAL-PROOF.json'),('part-first-sequence-v1','FROZEN-FOCUSED-PROOF.json'),('timeline-integration-plan-v1','FROZEN-INTEGRATION-PLAN.json'),('timeline-integration-v1','FROZEN-INTEGRATION-EVIDENCE.json')]:
 for f,h in load(B/rev/name)['files'].items():assert sha(f)==h
 frozen.append(rev)
for rev in ['rail-fit-correction-v1','p0-connections-v1','f-illustrative-proof-v1','part-first-sequence-v1','timeline-integration-v1']:
 for f,h in load(B/rev/'SOURCE-FINGERPRINTS.json')['files'].items():assert sha(ROOT/f)==h
save('PROTECTED-ASSET-VERIFICATION.json',dict(status='PASS',paths=len(protected),changes=0,historicalDeliveryFiles=len(historical),frozenProofs=frozen,Product01='UNCHANGED',JULIETTE='UNCHANGED',previousEvidence='UNCHANGED'))
src=ROOT/'src/products/product03-pet-crate-w114586144/s04-two-bolt-proof-v1'
save('SOURCE-FINGERPRINTS.json',dict(files={str(f.relative_to(ROOT)):sha(f) for f in src.glob('*.ts')},sourcePDF=sha(source),genericRenderer=sha(ROOT/'scripts/render-mechanism-diagnostics.ts')))
classified=[]
for r in load(P/'RAW-PATH-AUDIT.json'):
 if r['kind']=='UNRELATED':note='Conservative rotated-local-AABB false positive: precise world-vertex B bounds remain separated on a positive axis. Original raw pair retained; no threshold change/exclusion.'
 elif 'RECEIVING' in r['kind'] or 'K_VS' in r['kind']:note='RAW RECEIVING/K AABB — wood bore/thread/engagement unknown; visible K hole is source-supported but exact clearance unmeasured. Not physical collision PASS.'
 else:note='Concave visible hex-drive AABB; actual source-listed M4 key fits existing B drive with0.07846 side-plane margin in display geometry; not manufacturer tolerance.'
 classified.append(dict(**r,classification=note))
save('RAW-CANDIDATE-CLASSIFICATION.json',classified)
save('HUMAN-AUTHORIZATION.json',{'date':'2026-10-23','provenance':'Direct human message in Codex; not browser response','text':'bước tiếp theo đi và ở như ảnh lắp đủ 2 con ốc thay vì hiện tại đang lắp 1 con ốc','interpretation':'Authorize isolated S04 B/K geometry/tool correction and proof showing BOTH B per K. Overrides prior stop only for this focused scope.','scope':'Offline S04 correction; existing Assemble review exception only; no full-film production/audio/new source acquisition','sourceScreenshot':'evidence/HUMAN-SCREENSHOT.png','priorDecision':'timeline-integration-v1/director-review/DECISION.json'})
(P/'GEOMETRY-AND-ASSUMPTIONS.md').write_text('''# S04 geometry proposal and evidence limits

CONFIRMED: source PDFp5 printed4 S04 shows K×2, B M6×10L×4, one B through each perpendicular face of each K. Its enlarged inset shows a two-face bracket seated at the panel9/divider11 corner. No K dimensions or exact hole coordinates are supplied.

OLD PROTOTYPE: K used two18×18×2 plates, local face-center offset8. Its B centers put the circular heads too close to the inside bend. Original actual solid-overlap witnesses are retained in the previous frozen report. Source does not establish that the real OEM bracket has this defect.

NEW PROPOSAL: only existing K2 mesh proportions change. Each leg22 instead of18, same width18 and thickness2; existing visible circular holes stay radius3, one per face. Vertical leaf center moves[0,8,-8]→[0,10,-10]. Both surfaces still contact the original wood faces exactly. This is a source-compatible UNMEASURED VISUAL PROPOSAL, not dimensions derived from a perspective drawing or an OEM manufacturing specification. It is not a new hardware item, connecting bar or hidden receiver. Director must explicitly review the proposal.

Recomputed placements from the proposed visible K faces: left K[-169,904,220], B1[-169,903,220], B2[-178,894,220]; right mirrored. These are display coordinates. Both B axes are aligned to the SAME existing visible K holes. No hidden wood holes or threads added, no head/shaft sizes changed. All20 part meshes and all hardware/tool geometry except K2 match the accepted baseline. Inventory remains20 components,100 accessory units+3 tools,19 source steps.

Each head retains radius5/depth2.8. A9-unit distance from the inner seating corner bounds its outer radius+depth7.8, providing a1.2-unit separating-axis margin for all head rotations. Actual transformed vertex bounds at the final60° pose separate by~1.202677. These are model-space results, not physical clearances/tolerances. Raw shaft/solid wood and visible-hole AABB candidates remain; actual receiving fit/retention cannot be established.
''')
(P/'MOTION-AND-TOOL-PLAN.md').write_text('''# S04 motion / two-bolt teaching proof

Two14s native720p24fps clips, left then right, combined28s. Same fixed camera throughout each clip; one explicit forward cut. Right scene retains completed left K/B1/B2. Six structural parts and12 D from sourceS3 remain installed. No complete timeline rerender.

K stages55 units in front and35 below, moves into its corner, contacts both fixed wood faces at2.2s; contact hold until2.7. B1 runs2.7–7.2; B2 runs7.7–12.2; both retained to14. Right repeats for B3/B4.

Each bolt: bring through the open front; align its tip to the visible K opening; contact hold; bring L from the open bay; engage; initial symbolic feed/60° illustrative key stroke; exterior seat hold; withdraw along the axis, then down through the open bay. The stroke is not a torque/turn-count specification. The tool is removed only after fully outside the fixed camera. No hand, support fixture or hidden grip is fabricated. Source requires alignment before final tightening; this proof does not certify final retention.

L is the existing source-listed M4 key, not a new driver. Existing B hex drive has across-flats~4.1569 and key across-flats4, giving~0.07846 ideal side-plane margin. Recess fit is a display-model result; no actual OEM tool/socket tolerance claim.

SourceS04 quantity/order association is respected; order of the two B within each K is a disclosed illustrative choice, not a manufacturer-specified screw sequence. Same for the shown working orientation, support and approach curves.
''')
(P/'OPEN-ISSUES.md').write_text('''# Remaining issues

- K length/width/thickness and hole centers remain unmeasured; modified22-unit leg is a visual proposal requiring Director review.
- Exact hidden wood receiving holes, threads, engagement, strength, final tightening, human support and hand/tool envelope are unknown. Raw receiving stock intersections are retained, not certified collision-free.
- The visible K circular opening and nominal6-unit B shaft have ideal nominal tangency in this prototype; mesh tessellation/actual manufacturing clearance is not established. Do not claim physical insertion certification.
- C13/C14 end allocation, source I/J contradiction, F nonliteral representation, S17/S18 retention and S19 pad/door access remain unchanged/open.
- This package changes only isolated S04 proof sources. The accepted264s evaluator remains frozen with its historical S04 HOLD; no automatic whole-timeline integration or full Long/Short/audio authorization follows.
- Product01, JULIETTE and previous evidence preserved. Human alone accepts eventual films.
''')
(P/'DIRECTOR-REVIEW.md').write_text('''# PRODUCT03 — S04 TWO BOLTS PER K / FOCUSED CORRECTION

Review ID: PRODUCT03-S04-TWO-BOLT-PROOF-V1-20261023

Human explicitly reopened the focused next step after your integration STOP: show BOTH bolts at the pictured K interface, rather than leaving the second uninstalled. This is new direct human authority for S04 only; no full-film or general production scope is inferred.

## Actual deliverables

28s720p24fps silent MP4: left14s then right14s, both B individually shown per K, all four retained.672 actual PNG frames,16 source/current review stills and before/after evidence. Fixed camera within each14s clip; one explicit forward cut. Same previously installed module remains; right includes completed left K/B1/B2.

## Proposed correction — explicit limits

Manual PDFp5 shows K2/B4 and two perpendicular fastening faces. It provides no K dimensions. The old prototype had18-unit legs/8-unit center offset and verified head overlap. The NEW ISOLATED PROPOSAL uses22-unit legs/10-unit offset, retaining18 width,2 thickness and existing circular holes. This visibly aligns both B to their respective K faces and keeps contact to unchanged panel9/divider11. The22-unit value is UNMEASURED, not an OEM measurement or a dimension recovered from perspective imagery. Source diagram supports the connection topology, not this numerical geometry. Please explicitly accept/reject this visual approximation.

All B outer heads/full shafts/drive geometry are unchanged, as are all20 part meshes and other hardware/tool geometry. Only existing K2 geometry and K2/B4 transforms change. No new hardware, hidden wood bores, thread, receiver, connecting bar, clipping or manufactured tolerance. Both K wood-contact gaps0; all four modeled head seats0. Final actual-vertex head bounds separated~1.202677 display units. An analytic radius/depth bound separates the heads by at least1.2 independent of their rotation. No physical-fit certification.

L now approaches through the open bay at a near staging distance, rather than crossing the opposite divider from650 units away. Limited60° visual strokes point the short arm away from adjacent stock. It withdraws axially then down through the open bay and leaves the camera before hiding. All12 visibility boundaries are offscreen. The first bolt remains seated during the second.

## QA and unresolved evidence

2802 actual-time samples pass finite transforms/retained state, no premature bolts and deterministic arbitrary/backward seek. Both K contacts0; bolt targets0; engaged tool-axis error<1e-6. Conservative raw AABB audit retained20 candidates, including four B/B conservative bounds candidates. Precise world-transformed mesh vertices prove those sampled B pairs separated; no pair/threshold suppression. Raw receiving stock and concave-drive candidates remain classified; NOT physical collision/access PASS. Two tests and scoped TypeScript pass. A concurrent run exceeded the default5s test initialization budget; original timeout logs are preserved, and the same assertions pass with a20s local test timeout. No collision tolerance/assertion was weakened. Actual media fully decode, zero audio, exact672 frames. Offline capture jobs block all requests and record0 attempts. Protected938 paths and historical/frozen evidence/source hashes match.

K dimensions, visible-hole manufacturing clearance, buried receiving details, real support/hand access and retention remain open. C13/C14, I/J and other existing product holds unchanged. This proof is only exterior illustrative assembly; not certified engineering and not finished film approval.

## Decision requested / stopping boundary

Inspect ACTUAL28s video, byte-preserving ZIP, sourcep5, old one-bolt MP4 frame, old unguarded overlap image and new two-bolt stages. Decide PASS / REVISION_REQUIRED / FAIL for the human's two-bolt S04 visual request and the explicitly unmeasured K proportion proposal. Record precise remaining limits. Do not authorize finalLong/Short/audio or claim a whole-product physical PASS. Close this focused review if adequate; the old264s integration evidence stays frozen. No general Internet, paid service, new source acquisition or Product01/JULIETTE change is authorized.
''')
save('QA-SUMMARY.json',dict(reviewID='PRODUCT03-S04-TWO-BOLT-PROOF-V1-20261023',status='FOCUSED VISUAL PROPOSAL — REQUIRES DIRECTOR REVIEW',sourceB=4,sourceK=2,physicalFit='NOT_CERTIFIED',results=qa['results'],unresolvedUnrelatedCandidates=qa['unresolved'],rawAABBCandidates=qa['rawCandidates'],changedGeometry=['K1','K2'],unchanged='B4;20 numbered parts;all other hardware/tools',fullFilm='NOT RUN'))
files=['DIRECTOR-REVIEW.md','HUMAN-AUTHORIZATION.json','GEOMETRY-AND-ASSUMPTIONS.md','MOTION-AND-TOOL-PLAN.md','OPEN-ISSUES.md','QA-SUMMARY.json','S04-PAIR-AND-MOTION-QA.json','RAW-PATH-AUDIT.json','RAW-CANDIDATE-CLASSIFICATION.json','PRECISE-B-PAIR-REFINEMENT.json','BASELINE-DELTA.json','VISIBILITY-BOUNDARIES.json','MEDIA-QA.json','VIDEO-FRAME-MANIFEST.json','PROTECTED-ASSET-VERIFICATION.json','SOURCE-FINGERPRINTS.json','01-BEFORE-AFTER.jpg','02-TWO-BOLT-SEQUENCE.jpg','evidence/HUMAN-SCREENSHOT.png','evidence/OEM-PDF-P05.png','evidence/ACTUAL-OLD-ONE-BOLT.png','evidence/OLD-UNGUARDED-HEAD-CLASH.png','evidence/tests-frozen.log','evidence/typecheck-frozen.log',*[f.name for f in media]]
files += ['evidence/OEM-PDF-P03.png','evidence/tests-final.log','evidence/tests-concurrent-timeout.log',*[str(f.relative_to(P)) for f in stills.glob('*')]]
for side in ['left','right']:files += [f'final-frames-{side}/{n}' for n in ['selected-diagnostic-manifest.json','offline-network.json']]
for f in src.glob('*.ts'):
 target=P/'evidence/source'/f.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(f,target);files.append(str(target.relative_to(P)))
manifest=[dict(path=n,bytes=(P/n).stat().st_size,sha256=sha(P/n)) for n in files];save('PAYLOAD-SHA256.json',manifest)
z=P/'PRODUCT03-S04-two-bolt-proof-v1-review.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as a:
 for n in files+['PAYLOAD-SHA256.json']:a.write(P/n,n)
with zipfile.ZipFile(z) as a:assert all(hashlib.sha256(a.read(r['path'])).hexdigest()==r['sha256'] for r in manifest)
delivery=[z,combined,P/'DIRECTOR-REVIEW.md',P/'GEOMETRY-AND-ASSUMPTIONS.md',P/'01-BEFORE-AFTER.jpg',P/'02-TWO-BOLT-SEQUENCE.jpg']
save('REVIEW-DELIVERY-MANIFEST.json',[dict(path=str(f.resolve()),bytes=f.stat().st_size,sha256=sha(f)) for f in delivery]);(P/'DELIVERY-SHA256.txt').write_text(''.join(f'{sha(f)}  {f.name}\n' for f in delivery))
print(json.dumps(dict(payloads=len(manifest),zip=z.name,sha256=sha(z),bytes=z.stat().st_size,combined=mediaQA[-1],status='DIRECTOR REVIEW REQUIRED'),indent=2))
