# PRODUCT03 — S04 TWO BOLTS PER K / FOCUSED CORRECTION

Review ID: PRODUCT03-S04-TWO-BOLT-PROOF-V1-20261023

Human explicitly reopened the focused next step after your integration STOP: show BOTH bolts at the pictured K interface, rather than leaving the second uninstalled. This is new direct human authority for S04 only; no full-film or general production scope is inferred.

## Actual deliverables

28s720p24fps silent MP4: left14s then right14s, both B individually shown per K, all four retained.672 actual PNG frames,16 source/current review stills and before/after evidence. Fixed camera within each14s clip; one explicit forward cut. Same previously installed module remains; right includes completed left K/B1/B2.

## Proposed correction — explicit limits

Manual PDFp5 shows K2/B4 and two perpendicular fastening faces. It provides no K dimensions. The old prototype had18-unit legs/8-unit center offset and verified head overlap. The NEW ISOLATED PROPOSAL uses22-unit legs/10-unit offset, retaining18 width,2 thickness and existing circular holes. This visibly aligns both B to their respective K faces and keeps contact to unchanged panel9/divider11. The22-unit value is UNMEASURED, not an OEM measurement or a dimension recovered from perspective imagery. Source diagram supports the connection topology, not this numerical geometry. Please explicitly accept/reject this visual approximation.

All B outer heads/full shafts/drive geometry are unchanged, as are all20 part meshes and other hardware/tool geometry. Only existing K2 geometry and K2/B4 transforms change. No new hardware, hidden wood bores, thread, receiver, connecting bar, clipping or manufactured tolerance. Both K wood-contact gaps0; all four modeled head seats0. Final actual-vertex head bounds separated~1.202677 display units. An analytic radius/depth bound separates the heads by at least1.2 independent of their rotation. No physical-fit certification.

L now approaches through the open bay at a near staging distance, rather than crossing the opposite divider from650 units away. Limited60° visual strokes point the short arm away from adjacent stock. It withdraws axially then down through the open bay and leaves the camera before hiding. All12 visibility boundaries are offscreen. The first bolt remains seated during the second.

## QA and unresolved evidence

2802 actual-time samples pass finite transforms/retained state, no premature bolts and deterministic arbitrary/backward seek. Both K contacts0; bolt targets0; engaged tool-axis error<1e-6. Conservative raw AABB audit retained20 candidates, including four B/B conservative bounds candidates. Precise world-transformed mesh vertices prove those sampled B pairs separated; no pair/threshold suppression. Raw receiving stock and concave-drive candidates remain classified; NOT physical collision/access PASS. Two tests and scoped TypeScript pass. A concurrent run exceeded the default5s test initialization budget; original timeout logs are preserved, and the same assertions pass with a20s local test timeout. No collision tolerance/assertion was weakened. Actual media fully decode, zero audio, exact672 frames. Offline capture jobs block all requests and record0 attempts. Protected938 paths and historical/frozen evidence/source hashes match.

K dimensions, visible-hole manufacturing clearance, buried receiving details, real support/hand access and retention remain open. C13/C14, I/J and other existing product holds unchanged. This proof is only exterior illustrative assembly; not certified engineering and not finished film approval.

## Decision requested / stopping boundary

Inspect ACTUAL28s video, byte-preserving ZIP, sourcep5, old one-bolt MP4 frame, old unguarded overlap image and new two-bolt stages. Decide PASS / REVISION_REQUIRED / FAIL for the human's two-bolt S04 visual request and the explicitly unmeasured K proportion proposal. Record precise remaining limits. Do not authorize finalLong/Short/audio or claim a whole-product physical PASS. Close this focused review if adequate; the old264s integration evidence stays frozen. No general Internet, paid service, new source acquisition or Product01/JULIETTE change is authorized.
