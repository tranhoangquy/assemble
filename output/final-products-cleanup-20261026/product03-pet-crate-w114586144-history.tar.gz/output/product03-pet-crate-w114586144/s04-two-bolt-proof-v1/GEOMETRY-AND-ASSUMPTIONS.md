# S04 geometry proposal and evidence limits

CONFIRMED: source PDFp5 printed4 S04 shows K×2, B M6×10L×4, one B through each perpendicular face of each K. Its enlarged inset shows a two-face bracket seated at the panel9/divider11 corner. No K dimensions or exact hole coordinates are supplied.

OLD PROTOTYPE: K used two18×18×2 plates, local face-center offset8. Its B centers put the circular heads too close to the inside bend. Original actual solid-overlap witnesses are retained in the previous frozen report. Source does not establish that the real OEM bracket has this defect.

NEW PROPOSAL: only existing K2 mesh proportions change. Each leg22 instead of18, same width18 and thickness2; existing visible circular holes stay radius3, one per face. Vertical leaf center moves[0,8,-8]→[0,10,-10]. Both surfaces still contact the original wood faces exactly. This is a source-compatible UNMEASURED VISUAL PROPOSAL, not dimensions derived from a perspective drawing or an OEM manufacturing specification. It is not a new hardware item, connecting bar or hidden receiver. Director must explicitly review the proposal.

Recomputed placements from the proposed visible K faces: left K[-169,904,220], B1[-169,903,220], B2[-178,894,220]; right mirrored. These are display coordinates. Both B axes are aligned to the SAME existing visible K holes. No hidden wood holes or threads added, no head/shaft sizes changed. All20 part meshes and all hardware/tool geometry except K2 match the accepted baseline. Inventory remains20 components,100 accessory units+3 tools,19 source steps.

Each head retains radius5/depth2.8. A9-unit distance from the inner seating corner bounds its outer radius+depth7.8, providing a1.2-unit separating-axis margin for all head rotations. Actual transformed vertex bounds at the final60° pose separate by~1.202677. These are model-space results, not physical clearances/tolerances. Raw shaft/solid wood and visible-hole AABB candidates remain; actual receiving fit/retention cannot be established.
