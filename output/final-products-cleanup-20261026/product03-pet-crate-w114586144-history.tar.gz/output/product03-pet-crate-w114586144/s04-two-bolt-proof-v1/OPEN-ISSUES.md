# Remaining issues

- K length/width/thickness and hole centers remain unmeasured; modified22-unit leg is a visual proposal requiring Director review.
- Exact hidden wood receiving holes, threads, engagement, strength, final tightening, human support and hand/tool envelope are unknown. Raw receiving stock intersections are retained, not certified collision-free.
- The visible K circular opening and nominal6-unit B shaft have ideal nominal tangency in this prototype; mesh tessellation/actual manufacturing clearance is not established. Do not claim physical insertion certification.
- C13/C14 end allocation, source I/J contradiction, F nonliteral representation, S17/S18 retention and S19 pad/door access remain unchanged/open.
- This package changes only isolated S04 proof sources. The accepted264s evaluator remains frozen with its historical S04 HOLD; no automatic whole-timeline integration or full Long/Short/audio authorization follows.
- Product01, JULIETTE and previous evidence preserved. Human alone accepts eventual films.
