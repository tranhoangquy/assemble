# PRODUCT03-LONG-V2-BOUNDED-P0-REPAIR — R2 review

Request: review the actual bounded motion videos and evidence; clear the two gates and authorize full Long V2 only if visually satisfactory. Human continuous execution remains the authority. No human final acceptance claimed.

## Gate 1 — coherent camera, actual images

New versioned camera source `continuous-production-v2-r2` interpolates a common look-at focus and an exterior spherical position path. Fixed contexts face their first essential screw interface, avoiding a rapid half-orbit zoom. S08 context uses a stable post-inversion anchor, with a 2.5s integration exit from the accepted P1 corner macro. Accepted N278s clock and all geometry, materials, actor transforms, tool motion and quantities remain unchanged. No source edits in historical versions.

Actual ExportJobManager videos: V2R2-69-73 (4s/120frames) and V2R2-124-128 (4s/120frames), native1280×720/30fps/silent. Both decode fully. Before/after contact sheets include the actual failed V1 frames. All240 output frames pass the caption-free subject-presence guard. Actual images retain the product through the previously lost views; macro crops are intentional teaching views, not whole-product coverage claims.

R1 was rejected locally for 93 rapid camera samples; its source/evidence remains. R2 scans all8340 native-time camera samples: max angular increment4.49947° and maxposition increment240.671 unmeasured displayunits per30fps frame; zero flags at8°/400 criteria. These are presentation criteria, not physical tolerances. Source-pose equality and arbitrary/backward seek PASS. Camera-center projections supplement actual images, and do not prove visibility through opaque surfaces. Screenshots cover entry/mid/placement/endpoint for all19steps (76nativePNG), including all transitions. C14–18 remain contextual repeats rather than individual macro approvals.

## Gate 2 — correction of an incorrect prior visual finding

**The prior claim that original frame5708 at190.266667s was empty was WRONG.** It contains the product. The supplied original comparison image itself shows the product on both sides. That assertion and the resulting Director response are preserved historically; this document explicitly corrects them.

The new real ExportJobManager replay185–193s (8s/240frames, two fresh browser generations) reproduces the original full-export frame5708 **byte-for-byte** at replay frame158. Across the window,232/240PNG are byte-identical; eight differ only by6RGB levels in ONE caption pixel at(47,651). Product-region pixels match throughout all240frames. No absent-product frame, context loss or GLerror was observed. There is no evidenced GPU/exporter defect or established technical root cause to repair here. This is an operator interpretation/reporting error, not an engineering discovery.

A product-owned PNG guard still rejects absent subjects before checkpoint/encode. It is calibrated against actual failed V1 S05 and actual valid S14, excluding headers/captions (y65–534): >=.5% foreground at RGBdistance>30 from233/230/223. It catches blank-product output, not every crop, occlusion or mechanical error. Raw rejected images/telemetry are retained if triggered; the shared manager supplies bounded retry. V2 additionally records context/readiness/drawcalls/camera perframe and waits for GL completion. Shared engine/exporter unchanged.

## Preservation and limits

PROTECTED-ASSET-QA covers acceptedP1/N/P2P3, Product01/JULIETTE and rejected LongV1 including all8340nativeframes. No changes. Existing19OEMsteps,20componentinstances,103listedhardware/tool units remain. Generic package metadata120placementrows plus3controller-owned tools is not an inventory loss.

K22/10 UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN; S17/S18 POSE-ONLY; S19 pads/door HOLD; historical raw collisionFAIL remain. No receiver/thread/torque/access/retention/load/capacity certification. No new mechanical solution, audio, final Long/Short, research, purchase or publishing. Future LongV2 must be rendered and reviewed in full; these bounded proofs do not approve the whole film.
