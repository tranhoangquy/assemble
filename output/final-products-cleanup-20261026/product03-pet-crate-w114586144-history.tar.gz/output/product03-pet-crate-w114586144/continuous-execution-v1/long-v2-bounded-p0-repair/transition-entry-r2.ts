import './diagnostic-config';
import '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v2-r2/full-long-preview';
import {steps} from '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/option-n-runtime';
const checkpoints=steps.flatMap(s=>[{name:`${s.id}-entry.png`,time:s.start+.02,label:'entry'},{name:`${s.id}-mid.png`,time:s.start+1.2666666667,label:'transition'},{name:`${s.id}-placed.png`,time:Math.min(s.end-.01,s.start+3),label:'placed'},{name:`${s.id}-endpoint.png`,time:s.end-1/30,label:'endpoint'}]);
window.__MECHANISM_AUDIT_RENDERER__={ready:true,checkpoints,async render(name){const c=checkpoints.find(x=>x.name===name)!;await window.__VIDEO_RENDERER__!.renderFrame(c.time);return{...c,camera:window.__VIDEO_RENDERER__!.getCameraState?.(),state:window.__VIDEO_RENDERER__!.getSceneState?.()};}};
