import '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/full-long-preview';
import {capturePackage} from '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v2/full-long-package';
declare const __P03_START__:number;declare const __P03_END__:number;
const original=window.__VIDEO_RENDERER__!,frame=original.renderFrame.bind(original),pkg=capturePackage(__P03_START__,__P03_END__);
original.duration=__P03_END__-__P03_START__;original.getDuration=()=>original.duration;original.getCreativeDefinition=()=>({product:pkg.product,assembly:pkg.assembly,video:pkg.video});
let time=-1;
original.renderFrame=async t=>{await frame(t+__P03_START__);time=t+__P03_START__;};
(window as unknown as {__P03_TELEMETRY__:()=>unknown}).__P03_TELEMETRY__=()=>{const c=document.querySelector('canvas')!,gl=c.getContext('webgl2');return{time,ready:original.ready,contextLost:gl?.isContextLost(),glError:gl?.getError(),drawingBuffer:[gl?.drawingBufferWidth,gl?.drawingBufferHeight],camera:original.getCameraState?.(),state:original.getSceneState?.()};};
