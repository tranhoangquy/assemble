from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib,subprocess,zipfile
root=Path.cwd();p=root/'output/product03-pet-crate-w114586144/continuous-execution-v1/long-v2-bounded-p0-repair';base=p.parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();load=lambda f:json.loads(f.read_text())
checks=[]
for f in [root/'output/product03-pet-crate-w114586144/phase-a-v1/evidence/protected-baseline.json',base/'p1-camera-only-v1/FROZEN-P1-CAMERA-PILOT.json',base/'option-n-timing-isolated-v1/FROZEN-OPTION-N-TIMING.json',base/'p2-p3-camera-only-v1/FROZEN-P2-P3-CAMERA.json',base/'full-19-step-integration-v1/FROZEN-REJECTED-LONG-V1.json']:
 d=load(f);files=d.get('files',d)
 for n,h in files.items():
  f2=Path(n);f2=f2 if f2.is_absolute()else root/f2
  assert sha(f2)==h,n
  checks.append(n)
(p/'PROTECTED-ASSET-QA.json').write_text(json.dumps({'status':'PASS','checks':len(checks),'changes':0,'scope':'Product01/JULIETTE,acceptedP1/N/P2P3, rejectedLongV1 including all8340nativeframes/source/actualdecision; prior rawFAIL preserved'},indent=2))
qa=[]
for folder in ['V2R2-69-73','V2R2-124-128','V1-REPLAY-185-193']:
 d=p/folder;j=load(d/'COMPLETED-JOB.json');video=d/(folder+'.mp4')
 probe=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(video)]));s=probe['streams'];assert len(s)==1 and s[0]['codec_type']=='video';assert int(s[0]['nb_read_frames'])==j['totalFrames'];assert s[0]['width']==1280 and s[0]['height']==720
 subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(video),'-f','null','-'],check=True,capture_output=True)
 rows=[json.loads(x) for x in (d/'CAPTURE-TELEMETRY.ndjson').read_text().splitlines()];assert len(rows)==j['totalFrames'];assert all(x['metric']['pass'] and not x['telemetry']['contextLost'] and not x['telemetry']['glError'] for x in rows)
 qa.append({'name':video.name,'sha256':sha(video),'frames':j['totalFrames'],'duration':float(probe['format']['duration']),'codec':s[0]['codec_name'],'fps':s[0]['avg_frame_rate'],'audio':False,'fullDecode':'PASS','allFramesSubjectGuard':'PASS','minimumForegroundRatio':min(x['metric']['ratio'] for x in rows),'retries':0})
(p/'PROOF-QA.json').write_text(json.dumps(qa,indent=2))
for start,end in [(69,73),(124,128)]:
 f=next((p/f'V2R2-{start}-{end}').glob('render-jobs/*/frames'));items=[]
 for n in [0,15,30,38,60,90,119]:items.append((f'R2 {start+n/30:.4f}s',f/f'frame-{n:06d}.png'))
 oldIndex=2108 if start==69 else 3777;items.append((f'V1 {oldIndex/30:.4f}s',next((base/'full-19-step-integration-v1').glob(f'render-jobs/*/frames/frame-{oldIndex:06d}.png'))))
 im=Image.new('RGB',(1704,540),'#eee9e0');dr=ImageDraw.Draw(im)
 for k,(label,filename) in enumerate(items):t=Image.open(filename).convert('RGB');t.thumbnail((426,240));x=k%4*426;y=k//4*270;im.paste(t,(x,y));dr.text((x+8,y+244),label,fill='black')
 im.save(p/f'R2-CAMERA-{start}-{end}-BEFORE-AFTER.jpg',quality=92)
for suffix in ['entry','mid','placed','endpoint']:
 files=sorted((p/'all19-native-r2').glob(f'*-{suffix}.png'));assert len(files)==19
 im=Image.new('RGB',(1600,1200),'#eee9e0');dr=ImageDraw.Draw(im)
 for k,f in enumerate(files):t=Image.open(f).convert('RGB');t.thumbnail((400,225));x=k%4*400;y=k//4*240;im.paste(t,(x,y));dr.text((x+6,y+226),f.stem,fill='black')
 im.save(p/f'ALL19-R2-{suffix}.jpg',quality=94)
print(json.dumps({'protected':len(checks),'qa':qa},indent=2))
