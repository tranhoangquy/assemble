from pathlib import Path
from PIL import Image,ImageDraw,ImageChops,ImageStat
import json,hashlib,subprocess
p=Path(__file__).resolve().parent;d=p/'silent-render-r2';root=p.parents[3];base=p.parent;load=lambda f:json.loads(f.read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();run=lambda a:subprocess.check_output(a)
j=load(d/'COMPLETED-JOB.json');assert j['totalFrames']==1770 and j['fps']==30 and abs(j['timelineDuration']-59)<1e-9
jd=Path(j['frameDirectory']).parent;m=load(jd/'manifest.json');assert len(m['frames'])==1770 and not m['missingFrames']and not m['invalidFrames'];f=d/'PRODUCT03-Short-native-v1-silent-1080x1920.mp4';assert sha(f)==j['sha256'];v=load(jd/'logs/verification.json');assert v['fullDecode']=='PASS'and v['faststart']=='PASS';streams=v['media']['streams'];assert len(streams)==1 and streams[0]['width']==1080 and streams[0]['height']==1920 and int(streams[0]['nb_read_frames'])==1770
pts=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(f)]))['frames'];assert len(pts)==1770 and all(abs(float(x['best_effort_timestamp_time'])-i/30)<1e-6 for i,x in enumerate(pts))
tele=[json.loads(x)for x in (d/'CAPTURE-TELEMETRY.ndjson').read_text().splitlines()];assert len(tele)==1770
assert all(x['metric']['pass']and not x['telemetry']['contextLost']and x['telemetry']['glError']==0 and abs(x['telemetry']['shortTime']-i/30)<1e-9 and x['telemetry']['drawingBuffer']==[1080,1920]for i,x in enumerate(tele))
shots=load(p/'SOURCE-AND-CAMERA-QA.json')['shots'];assert load(p/'SOURCE-AND-CAMERA-QA.json')['status']=='PASS'
for i,x in enumerate(tele):
 t=i/30;s=next(s for s in shots if t>=s['start']and t<s['end']);expected=s['hold']if 'hold'in s and 'sourceEnd'not in s else s['source']+t-s['start'];expected=s['hold']if 'sourceEnd'in s and expected>=s['sourceEnd']else expected;assert abs(x['telemetry']['sourceTime']-expected)<1e-8
 if s['id']=='door2':assert x['telemetry']['door1']
 b=x['telemetry']['captionBounds']['panel'];assert b['left']>=72 and b['right']<=930.001 and b['bottom']<=1652.001 and b['top']>=1250
indices=sorted(set([0,1769]+[max(0,min(1769,round(t*30)+offset))for s in shots for t in [s['start'],s['end']]for offset in [-1,0,1]]+[round(t*30)for t in [6.25,6.6,8.5,9.18,11.75,20.5,23.35,25.5,28.35,30.5,32.2,33.55,35,36.85,38.5,39.6,40.6,41.6,42.6,44.6,45.6,46.6,47.8,48.7,49.9,50.7,51.8,52.79,53.2,53.9,54.6,55.5,58.9]]));decoded=d/'decoded-review';decoded.mkdir(exist_ok=True)
def balanced(a):
 if len(a)==1:return a[0]
 mid=len(a)//2;return '('+balanced(a[:mid])+'+'+balanced(a[mid:])+')'
expr=balanced(['eq(n'+chr(92)+','+str(i)+')'for i in indices]);run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-i',str(f),'-vf','select='+expr,'-fps_mode','passthrough','-start_number','0',str(decoded/'frame-%03d.png')]);assert len(list(decoded.glob('*.png')))==len(indices);rows=[]
for k,i in enumerate(indices):
 src=Path(j['frameDirectory'])/f'frame-{i:06d}.png';assert sha(src)==m['frames'][str(i)];a=Image.open(src).convert('RGB');b=Image.open(decoded/f'frame-{k:03d}.png').convert('RGB');assert a.size==b.size==(1080,1920);diff=ImageStat.Stat(ImageChops.difference(a,b)).mean;rows.append({'index':i,'time':i/30,'shot':tele[i]['telemetry']['shot'],'sourceTime':tele[i]['telemetry']['sourceTime'],'decoded':f'decoded-review/frame-{k:03d}.png','meanRGBencodeError':sum(diff)/3})
for page in range((len(rows)+11)//12):
 subset=rows[page*12:(page+1)*12];im=Image.new('RGB',(1440,2070),'#eee9e0');draw=ImageDraw.Draw(im)
 for k,x in enumerate(subset):a=Image.open(d/x['decoded']).convert('RGB');a.thumbnail((360,640));xx=k%4*360;yy=k//4*690;im.paste(a,(xx,yy));draw.text((xx+4,yy+645),f"{x['time']:.4f}s / {x['shot']}",fill='black')
 im.save(d/f'ACTUAL-SHORT-SHEET-{page+1:02d}.jpg',quality=94)
(d/'ACTUAL-MP4-FRAME-QA.json').write_text(json.dumps(rows,indent=2))
protected=[]
for f2 in [root/'output/product03-pet-crate-w114586144/phase-a-v1/evidence/protected-baseline.json',base/'full-19-step-integration-v2/FROZEN-LONG-V2-CANDIDATE.json',base/'full-19-step-integration-v2/FROZEN-LONG-V2-INTERNAL-PASS.json']:
 dic=load(f2);dic=dic.get('files',dic)
 for n,h in dic.items():z=Path(n);z=z if z.is_absolute()else root/z;assert sha(z)==h;protected.append(n)
for n,h in load(d/'INPUT-FREEZE.json')['files'].items():
 if n!='BUNDLE':assert sha(root/n)==h
assert not (p/'evidence/typecheck-final.log').read_text().strip();network=load(d/'OFFLINE-NETWORK-QA.json');assert network['externalRequestsTransmitted']==0
q={'status':'NATIVE CAPTURE / TECHNICAL PASS — ACTUAL DIRECTOR VISUAL REVIEW REQUIRED','file':f.name,'sha256':sha(f),'duration':59,'native':[1080,1920],'fps':30,'frames':1770,'audio':False,'fullDecode':'PASS','PTS':'PASS all1770','faststart':'PASS','chunks':len(m['chunks']),'retries':m['retries'],'allCaptureTimesAndSourceWindows':'PASS','allCaptionPanelsSafe':'PASS','sourcePoseAndSeek':'PASS','actorRetention':'PASS afterexplicitinitialreset','D1StopsBeforeD2':'PASS','bothBsameK':'PASS','A5host5RelativeOffset':'PASS displayonly','door1RetainedDuringDoor2':'PASS','graphicsOnlyR2':'60/60sceneROI pixel-identical to initialpreflight; contrastplatesonly','allFramesSubjectGuard':'PASS; not fullocclusion/compositioncertification','minForegroundRatio':min(x['metric']['ratio']for x in tele),'GLerrors':0,'contextLoss':0,'sampledActualMP4Frames':len(rows),'maxMeanRGBencodeError':max(x['meanRGBencodeError']for x in rows),'protectedChecks':len(protected),'changes':0,'reviewLimit':'Sampled-image screening+technicaldecode; no fabricated continuousplayback or physicalcertification','holds':['K22/10UNMEASURED','FNONLITERAL','C13/C14OPEN','I/JOPEN','S17/S18POSEONLY','S19pads/doorHOLD','historicalrawcollisionFAIL'],'C13ScopeClarification':'189.25–192.25 showsframe5placement context only; C13fastening begins192.6 and is omitted. NoShortclaim of verified C13installation.'};(d/'SHORT-QA.json').write_text(json.dumps(q,indent=2));print(json.dumps(q,indent=2))
