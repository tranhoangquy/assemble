import '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/p2-p3-preview';
const a=window.__MECHANISM_AUDIT_RENDERER__!;a.checkpoints.splice(0,a.checkpoints.length,...[193.75,195.5,208.5,218.5,227.95].map((time,i)=>({name:`camera-frame-${i}.png`,time,label:'native preflight r2'})));
