from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,zipfile,shutil
P=Path(__file__).resolve().parent;ROOT=P.parents[3];R=ROOT/'output/product03-pet-crate-w114586144';N=P.parent/'option-n-timing-isolated-v1'
def load(f):return json.loads(f.read_text())
def sha(f):return hashlib.file_digest(f.open('rb'),'sha256').hexdigest()
qa=load(P/'CAMERA-CAPTURE-QA.json');cam=load(P/'CAMERA-QA.json');assert qa['status']=='PASS'and cam['status']=='PASS'
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',20);selected=[]
sets={'P2':[185.5,187.75,190,192,193.75,195.5,203.5,208.4583333],'P3':[208.5,210.5,211.75,214.7,215.75,218.5,224.4,227.95]}
for proof in load(P/'BASELINE-AND-CAPTURE-IDENTITY.json')['proofs']:
 pid=proof['id']
 for page in range(2):
  im=Image.new('RGB',(1600,1085),'#ede8df');d=ImageDraw.Draw(im);d.text((16,16),f'{pid} CAMERA ONLY | LEFT: accepted N | RIGHT: newcamera | same N time',font=font,fill='#24292b')
  for j,t0 in enumerate(sets[pid][page*4:(page+1)*4]):
   i=max(0,min(proof['frames']-1,round((t0-proof['start'])*24)));t=proof['start']+i/24;y=65+j*255
   for x,base,label in [(0,N,'BEFORE'),(800,P,'AFTER')]:
    f=base/'frames'/pid/f'frame-{i:06d}.png'
    with Image.open(f)as a:im.paste(a.convert('RGB').resize((800,225)),(x,y))
    d.text((x+8,y+229),f'{label} frame{i} / global N {t:.6f}s',font=font,fill='#684b31')
   dest=P/'selected-originals'/pid;dest.mkdir(parents=True,exist_ok=True);f=P/'frames'/pid/f'frame-{i:06d}.png';dst=dest/f.name;shutil.copyfile(f,dst);selected.append(dict(proof=pid,index=i,time=t,path=str(dst.relative_to(P)),sha256=sha(dst)))
  im.save(P/f'CAMERA-COMPARISON-{pid}-{page+1}.jpg',quality=94)
(P/'SELECTED-ORIGINALS.json').write_text(json.dumps(selected,indent=2))
checks=[]
for freeze in [N/'FROZEN-OPTION-N-TIMING.json',P.parent/'p1-camera-only-v1/FROZEN-P1-CAMERA-PILOT.json']:
 for name,h in load(freeze)['files'].items():assert sha(ROOT/name)==h;checks.append(name)
for name,h in load(R/'phase-a-v1/evidence/protected-baseline.json').items():
 f=Path(name);f=f if f.is_absolute()else ROOT/f;assert sha(f)==h;checks.append(name)
for name,h in load(P/'BASELINE-AND-CAPTURE-IDENTITY.json')['sourceFiles'].items():assert sha(ROOT/name)==h;checks.append(name)
(P/'PROTECTED-VERIFICATION.json').write_text(json.dumps(dict(status='PASS',checked=len(checks),changes=0,Product01='UNCHANGED',JULIETTE='UNCHANGED',frozenN='UNCHANGED',frozenP1Camera='UNCHANGED',historicalCollisionFAIL='PRESERVED'),indent=2))
(P/'VISUAL-FINDINGS.md').write_text('''# P2/P3 actual camera-only correction

C13 native frames now expose the exterior head/tool contact and L key silhouette beside the front rail. Final lower oblique camera is240normal−400side+35Y at26degreesFOV, all display-space composition only. Projected head-object bounds25–31px wide at selected aligned/feed/hold times; bounding boxes are a proxy, not proof that every drive pixel is visible. Exterior targets/receiving allocation remain OPEN.

P2 fixed context shows carrier5 sliding laterally outside the posts then approaching in depth; A5 remains attached at the original relative pose. A5 is small in context; first teaching close-up is the separately approved P1. C14–18 remain contextual repeats, not a new individual-macro PASS. Upright return and unfastened floor retain source motion; after floor contact the camera eases closer for doors.

P3 uses one stable camera per E1/E2,E3/E4,E5/E6,E7/E8 pair. The first door remains in the source and is visible in the wide handover while the second arrives. Upper-leaf approach begins during the0.5s upward pan; visibility of that repeated initial tip-alignment phase still needs actual Director judgement. No added door swing or retention-release mechanism. Tool-free verification precedes handover pullback using accepted N plateau time.

The wider context is retained between macros. Full native frames show the product tightly framed at the doorway handovers; later production caption/layout must preserve margins and avoid masking feet. Diagnostic HUD is unchanged in this isolated comparator.

Initial calibration had38 camera motion flags including a near-reversal at C13; raw QA and native trials preserved. Refined oblique angle/longer ease/closer door wide yields0 flags, max5.395degrees and299.060displayunits/frame at24fps under declared6degree/300unit review thresholds. This numerical result does not certify smooth perceived playback. Pose equality passes all1080sampletimes including entry/exit buffers;208.5 seam maxpositionerror6.9e−13 and quaternionerror4.3e−8rad.

Entry184–185/exit228–229camera-only buffers are not included in attached43sP2/P3. Full integration must inspect them, the accepted P1buffers, D33–39 and all19steps. No graphics/timing/geometry correction in this iteration.

K22/10UNMEASURED;FNONLITERAL;C13/C14,I/JOPEN;S17/18POSE-ONLY;S19HOLD;rawcollisionFAIL remain. No physical-fit/toolaccess/retention/torque certification.
''')
(P/'DIRECTOR-REVIEW.md').write_text('''# PRODUCT03-P2-P3-CAMERA-ONLY-CORRECTION-V1

Two actual new silent MP4s attached:185–208.5s/564frames and208.5–228s/468frames, native1280×720/24fps,total43s/1032frames. Accepted OptionN clock/actors/geometry/graphics remain unchanged. Only product-owned camera wrapper differs. Full decode/PTS/nativeframe/chunkseam QA PASS,0externalrequests. All1080sampled actor digests equal N, including camera buffers;source typecheck/lint PASS. Same-N-time before/after sheets attached.

C13 lower oblique shows Lkey/exterior target. Fixed context preserves carrier5/A5 path/upright/floor. One stable view per Ehingeleafpair, wide handover retains firstdoor. Knownlimits: C14–18 contextualrepeat; A5smallinwide but separately taughtP1; upperleaf tipapproach overlaps pan; tightwide framing/HUD to be addressed for production. Please inspect actual videos before visual decision; exact details in VISUAL-FINDINGS.md. No claim of flawless continuous playback from numerical continuity alone.

If accepted, next automatically integrate acceptedP1camera + Ntiming + P2/P3camera, inspect buffers/D33–39 and all19steps/retained states/visible hardware/sourceHOLDs, then author complete Long and nativeportrait Short via existing resumable exporter. We propose tasteful production typography replacing diagnostic HUD, illustrative-source disclosure and explicit S17–19 HOLD treatment (no fabricated final function). Request your creative direction for truthful finished-film treatment and next scoped internal gate. Human continuous execution is active; no routine human permission request.

All physical OPEN/HOLD/rawFAIL remain; no production acceptance or humanfinalacceptance claimed. ActualMP4s are uploaded separately; evidenceZIP includes selected nativePNG, reports,QA and SHAmanifest, not duplicatedMP4payloads.
''')
files=[*P.glob('CAMERA-COMPARISON-*.jpg'),P/'DIRECTOR-REVIEW.md',P/'VISUAL-FINDINGS.md',P/'CAMERA-QA.json',P/'CAMERA-CAPTURE-QA.json',P/'PROTECTED-VERIFICATION.json',P/'BASELINE-AND-CAPTURE-IDENTITY.json',P/'CHUNK-SEAM-QA.json',P/'FRAME-SHA256-MANIFEST.json',P/'SELECTED-ORIGINALS.json',P/'evidence/CAPTURE-OUTPUT-ISOLATION.json',*P.glob('selected-originals/*/*.png')]
mp4=list(P.glob('*.mp4'));manifest=[dict(path=str(f.relative_to(P)),sha256=sha(f),bytes=f.stat().st_size,delivery='separate actual MP4 attachment'if f.suffix=='.mp4'else'evidence ZIP')for f in [*files,*mp4]];(P/'DELIVERY-SHA256.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(P/'PRODUCT03-P2-P3-CAMERA-EVIDENCE.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in [*files,P/'DELIVERY-SHA256.json']:z.write(f,str(f.relative_to(P)))
print(json.dumps(dict(media=qa['media'],zipSha256=sha(P/'PRODUCT03-P2-P3-CAMERA-EVIDENCE.zip')),indent=2))
