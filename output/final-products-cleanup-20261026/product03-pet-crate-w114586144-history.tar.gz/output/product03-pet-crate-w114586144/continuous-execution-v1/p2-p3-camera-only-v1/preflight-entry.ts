import '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/p2-p3-preview';
const a=window.__MECHANISM_AUDIT_RENDERER__!;a.checkpoints.splice(0,a.checkpoints.length,...[185.5,187.75,190,192,193.75,195.5,208.4583333333,208.5,211.75,214.7,215.75,218.5,222,224.4,226.5,227.95].map((time,i)=>({name:`camera-frame-${i}.png`,time,label:'native preflight'})));
