# P2/P3 actual camera-only correction

C13 native frames now expose the exterior head/tool contact and L key silhouette beside the front rail. Final lower oblique camera is240normal−400side+35Y at26degreesFOV, all display-space composition only. Projected head-object bounds25–31px wide at selected aligned/feed/hold times; bounding boxes are a proxy, not proof that every drive pixel is visible. Exterior targets/receiving allocation remain OPEN.

P2 fixed context shows carrier5 sliding laterally outside the posts then approaching in depth; A5 remains attached at the original relative pose. A5 is small in context; first teaching close-up is the separately approved P1. C14–18 remain contextual repeats, not a new individual-macro PASS. Upright return and unfastened floor retain source motion; after floor contact the camera eases closer for doors.

P3 uses one stable camera per E1/E2,E3/E4,E5/E6,E7/E8 pair. The first door remains in the source and is visible in the wide handover while the second arrives. Upper-leaf approach begins during the0.5s upward pan; visibility of that repeated initial tip-alignment phase still needs actual Director judgement. No added door swing or retention-release mechanism. Tool-free verification precedes handover pullback using accepted N plateau time.

The wider context is retained between macros. Full native frames show the product tightly framed at the doorway handovers; later production caption/layout must preserve margins and avoid masking feet. Diagnostic HUD is unchanged in this isolated comparator.

Initial calibration had38 camera motion flags including a near-reversal at C13; raw QA and native trials preserved. Refined oblique angle/longer ease/closer door wide yields0 flags, max5.395degrees and299.060displayunits/frame at24fps under declared6degree/300unit review thresholds. This numerical result does not certify smooth perceived playback. Pose equality passes all1080sampletimes including entry/exit buffers;208.5 seam maxpositionerror6.9e−13 and quaternionerror4.3e−8rad.

Entry184–185/exit228–229camera-only buffers are not included in attached43sP2/P3. Full integration must inspect them, the accepted P1buffers, D33–39 and all19steps. No graphics/timing/geometry correction in this iteration.

K22/10UNMEASURED;FNONLITERAL;C13/C14,I/JOPEN;S17/18POSE-ONLY;S19HOLD;rawcollisionFAIL remain. No physical-fit/toolaccess/retention/torque certification.
