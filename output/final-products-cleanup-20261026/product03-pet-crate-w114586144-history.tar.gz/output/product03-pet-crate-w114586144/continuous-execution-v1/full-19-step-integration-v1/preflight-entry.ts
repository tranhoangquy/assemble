import '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/full-long-preview';
import {steps,hardware} from '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/option-n-runtime';
const api=window.__MECHANISM_AUDIT_RENDERER__!,times=[...steps.map(s=>s.end-1/24),...steps.flatMap(s=>{const h=hardware.find(h=>h.step===s.number&&h.kind==='threaded');return h?[h.start+.6*(h.end-h.start)]:[];}),41.5,53.75,54.75,55.5,68.5,106.5,108,109.5,110.2,124,125,126,131.95,183.5,184.5,193.75,195.5,208.4583333,208.5,214.7,215.2,218.5,224.4,227.8,228.5,229.5,231,240,246,253,264.5,266.5,274];
api.checkpoints.splice(0,api.checkpoints.length,...times.map((time,i)=>({name:`preflight-frame-${i}.png`,time,label:`Native Long preflight ${time}s`})));
