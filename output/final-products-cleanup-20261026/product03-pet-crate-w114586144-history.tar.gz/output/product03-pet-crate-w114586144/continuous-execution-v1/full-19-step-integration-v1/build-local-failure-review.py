from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,subprocess,zipfile,shutil
P=Path(__file__).resolve().parent;ROOT=P.parents[3];j=json.loads((P/'COMPLETED-RENDER-JOB.json').read_text());D=Path(j['frameDirectory'])
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
steps=load(P.parent/'option-n-timing-isolated-v1/TIMING-QA.json')['steps'];font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',19);im=Image.new('RGB',(1920,70+5*300),'#eee9e0');draw=ImageDraw.Draw(im);draw.text((16,16),'ACTUAL LONG V1 / ALL19 STEP TRANSITION MIDPOINTS / RAW NATIVE FRAMES',font=font,fill='#252a2c')
for k,s in enumerate(steps):
 index=round((s['start']+1.25)*30);f=D/f'frame-{index:06d}.png';x=k%4*480;y=70+k//4*300
 with Image.open(f)as a:im.paste(a.convert('RGB').resize((480,270)),(x,y))
 draw.text((x+7,y+274),f"{s['id']} / f{index} / {index/30:.6f}s",font=font,fill='#6e4b30')
im.save(P/'ALL19-TRANSITION-MIDPOINTS.jpg',quality=94)
clips=[]
for name,frames,start,end in [('P0-01-S05-camera-loss-68.5-72.5.mp4',120,68.5,72.5),('P0-02-S08-context-loss-124.5-127.5.mp4',90,124.5,127.5)]:
 f=P/name;probe=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(f)]));assert len(probe['streams'])==1 and int(probe['streams'][0]['nb_read_frames'])==frames;clips.append(dict(file=name,globalStart=start,globalEnd=end,frames=frames,fps=30,audio=0,sha256=sha(f),derivation='Accurate decoded trim/reencode of actual completed fullLongV1; no new3Dcapture, no retiming; sourceSHA='+j['sha256']))
(P/'P0-CLIP-QA.json').write_text(json.dumps(clips,indent=2))
files=[P/'DIRECTOR-REVIEW-LOCAL-FAILURE.md',P/'LOCAL-VISUAL-FAILURE-AND-V2-PLAN.md',P/'P0-CLIP-QA.json',P/'ALL19-TRANSITION-MIDPOINTS.jpg',P/'S14-RENDER-PATH-DISCREPANCY.jpg',P/'FRAMING-DIAGNOSIS.json',P/'native-framing-repro/selected-diagnostic-manifest.json',P/'native-video-api-repro/selected-diagnostic-manifest.json',P/'native-framing-repro/repro-frame-0.png',P/'native-video-api-repro/video-api-frame-0.png',P/'evidence/ACTUAL-CAMERA-TRANSITION-CHECK-01.jpg',P/'EXPORT-ADAPTER-AND-SCOPE.md',P/'PRE-RENDER-GATE.json',P/'PRE-RENDER-QA.json',P/'SOURCE-REGISTRY-COUNT-QA.json',P/'RENDER-INPUT-FREEZE.json',P/'evidence/RENDER-STOP-SNAPSHOT.json']
for name in ['FULL-LONG-QA.json','PROTECTED-ASSET-VERIFICATION.json','ACTUAL-MP4-REVIEW-FRAMES.json']:
 f=P/name
 if f.exists():files.append(f)
files += sorted(P.glob('CONTACT-SHEET-LONG-*.jpg'))
files += sorted(P.glob('decoded-review-frames/sample-*.png'))[::4]
media=[P/'PRODUCT03-Long-integrated-v1-silent-720p.mp4',*[P/c['file']for c in clips]]
manifest=[dict(path=str(f.relative_to(P)),sha256=sha(f),bytes=f.stat().st_size,delivery='SeparateactualMP4'if f in media else'ZIP')for f in[*files,*media]];(P/'FAILURE-REVIEW-SHA256.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(P/'PRODUCT03-FULL-LONG-V1-P0-EVIDENCE.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in[*files,P/'FAILURE-REVIEW-SHA256.json']:z.write(f,str(f.relative_to(P)))
print(json.dumps(dict(fullLongSHA=j['sha256'],clips=clips,zipSHA=sha(P/'PRODUCT03-FULL-LONG-V1-P0-EVIDENCE.zip')),indent=2))
