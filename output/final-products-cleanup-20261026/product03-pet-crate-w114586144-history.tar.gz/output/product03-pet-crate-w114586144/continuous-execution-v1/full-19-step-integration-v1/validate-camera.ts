import * as T from 'three';import {writeFileSync} from 'node:fs';
import {createRuntime,steps,hardware} from '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/option-n-runtime';
import {createFilmCamera} from '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/full-camera';
import {ProductManager} from '../../../../src/engine/product/ProductManager';
import {longPackage} from '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/full-long-package';
const manager=new ProductManager([longPackage]);const pkg=manager.load(longPackage.id);if(pkg.video.scenes.reduce((a,s)=>a+s.duration,0)!==278)throw Error('duration');
const r=createRuntime(),track=createFilmCamera(r),deltas=[],rows=[];let previous:T.PerspectiveCamera|undefined,maxAngle=0,maxShift=0;
// Camera-only numeric scan at every actual Long frame. Source pose equality is
// sampled separately at every operation/boundary and reverse-seek checkpoint.
for(let i=0;i<6672;i++){const t=i/24;r.evaluate(t);const c=track.camera(t);if(previous){const angle=T.MathUtils.radToDeg(previous.quaternion.angleTo(c.quaternion)),shift=previous.position.distanceTo(c.position);maxAngle=Math.max(maxAngle,angle);maxShift=Math.max(maxShift,shift);if(angle>6||shift>300)deltas.push({frame:i,time:t,angle,shift});}previous=c;}
let equality=true,deterministic=true;
const times=[0,278,...steps.flatMap(s=>[s.start+.001,s.end-.001]),...hardware.flatMap(h=>[h.start+.001,h.start+.5*(h.end-h.start),h.end-.001]),106.5,108,124,125,126.2,132,183,184,185,203,208.375,208.5,228,229];
for(const t of times){const state=r.evaluate(t),before=JSON.stringify(r.digest());track.camera(t);const match=before===JSON.stringify(r.digest());equality&&=match;r.evaluate(278-t);r.evaluate(t);deterministic&&=before===JSON.stringify(r.digest());rows.push({time:t,poseEqual:match,step:state.step,installed:state.installed.length,seated:state.hardwareSeated.length,poseOnly:state.posedHeld.length,held:state.pending.length});}
const result={status:equality&&deterministic&&!deltas.length?'PASS':'REVIEW_REQUIRED',duration:278,expectedFrames:8340,outputFPS:30,cameraScanFPS:24,cameraFramesScanned:6672,maxAngle,maxShift,deltas,sourcePoseEqual:equality,arbitrarySeekDeterministic:deterministic,poseSamples:rows,registryCount:pkg.product.parts.length,OEMStepCount:pkg.assembly.steps.length,assemblyGraph:manager.validation(pkg.id),contract:track.contract,qualifications:'Illustrative only; all raw collisionFAIL and OPEN/HOLD unchanged; this is not a mechanical PASS'};writeFileSync(new URL('PRE-RENDER-QA.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify({status:result.status,maxAngle,maxShift,flags:deltas.length,equality,deterministic}));
