from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parent;ROOT=P.parents[3];R=ROOT/'output/product03-pet-crate-w114586144'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
q=load(P/'PRE-RENDER-QA.json');assert q['status']=='PASS'and q['sourcePoseEqual']and q['arbitrarySeekDeterministic'];assert q['registryCount']==120 and q['OEMStepCount']==19
counts=load(P/'SOURCE-REGISTRY-COUNT-QA.json');assert counts['status']=='PASS'and counts['runtimeRegistry']==123 and counts['exportPlacementMetadata']+len(counts['tools'])==123
smoke=load(P/'COMPLETED-SMOKE-JOB.json');assert smoke['status']=='completed'and smoke['totalFrames']==30 and smoke['width']==1280 and smoke['height']==720 and smoke['fps']==30
network=load(P/'SMOKE-OFFLINE-NETWORK-QA.json');assert network['externalRequestsTransmitted']==0
for name,h in load(P/'RENDER-INPUT-FREEZE.json')['files'].items():assert sha(ROOT/name)==h
checks=[]
for f in [R/'phase-a-v1/evidence/protected-baseline.json']:
 for n,h in load(f).items():
  p=Path(n);p=p if p.is_absolute()else ROOT/p;assert sha(p)==h;checks.append(n)
for f in [P.parent/'p1-camera-only-v1/FROZEN-P1-CAMERA-PILOT.json',P.parent/'option-n-timing-isolated-v1/FROZEN-OPTION-N-TIMING.json',P.parent/'p2-p3-camera-only-v1/FROZEN-P2-P3-CAMERA.json']:
 for n,h in load(f)['files'].items():assert sha(ROOT/n)==h;checks.append(n)
for f in ['typecheck-runner-final.log','lint-final.log']:
 assert not (P/'evidence'/f).read_text().strip(),f
native=load(P/'native-preflight-final/selected-diagnostic-manifest.json');layout=load(P/'native-layout-preflight-final/selected-diagnostic-manifest.json');assert len(native)==66 and len(layout)==5
assert not load(P/'native-preflight-final/offline-network.json')['attemptedRequests']and not load(P/'native-layout-preflight-final/offline-network.json')['attemptedRequests']
report=dict(status='PASS — SOFTWARE / SOURCE-STATE / NATIVE-PREFLIGHT ONLY',duration=278,fps=30,totalFrames=8340,native='1280x720',cameraScan=dict(framesAt24fps=q['cameraFramesScanned'],flags=0,maxAngle=q['maxAngle'],maxShift=q['maxShift']),sourcePoseAndSeek='PASS',sourceInventory=counts,nativeFullTimelineCheckpoints=66,finalLayoutCheckpoints=5,smoke=dict(job=smoke['id'],frames=30,status='PASS',sha256=smoke['sha256']),protectedChecks=len(checks),changes=0,authority='Human continuous execution + actual P2/P3 Director decision full278sLong review',mechanicalGates='NOT CERTIFIED. Historical raw collisionFAIL preserved; K22/10UNMEASURED;FNONLITERAL;C13/C14,IJOPEN;S17/18POSE-ONLY;S19HOLD. No source confidence upgrade.',graphQualification='19 documentary dependency nodes valid;0 connected installation-path operations in generic metadata adapter. This is not independent physical/path/access PASS.',fpsDisposition='Existing shared export profiles support30/60fps; fullLong uses30 at unchanged278s and the exact continuous source clock. Earlier diagnosticproofs remain24fps.',disk=dict(availableBytes=shutil.disk_usage(P).free,estimatedLongPNGBytes=round(8340*sum(p.stat().st_size for p in (P/'native-preflight-final').glob('*.png'))/66),minimumReserveBytes=3*2**30),globalTypecheck='Archived output snapshots have pre-existing errors; all actual src plus new runner typecheck PASS; production bundle compiled',visualStatus='REQUIRES DIRECTOR REVIEW OF ACTUAL FULL LONG; native preflight does not equal final acceptance')
(P/'PRE-RENDER-GATE.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
