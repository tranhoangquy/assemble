from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageChops,ImageStat
import json,hashlib,subprocess,shutil,zipfile
P=Path(__file__).resolve().parent;ROOT=P.parents[3];R=ROOT/'output/product03-pet-crate-w114586144'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True).stdout
j=load(P/'COMPLETED-RENDER-JOB.json');assert j['status']=='completed'and j['totalFrames']==8340 and j['fps']==30 and j['timelineDuration']==278
jobdir=Path(j['frameDirectory']).parent;manifest=load(jobdir/'manifest.json');assert len(manifest['frames'])==8340 and not manifest['missingFrames']and not manifest['invalidFrames']
f=P/'PRODUCT03-Long-integrated-v1-silent-720p.mp4';assert sha(f)==j['sha256']==sha(Path(j['outputPath']))
verified=load(jobdir/'logs/verification.json');assert verified['status']=='PASS'and verified['fullDecode']=='PASS'and verified['faststart']=='PASS'
streams=verified['media']['streams'];assert len(streams)==1 and streams[0]['codec_name']=='h264'and streams[0]['width']==1280 and streams[0]['height']==720 and int(streams[0]['nb_read_frames'])==8340
pts=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(f)]))['frames'];assert len(pts)==8340 and all(abs(float(x['best_effort_timestamp_time'])-i/30)<1e-6 for i,x in enumerate(pts));(P/'ENCODED-FRAME-PTS.json').write_text(json.dumps(pts))
points=load(P/'REVIEW-CHECKPOINTS.json');indices=[p['index']for p in points];decoded=P/'decoded-review-frames';decoded.mkdir(exist_ok=True)
expr='+'.join(f'eq(n\\,{i})'for i in indices)
run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-i',str(f),'-vf','select='+expr,'-vsync','0','-start_number','0',str(decoded/'sample-%03d.png')])
assert len(list(decoded.glob('sample-*.png')))==len(points)
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17);big=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',25);review=[]
originals=P/'selected-native-originals';originals.mkdir(exist_ok=True)
for k,p in enumerate(points):
 source=Path(j['frameDirectory'])/f"frame-{p['index']:06d}.png";assert sha(source)==manifest['frames'][str(p['index'])]
 d=decoded/f'sample-{k:03d}.png'
 with Image.open(source)as a,Image.open(d)as b:
  assert a.size==b.size==(1280,720);diff=ImageStat.Stat(ImageChops.difference(a.convert('RGB'),b.convert('RGB'))).mean;std=ImageStat.Stat(b.convert('RGB')).stddev;assert max(std)>1
 row=dict(**p,sourcePNG=str(source.relative_to(ROOT)),sourceSha256=sha(source),decodedPNG=str(d.relative_to(P)),decodedSha256=sha(d),meanAbsoluteRGBError=sum(diff)/3,nonBlank=True)
 if k%5==0 or p['label'].startswith('S04') or abs(p['time']-193.6666666667)<.01:
  dest=originals/source.name;shutil.copyfile(source,dest);row['selectedNativePath']=str(dest.relative_to(P))
 review.append(row)
for page in range((len(points)+15)//16):
 subset=review[page*16:(page+1)*16];im=Image.new('RGB',(1920,70+4*310),'#eee8df');draw=ImageDraw.Draw(im);draw.text((20,18),f'PRODUCT03 / ACTUAL ENCODED LONG / page{page+1} / 278s,30fps',font=big,fill='#292c2e')
 for n,p in enumerate(subset):
  x=n%4*480;y=70+n//4*310
  with Image.open(P/p['decodedPNG'])as a:im.paste(a.convert('RGB').resize((480,270)),(x,y))
  draw.text((x+7,y+274),f"f{p['index']} / {p['time']:.6f}s",font=font,fill='#705035');draw.text((x+7,y+292),p['label'][:49],font=font,fill='#292c2e')
 im.save(P/f'CONTACT-SHEET-LONG-{page+1:02d}.jpg',quality=93)
(P/'ACTUAL-MP4-REVIEW-FRAMES.json').write_text(json.dumps(review,indent=2))
# Independent chunk boundary schedule check; original per-frame CRC/hash reconciliation is shared-manager evidence.
seams=[]
for c in manifest['chunks'][1:]:
 i=c['start'];assert str(i-1)in manifest['frames']and str(i)in manifest['frames'];seams.append(dict(before=i-1,after=i,beforeTime=(i-1)/30,afterTime=i/30,step=1/30))
network=load(P/'OFFLINE-NETWORK-QA.json');assert network['externalRequestsTransmitted']==0
for name,h in load(P/'RENDER-INPUT-FREEZE.json')['files'].items():assert sha(ROOT/name)==h
protected=[]
for name,h in load(R/'phase-a-v1/evidence/protected-baseline.json').items():
 path=Path(name);path=path if path.is_absolute()else ROOT/path;assert sha(path)==h;protected.append(name)
for freeze in [P.parent/'p1-camera-only-v1/FROZEN-P1-CAMERA-PILOT.json',P.parent/'option-n-timing-isolated-v1/FROZEN-OPTION-N-TIMING.json',P.parent/'p2-p3-camera-only-v1/FROZEN-P2-P3-CAMERA.json']:
 for name,h in load(freeze)['files'].items():assert sha(ROOT/name)==h;protected.append(name)
(P/'PROTECTED-ASSET-VERIFICATION.json').write_text(json.dumps(dict(status='PASS',checks=len(protected),changes=0,Product01='UNCHANGED',JULIETTE='UNCHANGED',frozenAcceptedPilots='UNCHANGED',historicalRawCollisionFAIL='PRESERVED'),indent=2))
qa=dict(status='CAPTURE / SOFTWARE QA PASS — LOCAL VISUAL P0 FAIL / REVISION REQUIRED',file=f.name,sha256=sha(f),duration=278,frames=8340,fps=30,width=1280,height=720,audioStreams=0,fullDecode='PASS inherited actual shared-manager verification',framePTS='PASS all8340',faststart='PASS',nativeFrames='All8340 CRC/dimensions/hash-validated by existing manager before encode',chunks=len(manifest['chunks']),retries=manifest['retries'],chunkSeams=seams,sourceIdentity='Frozen109inputs and compiledbundle unchanged; loadedcreative metadata verified on browserrecycles',sampledActualMP4Frames=len(review),maxSampledMeanAbsoluteRGBError=max(p['meanAbsoluteRGBError']for p in review),visualQualification='Source/native/encoded sampled-frame comparison does not prove perfect continuous playback or physical fit',preRender=load(P/'PRE-RENDER-GATE.json'),protectedChecks=len(protected),network=network)
qa['confirmedVisualP0s']=[dict(time=70.2666666667,frame=2108,finding='Subject nearly absent from frame during S05 camera transition; actual rendered evidence'),dict(time=125.9,frame=3777,finding='Severe loss of context/crop during post-P1 camera buffer; actual rendered evidence')];qa['nonBlankQualification']='Caption pixels can keep nonblank statistics positive while the product is offscreen. Numerical pose/camera metrics did not establish visual acceptance.'
(P/'FULL-LONG-QA.json').write_text(json.dumps(qa,indent=2));print(json.dumps({k:qa[k]for k in ['file','sha256','duration','frames','fps','chunks','retries','sampledActualMP4Frames','maxSampledMeanAbsoluteRGBError']},indent=2))
