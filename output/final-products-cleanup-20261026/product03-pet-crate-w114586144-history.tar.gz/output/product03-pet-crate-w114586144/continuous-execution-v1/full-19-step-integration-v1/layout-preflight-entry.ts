import '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/full-long-preview';
const a=window.__MECHANISM_AUDIT_RENDERER__!;a.checkpoints.splice(0,a.checkpoints.length,...[7.696,208.5,262.5,264.5,274].map((time,i)=>({name:`layout-frame-${i}.png`,time,label:'Caption/layout only final check'})));
