# Full Long V1 — local visualP0 fail / V2 camera repair proposal

The actual complete278-second Long V1 exists,8340frames,native720p/30fps,silent. The shared exporter finished all35chunks with0retries; decode/native/checkpoint/identity checks pass. It is NOT visually accepted. The render finished before a requested local stop reached its owned process; nothing was killed/deleted. V1andallinputs/frames remain preserved.

## Confirmed actual visual failures

- P0-A: around70.266667s/frame2108, S05transition nearly loses the product entirely; only a tiny wood fragment remains near the image bottom. Actual4sMP4proof68.5–72.5 attached.
- P0-B: around125.9s/frame3777, post-P1transition crops away substantial context and loses the intended assembly framing. Actual3sMP4proof124.5–127.5 attached.
- The operator inspected actual generated PNGs and prepared actual encoded-MP4 samples. Pose equality/deterministic seek/angle deltas did not establish on-screen visibility. Caption pixels also make a generic nonblank-image statistic insufficient.

## Cause hypothesis — not a new engineering finding

The new full-film camera wrapper interpolates camera positions and quaternions independently between contexts with differing targets. A smooth angular delta can still aim away from the subject or pass too close to the display envelope. The S08fallback context was sampled at112.5s, during presentation inversion, rather than at a stable fully reoriented canonical state. Contextual safe-area heuristics do not prove camera/target continuity. The unchanged N actors remain present; this is a presentation failure, not proof of lost parts or changed product geometry.

## Proposed bounded V2 repair

1. Preserve rejected V1 source, MP4, all frames, softwarePASS and actual visualFAIL evidence. Create new versioned full-film camera/output files; do not overwrite accepted P1/N/P2P3 or V1.
2. Use explicit product-owned camera poses with position AND focus target. Interpolate focus coherently; use an exterior arc/bounded path where a straight camera chord risks crossing the display assembly. Keep source geometry, N278s clock, all actorposes and quantities untouched.
3. Derive fixed context anchors from stable canonical subassembly bounds, including a fully inverted/side-frame-installed S08state. Keep accepted proof interiors; repair integration buffers and other step transitions.
4. Replace the global-position safe-area heuristic with declared shot framing / caption-safe projection. Verify target/joint/host projections in actual view. No moving parts for visibility, no transparency/clipping tricks or hidden receivers.
5. Before another full278s render, render short continuous before/after V2 proofs for69–73s and124–128s, plus representative transition/native checks across all19steps. Screen-space subject/interface coverage and actual motion review supplement pose/angle tests. No full rerender until focused repair proof clears internal review.
6. After Director approval, render LongV2 via the existing resumable exporter, then nativeShort after internalLongPASS under continuous human authority.

No new mechanical geometry, timing, audio, research, purchase or third-party service. K22/10UNMEASURED;FNONLITERAL;C13/C14,IJOPEN;S17/18POSE-ONLY;S19HOLD/rawcollisionFAIL remain. No humanfinalacceptance.

## Additional P0 — render-path discrepancy

At190.266667s/frame5708 the actual full job PNG is empty of the product, while fresh exact-time renders through both the diagnostic API and actual VIDEO renderFrame API show it. Three back/forward direct renders are byte-identical; fresh WebGL contextLost=false/error=0. CPU projection predicts17visible component centers. Therefore this frame must NOT be blamed solely on camera math. Full-job perframe GPU telemetry was not recorded; cause remains OPEN. Diagnostic and full-export launch/hosting/lifecycle paths differ.

Before another full render, replay a bounded identical source window through the real shared ExportJobManager, investigate capture/settling/context/lifecycle differences, and require actual source-to-pixel fidelity. Add an appropriate product-owned readiness/context/subject-coverage guard if supported; no false deterministic-render PASS from transform digests alone. Keep raw full PNG, exact-time repros, manifests and failure evidence. All mechanical OPEN/HOLD remain unchanged.
