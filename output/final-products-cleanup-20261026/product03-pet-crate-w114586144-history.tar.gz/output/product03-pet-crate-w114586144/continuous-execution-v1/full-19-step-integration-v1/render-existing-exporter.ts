/** Product-owned local host + offline browser policy only. Capture, checkpoints,
 * recovery, native validation, encode and media QA are the existing shared manager. */
import http from 'node:http';import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';import {build} from 'esbuild';import {chromium} from 'playwright';
import {ProductManager} from '../../../../src/engine/product/ProductManager';
import {ExportJobManager} from '../../../../src/engine/export/ExportJobManager';
import {longPackage as pkg} from '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/full-long-package';
async function main(){
 const smoke=process.env.PRODUCT03_SMOKE==='1';
 const out=path.resolve('output/product03-pet-crate-w114586144/continuous-execution-v1/full-19-step-integration-v1');
 const fileList=JSON.parse(fs.readFileSync(path.join(out,'RENDER-INPUT-FREEZE.json'),'utf8')) as {files:Record<string,string>};
 function sourceHash(){const h=createHash('sha256');for(const name of Object.keys(fileList.files).sort()){const b=fs.readFileSync(name),actual=createHash('sha256').update(b).digest('hex');if(actual!==fileList.files[name])throw Error('Frozen render input changed: '+name);h.update(name).update('\0').update(b).update('\0');}return h.digest('hex');}
 sourceHash();const disk=fs.statfsSync(out);if(Number(disk.bavail)*Number(disk.bsize)<4*2**30)throw Error('LOCAL_DISK_RESERVE: need at least4GiB available before starting; no cleanup performed');
 const bundle=await build({entryPoints:['src/products/product03-pet-crate-w114586144/continuous-production-v1/full-long-preview.ts'],bundle:true,write:false,platform:'browser',format:'iife',target:'es2020',define:{'process.env.NODE_ENV':'"production"'}});
 const actualBundleHash=createHash('sha256').update(bundle.outputFiles[0].text).digest('hex');if(actualBundleHash!==fileList.files[path.relative(process.cwd(),path.join(out,'BUNDLED-RENDERER.js'))])throw Error('Renderer bundle differs from frozen inputs');
 const server=http.createServer((req,res)=>{if(!req.url?.startsWith('/render')){res.writeHead(404);res.end();return;}res.setHeader('Content-Security-Policy',"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; font-src 'none'; worker-src 'none'; object-src 'none'; frame-src 'none'");res.setHeader('Content-Type','text/html');res.end('<!doctype html><html><head><meta charset="utf-8"></head><body><script>'+bundle.outputFiles[0].text+'</script></body></html>');});
 await new Promise<void>(resolve=>server.listen(0,'127.0.0.1',resolve));const port=(server.address()as {port:number}).port,origin=`http://127.0.0.1:${port}`;
 const requests:string[]=[],blocked:string[]=[],launch=chromium.launch.bind(chromium);
 // Existing shared manager has no page-policy injection option. Configure its
 // real Playwright launch in THIS isolated process; never patch shared source.
 chromium.launch=async options=>{const browser=await launch({...options,args:[...(options?.args??[]),'--disable-quic','--disable-background-networking','--disable-component-update','--disable-sync','--no-pings','--no-first-run','--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1','--proxy-server=127.0.0.1:9','--proxy-bypass-list=127.0.0.1']});const newPage=browser.newPage.bind(browser);browser.newPage=async options=>{const page=await newPage({...options,serviceWorkers:'block'});await page.route('**/*',route=>{const url=route.request().url();if(url.startsWith(origin+'/render?')){requests.push(url);return route.continue();}blocked.push(url);return route.abort('blockedbyclient');});return page;};return browser;};
 const manager=new ExportJobManager(new ProductManager([pkg]),{storageRoot:path.join(out,smoke?'smoke-jobs':'render-jobs'),chunkSize:240,recycleEveryChunks:2,maxRetries:1,sourceHash});await manager.ready();
 const previous=await manager.list(pkg.id);let job=previous.find(j=>j.status==='completed')??previous.find(j=>j.canResume);
 if(job?.canResume)job=(await manager.resume(job.id,origin))!;
 if(!job)job=manager.start({productId:pkg.id,profileId:'720p',fps:30,origin});
 fs.writeFileSync(path.join(out,smoke?'smoke-job.json':'render-job.json'),JSON.stringify(job,null,2));let last='';
 try{for(;;){const j=manager.get(job.id)!;const disk=fs.statfsSync(out);if(Number(disk.bavail)*Number(disk.bsize)<3*2**30){await manager.cancel(job.id);throw Error('LOCAL_DISK_RESERVE: stopped with checkpoint intact; no files deleted');}const status=`${j.status} ${j.validFrames}/${j.totalFrames}`;if(status!==last){console.log(status);last=status;}if(j.status==='completed'){fs.copyFileSync(j.outputPath,path.join(out,smoke?'PRODUCT03-exporter-native-smoke.mp4':'PRODUCT03-Long-integrated-v1-silent-720p.mp4'));fs.writeFileSync(path.join(out,smoke?'COMPLETED-SMOKE-JOB.json':'COMPLETED-RENDER-JOB.json'),JSON.stringify(j,null,2));break;}if(['error','stale','waiting_for_resume','cancelled'].includes(j.status)){fs.writeFileSync(path.join(out,'RENDER-FAILURE.json'),JSON.stringify(j,null,2));throw Error(status+' '+j.error);}await new Promise(resolve=>setTimeout(resolve,1000));}}
 finally{fs.writeFileSync(path.join(out,smoke?'SMOKE-OFFLINE-NETWORK-QA.json':'OFFLINE-NETWORK-QA.json'),JSON.stringify({allowedLocalRendererRequests:requests,blockedRequests:blocked,externalRequestsTransmitted:0,policy:'CSP default-none/connect-none, route allow exact loopback render URL only, serviceworkers blocked, external DNS unresolved, loopback-only outbound proxy'},null,2));chromium.launch=launch;server.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
