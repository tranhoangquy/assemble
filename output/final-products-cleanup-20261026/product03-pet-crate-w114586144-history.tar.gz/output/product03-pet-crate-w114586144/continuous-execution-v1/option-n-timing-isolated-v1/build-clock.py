from pathlib import Path
import json
ROOT=Path.cwd();P=Path(__file__).resolve().parent;source=ROOT/'src/products/product03-pet-crate-w114586144/continuous-production-v1'
p=json.loads((ROOT/'output/product03-pet-crate-w114586144/teaching-readability-correction-plan-v1/TIMING-OPTIONS.json').read_text())['primaryDurationNeutral']
segments=[]
def add(id,a,b,c,d,kind):segments.append(dict(id=id,baselineStart=a,baselineEnd=b,proposedStart=c,proposedEnd=d,kind=kind))
delta=p['D30']['addedHold'];oldEnd=120.37272727272727;hidden=120.29854545454546
add('D30-tool-free',hidden,oldEnd,hidden,oldEnd+delta,'STATIC_HOLD_ADDED')
add('D31-D39',oldEnd,131.5,oldEnd+delta,131.5+delta,'MOVING_UNCHANGED_DURATION')
add('S08-tail',131.5,132,131.5+delta,132,'STATIC_DONOR')
delta=p['C13']['addedHold'];oldEnd=195.42857142857142;hidden=195.34371428571428
add('C13-tool-free',hidden,oldEnd,hidden,oldEnd+delta,'STATIC_HOLD_ADDED')
add('C14-C18',oldEnd,202.5,oldEnd+delta,202.5+delta,'MOVING_UNCHANGED_DURATION')
add('S14-tail',202.5,203,202.5+delta,203,'STATIC_DONOR')
add('S15-floor-tail',207.15,209,207.15,208.375,'STATIC_DONOR')
segments+=p['S16']['segments'];segments.sort(key=lambda x:x['proposedStart'])
lastOld=lastNew=0;complete=[]
for s in segments:
 a,b,c,d=[s[k]for k in ['baselineStart','baselineEnd','proposedStart','proposedEnd']]
 assert a>=lastOld-1e-8 and c>=lastNew-1e-8
 if a>lastOld+1e-8 or c>lastNew+1e-8:
  assert abs((a-lastOld)-(c-lastNew))<1e-7
  complete.append(dict(id='unchanged',baselineStart=lastOld,baselineEnd=a,proposedStart=lastNew,proposedEnd=c,kind='IDENTITY_OR_TRANSLATION'))
 assert b>a and d>c
 complete.append(s);lastOld=b;lastNew=d
if lastNew<278:add('tail',lastOld,278,lastNew,278,'IDENTITY_OR_TRANSLATION');complete.append(segments[-1])
assert complete[-1]['baselineEnd']==complete[-1]['proposedEnd']==278
for a,b in zip(complete,complete[1:]):assert abs(a['baselineEnd']-b['baselineStart'])<1e-7 and abs(a['proposedEnd']-b['proposedStart'])<1e-7
(source/'option-n-segments.json').write_text(json.dumps(complete,indent=2))
(P/'OPTION-N-CLOCK-CONTRACT.json').write_text(json.dumps(dict(duration=278,mode='Single continuous monotone whole-scene clock',segments=complete,physicalSemantics='Unchanged OPEN/HOLD; no engineering upgrade',proofs=[dict(id='P1',start=108,end=124,frames=384),dict(id='P2',start=185,end=208.5,frames=564),dict(id='P3',start=208.5,end=228,frames=468)]),indent=2))
print(len(complete),'clock segments')
