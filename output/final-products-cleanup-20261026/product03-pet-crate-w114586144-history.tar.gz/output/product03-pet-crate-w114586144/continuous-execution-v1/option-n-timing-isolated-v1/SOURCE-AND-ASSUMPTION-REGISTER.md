# Source / unchanged assumptions

Accepted278s S04 IntegrationV2 is the only geometry and operation source. N maps the WHOLE scene through one continuous monotone clock. All moving intervals retain source duration and trajectory. Only verified actor-static intervals are stretched/compressed. No camera, light, material or overlay-code correction in this comparator. The displayed global clock changes to N, as expected.

K22/10 UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN; S17/S18 POSE-ONLY; S19 pads/door HOLD. Raw historical collisionFAIL is unchanged. Neither new timing nor source-pose equality certifies receiving geometry, retention, torque, support, hand/tool access or physical feasibility. All19source steps and20structural/100accessoryunits+3tools remain represented under their prior limitations.

Comparison sheets use nearest original baseline-source-time frames; their timestamps are explicitly labeled. They are not claimed byte-identical rendered comparisons where the exact mapped time falls between old24fps samples.
