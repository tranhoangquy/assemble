from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,zipfile,shutil
P=Path(__file__).resolve().parent;ROOT=P.parents[3];R=ROOT/'output/product03-pet-crate-w114586144';OLD=R/'targeted-motion-proofs-v1'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
qa=load(P/'TIMING-CAPTURE-QA.json');assert qa['status']=='PASS';q=load(P/'TIMING-QA.json');assert q['status']=='PASS'
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',21)
selected=[]
# Matched source-time before / mapped display-time after, not a misleading same-global-state comparison.
examples={'P1':[120.2916667,120.3333333,120.4166667,120.5,120.5833333,123.9583333], 'P2':[192.5833333,193.75,195.3333333,195.4166667,195.5,208.4583333], 'P3':[208.5,214.5833333,214.6666667,214.7916667,224.2916667,227.9583333]}
config=load(P/'BASELINE-AND-CAPTURE-IDENTITY.json');clock=load(P/'OPTION-N-CLOCK-CONTRACT.json')['segments']
def source(t):
 s=next((s for s in clock if t<s['proposedEnd']),clock[-1]);return s['baselineStart']+(t-s['proposedStart'])/(s['proposedEnd']-s['proposedStart'])*(s['baselineEnd']-s['baselineStart'])
for proof in config['proofs']:
 pid=proof['id'];im=Image.new('RGB',(1600,6*255+65),'#eee9e0');draw=ImageDraw.Draw(im);draw.text((12,16),f'{pid} TIMING ONLY | LEFT: nearest baseline source frame | RIGHT: mapped Option N',font=font,fill='#23272a')
 for j,time in enumerate(examples[pid]):
  i=round((time-proof['start'])*24);t=proof['start']+i/24;src=source(t);oldStart={'P1':108,'P2':185,'P3':209}[pid];oldCount={'P1':384,'P2':576,'P3':456}[pid];oi=max(0,min(oldCount-1,round((src-oldStart)*24)));of=OLD/'frames'/pid/f'frame-{oi:06d}.png';nf=P/'frames'/pid/f'frame-{i:06d}.png';sel=P/'selected-originals'/pid;sel.mkdir(parents=True,exist_ok=True);dst=sel/nf.name;shutil.copyfile(nf,dst);selected.append(dict(proof=pid,index=i,time=t,sourceV2Time=src,path=str(dst.relative_to(P)),sha256=sha(dst)))
  y=65+j*255
  for x,f,label in [(0,of,f'V2 source {oldStart+oi/24:.6f}s (nearest frame)'),(800,nf,f'N display {t:.6f}s → V2 {src:.6f}s')]:
   with Image.open(f)as a:im.paste(a.convert('RGB').resize((800,225)),(x,y))
   draw.text((x+8,y+229),label,font=font,fill='#6f4a2b')
 im.save(P/f'TIMING-COMPARISON-{pid}.jpg',quality=94)
(P/'SELECTED-ORIGINALS.json').write_text(json.dumps(selected,indent=2))
(P/'SOURCE-AND-ASSUMPTION-REGISTER.md').write_text('''# Source / unchanged assumptions

Accepted278s S04 IntegrationV2 is the only geometry and operation source. N maps the WHOLE scene through one continuous monotone clock. All moving intervals retain source duration and trajectory. Only verified actor-static intervals are stretched/compressed. No camera, light, material or overlay-code correction in this comparator. The displayed global clock changes to N, as expected.

K22/10 UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN; S17/S18 POSE-ONLY; S19 pads/door HOLD. Raw historical collisionFAIL is unchanged. Neither new timing nor source-pose equality certifies receiving geometry, retention, torque, support, hand/tool access or physical feasibility. All19source steps and20structural/100accessoryunits+3tools remain represented under their prior limitations.

Comparison sheets use nearest original baseline-source-time frames; their timestamps are explicitly labeled. They are not claimed byte-identical rendered comparisons where the exact mapped time falls between old24fps samples.
''')
(P/'VISUAL-FINDINGS.md').write_text('''# Actual timing-only proof observations

D30/C13/E2/E6 now each have six native frame samples after tool visibility turns off and before the next operation. This is a visual exterior plateau, not a torque/secured-state claim. Later repeated D/C/E individual holds remain short; stable grouped camera views are the next separate task.

Baseline camera jumps, small A4/A5 and C13 occlusion can still appear in these timing-only videos. The accepted P1camera wrapper is deliberately absent so cause/effect remains separate. These unresolved camera defects are not hidden or reported as fixed by timing. No added door swing or S17–19 operation.

D31–39 and C14–18 move downstream locally, with identical moving durations;132/203/228/278 canonical endpoints remain exact. Floor motion205.15–207.15 is unchanged and never receives a fastener. S15/S16boundary208.375; door1starts208.5. Door1 remains installed during door2; A5 keeps the original carrier5-relative pose. Actual visual review remains Director's task; local numerical/source tests do not substitute for continuous playback judgement.
''')
(P/'DIRECTOR-REVIEW.md').write_text('''# PRODUCT03-OPTION-N-TIMING-ISOLATED-V1

Actual three new native silent MP4 proofs attached: P1 108–124/384frames; P2 185–208.5/564frames; P3 208.5–228/468frames. Total59s/1416frames,1280×720/24fps. Full decode, framePTS, PNG sequence and chunk seams verified. Exact hashes in DELIVERY-SHA256.json.

One whole-scene continuous monotone source clock preserves moving-phase durations. Only source-static intervals change. All1416 actor/visibility transforms equal frozenV2 at mapped source time. Baseline camera rule retained; no accepted P1camera mixing. D30/C13/E2/E6 have exactly0.25s tool-free plateaus and six actual24fps samples each. D31–39/C14–18, floor donor, S15/16 and canonical132/203/228/278 documented in TIMING-QA.json. All19steps/quantities andOPEN/HOLD semantics retained.

Please review actual MP4s and return an explicit timing-only decision. If accepted, next within continuous human scope is P2/C13 camera-only and P3 stable leaf-pair/door-context camera proofs, then combinedOptionN integration and whole19-step film review. No need request routine human permission. K22/10UNMEASURED;FNONLITERAL;C13/C14,I/JOPEN;S17/18POSE-ONLY;S19HOLD/rawcollisionFAIL remain.

No mechanical confidence upgrade and no final human acceptance. Full Long/Short films still pending. Please distinguish sampled-MP4-frame review from continuous real-time playback.
''')
# Verify every current capture source and protected products; keep prior evidence manifests immutable.
checks=[]
for f,h in load(P/'BASELINE-AND-CAPTURE-IDENTITY.json')['sourceFiles'].items():assert sha(ROOT/f)==h;checks.append(f)
for f,h in load(R/'phase-a-v1/evidence/protected-baseline.json').items():
 path=Path(f);path=path if path.is_absolute()else ROOT/path;assert sha(path)==h;checks.append(f)
for f,h in load(P.parent/'p1-camera-only-v1/FROZEN-P1-CAMERA-PILOT.json')['files'].items():assert sha(ROOT/f)==h;checks.append(f)
(P/'PROTECTED-VERIFICATION.json').write_text(json.dumps(dict(status='PASS',checked=len(checks),changes=0,Product01='UNCHANGED',JULIETTE='UNCHANGED',acceptedP1Camera='UNCHANGED',historicalCollisionFAIL='PRESERVED'),indent=2))
files=[*P.glob('*.mp4'),*P.glob('TIMING-COMPARISON-*.jpg'),P/'DIRECTOR-REVIEW.md',P/'VISUAL-FINDINGS.md',P/'SOURCE-AND-ASSUMPTION-REGISTER.md',P/'TIMING-QA.json',P/'RETENTION-AND-COUNT-QA.json',P/'TIMING-CAPTURE-QA.json',P/'OPTION-N-CLOCK-CONTRACT.json',P/'PROTECTED-VERIFICATION.json',P/'BASELINE-AND-CAPTURE-IDENTITY.json',P/'CHUNK-SEAM-QA.json',P/'FRAME-SHA256-MANIFEST.json',P/'SELECTED-ORIGINALS.json',*P.glob('selected-originals/*/*.png')]
manifest=[dict(path=str(f.relative_to(P)),sha256=sha(f),bytes=f.stat().st_size)for f in files];(P/'DELIVERY-SHA256.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(P/'PRODUCT03-OPTION-N-TIMING-EVIDENCE.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in [*files,P/'DELIVERY-SHA256.json']:z.write(f,str(f.relative_to(P)))
print(json.dumps(dict(media=qa['media'],evidenceZipSha256=sha(P/'PRODUCT03-OPTION-N-TIMING-EVIDENCE.zip')),indent=2))
