# Actual timing-only proof observations

D30/C13/E2/E6 now each have six native frame samples after tool visibility turns off and before the next operation. This is a visual exterior plateau, not a torque/secured-state claim. Later repeated D/C/E individual holds remain short; stable grouped camera views are the next separate task.

Baseline camera jumps, small A4/A5 and C13 occlusion can still appear in these timing-only videos. The accepted P1camera wrapper is deliberately absent so cause/effect remains separate. These unresolved camera defects are not hidden or reported as fixed by timing. No added door swing or S17–19 operation.

D31–39 and C14–18 move downstream locally, with identical moving durations;132/203/228/278 canonical endpoints remain exact. Floor motion205.15–207.15 is unchanged and never receives a fastener. S15/S16boundary208.375; door1starts208.5. Door1 remains installed during door2; A5 keeps the original carrier5-relative pose. Actual visual review remains Director's task; local numerical/source tests do not substitute for continuous playback judgement.
