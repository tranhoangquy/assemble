"""Invoke the existing offline diagnostic renderer in six bounded fresh jobs.
No new exporter or creative behavior. Chunk checkpoints/checksums are local evidence.
"""
from pathlib import Path
from PIL import Image
import json,hashlib,subprocess,os,datetime,shutil
P=Path(__file__).resolve().parent;ROOT=P.parents[3]
def load(f):return json.loads(Path(f).read_text())
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(f,v):
 t=Path(str(f)+'.tmp');t.write_text(json.dumps(v,indent=2)+'\n');t.replace(f)
config=load(P/'BASELINE-AND-CAPTURE-IDENTITY.json')
identity=hashlib.sha256(json.dumps(dict(config=config,entry=sha(P/'capture-entry.ts'),renderer=sha(ROOT/'scripts/render-mechanism-diagnostics.ts')),sort_keys=True).encode()).hexdigest()
jobfile=P/'CAPTURE-JOB.json';job=load(jobfile)if jobfile.exists()else dict(version=1,identity=identity,createdAt=now(),status='PENDING',chunks={},retryLimit=1,workerCount=1)
assert job['identity']==identity,'Capture identity changed; preserve old job and STOP'
def sources_match():assert all(sha(ROOT/f)==h for f,h in config['sourceFiles'].items()),'Frozen source changed'
def validate(p,c,chunk,d):
 m=load(d/'selected-diagnostic-manifest.json');expected=[f"{p['id']}-C{c+1}-frame-{i:06d}.png"for i in range(chunk['start'],chunk['end'])];assert [r['name']for r in m]==expected
 assert not load(d/'offline-network.json')['attemptedRequests'];rows=[]
 for i,r in zip(range(chunk['start'],chunk['end']),m):
  assert abs(r['time']-(p['start']+i/config['fps']))<1e-9 and r['state']['clippingPlanes']==0 and not r['networkRequests']
  f=d/r['name']
  with Image.open(f)as im:im.verify()
  with Image.open(f)as im:im.load();assert im.size==(1280,720)
  rows.append(dict(proof=p['id'],index=i,time=r['time'],path=str(f.relative_to(P)),sha256=sha(f),bytes=f.stat().st_size))
 return rows
allframes=[];job['status']='CAPTURING';save(jobfile,job)
for p in config['proofs']:
 for c,chunk in enumerate(p['chunks']):
  key=f"{p['id']}-C{c+1}";sources_match();previous=job['chunks'].get(key)
  if previous and previous['status']=='COMPLETE':
   rows=validate(p,c,chunk,P/previous['directory']);assert rows==previous['frames'];allframes+=rows;print(key,'verified existing completed chunk',flush=True);continue
  success=False
  for attempt in [1,2]:
   d=P/'chunks'/f'{key}-attempt{attempt}'
   if d.exists():continue # preserve any failed/partial old attempt; never overwrite it
   d.mkdir(parents=True);log=P/'evidence'/f'{key}-attempt{attempt}.log'
   job['chunks'][key]=dict(status='RUNNING',directory=str(d.relative_to(P)),attempt=attempt,startIndex=chunk['start'],endExclusive=chunk['end'],startedAt=now());save(jobfile,job)
   env=os.environ.copy();env.update(AUDIT_OFFLINE='1',PRODUCT_AUDIT_MODULE=str(P/'capture-entry.ts'),SCREENSHOTS_DIR=str(d),CHECKPOINT_PATTERN='^'+key+'-frame-',NEXT_TELEMETRY_DISABLED='1',DO_NOT_TRACK='1')
   print(key,'capture',chunk['start'],chunk['end'],'attempt',attempt,flush=True)
   with log.open('w')as stream:r=subprocess.run(['node','--import','tsx','scripts/render-mechanism-diagnostics.ts'],cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
   try:
    assert r.returncode==0,f'Existing renderer exit{r.returncode}; see {log.name}'
    rows=validate(p,c,chunk,d);sources_match();job['chunks'][key].update(status='COMPLETE',completedAt=now(),frames=rows);allframes+=rows;save(jobfile,job);success=True;print(key,'COMPLETE',len(rows),'native PNGs',flush=True);break
   except Exception as e:
    job['chunks'][key].update(status='FAILED',error=str(e));save(jobfile,job);print(key,'FAILED',str(e),flush=True)
  if not success:job['status']='BLOCKED';save(jobfile,job);raise RuntimeError(f'{key} bounded capture failed; all partial evidence preserved')
sources_match();assert len(allframes)==1416
for p in config['proofs']:
 rows=[r for r in allframes if r['proof']==p['id']];assert [r['index']for r in rows]==list(range(p['frames']))
 d=P/'frames'/p['id'];d.mkdir(parents=True,exist_ok=True)
 for r in rows:
  target=d/f"frame-{r['index']:06d}.png"
  if target.exists():assert sha(target)==r['sha256']
  else:os.link(P/r['path'],target)
  r['continuousPath']=str(target.relative_to(P))
save(P/'FRAME-SHA256-MANIFEST.json',allframes);job['status']='ALL_FRAMES_VALIDATED';job['completedAt']=now();job['totalFrames']=len(allframes);save(jobfile,job)
print('ALL FRAMES VALIDATED:1416;3 contiguous native sequences;0 network attempts',flush=True)
