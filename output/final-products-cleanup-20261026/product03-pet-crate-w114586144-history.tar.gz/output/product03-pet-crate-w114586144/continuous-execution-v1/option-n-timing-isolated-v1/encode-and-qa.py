from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,subprocess,shutil,struct,datetime
P=Path(__file__).resolve().parent
def load(f):return json.loads(Path(f).read_text())
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def save(n,v):(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True).stdout
identity=load(P/'BASELINE-AND-CAPTURE-IDENTITY.json');job=load(P/'CAPTURE-JOB.json');frames=load(P/'FRAME-SHA256-MANIFEST.json');assert job['status']=='ALL_FRAMES_VALIDATED'and len(frames)==1416
comparison=load(P/'TIMING-QA.json');assert comparison['status']=='PASS'
media=[];seams=[]
for ordinal,p in enumerate(identity['proofs'],1):
 rows=[r for r in frames if r['proof']==p['id']];assert [r['index']for r in rows]==list(range(p['frames']))
 for r in rows:assert sha(P/r['continuousPath'])==r['sha256']
 for c in p['chunks'][1:]:
  i=c['start'];a,b=rows[i-1],rows[i];assert abs(b['time']-a['time']-1/24)<1e-9;seams.append(dict(proof=p['id'],before=a,after=b,frameIndexContinuous=True,timeContinuous=True,qualification='Equal content during genuine holds is permitted; no content-based deduplication or frame repetition introduced.'))
 f=P/f"OPTION-N-{p['id']}-{p['start']}-{p['end']}.mp4"
 run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-framerate','24','-start_number','0','-i',str(P/'frames'/p['id']/'frame-%06d.png'),'-frames:v',str(p['frames']),'-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-an','-movflags','+faststart',str(f)])
 info=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(f)]));save(f'evidence/PROOF-{ordinal:02d}-ffprobe.json',info);assert len(info['streams'])==1;s=info['streams'][0]
 assert s['codec_name']=='h264'and s['width']==1280 and s['height']==720 and s['r_frame_rate']==s['avg_frame_rate']=='24/1'and int(s['nb_read_frames'])==p['frames']and abs(float(info['format']['duration'])-p['seconds'])<1e-6
 decode=subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(f),'-f','null','-'],capture_output=True,text=True);(P/f'evidence/PROOF-{ordinal:02d}-full-decode.log').write_text(decode.stderr);assert decode.returncode==0 and not decode.stderr.strip()
 pts=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(f)]))['frames'];assert len(pts)==p['frames']and all(abs(float(r['best_effort_timestamp_time'])-i/24)<1e-6 for i,r in enumerate(pts));save(f'evidence/PROOF-{ordinal:02d}-frame-pts.json',pts)
 atoms=[]
 with f.open('rb')as stream:
  while stream.tell()<f.stat().st_size:
   offset=stream.tell();header=stream.read(8)
   if len(header)<8:break
   size,code=struct.unpack('>I4s',header)
   if size==1:size=struct.unpack('>Q',stream.read(8))[0]
   if size==0:size=f.stat().st_size-offset
   atoms.append(dict(type=code.decode('ascii'),offset=offset,size=size));stream.seek(offset+size)
 assert next(r['offset']for r in atoms if r['type']=='moov')<next(r['offset']for r in atoms if r['type']=='mdat')
 media.append(dict(proof=p['id'],file=f.name,globalStart=p['start'],globalEndExclusive=p['end'],lastGlobalTime=p['start']+(p['frames']-1)/24,duration=p['seconds'],frames=p['frames'],codec=s['codec_name'],width=1280,height=720,fps='24/1',audioStreams=0,fullDecode='PASS',framePTS='PASS',faststart=True,sha256=sha(f),bytes=f.stat().st_size))
save('CHUNK-SEAM-QA.json',seams)

save('TIMING-CAPTURE-QA.json',dict(status='PASS',media=media,seams=seams,scope='Timing-only at mapped source clock; baseline camera/geometry/graphics',timingQA=comparison))
print(json.dumps(media,indent=2))
