import {writeFileSync} from 'node:fs';
import * as T from 'three';
import {segments,toV2,fromV2} from '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/option-n-clock';
import {createRuntime,hardware,steps} from '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/option-n-runtime';
import {createRuntime as createV2} from '../../../../src/products/product03-pet-crate-w114586144/s04-integration-v2/runtime';
import {hardware as oldHardware} from '../../../../src/products/product03-pet-crate-w114586144/s04-integration-v2/timeline';
const n=createRuntime(),old=createV2(),failures:string[]=[],checks:unknown[]=[];
const assert=(v:unknown,m:string)=>{if(!v)failures.push(m);};
for(const s of segments){const a=s.proposedStart,b=s.proposedEnd;assert(b>a&&s.baselineEnd>s.baselineStart,'positive '+s.id);assert(Math.abs(toV2(a)-s.baselineStart)<1e-7&&Math.abs(toV2(b)-s.baselineEnd)<1e-7,'mapping '+s.id);
 if(s.kind.startsWith('STATIC')){old.evaluate(s.baselineStart+1e-6);const before=JSON.stringify(old.digest());old.evaluate(s.baselineEnd-1e-6);assert(JSON.stringify(old.digest())===before,'donor/hold must be entirely actor-static '+s.id);}
 else assert(Math.abs((b-a)-(s.baselineEnd-s.baselineStart))<1e-7,'moving phase duration '+s.id);
}
let count=0;
for(const p of [{a:108,frames:384},{a:185,frames:564},{a:208.5,frames:468}])for(let i=0;i<p.frames;i++){
 const t=p.a+i/24,source=toV2(t),s=n.evaluate(t);old.evaluate(source);assert(JSON.stringify(n.digest())===JSON.stringify(old.digest()),'whole-scene equality '+t);
 const before=JSON.stringify(n.digest());const cam=n.camera(t);assert(JSON.stringify(n.digest())===before,'camera re-evaluation source state '+t);const oc=old.camera(source);assert(cam.position.distanceTo(oc.position)<1e-9&&cam.quaternion.angleTo(oc.quaternion)<1e-7,'baseline camera unchanged '+t);
 if(t>=218.1952)assert(n.r.registry.require('part-7-1').visible,'door1 retained '+t);
 assert(s.hardwareSeated.filter(id=>/^hardware-B-/.test(id)).length===4,'B4 retained '+t);count++;
}
for(const id of ['hardware-D-30','hardware-C-13','hardware-E-2','hardware-E-6']){const a=oldHardware.find(h=>h.id===id)!,b=hardware.find(h=>h.id===id)!,hidden=fromV2(a.start+.97*(a.end-a.start)),end=b.end;assert(Math.abs(end-hidden-.25)<1e-7,'quartersecond hold '+id);let visibleFrames=0;const tool=n.r.registry.require(`hardware-${a.tool}-1`);for(let i=Math.ceil(hidden*24);i/24<end-1e-9;i++){n.evaluate(i/24);assert(!tool.visible,'tool hidden '+id);visibleFrames++;}assert(visibleFrames>=6,'six actual frames '+id);checks.push({id,oldStart:a.start,oldEnd:a.end,start:b.start,end:b.end,toolHidden:hidden,toolFreeDuration:end-hidden,actualNativeToolFreeFrames:visibleFrames});}
for(const t of [0,18,31,41,69,85,104,112,132,144,154,164,173,189,203,207.15,228,238,247,262,268,278]){assert(Math.abs(toV2(t)-t)<1e-7,'canonical clock '+t);n.evaluate(t);const d=JSON.stringify(n.digest());old.evaluate(t);assert(d===JSON.stringify(old.digest()),'canonical endpoint '+t);n.evaluate(278-t);n.evaluate(t);assert(d===JSON.stringify(n.digest()),'backward deterministic '+t);}
const dshift=hardware.filter(h=>h.id.startsWith('hardware-D-')&&Number(h.id.split('-').at(-1))>=31).map(h=>({id:h.id,start:h.start,end:h.end}));const cshift=hardware.filter(h=>h.id.startsWith('hardware-C-')&&Number(h.id.split('-').at(-1))>=14).map(h=>({id:h.id,start:h.start,end:h.end}));
assert(steps.length===19&&steps[14].end===208.375&&steps[15].start===208.375&&steps[15].end===228,'19steps and shifted S15/16');
const result={status:failures.length?'FAIL':'PASS',wholeSceneFrameComparisons:count,clock:'Single continuous monotone source clock',movingDurations:'UNCHANGED',camera:'Original baseline rule at source time',duration:278,steps,essentialHolds:checks,downstreamD31D39:dshift,downstreamC14C18:cshift,finalState:n.evaluate(278),qualifications:'K22/10 UNMEASURED; F NONLITERAL; C13/C14 I/J OPEN; S17/18 POSE-ONLY; S19 HOLD; no physical upgrade',failures};writeFileSync(new URL('TIMING-QA.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify({status:result.status,frames:count,failures,holds:checks}));if(failures.length)process.exitCode=1;
