# Product03 — limits carried into the films

This is an illustrative assembly film grounded in the human-supplied manual, not installation or physical-fit certification. Director acceptance is internal creative review; only the human can accept the completed films.

## Documentary authority

13-page local installation manual, SHA256 `70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29`. Visible assembly: open cubby, double mesh-door wooden pet crate, **no drawers**. Wayfair W114586144 commercial identity is metadata-only and has not been independently verified. The film does not add drawer hardware or substitute a different manual.

15 numbered component types /20instances; hardware/tools A–O15types /103listedunits (100accessory units+3tools). Nineteen source steps. The source instruction to align before final tightening remains; visual initial seating is never a torque/final-retention claim.

## Unresolved physical truth

- All overall/panel dimensions and many mounting coordinates are unmeasured visual approximations. Engine adapter `mm` units do not turn display coordinates into OEM measurements.
- K22/10 remains UNMEASURED. The accepted S04proof teaches one bracket with two B bolts in the existing visual model; no invented receiving bore, thread or physical retention is claimed.
- F remains NONLITERAL: a declared illustrative association, not a validated OEM fastening simulation.
- C allocation in S13/S14 remains inferred, including C13 target/access. All18C units reconcile in the visual inventory; this does not establish exact physical end allocation.
- S18 inset/summary I/J identity contradiction remains OPEN. Proposed J upper/I lower is an inference; no OEM correction or exact retaining mechanism is asserted.
- S17/S18 are exterior POSE-ONLY. No hidden receiver, grip, retention or tightening is invented.
- S19: all4N pads remain staged/HOLD. Door/latch release, access and functional opening are not established. No operating door demonstration, secured completion or certified usable capacity is shown.
- Historical raw collision FAIL and physical-fit limitations remain in the historical records. Camera/pose/encode PASS never converts them to mechanical PASS.
- No load, torque, material-grade, screw-thread, tool/hand-envelope, certified capacity, wall suitability or animal-safety claim.

## Review limits

PerframePNG subject presence detects gross absence only; it cannot establish correct framing, no occlusion or successful fastening. Screen-space projections and transform digests are supplementary. Actual MP4 review uses documented samples and complete technical decode, with no fabricated continuous-playback claim.

The earlier S14 absent-product assertion was an incorrect visual interpretation, formally corrected by Codex and Director. The original/replay product pixels match; no GPU/exporter defect was established. Prior incorrect reports and the explicit correction remain preserved.

## Editing rules

Long preserves accepted OptionN278s and all19 source steps. Any eventual portrait Short must clearly declare selected/omitted repeated work, retain source state at forwardcuts and label the finished appearance hook as a preview. Omitted repeats do not change source counts or imply verified physical work. Product01, discontinued JULIETTE, frozenV1 and all prior evidence stay unchanged. No publication authorized.
