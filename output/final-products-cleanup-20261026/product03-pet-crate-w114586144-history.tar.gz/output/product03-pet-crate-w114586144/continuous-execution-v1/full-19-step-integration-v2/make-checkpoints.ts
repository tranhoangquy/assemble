import fs from 'node:fs';import {steps,hardware,bodies} from '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/option-n-runtime';
const points=new Map<number,string[]>(),add=(t:number,label:string)=>{const i=Math.max(0,Math.min(8339,Math.round(t*30)));points.set(i,[...(points.get(i)??[]),label]);};
for(const s of steps){for(const[offset,label]of [[.001,'entry'],[1.266666667,'transition'],[2.5,'contact/context'],[s.duration-1/30,'endpoint']]as const)add(s.start+offset,s.id+' '+label);}
for(const h of hardware){if(h.kind==='threaded'){add(h.start+(h.end-h.start)*.5,h.id+' feed/tool');add(h.start+(h.end-h.start)*.985,h.id+' tool-withdrawn initialvisualposition');}else if(h.kind==='foot')add((h.start+h.end)/2,h.id+' host-relative approach');}
for(const b of bodies){add(b.contact-.01,b.id+' precontact');add(b.contact+.01,b.id+' retained');}
for(const t of [0,70.2666666667,125.9,190.2666666667,203,204,205.15,207.15,208.375,208.5,210.5,218.1952,220.1952,228,229,247,262,266,268,272,277.9666666667])add(t,'critical boundary/hold/review');
fs.writeFileSync(new URL('REVIEW-CHECKPOINTS.json',import.meta.url),JSON.stringify([...points].sort((a,b)=>a[0]-b[0]).map(([index,label])=>({index,time:index/30,label:label.join('; ')})),null,2));console.log(points.size+' actualMP4checkpoints prepared');
