import fs from 'node:fs';import {createHash} from 'node:crypto';import {build} from 'esbuild';
const p='output/product03-pet-crate-w114586144/continuous-execution-v1/full-19-step-integration-v2';
async function main(){
const b=await build({entryPoints:['src/products/product03-pet-crate-w114586144/continuous-production-v2-r2/full-long-preview.ts'],bundle:true,write:false,platform:'browser',format:'iife',target:'es2020',define:{'process.env.NODE_ENV':'"production"','__P03_START__':'0','__P03_END__':'278'}});
const text=b.outputFiles[0].text,h=createHash('sha256').update(text).digest('hex');if(h!==JSON.parse(fs.readFileSync(p+'/INPUT-FREEZE.json','utf8')).files.BUNDLE)throw Error('Archived bundle mismatch');fs.writeFileSync(p+'/BUNDLED-RENDERER.js',text,{flag:'wx'});console.log('Actual render bundle archived and fingerprint matched '+h);

}
main().catch(e=>{console.error(e);process.exitCode=1;});
