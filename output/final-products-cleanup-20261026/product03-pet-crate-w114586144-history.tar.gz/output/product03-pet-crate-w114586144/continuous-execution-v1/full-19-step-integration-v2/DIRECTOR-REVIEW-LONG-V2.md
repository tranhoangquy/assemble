# PRODUCT03-FULL-LONG-V2-RENDER-AND-INTERNAL-REVIEW

Actual full LongV2 attached. **TECHNICAL PASS / DIRECTOR VISUAL DECISION REQUIRED.**

278s /8340frames /1280×720 /30fps /silent H264, native shared ExportJobManager. SHA256 `5bf1776724654f7a3ec0b2a00495227e021273ac7e26a988ec9e71a4a223755b`.35chunks,0retries,18browsergenerations. All8340nativeframes validated; encodedPTS exactlyi/30; full decode andfaststartPASS. All8340capturedtimes/readiness/context/GLchecksPASS; caption-free subject guard minimum3.189% (criterion.5%). Guard cannot certify composition, occlusion or physical fit.

282actualMP4frames decoded and matched to native originals; maxsample mean RGBencodeerror4.529/255. Visual inspection covers all19transition/endpoints, essential first-joint samples, D30–39/C13–18 and E1–8 feed/withdrawal. Contact sheets and all282decodedframes included. This is sampled visual screening, **not** a claim that Codex watched continuous278s playback. Source/evaluator poseequality and arbitrary seek retain accepted N278s.16756protectedhashchecks,0changes. Actualsrc+runner typecheckPASS; sharedengine unchanged.

## Actual visual findings

- Previous lost-product S05 and brokencontext S08 repaired. Fullframes2108/70.266667 and3777/125.9 are byte-identical to their acceptedR2proof counterparts. Actualsource/pixels match across the reviewed transition images.
- S04shows both B bolts perK in the retained source choreography; no hidden receivinggeometry added. D30–34 macros show visible L/tool. E1–8 samples show exteriorhead/tool and tool withdrawal, with firstdoor retained during seconddoor placement.
- C13 macro exposes its exterior tool region; this does not close the inferred end-allocation/physical-access questions.
- **Readability WARN:** D35–39 and C14–18 remain contextual repeats. Their targets/tools are not individually legible in every frame, with far-side occlusion/tiny size in some views. Two actual-film reviewclips and close review sheets are attached. Do not treat retained-actor/digest PASS as individual fastener visibilityPASS. Please explicitly decide whether acceptable repetition shorthand or a targeted camera correction is needed.
- S17/S18 are clearly POSE-ONLY; N4remainstaged/HOLD; finalstudy has no operational door animation. Holds and source confidence are not upgraded.

## Director decision requested

Review actual fullmovie, two repeat-readability clips and evidence. State Long VISUALPASS or specific REVISION_REQUIRED findings. If repeatvisibility needswork, prefer focused camera-only proof(s) before another whole-film render; keep source/timing unless a separately documented presentation redistribution is needed. No new mechanical fixes are proposed.

If Long is internally accepted, review attached59s portrait proposal and authorize native1080×1920/30fps Short authoring/render. It retains source speed in shown windows, teaches D1 and BOTH K/B bolts, declares omitted repeats/forwardcuts, retains firstdoor, and explicitlylabels appearance preview/pose-only/HOLD. No unsupported functional opening or hidden hardware. Shorthasnotbeenimplemented/rendered yet. Audio remains unstarted pending picture approval.

K22/10UNMEASURED;FNONLITERAL;S13/S14 C allocation andI/JOPEN;S17/S18POSEONLY;S19pads/doorHOLD;historicalrawcollisionFAIL remain. Original sourcePDF and allprevious evidence preserved. Earlier S14falsealarm was formally retracted by Codex and Director; no GPU/exporter defect established. Human alone makes final acceptance after reviewing both actual completedfilms. No purchases/publication/generalInternet/Product01/JULIETTEchanges.
