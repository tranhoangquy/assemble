from pathlib import Path
from PIL import Image,ImageDraw,ImageChops,ImageStat
import json,hashlib,subprocess,shutil,zipfile
p=Path(__file__).resolve().parent;root=p.parents[3];base=p.parent;load=lambda f:json.loads(f.read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();run=lambda a:subprocess.check_output(a)
j=load(p/'COMPLETED-JOB.json');assert j['status']=='completed' and j['totalFrames']==8340
jd=Path(j['frameDirectory']).parent;m=load(jd/'manifest.json');assert len(m['frames'])==8340 and not m['missingFrames'] and not m['invalidFrames']
f=p/'PRODUCT03-Long-integrated-v2-silent-720p.mp4';assert sha(f)==j['sha256'];v=load(jd/'logs/verification.json');assert v['status']=='PASS' and v['fullDecode']=='PASS' and v['faststart']=='PASS'
s=v['media']['streams'];assert len(s)==1 and s[0]['codec_type']=='video' and int(s[0]['nb_read_frames'])==8340
pts=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(f)]))['frames'];assert len(pts)==8340 and all(abs(float(x['best_effort_timestamp_time'])-i/30)<1e-6 for i,x in enumerate(pts));(p/'ENCODED-PTS.json').write_text(json.dumps(pts))
telemetry=[json.loads(x) for x in (p/'CAPTURE-TELEMETRY.ndjson').read_text().splitlines()];assert len(telemetry)==8340
assert all(x['metric']['pass'] and not x['telemetry']['contextLost'] and x['telemetry']['glError']==0 and abs(x['telemetry']['time']-i/30)<1e-9 and x['telemetry']['drawingBuffer']==[1280,720] for i,x in enumerate(telemetry))
points=load(p/'REVIEW-CHECKPOINTS.json');d=p/'decoded-review';d.mkdir(exist_ok=True)
def balanced(values):
 if len(values)==1:return values[0]
 mid=len(values)//2;return '('+balanced(values[:mid])+'+'+balanced(values[mid:])+')'
expr=balanced(['eq(n'+chr(92)+','+str(x['index'])+')' for x in points])
run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-i',str(f),'-vf','select='+expr,'-fps_mode','passthrough','-start_number','0',str(d/'frame-%03d.png')]);assert len(list(d.glob('frame-*.png')))==len(points)
review=[]
for k,x in enumerate(points):
 src=Path(j['frameDirectory'])/f"frame-{x['index']:06d}.png";assert sha(src)==m['frames'][str(x['index'])];out=d/f'frame-{k:03d}.png'
 a=Image.open(src).convert('RGB');b=Image.open(out).convert('RGB');assert a.size==b.size==(1280,720);error=ImageStat.Stat(ImageChops.difference(a,b)).mean;review.append(dict(**x,decoded=str(out.relative_to(p)),sourceSha256=sha(src),meanRGBerror=sum(error)/3))
for page in range((len(review)+19)//20):
 rows=review[page*20:(page+1)*20];im=Image.new('RGB',(1600,1250),'#eee9e0');dr=ImageDraw.Draw(im)
 for k,x in enumerate(rows):a=Image.open(p/x['decoded']).convert('RGB');a.thumbnail((400,225));xx=k%4*400;yy=k//4*250;im.paste(a,(xx,yy));dr.text((xx+4,yy+227),f"{x['time']:.4f}s / {x['label'][:45]}",fill='black')
 im.save(p/f'ACTUAL-MP4-SHEET-{page+1:02d}.jpg',quality=94)
(p/'ACTUAL-MP4-FRAME-QA.json').write_text(json.dumps(review,indent=2))
protected=[]
for file in [root/'output/product03-pet-crate-w114586144/phase-a-v1/evidence/protected-baseline.json',base/'long-v2-bounded-p0-repair/FROZEN-R2-REPAIR-PASS.json',base/'p1-camera-only-v1/FROZEN-P1-CAMERA-PILOT.json',base/'option-n-timing-isolated-v1/FROZEN-OPTION-N-TIMING.json',base/'p2-p3-camera-only-v1/FROZEN-P2-P3-CAMERA.json',base/'full-19-step-integration-v1/FROZEN-REJECTED-LONG-V1.json']:
 dic=load(file);files=dic.get('files',dic)
 for n,h in files.items():z=Path(n);z=z if z.is_absolute()else root/z;assert sha(z)==h;protected.append(n)
for n,h in load(p/'INPUT-FREEZE.json')['files'].items():
 if n!='BUNDLE':assert sha(root/n)==h
network=load(p/'OFFLINE-NETWORK-QA.json');assert network['externalRequestsTransmitted']==0
q={'status':'TECHNICAL PASS / REQUIRES ACTUAL DIRECTOR VISUAL REVIEW','file':f.name,'sha256':sha(f),'native':[1280,720],'duration':278,'fps':30,'frames':8340,'audio':False,'decode':'PASS actual sharedmanager','PTS':'PASS all8340','faststart':'PASS','chunks':len(m['chunks']),'retries':m['retries'],'guardFrames':len(telemetry),'minimumForegroundRatio':min(x['metric']['ratio'] for x in telemetry),'contextLoss':0,'glErrors':0,'exactCaptureTimes':True,'browserGenerations':len(set(x['g'] for x in telemetry)),'actualMP4SampledFrames':len(review),'maxMeanRGBEncodeError':max(x['meanRGBerror']for x in review),'protectedChecks':len(protected),'changes':0,'screeningLimit':'Sampled images + perframe foreground guard cannot establish continuous perfect playback, absence of all occlusion or physical assembly certification','holds':['K22/10UNMEASURED','FNONLITERAL','C13/C14OPEN','I/JOPEN','S17/S18POSEONLY','S19pads/doorHOLD','historicalrawcollisionFAIL'],'S14correction':'Prior empty-frame report formally retracted; actual original and replay match productpixels'}
(p/'FULL-LONG-V2-QA.json').write_text(json.dumps(q,indent=2));print(json.dumps(q,indent=2))
