# Native portrait Short — proposed59s edit (planning only)

Pending actual Long internal visualPASS. No Short implementation/render yet. Same geometry/materials/OEM inventory/acceptedNsource. Native1080×1920/30fps/1770frames through existing vertical-1080p exporter. New portrait camera, captions and source-window identity; never crop/re-encode the landscape Long or globally accelerate assembly.

| Short time | Accepted N source window | Purpose / omission disclosure |
|---|---|---|
|0–2|Frozen272s|Finished appearance preview; clearly labeled illustrative/HOLD, no operational door demo; explicit reset into assembly next|
|2–11.9|0–9.76 then.14s hold|First two side panels, contact, complete D1/L approach/insertion/withdrawal; fixed near9.7599s for last.14s rather than starting D2|
|11.9–15.9|18–22|Two dividers contact; repeated screws omitted/seeLong|
|15.9–18.4|31–33.5|Top panel placement; no premature screw claim|
|18.4–31.7|41–54.3|Teach one complete K bracket and BOTH B bolts, with tool withdrawal; opposite bracket is declared repeated in Long; K22/10UNMEASURED|
|31.7–34.1|108.5–110.9|A4/A5 foot preparation; A5 remains host5-relative|
|34.1–39.6|112–117.5|Actual source inversion and both side-frame contacts; repeated D screws are omitted by forwardcut, not reinstalled|
|39.6–42.6|189.25–192.25|Prepared host5 with A5 approaches/contacts; intermediate rear/front/rail steps omitted and explicitly referred to Long; C13/C14allocationOPEN|
|42.6–44.6|205.15–207.15|Place floor, no screw invention|
|44.6–46.6|208.5–210.5|Door7 placement|
|46.6–50.8|210.75–214.8251 then.1249s hold|Exterior E1/E2 + M, tool withdrawal retained; remaining E repeated operations omitted explicitly|
|50.8–52.8|218.1952–220.1952|Door8 placement; door7 retained|
|52.8–53.533333|Frozen231s|S17 exterior pose only, no tightening/retention claim|
|53.533333–54.266667|Frozen241s|I/J unresolved pose only|
|54.266667–55|Frozen266s|Four N pads staged/HOLD, no operation claim|
|55–59|Frozen272s|Clean product study hero; installation/door holds remain; no usable/certified-capacity claim|

All source windows after the opening reset move forward. Every cut restores the exact next canonical source state, including all omitted already-placed parts/hardware. Captions must visibly identify omitted repeats; counts remain source-owned and no completed mechanical work is implied. F NONLITERAL steps are explicitly omitted from highlights, still disclosed in limits/Long. Final source retains20structural,84initialvisualseats,12pose-only,4Nheld. No source confidence upgrade.

Portrait framing plan: context before each essential connection, dedicated native macro for D1 and both K/B bolts, close E pair with unobscured tool tip, clear retained-state door2 context. Hook/final are appearance studies, NOT an unsupported functional demonstration. Mobile safe text region and active targets must be validated in native PNGs. No audio until visual approval. Proposed omissions/held functional hook require Director disposition with actual Long review before authoring.
