# P1 camera-only pilot — actual motion capture

- 108–124s,384 native frames,24fps,16s,no audio. All V2 actor transforms/visibility remain identical at the same timestamps. Only camera changes.
- A4/A5 underside composition now exposes both feet beneath their prepared hosts. A5 still belongs to carrier5; no host/foot motion was corrected or certified.
- Stable wide view retains inversion and side-frame approach. Camera transitions replace abrupt wide/macro switches; rail/socket/tool context is visible in the oblique macro.
- Native frames show earlier D heads retained while the active D/tool progresses. This partial window does not show all10 D of S08. D33 is incomplete at the end.
- Fastener-completion holds remain short because this is camera-only. No timing improvement is claimed. L key is visible, but some shaft/head views still depend on phase and need Director judgement.
- Initial camera trial had12 numerical motion flags; a later calibration had5 flags at rail-to-corner. Preserved logs document both. Final1-second blend yields0 flags at6 degrees/frame and300 display-units/frame review thresholds. These are camera review criteria, not engineering tolerances.
- Actual PNG inspection supports the observations above; full continuous playback is requested from Director. No local auditory or human ergonomic QA is claimed.

## Camera buffers
Entry106.5–108 and exit124–125s are product-owned camera-only buffers; the attached pilot remains exactly108–124s. They do not alter assembly timestamps. Later integrated review must inspect these buffers and all transitions too.

## Unchanged source qualifications
K22/10 UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN; S17/S18 POSE-ONLY; S19 HOLD. Historical raw collision FAIL retained. No receiving holes, physical retention, torque, hand/tool access or OEM dimensions certified.
