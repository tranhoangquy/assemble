from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,shutil,zipfile,datetime
P=Path(__file__).resolve().parent;ROOT=P.parents[3];R=ROOT/'output/product03-pet-crate-w114586144';old=R/'targeted-motion-proofs-v1'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
media=load(P/'PILOT-MEDIA-QA.json');camera=load(P/'CAMERA-CHECK.json');assert media['status']=='PASS'and camera['cameraOnlyPoseEquality']and not camera['flags']
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18);large=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',26)
indices=[0,36,50,72,100,120,144,168,228,240,264,288,312,336,360,372]
selected=[]
for page in range(4):
 im=Image.new('RGB',(1600,4*255+65),'#ede8df');d=ImageDraw.Draw(im);d.text((16,14),'P1 CAMERA ONLY | LEFT: FROZEN V2 | RIGHT: PILOT | same absolute time',font=large,fill='#282c2e')
 for j,i in enumerate(indices[page*4:(page+1)*4]):
  t=108+i/24;y=65+j*255
  for x,base,label in [(0,old,'BEFORE'),(800,P,'AFTER')]:
   f=base/'frames/P1'/f'frame-{i:06d}.png'
   with Image.open(f)as a:im.paste(a.convert('RGB').resize((800,225)),(x,y))
   d.text((x+10,y+229),f'{label}  f{i:03d} / global {t:.6f}s',font=font,fill='#5a4531')
 im.save(P/f'BEFORE-AFTER-{page+1:02d}.jpg',quality=94)
sel=P/'selected-originals';sel.mkdir(exist_ok=True)
for i in indices:
 f=P/'frames/P1'/f'frame-{i:06d}.png';dst=sel/f.name;shutil.copyfile(f,dst);selected.append(dict(index=i,time=108+i/24,path=str(dst.relative_to(P)),sha256=sha(dst)))
(P/'SELECTED-ORIGINALS.json').write_text(json.dumps(selected,indent=2))
checks=[]
protected=load(R/'phase-a-v1/evidence/protected-baseline.json')
base=load(P.parent/'PROTECTED-BASELINE.json')
# Historical baselines are read, never rewritten; all recorded frozen contents verified.
def verify(entries,owner):
 for name,h in entries.items():
  f=Path(name)
  if not f.is_absolute():
   f=next((b/name for b in [ROOT,R,owner.parent] if (b/name).is_file()),ROOT/name)
  actual=sha(f);checks.append(dict(path=str(f.relative_to(ROOT)),expected=h,actual=actual,match=actual==h))
verify(protected,R/'phase-a-v1/evidence/protected-baseline.json')
verify(load(P/'BASELINE-AND-CAPTURE-IDENTITY.json')['sourceFiles'],P/'BASELINE-AND-CAPTURE-IDENTITY.json')
for f in R.glob('*/REVIEW-DELIVERY-MANIFEST.json'):
 for row in load(f):verify({row['path']:row['sha256']},f)
for n in ['f-illustrative-proof-v1/FROZEN-LOCAL-PROOF.json','part-first-sequence-v1/FROZEN-FOCUSED-PROOF.json','timeline-integration-plan-v1/FROZEN-INTEGRATION-PLAN.json','timeline-integration-v1/FROZEN-INTEGRATION-EVIDENCE.json','s04-two-bolt-proof-v1/FROZEN-S04-PROOF.json','s04-integration-v2/FROZEN-INTEGRATION-V2.json','p0-teaching-continuity-audit-v1/FROZEN-READ-ONLY-AUDIT.json','phase-d-illustrative-v2/FROZEN-BLOCKING-SHA256.json','targeted-motion-proofs-v1/FROZEN-MOTION-PROOF-EVIDENCE.json','teaching-readability-correction-plan-v1/FROZEN-READABILITY-PLAN.json']:
 f=R/n
 if f.exists():verify(load(f)['files'],f)
assert all(x['match']for x in checks)
(P/'PROTECTED-VERIFICATION.json').write_text(json.dumps(dict(status='PASS',checkedEntries=len(checks),protectedProduct01JuliettePaths=len(protected),changes=0,historicalCollisionFAIL='PRESERVED',checks=checks),indent=2))
(P/'VISUAL-FINDINGS.md').write_text('''# P1 camera-only pilot — actual motion capture

- 108–124s,384 native frames,24fps,16s,no audio. All V2 actor transforms/visibility remain identical at the same timestamps. Only camera changes.
- A4/A5 underside composition now exposes both feet beneath their prepared hosts. A5 still belongs to carrier5; no host/foot motion was corrected or certified.
- Stable wide view retains inversion and side-frame approach. Camera transitions replace abrupt wide/macro switches; rail/socket/tool context is visible in the oblique macro.
- Native frames show earlier D heads retained while the active D/tool progresses. This partial window does not show all10 D of S08. D33 is incomplete at the end.
- Fastener-completion holds remain short because this is camera-only. No timing improvement is claimed. L key is visible, but some shaft/head views still depend on phase and need Director judgement.
- Initial camera trial had12 numerical motion flags; a later calibration had5 flags at rail-to-corner. Preserved logs document both. Final1-second blend yields0 flags at6 degrees/frame and300 display-units/frame review thresholds. These are camera review criteria, not engineering tolerances.
- Actual PNG inspection supports the observations above; full continuous playback is requested from Director. No local auditory or human ergonomic QA is claimed.

## Camera buffers
Entry106.5–108 and exit124–125s are product-owned camera-only buffers; the attached pilot remains exactly108–124s. They do not alter assembly timestamps. Later integrated review must inspect these buffers and all transitions too.

## Unchanged source qualifications
K22/10 UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN; S17/S18 POSE-ONLY; S19 HOLD. Historical raw collision FAIL retained. No receiving holes, physical retention, torque, hand/tool access or OEM dimensions certified.
''')
(P/'DIRECTOR-REVIEW.md').write_text('''# PRODUCT03 — P1 CAMERA-ONLY PILOT V1 REVIEW

Human has authorized continuous execution to completed Long/Short internal review; actual authority JSON attached. Old per-proof stop boundaries do not require asking human to continue within this scope. OPEN/HOLD and security limits remain binding.

Actual new deliverable: PRODUCT03-P1-camera-only-pilot-v1-720p.mp4 (16s,384 frames,1280x720,24fps,silent). Four same-time before/after contact sheets, selected original PNGs, media QA, camera-only pose equality and preserved raw trials are in the evidence archive.

CAM-01/02/03 improve feet identification, fixed inversion/context view and stable oblique fastener composition. Frozen V2 actor poses match exactly at384timestamps. No timing/geometry/graphics change. Entry/exit buffer106.5–108/124–125s disclosed. Numeric camera continuity0 flags in the pilot; actual visual acceptance remains your decision.

Please inspect actual MP4 and comparisons. Return an explicit camera-only decision, remaining visible defects, and the next scoped technical/creative revision. Recommended next: implement isolated OptionN static-wait redistribution at unchanged278s, retaining moving-phase durations; then P2/C13 and P3 door camera revisions, followed by full19-step integration and actual Long/Short film review. Preserve all unresolved physical semantics; do not authorize invented mechanical fixes. We will continue autonomously within the new human scope after your decision.

Global npm typecheck fails on pre-existing archived output snapshots. The isolated all-src typecheck passes;2 targeted deterministic tests pass; lint has no errors (one inherited unused import removed before capture). No application/catalog or frozen source edits.
''')
# Actual authorizing text is already saved separately; include for explicit scope provenance.
shutil.copyfile(P.parent/'HUMAN-CONTINUOUS-AUTHORIZATION.json',P/'HUMAN-CONTINUOUS-AUTHORIZATION.json')
items=[P/'PRODUCT03-P1-camera-only-pilot-v1-720p.mp4',P/'PILOT-MEDIA-QA.json',P/'CAMERA-CHECK.json',P/'BASELINE-AND-CAPTURE-IDENTITY.json',P/'CHUNK-SEAM-QA.json',P/'FRAME-SHA256-MANIFEST.json',P/'SELECTED-ORIGINALS.json',P/'DIRECTOR-REVIEW.md',P/'VISUAL-FINDINGS.md',P/'PROTECTED-VERIFICATION.json',P/'HUMAN-CONTINUOUS-AUTHORIZATION.json',*P.glob('BEFORE-AFTER-*.jpg'),*sel.glob('*.png')]
manifest=[dict(path=str(f.relative_to(P)),sha256=sha(f),bytes=f.stat().st_size)for f in items];(P/'REVIEW-SHA256.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(P/'PRODUCT03-P1-CAMERA-ONLY-EVIDENCE.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in [*items,P/'REVIEW-SHA256.json']:z.write(f,str(f.relative_to(P)))
print(json.dumps(dict(media=media['media'],evidenceZipSha256=sha(P/'PRODUCT03-P1-CAMERA-ONLY-EVIDENCE.zip'),preserved=len(checks)),indent=2))
