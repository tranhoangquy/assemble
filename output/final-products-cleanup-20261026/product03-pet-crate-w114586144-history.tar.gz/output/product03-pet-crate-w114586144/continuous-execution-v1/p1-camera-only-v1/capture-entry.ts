/** Capture scheduling only. The frozen presentation module renders each frame
 * with its unchanged evaluator, camera(time,false), materials, lighting and HUD. */
import '../../../../src/products/product03-pet-crate-w114586144/continuous-production-v1/p1-preview';
import identity from './BASELINE-AND-CAPTURE-IDENTITY.json';
const api=window.__MECHANISM_AUDIT_RENDERER__;
if(!api)throw Error('Frozen V2 renderer not ready');
// Mutate the original list in place: the original render(name) closure searches
// this same array. Do not replace render(), create a camera or change the scene.
api.checkpoints.splice(0,api.checkpoints.length,...identity.proofs.flatMap(p=>
 p.chunks.flatMap((chunk,c)=>Array.from({length:chunk.end-chunk.start},(_,j)=>{
  const i=chunk.start+j;
  return{name:`${p.id}-C${c+1}-frame-${String(i).padStart(6,'0')}.png`,label:p.id,time:p.start+i/identity.fps};
 }))));
