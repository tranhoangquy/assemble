"""Offline documentary audit. Never imports renderer, browser, or networking code."""
from pathlib import Path
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo
import csv
import hashlib
import json
from pypdf import PdfReader

B = Path(__file__).resolve().parent
ROOT = B.parents[2]
PDF = B / 'source/human-provided-pet-crate-manual.pdf'
stamp = datetime.now(ZoneInfo('Asia/Ho_Chi_Minh')).isoformat()

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def save(name, value):
    p = B / name
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n' if name.endswith('.json') else value)

def table(headers, rows):
    return '| ' + ' | '.join(headers) + ' |\n|' + '|'.join('---' for _ in headers) + '|\n' + ''.join('| ' + ' | '.join(str(v).replace('|', '/') for v in row) + ' |\n' for row in rows)

# IDs and quantities are transcription, descriptive names are not OEM names.
part_rows = [
    ('1', 1, 'Tubular mesh side-frame variant 1', 'S7 feet; S8 module attachment', 'Opposite side to 2; curved rail at finished top. Do not interchange hole faces.'),
    ('2', 1, 'Tubular mesh side-frame variant 2', 'S7 feet; S8 module attachment', 'Opposite side to 1; preserve square-pipe direction in S8 insets.'),
    ('3', 1, 'Front upper crossrail / door-header assembly', 'S11', 'Handle/tab faces follow S11 inset; descriptive role INFERRED from location.'),
    ('4', 1, 'Rear mesh-frame assembly', 'S9', 'Spans sides 1/2; four C fixing positions depicted.'),
    ('5', 1, 'Front lower crossrail with centre foot support and tabs', 'S7 A preparation; S14', 'Preserve tab/iron direction, centre A foot and depicted projecting studs.'),
    ('6', 4, 'Floor-support crossrails', 'S13/S14', 'Four bars; end receiver shown in S13. Exact C allocation across ends unresolved.'),
    ('7', 1, 'Front door variant 7', 'S16', 'Left in S16 front view; hinge leaves and handle are depicted constituent features.'),
    ('8', 1, 'Front door variant 8', 'S16', 'Right in S16 front view; do not mirror latch studs/hinges arbitrarily.'),
    ('9', 1, 'Large upper panel / tabletop', 'S3', 'Four D positions depicted; finished role supported by exploded and completed views.'),
    ('10', 2, 'Upper-module side panels', 'S1', 'Hole-marked faces/edges as S1; identical ID does not permit arbitrary orientation.'),
    ('11', 2, 'Upper-module divider panels', 'S2', 'S2 Metal nuts labels and hole marks; K brackets added in S4.'),
    ('12', 1, 'Long upper-module connecting panel', 'S1', 'Links 10 pair and receives divider association in S2; rear-wall role INFERRED.'),
    ('13', 1, 'Long upper-module panel / rear upstand', 'S5', 'Seven D positions. Upstand role INFERRED by relating exploded and finished views.'),
    ('14', 1, 'Crate floor panel', 'S15', 'Placed over completed lower supports; no additional fixing hardware called out.'),
    ('15', 1, 'Upper-module broad closing panel', 'S6', 'Ten D positions; finished cubby-floor role INFERRED. Prefer numbered steps over ambiguous exploded leaders.'),
]
parts = [dict(id=i, quantity=q, description=d, introduction=s, orientation=o,
              evidence='PDF p3, printed p2; PDF p1 exploded; relevant numbered step',
              quantity_status='CONFIRMED_LOCAL_MANUAL', dimensions='UNKNOWN') for i,q,d,s,o in part_rows]

hardware_rows = [
    ('A',5,'Round adjustable-foot type','Ø16','installed','S7:5','External foot/stem pictured; thread diameter/pitch and adjustment range UNKNOWN.'),
    ('B',4,'Socket-head short bolt','Ø6X10L','installed','S4:4','Through K into shown panel receiving points; hidden insert construction UNKNOWN.'),
    ('C',18,'Socket-head long bolt','Ø6X25L','installed','S9:4; S11:4; S13:4; S14:6','Frame/rail joints; exact bore coordinates/thread pitch UNKNOWN.'),
    ('D',39,'Pointed socket-drive panel screw','Ø5X44L','installed','S1:4; S2:4; S3:4; S5:7; S6:10; S8:10','Screw silhouette and nominal size shown. No invented pilot depth, thread helix/pitch or insert.'),
    ('E',8,'Cross-drive short hinge screw','Ø4*11L','installed','S16:8','Two per depicted hinge attachment; receiving construction not sectioned.'),
    ('F',8,'Cross-drive long frame-to-module screw','Ø4*25L','installed','S10:4; S12:4','Source explicitly says Lock the screws firmly; preserve alignment-first rule.'),
    ('G',4,'Hex nut with raised collar','not stated','installed','S17:2; S18:2','Exact thread and insert/locking chemistry UNKNOWN.'),
    ('H',4,'Split-ring washer','not stated','installed','S17:2; S18:2','Shown split; dimensions and washer material UNKNOWN.'),
    ('I',2,'Bent rotating retaining tab, ID I','not stated','installed','S18:2 PROVISIONAL','S18 inset says I; S18 summary says J. Conflict must remain visible.'),
    ('J',2,'Bent rotating retaining tab, ID J','not stated','installed','S17:2','S17 inset and summary agree J. Do not silently consume J twice.'),
    ('K',2,'Right-angle fixing bracket','not stated','installed','S4:2','Two B per bracket connect divider region to broad panel as inset.'),
    ('L',1,'L-shaped hex key','M4','tool','tool, not consumed','M4 is the tool label; not proof all mating threads are M4.'),
    ('M',1,'Phillips screwdriver','not stated','tool','tool, not consumed','Manual tool-required notice; power tool NOT recommended.'),
    ('N',4,'EVA-type pad/disc','Ø19*3','accessory','S19:4','Release-liner sketch, two positions per door; selection wording is ambiguous.'),
    ('O',1,'Open-ended spanner','not stated','tool','tool, not consumed','Jaw size UNKNOWN; not an installed product component.'),
]
hardware = [dict(id=i,quantity=q,description=d,printed_size=size,category=cat,allocation=a,
                 limitations=lim,evidence='PDF p1 hardware table; named steps',
                 quantity_status='CONFIRMED_LOCAL_MANUAL',
                 size_units='Units not printed; do not silently promote conventional mm interpretation to source-confirmed dimensions')
            for i,q,d,size,cat,a,lim in hardware_rows]

# Introduction is not an assertion that an entire composite part has no factory features.
steps_data = [
 (1,4,['10','12'],{'D':4},'Connect the two 10 panels to the ends of 12; align the indicated hole faces before seating D.','Across outer 10 faces toward 12 ends. Receiving geometry beyond depicted holes UNKNOWN.'),
 (2,4,['11'],{'D':4},'Add both 11 dividers to the S1 module. Preserve Metal nuts / hole orientation.','D alignment follows inset through connecting panel toward divider end; exact buried receiver UNKNOWN.'),
 (3,5,['9'],{'D':4},'Align panel9 over the module and place four D at the illustrated positions.','Broad-face access normal to panel9; support module and keep edge alignment visible.'),
 (4,5,[],{'B':4,'K':2},'Add two K brackets at divider/broad-panel interfaces with two B per bracket.','Two perpendicular bolt axes in each K; underside view implies supported module reorientation, not a new OEM step.'),
 (5,6,['13'],{'D':7},'Position 13 against the illustrated upper-module edges and insert seven D.','Approach normal to 13. Individual backing ownership of all seven positions needs mapping; no invented pilot detail.'),
 (6,6,['15'],{'D':10},'Close the illustrated module face with 15, aligning all ten D positions.','Approach normal to 15. Keep partitions retained; source does not section each receiver.'),
 (7,7,['1','2','5'],{'A':5},'Prepare four corner feet on frames1/2 and one on rail5. Keep rail5 available for S14.','Feet enter the illustrated frame ends/rail boss; no invented thread size or travel.'),
 (8,7,[],{'D':10},'Join frames1/2 to the completed upper module using ten D; obey square-pipe orientation in both insets.','Drawing is inverted relative to final use. Align through pipe faces to module points; do not animate a hidden unsupported flip.'),
 (9,8,['4'],{'C':4},'Join rear frame4 between sides1/2 with four C, retaining all previous components.','External side-post approach to rear-frame ends as inset.'),
 (10,8,[],{'F':4},'Insert four F at the rear frame/module association and tighten as instructed after alignment.','Cross-drive access from pictured exposed rail face; no power tool. Exact each backing/shaft envelope not dimensioned.'),
 (11,9,['3'],{'C':4},'Join front rail3 using four C; preserve its handle/tab direction.','External side-post approach; orientation inset is mandatory.'),
 (12,9,[],{'F':4},'Insert four F at front rail/module association and tighten after alignment.','Keep front and side alignment established; do not claim certified driver access.'),
 (13,10,['6'],{'C':4},'Place four rails6 as shown, using only the four C assigned to S13.','Receiver at rail end is illustrated. Opposite-end capture/remaining C allocation is not fully explicit.'),
 (14,10,[],{'C':6},'Join prepared rail5 with centre A foot, preserve iron/tab direction and complete six C shown.','Likely completes four rail6 ends plus two rail5 ends, but this allocation is INFERRED and needs resolution before animation.'),
 (15,11,['14'],{},'Reorient to the illustrated upright state and lower floor14 onto the supports; no fastener added.','Turnover/support choreography is presentation staging, not an OEM instruction. Do not screw down14 without evidence.'),
 (16,11,['7','8'],{'E':8},'Position and support both doors; attach depicted hinge leaves using eight E.','Two E per hinge, four hinges shown. Inset screw studs are already part of depicted assemblies, not new loose hardware.'),
 (17,12,[],{'G':2,'H':2,'J':2},'Fit two J upper retaining tabs with two H and two G to the existing studs.','Source exploded order: stud, H, J, G outward. Do not assert a buried stud fastening method.'),
 (18,12,[],{'G':2,'H':2,'I':2},'Fit lower retaining tabs provisionally identified I by inset. Summary incorrectly/redundantly labels J.','Source exploded order: stud, H, I, G. I/J disposition remains unresolved; do not silently relabel.'),
 (19,13,[],{'N':4},'Apply four N pads at the two indicated positions on each opened door.','Source shows a release liner and mentions choosing own EVA pad. Exact contact action, placement coordinates and optionality need clarification.'),
]
steps=[]
for n,p,intro,hw,action,access in steps_data:
    steps.append(dict(id=f'S{n:02}',OEM_step=n,pdf_page=p,printed_page=p-1,
                      sequence_prerequisites=[f'S{n-1:02}'] if n>1 else [],
                      introduced_part_ids=intro,hardware=hw,action=action,
                      receiving_and_access=access,alignment_rule='ALIGN_ALL_RELEVANT_COMPONENTS_BEFORE_FINAL_TIGHTENING',
                      state_rule='Retain every previously installed component; no reset or disappearance',
                      confidence='DOCUMENTED_ASSOCIATION_WITH_EXPLICIT_UNKNOWNS',
                      production_motion_validation='NOT_RUN'))

issues = [
 ('P03-U01','P0','Identity / variant','PDF metadata names Wayfair W114586144 and drawers; visible pages have no model label and show open cubbies, not drawer boxes/slides.','Human-confirmed local product reference/model label or dimensioned matched local sheet. Do not add drawers.','Exact commercial/finish variant and drawer animation'),
 ('P03-U02','P0','Dimensions','No overall or per-panel dimensions, mesh pitch, tube section or thickness drawing.','Dimensioned local product/part drawing or measurements supplied with authority. Never scale hardware/perspective into certified panel sizes.','Faithful dimensioned geometry and fit'),
 ('P03-U03','P0','S18 I/J conflict','PDF p12 inset calls I twice, summary calls J x2; inventory gives I2/J2.','Authoritative correction or clear local photos of I/J and their installed positions. Recommendation only: J2 upper/S17, I2 lower/S18.','Lower retaining-tab identity; no automatic confidence upgrade'),
 ('P03-U04','P1','C allocation S13/S14','Four rails6, C4 in S13 and C6 in S14 together with rail5.','Clear matched end-connection views or annotated OEM allocation. Hypothesis four C at opposite6 ends plus two at5 is not confirmed.','Individual fastener chronology/end targets'),
 ('P03-U05','P0','Receiving geometry','Diagrams establish visible associations but no depth, thread pitch, insert construction, exact bore coordinates or engagement lengths.','Local detailed drawings/photos/measurements for any hidden feature to be modeled. Keep visible-only abstraction explicit where permitted.','Detailed internal fastener/receiving models; not a rejection of documented qualitative joints'),
 ('P03-U06','P1','Panel orientation / role mapping','10/11 hole orientation and 12/13/15 roles require preserving numbered-step views; exploded leaders alone can be ambiguous.','Cross-view local annotation of every mating face; receive-coordinate evidence for production fit.','Orientation transforms and backing ownership'),
 ('P03-U07','P1','Support and reorientation','S4 underside view; S8-S14 inverted frame; S15 upright. No manpower or supported turnover path specified.','Local approved support/staging plan; do not certify lifting or stability. Keep all installed parts rigidly grouped during a visible change.','Turnovers and unsupported floating states'),
 ('P03-U08','P1','Full tightening semantics','Global alignment-first notice plus explicit firmly-lock captions in S10/S12; no torque or comprehensive final tightening sequence.','Documentary plan that honors source checkpoints and has a final inspection after all alignment; no arbitrary torque.','No early final tightening or blanket looseness after completion'),
 ('P03-U09','P1','Tools and access','L/M/O pictured; no precise hand/bit/shaft clearance in installed state; power tool not recommended.','Actual local dimensions/access evidence before certifying tool/hand fit; visible manual axes may be taught without hidden engagement claims.','Connection proof and future access'),
 ('P03-U10','P1','Factory features / studs / hinges','Door handles, hinge leaves and studs are drawn in composite parts; no separate loose inventory IDs or fasteners to build them.','Detailed matched local feature views if necessary. Retain as integrated depicted features, do not invent installation hardware.','Door rig, latch stack and inventory boundaries'),
 ('P03-U11','P1','Floor14 and operation limits','Floor is placed in S15 without screws; no load, pet size, floor fixing, door angle limit or closing clearance stated.','Matched local dimensional/functional evidence. No fabricated floor fixings, stop or certified capacity.','Functional demonstration claims and collision setup'),
 ('P03-U12','P1','Pad N','Inventory N4 and S19 N4; text allows own EVA pad, liner sketch shown.','Local choice/confirmation of supplied pads and clear target photos; no invented adhesive product or certified pinch protection.','Optionality and final contacts'),
 ('P03-U13','P2','Materials / colors','Line drawing does not specify wood species, board composition, coating, paint, plating or color.','Local product appearance reference or human approval of clearly labeled art proposal.','Final appearance; proposed palette is not OEM fact'),
 ('P03-U14','P2','Source readability','Catalog/foreword page overlaps text; Poppler reports Adobe-GB1 / R19 font warnings. Main numbered diagrams/tables are legible in reviewed images.','Retain raw PDF and warn about rendering limits; use extracted text and visible instruction inset together, not guessed lost glyphs.','Do not claim error-free source render'),
 ('P03-U15','P1','Exact hardware specifications','Sizes printed without explicit unit statement; Ø is not an ISO thread specification; G/H/I/J/K have no dimensions.','Matched local specification if exact engineering dimensions are required. M4 on L does not assign every joint thread.','Engineering-sized fastener prototypes'),
]

save('PARTS-HARDWARE-INVENTORY.json',{'parts':parts,'hardware':hardware,'counting_rule':'Count 1-15 as OEM supplied assemblies. Do not count constituent welded mesh/hinges/handles as extra OEM parts.','totals':{'part_types':15,'part_instances':sum(p['quantity'] for p in parts),'hardware_and_tool_types':15,'hardware_accessories_and_tool_units':sum(h['quantity'] for h in hardware),'installed_or_accessory_units':sum(h['quantity'] for h in hardware if h['category']!='tool'),'tool_units':3}})
save('ASSEMBLY-DEPENDENCIES.json',{'schema_scope':'Documentary operation ledger, not a new runtime AssemblyGraph schema','steps':steps,'reorientations':[{'between':'S3/S4','status':'INFERRED staging, support required'},{'between':'S7/S8','status':'Illustrated inverted assembly orientation; staging/support not specified'},{'between':'S14/S15','status':'Upright final orientation observable; turnover choreography unverified'}]})
save('UNCERTAINTY-REGISTER.json',[dict(id=i,severity=p,subject=s,observed=e,evidence_needed=n,affected_scope=a,status='OPEN') for i,p,s,e,n,a in issues])

save('PRODUCT-BOM.md', '# Product #03 - parts and hardware inventory\n\nLocal PDF pages are 1-based; printed page numbers are one lower from PDF p3 onward. PDF p2 is an unnumbered foreword. CONFIRMED means confirmed in this local manual, not independent physical certification. Descriptive names are analyst labels.\n\n## Numbered assemblies\n\n'+table(['OEM ID','Qty','Description','Introduction','Orientation / limits'],part_rows)+'\nEvery row is sourced to PDF p3 (printed p2) and PDF p1 exploded view, checked against the listed steps. **15 types / 20 numbered component instances.** Dimensions of every numbered part are UNKNOWN.\n\n## A-O inventory\n\n'+table(['ID','Qty','Description','Printed size','Category','Step allocation','Limitations'],hardware_rows)+'''\nAll A-O counts and printed size strings: PDF p1 hardware table. Step callouts are checked on PDF pp4-13. **103 listed units = 100 installed/accessory units + 3 tools (L/M/O).** N is included as a listed accessory; optionality remains open. No spares explicitly declared.

The A-O nomenclature includes tools; do not place all 103 units in a product mesh registry. Hinges, handles, mesh, welded tabs and studs depicted within numbered assemblies remain constituent features, not invented extra OEM part IDs. Their exact factory assembly/fastening is unknown.

**S18 conflict:** using the literal J summary twice would demand J4 while leaving I2 unused. J2 in S17 and I2 in S18 reconciles the inventory and matches S18 inset, but remains a proposed correction requiring resolution. No manufacturer correction is asserted.

**No drawers:** the PDF metadata mentions drawers; the 15-part list and 19 steps contain open divided storage with no drawer boxes, slides or drawer-installation operations. Do not create any.
''')

save('ASSEMBLY-DEPENDENCY-MAP.md','# Product #03 - documentary assembly dependencies\n\n**19/19 OEM steps covered.** The conservative dependency chain retains the manual order; this is a source ledger, not implemented animation. Unobserved support/tool access is not validated by a diagram.\n\n'+table(['Step','PDF / printed page','New part IDs','Hardware','Operation','Receiving/access notes'],[(s['id'],f"{s['pdf_page']} / {s['printed_page']}",', '.join(s['introduced_part_ids']) or 'retained state','; '.join(f'{k}x{v}' for k,v in s['hardware'].items()) or 'none',s['action'],s['receiving_and_access']) for s in steps])+'''
## Dependency structure

```mermaid
flowchart TD
  S1["S1-S3: 10/12, dividers11, panel9"] --> S4["S4: K/B brackets"]
  S4 --> S56["S5-S6: 13 and15 close upper module"]
  S56 --> S7["S7: A feet on1/2 and5"]
  S7 --> S8["S8: side frames1/2 to module, inverted"]
  S8 --> S910["S9-S10: rear4, C thenF"]
  S910 --> S1112["S11-S12: front3, C thenF"]
  S1112 --> S1314["S13-S14: four6 and prepared5; C allocation open"]
  S1314 --> S15["S15: supported upright state, floor14"]
  S15 --> S16["S16: doors7/8, E"]
  S16 --> S1718["S17-S18: retaining tabs, I/J conflict open"]
  S1718 --> S19["S19: N pads and completed-state check"]
```

Rail5 is prepared with A in S7 and retained as a staged subassembly until S14; do not show it installed then disappear. Four6 arrive in S13 and stay installed through S14. Every other introduction is retained in subsequent forward assembly. Integrated mesh, handles and hinges must not be reinstalled as fictional loose parts.

## Alignment and tightening

PDF p2 requires all relevant pieces aligned before final screw tightening. S10/S12 specifically say to lock firmly. Establish the associated frame/module alignment first, then execute those source checkpoints. Use temporary engagement/placement states before final securing; no invented torque or number of turns. Add a final inspection, explicitly a presentation verification rather than OEM step20. A local sequence plan must reconcile remaining-group final tightening without making earlier shots imply a misaligned rigid enclosure.

## Orientation and support

S4 exposes the module underside; S8-S14 show the structure inverted relative to final use (feet at upper side, curved finished top toward support). S15 shows it upright. Source views establish orientation changes, not a safe lifting maneuver or human tool-access certification. Proposed staging must show context before and after supported rigid-body reorientation, retain parts, and avoid contact on unprotected finished surfaces. No installation path has been simulated in Phase A.

## Critical proof recommendation (Phase C only)

Use one C-to-rail6-end joint from S13: the source supplies a close-up of an external frame hole and a receiving feature at the rail end. Teach context, approach, alignment, contact, visible fastener placement and retained result. Resolve exact C allocation/end ownership and dimension/receiver limits first. Do not fabricate hidden threads or certify hand access. A simpler D S1 panel-to-panel proof is an alternative if the C interface remains unresolved; changing proof choice must not erase its limitations.
''')

save('UNCERTAINTY-REGISTER.md','# Product #03 - uncertainty and contradiction register\n\nAll entries OPEN. P0 blocks a dependent exact/faithful claim, not independent documentary extraction. P1 must be resolved or truthfully limited before the corresponding connection proof/animation. P2 is appearance/source-quality uncertainty. These are production-review priorities, not manufacturer safety ratings.\n\n'+table(['ID','Priority','Subject','Observed / unknown','Exact evidence / resolution needed','Affected scope'],issues)+'''
No hidden receiving bore, manufacturing tolerance, fastening method or wall installation is inferred. Unlike JULIETTE, this manual does not depict wall anchoring; do not transplant that product's rail/anchors or safety sequence. This does not establish that anchoring is never appropriate for a specific real installation.

No geometry measurements, connection access tests or collision tests were run. Documentary completeness is separate from physical installation certification. Exact dimensions, material grades, pet size, load, hinge limits and containment safety remain unestablished.
''')

save('PREMIUM-ART-DIRECTION.md','''# Product #03 - proposed premium art direction

**PROPOSAL, not an approved OEM color variant or a rendered result.** All work in Phase A is documentary and offline. No geometry, scene, camera track, video or audio has been created.

## Direction: Crafted Frame

Build a calm contemporary furniture identity around the open mesh, repeated diagonals, tactile wood and precise visible connections. Use material restraint and readable attachment detail to improve on Product #01's teaching strengths. Artistic superiority remains a future perceptual review, not a Phase A achievement.

| Element | Proposed treatment | Evidence boundary |
|---|---|---|
| Wood panels | Warm smoked oak-brown (#77533B base), varied subtle grain, low satin roughness | Wood species, laminate/solid-board composition, finish and grain scale not specified; proposal only |
| Tube/mesh frame | Deep charcoal (#292C2F), restrained coated-metal highlights, fine surface variation | Metal construction inferred from tubular/mesh drawings; alloy/coating/color unknown |
| Visible fasteners | Muted steel-grey highlights (#8C9398), clear drive silhouette | Plating/grade unknown; no invented branding, threads or pitch |
| Studio stage | Warm grey floor/wall (#D8D2C8), broad soft key and edge light separating dark mesh | Presentation-only design, no change to product assembly |
| Finished environment | Quiet living area, light neutral walls, oak-toned flooring, restrained rug/chair/plant outside door sweep | Props stay outside product registry and connection logic; no pet/capacity certification |
| Captions | Charcoal/ivory, one hardware ID and quantity at a time, outside tool/connection corridor | Screen treatment only, not extra OEM instruction |

Use existing Three.js materials and locally generated procedural texture controls in Phase B if authorized. Do not acquire assets, fonts, HDRIs or plugins online. Wood grain follows each panel's long direction as a labeled art proposal; do not copy one identical patch onto every panel. Use broad lights that reveal wire, tube edges and drive recesses without glare. Exact metallic/roughness numbers belong to later material prototypes, not source specification.

## Long: teach then build rhythm

1. Brief furnished finished-product context with doors closed; function preview only after mechanism evidence permits it.
2. Source-matched 20-component overview and A-O inventory separating the three tools.
3. Full upper-module chronology, with one clear D joint and one K/B bracket macro. Show alignment before final tightening.
4. Side-frame orientation and supported inverted construction. Establish context before each close-up, retain installed parts, and show why access precedes closure.
5. Rear4/front3, support rails6/5, supported upright transition and placed floor14.
6. Door hinges and retaining tabs only after I/J disposition is resolved; do not hide a guessed latch movement in a cut.
7. Source-consistent pad placement, final alignment/fastener inspection, furnished reveal and permitted door function. No invented load or pet-fit claims.

Do not choose a fixed Long duration before connection teaching and support transitions are planned. First essential attachment gets context → approach → alignment → contact → source-supported fastener action → retained result. Compress repetition, not required mechanical information.

## Short: authored portrait

Native portrait is the future target, not a landscape crop. Use a brief finished-function hook, a clean exact reset to the actual assembly start, vertical part/hardware hierarchy, one critical interface close-up and forward cuts through declared repetitions. Distinguish upside-down assembly from finished orientation with a context shot. Never omit prerequisites to save time. Finish with aligned doors, useful storage and a strong product hero.

Provisional delivery profile: Short 1080x1920 / 30fps per repository convention; Long resolution/FPS and both runtimes remain proposals pending technical/creative planning. No timing or final profile was approved here. Both films remain complete assembly storytelling, not a schematic substitute.

## Phase B/C review priorities

Produce local material/geometry prototypes and one fastener macro only after Phase A issues are dispositioned. Prefer C (printed Ø6X25L) at a rail6 end: clear tube-face hole, supported rail, source-visible receiver, drive silhouette and completed retained joint. Do not model a hidden threaded bore/pitch without evidence. Treat all engineering dimensions absent from the source as unknown; any approved visual approximation needs a ledger.

Future sound is separate from picture. No music processing, license inheritance, SFX or pet sounds is authorized by this proposal. Any later reuse of local audio needs its own permitted rights/provenance and review scope. No Internet lookup occurs now.

ChatGPT Web remains the intended internal Director, but all browser/external handoffs are suspended under the human's offline rule. Local files may be reviewed in Codex; no internal Director approval is fabricated. Only the human can finally accept both complete videos.
''')

reader=PdfReader(PDF)
save('evidence/extracted-text.json',{'pages':[dict(pdf_page=i+1,text=p.extract_text() or '') for i,p in enumerate(reader.pages)],'limitation':'Most pages are diagram-based; text extraction alone is insufficient. All 13 rendered source pages visually inspected.'})
identity=json.loads((B/'evidence/source-identity-initial.json').read_text())
identity.update({'identity_status':'MATCHED_LOCAL_13_PAGE_PET_CRATE_MANUAL; exact commercial identity metadata-only', 'pdf_metadata':{str(k):str(v) for k,v in (reader.metadata or {}).items()},'page_count':len(reader.pages),'printed_numbering':'p1 hardware; unnumbered foreword inserted as PDF p2; printed2-12 at PDF p3-13','manual_visible_title':'INSTALLATION INSTRUCTION','online_verification':'NOT_RUN — forbidden','scope':'20 numbered assemblies and 19 steps for pictured open-cubby, double-door mesh crate. Metadata drawer wording is not a license to add drawers.'})
save('SOURCE-AUTHORITY.json',identity)

counts=Counter()
for step in steps: counts.update(step['hardware'])
declared={h['id']:h['quantity'] for h in hardware if h['category']!='tool'}
literal=counts.copy(); literal['I']-=2; literal['J']+=2
baseline=json.loads((B/'evidence/protected-baseline.json').read_text())
changed=[]
for name,expected in baseline.items():
    p=ROOT/name
    actual=sha(p) if p.is_file() else None
    if actual!=expected: changed.append({'path':name,'expected':expected,'actual':actual})
qa={
 'revision':'PRODUCT03-PHASE-A-V1','checked_at':stamp,
 'checks':{
  'source_pages':{'status':'PASS','actual':len(reader.pages),'expected':13},
  'source_copy_identity':{'status':'PASS' if sha(PDF)==identity['sha256'] else 'FAIL','sha256':sha(PDF)},
  'numbered_parts':{'status':'PASS','types':len(parts),'instances':sum(p['quantity'] for p in parts),'expected_instances':20},
  'all_steps_accounted':{'status':'PASS','actual_steps':[s['OEM_step'] for s in steps],'expected_steps':list(range(1,20))},
  'part_introduction_coverage':{'status':'PASS' if sorted(i for s in steps for i in s['introduced_part_ids'])==sorted(p['id'] for p in parts) else 'FAIL'},
  'dependency_acyclic_and_ordered':{'status':'PASS' if all(all(int(x[1:])<s['OEM_step'] for x in s['sequence_prerequisites']) for s in steps) else 'FAIL'},
  'A_O_inventory':{'status':'PASS','units':sum(h['quantity'] for h in hardware),'installed_accessory_units':sum(declared.values()),'tool_units':3},
  'literal_S18_summary_reconciliation':{'status':'FAIL — SOURCE CONTRADICTION','I_declared':2,'I_literal_used':literal['I'],'J_declared':2,'J_literal_used':literal['J']},
  'provisional_S18_inset_reconciliation':{'status':'WARNING — hypothesis only, not manufacturer approval','allocated':dict(sorted(counts.items())),'declared':declared,'counts_match':dict(counts)==declared},
  'physical_fit_tool_access':{'status':'NOT_RUN','reason':'No geometry; engineering dimensions/access evidence missing'},
  'geometry_video_audio':{'status':'NOT_RUN','reason':'Phase A only'},
  'source_render_quality':{'status':'WARNING','reason':'Poppler Adobe-GB1 / R19 font warnings; PDF p2 overlapping text; all main diagram and hardware/parts callouts inspected; no source repair claimed'},
  'director_review':{'status':'NOT_RUN','reason':'Offline-only instruction prohibits browser handoff'},
  'protected_assets':{'status':'PASS' if not changed else 'FAIL','manifest_paths_checked':len(baseline),'changed':changed,'scope':'Existing historical protection manifest plus full local source packages for P01/P02; not exhaustive hashing of every media frame'}
 },
 'phase_A':'DOCUMENTARY_AUDIT_COMPLETE_WITH_OPEN_ISSUES',
 'foundation_gate':'REQUIRES_LOCAL_REVIEW — I/J conflict and missing geometry evidence',
 'phase_B_F':'NOT_STARTED',
 'JULIETTE':'DISCONTINUED_BY_HUMAN; files preserved',
 'security':'OFFLINE_ONLY; no browser, network, upload, account, external API, installation or paid action',
 'final_acceptance':'NOT_GRANTED; human alone must accept both completed Long/Short films'
}
save('PHASE-A-QA.json',qa)
save('PHASE-A-REPORT.md',f'''# Product #03 - offline Phase A audit

**DOCUMENTARY AUDIT COMPLETE WITH OPEN ISSUES.** Foundation requires local review; no Phase B-F work started. JULIETTE is discontinued by human instruction and remains preserved; Product #01 is unchanged.

## Source identity

Found the human-provided 13-page pet-crate PDF in the local source folder. Local title: INSTALLATION INSTRUCTION. Metadata names Wayfair W114586144 Large Wooden Dog Crate End Table With Drawers; visible assembly is an open-cubby double-door mesh crate, without drawer parts/slides. Commercial identity is metadata-only, not independently verified. Do not add drawers.

- [Preserved local PDF](source/human-provided-pet-crate-manual.pdf)
- SHA256: `{sha(PDF)}`
- Original bytes: {PDF.stat().st_size}; all 13 PDF pages inspected as source images.
- Printed page references differ: PDF p1 printed1; PDF p2 unnumbered foreword; PDF p3-13 printed2-12.
- [Source authority and metadata](SOURCE-AUTHORITY.json)

## Findings

**15 numbered types / 20 component instances. 15 A-O types / 103 listed units = 100 installed/accessory units + 3 tools. 19/19 assembly steps accounted for.** Each inventory entry has a source reference; chronological dependencies retain installed parts. All screw quantities reconcile only under the explicit provisional S18 I/J correction.

**Source conflict:** S18 inset labels I; its summary repeats J. Literal summary would use J4 against J2 listed and leave I2 unused. Proposed J upper / I lower is an inference, not an OEM correction. Evidence crop preserved.

**Further uncertainties:** no overall/panel dimensions; exact hidden bores/threads/access are not established; C4 in S13 and C6 in S14 require exact end allocation; support/reorientation and final tightening choreography need a documented plan. No screw torque, tool envelope, physical load/fit, hinge limit, material grade or color is certified. Global instruction requires alignment before final tightening; S10/S12 explicitly say to lock firmly.

## Deliverables

- [Precise BOM and tools](PRODUCT-BOM.md) / [structured inventory](PARTS-HARDWARE-INVENTORY.json)
- [19-step dependency map](ASSEMBLY-DEPENDENCY-MAP.md) / [operation ledger](ASSEMBLY-DEPENDENCIES.json)
- [15-item uncertainty register](UNCERTAINTY-REGISTER.md)
- [Proposed premium art direction](PREMIUM-ART-DIRECTION.md)
- [13-page source contact sheet](evidence/source-contact-sheet.jpg)
- [S18 I/J contradiction crop](evidence/step18-I-J-conflict.png)
- [QA and preservation results](PHASE-A-QA.json)

## Local execution boundary

Current authorized milestone is Phase A. No new 3D geometry, hardware model, scene, animation, rendered film or audio has been created. Source PDF rasterization is documentary inspection only. Source and runtime were not altered. Protected verification checked {len(baseline)} manifest paths; changes: {len(changed)}. The original research/history is retained, including historical failures.

Before dependent faithful geometry/proof: resolve the I/J identity conflict and establish a local dimensional basis, or explicitly disposition limited visual approximations without inventing hidden receiving details. Do not treat an unmeasured plausible scene as assembly evidence. Phase C must show a supported, source-grounded joint and retain installed components.

Internet and ChatGPT Web handoff are **SUSPENDED** by the current human security instruction. No online lookup, authenticated session, external message, upload, telemetry, software installation or paid service was used. No Director decision is claimed. External collaboration would require explicit human authorization of channel and data scope. Both eventual films require explicit final human review and acceptance; no publication is authorized.
''')
state={'product':'Product #03 - local pet-crate manual; metadata W114586144','authority':'Human PRODUCT #03 CREATIVE DIRECTION & LOCAL PRODUCTION KICKOFF','phase_A':qa['phase_A'],'foundation_gate':qa['foundation_gate'],'phase_B_F':'NOT_STARTED','source_sha256':sha(PDF),'offline_only':True,'internet_and_external_handoffs':'NOT_AUTHORIZED','prior_direct_handoff_protocol':'SUSPENDED by latest P0 offline restriction','product02':'DISCONTINUED; preserve files','product01':'PROTECTED; no changes','human_final_acceptance':'NOT_GRANTED','report':'phase-a-v1/PHASE-A-REPORT.md'}
(B.parent/'CURRENT-PROJECT-STATE.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
all_files=sorted(p for p in B.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt')
save('SHA256SUMS.txt',''.join(f'{sha(p)}  {p.relative_to(B)}\n' for p in all_files))
print(json.dumps({'phase_A':qa['phase_A'],'source_sha256':sha(PDF),'parts':20,'listed_A_O_units':103,'installed_accessory_units':100,'tools':3,'steps':19,'protected_paths':len(baseline),'protected_changes':changed,'report':str(B/'PHASE-A-REPORT.md')},indent=2))
