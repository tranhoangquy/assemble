# Phase C V1 — delivery integrity correction R1

Review ID: PRODUCT03-PHASE-C-V1-INTEGRITY-R1-20261020. Documentation/transport correction only. No scene, geometry, video, camera, motion or source change.

## Actual finding and cause boundary

The original hinge JPEG is **872906 bytes,1920×2280**, SHA256 `dd94277cfe5b3a85c58826c438000c8231c82d28c000b4698b826e471f972b07`. This exactly matches the pre-send manifest and frozen delivery JSON. All8 original submission files still match their locally recorded hashes. The source file was not changed or silently replaced.

Using the existing Assemble image viewer Download button, we retrieved a separate received JPEG: **549009 bytes,1724×2048**, SHA256 `53e9d15816713134b6b23b11050a0c8af85b1542c6fef89a360be599a988a3d9`. This matches the Director-reported53e9d158 prefix. Both distinct byte versions are now preserved locally and inside the archive. Their dimensions and compression differ. The observed viewer delivery path rescaled/re-encoded the image; the exact internal processing stage/algorithm is unknown. We do not relabel a derivative as the original or claim byte identity.

The raw finding remains: original manifest hash does NOT match the browser-delivered resized derivative. The new report accounts for the two identities separately. There is no evidence of local file corruption. A LANCZOS-resampled content comparison gives mean absolute RGB differences [2.7037285541437064, 2.6318900336245648, 2.6702453188442576]; this is visual comparison only, not a hash PASS.

## Reliable corrected delivery

`PRODUCT03-PhaseC-integrity-R1.zip` contains all original8 submission files under originals/, preserving their byte identity and original SHA manifest; the separate viewer derivative under received/; this report; the evidence-gate matrix; and integrity QA. `ARCHIVE-CONTENTS-SHA256.txt` hashes every inner payload with relative paths. `ARCHIVE-SHA256.txt` hashes the ZIP plus the standalone review documents. No image was regenerated, resaved or resized for the corrected original payload.

Please extract ZIP and hash actual originals/02-HINGE-BEFORE-AFTER.jpg against originals/REVIEW-SHA256.txt and the archive content manifest. Compare received/received-hinge-viewer-download.jpg separately. Do not hash a rendered preview/screenshot in place of an original payload. Preserve the original review outcome and mismatch as historical evidence.

## Technical status retained

The original16s S1 video remains SHA256 `3870bf7cf04dc77431d73adfe0e636be849917e8637dfd31698a98dcef68dec6`. No new render/test/animation was needed for documentation-only transport correction. Original3/3 tests, source typecheck and full decode remain actual results; historical root failures remain disclosed. All protected938 paths and prior B source/payload hashes remain unchanged.

Source-visible S1 contact/approach is accepted; D securing and hinge motion remain BLOCKED. The hinge candidate remains STATIC VISUAL HYPOTHESIS. No new bores, threads, receivers, engagement, tool access, source confidence or broader production authorization. Human remains sole final acceptance authority.

## Closure review requested

Verify byte-accurate archive delivery and matrix; return explicit limited Phase C closure with unresolved physical gates separated from accepted exterior proof. No Phase D/full production authorization requested or implied. Any evidence acquisition or broader scope requires human approval.
