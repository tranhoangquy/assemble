from pathlib import Path
from PIL import Image,ImageChops,ImageStat
import hashlib,json,zipfile,shutil
b=Path(__file__).resolve().parent;v=b.parent/'phase-c-v1';root=b.parents[2];d=b/'review-files';d.mkdir(exist_ok=True);stage=b/'archive-content';(stage/'originals').mkdir(parents=True,exist_ok=True);(stage/'received').mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((v/'REVIEW-DELIVERY-MANIFEST.json').read_text());checks=[]
for row in old:
 p=Path(row['path']);checks.append({'name':p.name,'manifestSha256':row['sha256'],'currentSha256':sha(p),'match':sha(p)==row['sha256']});assert checks[-1]['match'];shutil.copyfile(p,stage/'originals'/p.name)
received=b/'evidence/received-hinge-viewer-download.jpg';shutil.copyfile(received,stage/'received'/received.name)
comparison=json.loads((b/'evidence/RECEIVED-IMAGE-COMPARISON.json').read_text());orig=Image.open(v/'review-files/02-HINGE-BEFORE-AFTER.jpg').convert('RGB');deriv=Image.open(received).convert('RGB');diff=ImageChops.difference(orig.resize(deriv.size,Image.Resampling.LANCZOS),deriv);comparison['resampledVisualComparison']={'method':'Original resized with PIL LANCZOS only for content comparison; not a claim about ChatGPT internal algorithm','meanAbsoluteRGBDifference':ImageStat.Stat(diff).mean,'notByteIdentity':True};(b/'evidence/RECEIVED-IMAGE-COMPARISON.json').write_text(json.dumps(comparison,indent=2)+'\n')
report=f'''# Phase C V1 — delivery integrity correction R1

Review ID: PRODUCT03-PHASE-C-V1-INTEGRITY-R1-20261020. Documentation/transport correction only. No scene, geometry, video, camera, motion or source change.

## Actual finding and cause boundary

The original hinge JPEG is **872906 bytes,1920×2280**, SHA256 `{comparison['localOriginal']['sha256']}`. This exactly matches the pre-send manifest and frozen delivery JSON. All8 original submission files still match their locally recorded hashes. The source file was not changed or silently replaced.

Using the existing Assemble image viewer Download button, we retrieved a separate received JPEG: **549009 bytes,1724×2048**, SHA256 `{comparison['viewerDownload']['sha256']}`. This matches the Director-reported53e9d158 prefix. Both distinct byte versions are now preserved locally and inside the archive. Their dimensions and compression differ. The observed viewer delivery path rescaled/re-encoded the image; the exact internal processing stage/algorithm is unknown. We do not relabel a derivative as the original or claim byte identity.

The raw finding remains: original manifest hash does NOT match the browser-delivered resized derivative. The new report accounts for the two identities separately. There is no evidence of local file corruption. A LANCZOS-resampled content comparison gives mean absolute RGB differences {comparison['resampledVisualComparison']['meanAbsoluteRGBDifference']}; this is visual comparison only, not a hash PASS.

## Reliable corrected delivery

`PRODUCT03-PhaseC-integrity-R1.zip` contains all original8 submission files under originals/, preserving their byte identity and original SHA manifest; the separate viewer derivative under received/; this report; the evidence-gate matrix; and integrity QA. `ARCHIVE-CONTENTS-SHA256.txt` hashes every inner payload with relative paths. `ARCHIVE-SHA256.txt` hashes the ZIP plus the standalone review documents. No image was regenerated, resaved or resized for the corrected original payload.

Please extract ZIP and hash actual originals/02-HINGE-BEFORE-AFTER.jpg against originals/REVIEW-SHA256.txt and the archive content manifest. Compare received/received-hinge-viewer-download.jpg separately. Do not hash a rendered preview/screenshot in place of an original payload. Preserve the original review outcome and mismatch as historical evidence.

## Technical status retained

The original16s S1 video remains SHA256 `3870bf7cf04dc77431d73adfe0e636be849917e8637dfd31698a98dcef68dec6`. No new render/test/animation was needed for documentation-only transport correction. Original3/3 tests, source typecheck and full decode remain actual results; historical root failures remain disclosed. All protected938 paths and prior B source/payload hashes remain unchanged.

Source-visible S1 contact/approach is accepted; D securing and hinge motion remain BLOCKED. The hinge candidate remains STATIC VISUAL HYPOTHESIS. No new bores, threads, receivers, engagement, tool access, source confidence or broader production authorization. Human remains sole final acceptance authority.

## Closure review requested

Verify byte-accurate archive delivery and matrix; return explicit limited Phase C closure with unresolved physical gates separated from accepted exterior proof. No Phase D/full production authorization requested or implied. Any evidence acquisition or broader scope requires human approval.
'''
mat='''# Phase C — OEM operation versus evidence-gate matrix

| Operation | OEM documentation | Actual proof | Evidence missing | Gate / next boundary |
|---|---|---|---|---|
| S1 panel10 to end12 | PDF p4/printed3: two10 at ends12; qualitative orientation and D4 | One end approaches and remains in contact, two-panel mesh ray contact0 display units | Matched panel sizes/thicknesses and exact receiver coordinates for engineering fit | Exterior alignment/contact accepted; physical fit NOT CERTIFIED |
| S1 D direction/face | Same page: D through outside10 toward end12 | Two D stop2 display units outside face; projected target rings are annotations | Detailed exterior/end receiving views and local measurements | Exterior approach accepted; no internal insertion shown |
| S1 D insertion/retention | Diagram depicts D securing joint, but no receiver section | NOT SHOWN; endpoint explicitly STOP | Receiving construction/type/depth, engagement path, relevant dimensions; no inferred hidden insert/thread | BLOCKED — no complete secured-connection claim |
| S1 tool/tightening | Global alignment-before-final-tightening; no torque or exact access envelope | NOT SHOWN; no spin/tool action | Matching visible drive, shaft/bit/hand approach clearance and supported assembly state | NOT VALIDATED; human source/acquisition choice required |
| S1 holding/support | Source association/orientation, no certified holding method | Flat review stage; external holding required by caption | Local approved support/handling method and dimensions | No load, stability or hand-support certification |
| S16 hinge external leaf | PDF p11/printed10 inset shows exterior leaf, integrated door hinges, E8 | Four baseline/candidate static macros; candidate external plane contact0 | True leaf placement, side/edge view, door setback, barrel/axis relationship | STATIC VISUAL HYPOTHESIS accepted conditionally, no mechanical promotion |
| S16 E fastening | E8, two E per depicted frame-side hinge | NOT SHOWN | Actual receiving E feature, depth/type, installed interface and driver access | BLOCKED |
| Hinge opening/closing | Door source association; no measured motion limit/axis specification | NOT RUN | Matched physical hinge construction, axis, limits and clearances | BLOCKED; no visually plausible motion substituted as evidence |
| C S13/S14 | QuantitiesC4+C6; end ownership incomplete | Unchanged historical documentary annotation | Exact source-matched each-end allocation incl. unlocated sixth S14 callout | OPEN; not resolved by choosing S1 |
| S18 I/J | InsetI vs summaryJ conflict | No new action; hypothesis retained | Authoritative/local part and installed-position evidence | OPEN |
| Phase D / full Long/Short | Final mission remains complete truthful films | NOT STARTED | Human authorization and required physical/source gates | NOT AUTHORIZED; internal visual PASS cannot clear physical gates |

No new Internet research, manufacturer contact or source acquisition is authorized here. No production rendering/audio. Possible next actions require human choice: provide local matched evidence, authorize a defined evidence-acquisition channel/data scope, or explicitly decide a different permitted simulation scope without misrepresenting it as a physical proof. This matrix does not approve that scope change.
'''
qa={'revision':'PRODUCT03-PHASE-C-V1-INTEGRITY-R1-20261020','scope':'Documentation and byte-preserving re-delivery only','originalSubmissionFiles':checks,'originalHinge':comparison['localOriginal'],'receivedViewerHinge':comparison['viewerDownload'],'transportByteIdentity':'FAIL between original and resized received derivative — preserved, not relabeled PASS','finding':'Observed received JPEG dimensions/encoding differ; source and derivative separately preserved; exact internal processing unspecified','originalVideoUnchanged':sha(v/'review-files/PRODUCT03-PhaseC-S1-external-approach-proof.mp4')=='3870bf7cf04dc77431d73adfe0e636be849917e8637dfd31698a98dcef68dec6','creativeSourceChanged':False,'newTestsOrRenders':'NOT_RUN — documentation-only correction','physicalGates':'UNCHANGED — D securing, E fastening, hinge motion BLOCKED','directorReview':'PENDING actual archive integrity confirmation'}
for name,content in [('INTEGRITY-REPORT.md',report),('EVIDENCE-GATE-MATRIX.md',mat),('INTEGRITY-QA.json',json.dumps(qa,indent=2)+'\n')]:
 (b/name).write_text(content);(stage/name).write_text(content)
for name in ['INTEGRITY-REPORT.md','EVIDENCE-GATE-MATRIX.md']:shutil.copyfile(b/name,d/name)
# The inner manifest names the preserved source and received derivative independently.
inner=sorted(p for p in stage.rglob('*') if p.is_file());(stage/'ARCHIVE-CONTENTS-SHA256.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(stage).as_posix()}\n' for p in inner))
z=d/'PRODUCT03-PhaseC-integrity-R1.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for p in sorted(stage.rglob('*')):
  if p.is_file():archive.write(p,p.relative_to(stage).as_posix())
with zipfile.ZipFile(z) as archive:
 assert archive.testzip() is None
 for p in stage.rglob('*'):
  if p.is_file():assert archive.read(p.relative_to(stage).as_posix())==p.read_bytes()
(d/'ARCHIVE-SHA256.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(d.iterdir()) if p.name!='ARCHIVE-SHA256.txt'))
(b/'REVIEW-DELIVERY-MANIFEST.json').write_text(json.dumps([{'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(d.iterdir())],indent=2)+'\n')
print(json.dumps({'files':len(list(d.iterdir())),'archiveSha256':sha(z),'originalHash':comparison['localOriginal']['sha256'],'receivedHash':comparison['viewerDownload']['sha256'],'archiveRoundTrip':'PASS'},indent=2))
