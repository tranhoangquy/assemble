# Phase C — OEM operation versus evidence-gate matrix

| Operation | OEM documentation | Actual proof | Evidence missing | Gate / next boundary |
|---|---|---|---|---|
| S1 panel10 to end12 | PDF p4/printed3: two10 at ends12; qualitative orientation and D4 | One end approaches and remains in contact, two-panel mesh ray contact0 display units | Matched panel sizes/thicknesses and exact receiver coordinates for engineering fit | Exterior alignment/contact accepted; physical fit NOT CERTIFIED |
| S1 D direction/face | Same page: D through outside10 toward end12 | Two D stop2 display units outside face; projected target rings are annotations | Detailed exterior/end receiving views and local measurements | Exterior approach accepted; no internal insertion shown |
| S1 D insertion/retention | Diagram depicts D securing joint, but no receiver section | NOT SHOWN; endpoint explicitly STOP | Receiving construction/type/depth, engagement path, relevant dimensions; no inferred hidden insert/thread | BLOCKED — no complete secured-connection claim |
| S1 tool/tightening | Global alignment-before-final-tightening; no torque or exact access envelope | NOT SHOWN; no spin/tool action | Matching visible drive, shaft/bit/hand approach clearance and supported assembly state | NOT VALIDATED; human source/acquisition choice required |
| S1 holding/support | Source association/orientation, no certified holding method | Flat review stage; external holding required by caption | Local approved support/handling method and dimensions | No load, stability or hand-support certification |
| S16 hinge external leaf | PDF p11/printed10 inset shows exterior leaf, integrated door hinges, E8 | Four baseline/candidate static macros; candidate external plane contact0 | True leaf placement, side/edge view, door setback, barrel/axis relationship | STATIC VISUAL HYPOTHESIS accepted conditionally, no mechanical promotion |
| S16 E fastening | E8, two E per depicted frame-side hinge | NOT SHOWN | Actual receiving E feature, depth/type, installed interface and driver access | BLOCKED |
| Hinge opening/closing | Door source association; no measured motion limit/axis specification | NOT RUN | Matched physical hinge construction, axis, limits and clearances | BLOCKED; no visually plausible motion substituted as evidence |
| C S13/S14 | QuantitiesC4+C6; end ownership incomplete | Unchanged historical documentary annotation | Exact source-matched each-end allocation incl. unlocated sixth S14 callout | OPEN; not resolved by choosing S1 |
| S18 I/J | InsetI vs summaryJ conflict | No new action; hypothesis retained | Authoritative/local part and installed-position evidence | OPEN |
| Phase D / full Long/Short | Final mission remains complete truthful films | NOT STARTED | Human authorization and required physical/source gates | NOT AUTHORIZED; internal visual PASS cannot clear physical gates |

No new Internet research, manufacturer contact or source acquisition is authorized here. No production rendering/audio. Possible next actions require human choice: provide local matched evidence, authorize a defined evidence-acquisition channel/data scope, or explicitly decide a different permitted simulation scope without misrepresenting it as a physical proof. This matrix does not approve that scope change.
