# Product03 — limited Phase C V1 review

Review ID: PRODUCT03-PHASE-C-V1-20261020. **PARTIAL PROOF COMPLETE — PHYSICAL FASTENING/MOTION BLOCKED; REQUIRES DIRECTOR REVIEW.** The human replied “tiếp tục” directly to the request for limited Phase C: one evidence-grounded joint and hinge contact investigation, without Long/Short production. No Phase D/full assembly film, audio, general Internet or other services are authorized.

## Source and choice of joint

Human-supplied13-page PDF SHA256 `70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29`. PDF p4 / printed3 / S1 explicitly depicts two panels10 meeting the ends of panel12, with D4 through outer10 faces. This is independent of unresolved S13/S14 C allocation; choosing S1 does not resolve that C issue. The still sheet includes actual local source crops for S1 and S16. Source-commercial identity remains metadata-only.

We show one end/one panel10 and two of S1's four D. Other end is outside this focused operation, not installed then removed. Registry remains20 parts +103 A–O units. No OEM order or count changes. The shown suboperation order within S1 is a visual staging proposal, not an extra OEM step. No unrelated parts, drawers or receivers added.

## Actual motion proof:16 seconds /192 frames /12fps /native1280x720 /silent

- 0–2s: orientation identifying10 and12, pre-aligned axes, active10 staged90 display units outside its final position.
- 2–5s:10 approaches12 along X on a flat review stage. External holding/support is explicitly required, with no claim to a validated human support procedure.
- 5–6s: faces remain in contact, not secured.
- 6–8s: camera moves to the exterior receiving-face context; panels stay retained.
- 8–9s: two D shown outside the source-indicated face.
- 9–11s: first D approaches along+X;11–13s: second D approaches. Both stop with tips2 arbitrary display units outside the exterior face. No rotation or engagement into concealed geometry.
- 13–16s: explicit STOP hold. No final tightening, installed screw, tool action or completed S1 is claimed.

At every forward frame after5s both panels retain contact. No reset, teleport, reinstallation or disappearance. Evaluation is absolute-time, reset from full descendant snapshot; no GSAP/wall-clock state accumulation. The ending is deliberately an unresolved operation, never a finished/secured connection.

Bronze rings are source-target annotations projected into the view, not added holes. The side/end hole associations are documented; their exact coordinates, bore profiles and hidden receiver depth/construction are not. We did not subtract a guessed hidden bore or add a thread/carrier. Final tip positions are(-578,865,-270) and(-578,785,-270), exterior faceX=-576. These are unmeasured display coordinates, not OEM millimetres.

## Numeric local contact/path checks

193 samples from0–16s inclusive,1/12s interval. Minimum D tip standoff2 display units; maximum panel bounding-overlap volume0; panel end contact gap0 after5s. A double-sided ray through actual mesh triangles atY825,Z-270 finds panel10 facesX=-576/-558 and panel12 endX=-558: sampled surface separation0. This is actual local mesh contact, not a complete structural/installation PASS. Floating-point comparison threshold1e-6 display units is a review numerical criterion, never OEM manufacturing tolerance. No collision pair was excluded to mask penetration; bounding checks are explicitly limited to the two shown panels. No full-product collision pass is claimed.

Access matrix, full time samples and state hashes are in VALIDATION.json. Both D rows: target10 outside→12 end, approach+X, two-panel context, exterior approach clear in this provisional model; hidden insertion BLOCKED; tool/hand fit NOT VALIDATED; holding/support REQUIRED. L driver action, torque, hand envelope, internal travel and final securing are NOT RUN. The global alignment-before-final-tightening instruction remains in force; no final tightening is shown.

## Hinge contact investigation — static proposal only

PDF p11 / printed10 / S16 depicts integrated door hinges, E8 and an externally visible frame leaf. V2's leaves and barrel are substantially buried in the modeled frame/door; source visibility establishes a real visual presentation defect. The manual does not establish the exact axis depth, door setback, leaf profile or holes.

Baseline signed FRONT-PLANE offsets: leaf rear−stationary face=-1.25; leaf rear−moving face=-17.25; barrel rear−moving face=-19.80 display units. These values are signed plane setbacks, **NOT solid penetration depths**. Actual baseline geometry remains preserved, with no raw failure suppressed.

Separate candidate: door centerZ302→286 (-16); left/right hinge localX∓280→∓285 (5 outward); barrel localZ−7.5→12.3; leaf localZ0→-2.55. Existing leaves/barrels remain the same external shapes and counts, with no new bridge, holes, E, stud or mechanism. Candidate world axesX±574, Y185/631, Z298.3. Both leaf rear planes and barrel rear extrema reachZ295, matching the provisional stationary/moving outer face planes: signed gaps0 at all four locations. The leaves contact exterior faces in the proposed view, rather than being buried. These are **visual proportions and transform proposals**, not recovered manufacturer coordinates or approved product changes. The frozen B implementation remains unchanged; only the isolated C candidate applies these transforms.

Four BEFORE/AFTER rendered macro pairs show every existing hinge. No door opening or closing is animated. No claim of pivot capture, interleaved knuckle construction, hidden hinge pin, E engagement or hand/tool access is made. Exact local interface evidence is still required before converting this visual proposal into a physical motion/fastening proof.

## Unresolved issues and escalation

P0 for dependent fastening: actual local receiver depth/construction, side10/end12 dimensional basis and unobstructed tool engagement remain unavailable. The manual establishes qualitative association and approach, not a sectioned receiver. We stop at the first unverified internal travel instead of fabricating completion.

P1 for hinge motion: matched exterior/edge/side photographs or dimensional local feature drawing showing factory leaf placement, barrel axis and door setback; source-matched information about receiving E holes and true contact; then a supported motion range. Current hypothesis is not that evidence.

I/J conflict, C13/C14 end allocation, support/turnover, pet fit/load and all other Phase A physical uncertainties remain open. No public research/manufacturer contact/new acquisition is undertaken. Any new evidence acquisition or scope change requires separate human authorization.

## QA and preservation

3/3 targeted tests PASS (all time samples, count, deterministic arbitrary/backward seek, full descendant reset, baseline-versus-candidate separation). Current src/scripts TypeScript PASS. Initial TS2556 spread diagnostic was retained and corrected before render; prior historical root snapshot failures remain disclosed, no root-wide PASS claimed. Native192 PNG sequence validated complete and decoded; MP4 H26416s,192 frames,1280x720,12fps, no audio; full decode PASS.

938 protected manifest paths unchanged. Previous B source files and actual submitted review payload hashes match. No Product01/JULIETTE changes, no overwritten B artifacts, no new exporter/schema/catalog entry. Existing diagnostic renderer produced deterministic frames; local ffmpeg used the same standard H264/yuv420p/faststart encode pattern as existing render-video.ts, with no external asset or service. Offline browser contexts report0 network requests. Only this authorized Assemble review uses the Internet.

## Director decision requested

Review actual local proof MP4, source crops, hinge before/after, numeric checks and QA. Return explicit decision separately for (a) source-visible panel alignment/approach, (b) static hinge visual candidate, and (c) readiness for a completed physical connection proof. Please do not label partial/exterior evidence as a completed/secured connection or certify hinge motion. Bounded presentation revisions remain within Phase C. If missing source evidence prevents truthful completion, return a specific BLOCKED/NEEDS_HUMAN_DECISION and the exact evidence or scope choice needed. Do not authorize full Phase D, audio or Long/Short under this limited human approval. Human alone performs final acceptance of both eventual films.
