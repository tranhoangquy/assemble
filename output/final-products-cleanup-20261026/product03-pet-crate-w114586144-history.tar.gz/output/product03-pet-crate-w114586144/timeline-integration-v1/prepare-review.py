from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import hashlib,json,subprocess,zipfile,shutil,collections
P=Path(__file__).resolve().parent; B=P.parent; ROOT=P.parents[2]
def load(p):return json.loads(Path(p).read_text())
def save(n,v):(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for c in iter(lambda:f.read(4*1024*1024),b''):h.update(c)
 return h.hexdigest()
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True).stdout
qa=load(P/'INTEGRATION-QA.json'); assert all(qa['software'].values())
assert qa['graph']['steps']==19 and not qa['graph']['cycles'] and not qa['graph']['missing']
assert not qa['unrelatedOrUnclassified'];assert qa['inventory']['hardwareUnits']==100
assert '3 passed' in (P/'evidence/tests.log').read_text()
assert not (P/'evidence/typecheck-with-tests.log').read_text().strip()
frame_rows=[]; media=[]; motion=[]
for code,folder,prefix in [('S01','proof-S01','S01-proof'),('S04','proof-S04','S04-hold-proof')]:
 d=P/folder;manifest=load(d/'selected-diagnostic-manifest.json');assert len(manifest)==240
 assert not load(d/'offline-network.json')['attemptedRequests']
 expected=[f'{prefix}-frame-{i:06d}.png' for i in range(240)]
 assert [r['name'] for r in manifest]==expected
 for row in manifest:
  assert not row['networkRequests'];f=d/row['name']
  with Image.open(f) as im: im.load();assert im.size==(1280,720)
  frame_rows.append(dict(path=str(f.relative_to(P)),sha256=sha(f),bytes=f.stat().st_size))
 # Deliberate forward cuts between hardware operations are disclosed; camera jumps
 # are not hidden by calling them continuous motion.
 cuts=[]
 for a,b in zip(manifest,manifest[1:]):
  ca,cb=a['camera'],b['camera'];delta=sum((x-y)**2 for x,y in zip(ca['position'],cb['position']))**.5
  if delta>1e-6:cuts.append(dict(time=b['time'],translation=delta,fromStage=a['state']['stage'],toStage=b['state']['stage']))
 motion.append(dict(clip=code,frames=240,declaredForwardCameraCuts=cuts,qualification='Camera is fixed within each shot. Cuts occur at a new fastener or wide/macro boundary; not a continuous camera move. No installed actor is reset.'))
 f=P/f'PRODUCT03-{code}-integration-diagnostic-v1-720p.mp4'
 if not f.exists():run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-framerate','24','-i',str(d/(prefix+'-frame-%06d.png')),'-frames:v','240','-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-an','-movflags','+faststart',str(f)])
 data=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(f)]));s=data['streams'];assert len(s)==1 and s[0]['codec_type']=='video';assert s[0]['width']==1280 and s[0]['height']==720 and s[0]['r_frame_rate']=='24/1' and int(s[0]['nb_read_frames'])==240;assert abs(float(data['format']['duration'])-10)<.001
 run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(f),'-f','null','-'])
 media.append(dict(path=f.name,sha256=sha(f),bytes=f.stat().st_size,seconds=10,frames=240,fullDecode='PASS',audioStreams=0))
save('MEDIA-QA.json',dict(media=media,pngFrames=480,frameDecode='PASS',jobs='Two complete fresh offline jobs; no recovery or missing state manifests',full264sRender='NOT RUN'))
save('VIDEO-FRAME-MANIFEST.json',frame_rows);save('CAMERA-CUT-REGISTER.json',motion)
checkpoints=load(P/'checkpoints/selected-diagnostic-manifest.json');assert len(checkpoints)==42
assert not load(P/'checkpoints/offline-network.json')['attemptedRequests']
for row in checkpoints:
 assert not row['networkRequests']
 with Image.open(P/'checkpoints'/row['name']) as im: im.load();assert im.size==(1280,720)

font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',22)
small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17)
big=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',29)
im=Image.new('RGB',(1920,2010),'#f3efe6');d=ImageDraw.Draw(im)
d.text((24,14),'19 SOURCE ENDPOINTS / S04 ONWARD CONDITIONAL — NOT A COMPLETE FILM',font=big,fill='#2a2c2e')
for i in range(19):
 x=(i%3)*640;y=80+(i//3)*273
 im.paste(Image.open(P/f'checkpoints/S{i+1:02d}-endpoint.png').convert('RGB').resize((640,360)).crop((0,0,640,250)),(x,y))
 d.text((x+12,y+249),f'S{i+1:02d} / '+('INITIAL SEATING' if i<3 else 'CONDITIONAL / HOLDS'),font=small,fill='#805534')
d.text((24,1990),'Original full 1280×720 PNGs and actual states are included; thumbnails intentionally omit small captions.',font=small,fill='#805534');im.save(P/'01-19-STEP-CONTACT-SHEET.jpg',quality=94)
im=Image.new('RGB',(1920,730),'#f3efe6');d=ImageDraw.Draw(im)
d.text((22,12),'S04 PROTOTYPE DEFECT: TWO PERPENDICULAR B HEADS SHARE SOLID SPACE',font=big,fill='#2a2c2e')
for i,side in enumerate(['left','right']):
 im.paste(Image.open(P/f'checkpoints/S04-head-clash-{side}.png').convert('RGB').resize((960,540)),(i*960,70))
 d.text((i*960+20,625),('B1/B2  witness [-175.5,900.5,220]' if i==0 else 'B3/B4  witness [175.5,900.5,220]'),font=font,fill='#805534')
d.text((22,675),'Display units, NOT OEM mm. Guarded runtime leaves B2/B4 uninstalled. No resizing, hole move or false completion.',font=font,fill='#805534');im.save(P/'02-S04-VERIFIED-HEAD-DEFECT.jpg',quality=95)
im=Image.new('RGB',(1920,1250),'#f3efe6');d=ImageDraw.Draw(im);d.text((22,12),'ACTUAL MOTION PROOFS / CONTACT BEFORE CURRENT HARDWARE',font=big,fill='#2a2c2e')
for row,(folder,prefix,frames) in enumerate([('proof-S01','S01-proof',[48,102,135,170]),('proof-S04','S04-hold-proof',[45,110,165,230])]):
 for col,n in enumerate(frames):
  x=col*480;y=90+row*565;im.paste(Image.open(P/f'{folder}/{prefix}-frame-{n:06d}.png').convert('RGB').resize((480,270)),(x,y));d.text((x+12,y-25),f'{prefix} / {n/24:.2f}s',font=small,fill='#805534')
 d.text((22,y+290),'S01: rail placement → contact → screw → L key' if row==0 else 'S04: K placement → first B/key → B2 held uninstalled',font=font,fill='#805534')
im.save(P/'03-MOTION-PROOF-CONTACT-SHEET.jpg',quality=94)
shutil.copyfile(B/'phase-a-v1/evidence/pages/page-05.png',P/'evidence/OEM-PDF-P05-S03-S04.png')

initial=load(P/'evidence/initial-candidate/RAW-INSTALLATION-AND-TOOL-CANDIDATES.json');current=load(P/'RAW-INSTALLATION-AND-TOOL-CANDIDATES.json')
def classify(r,initial_run=False):
 k=r['kind']
 if k=='RECEIVING_STOCK_RAW_CANDIDATE':return 'RAW SHAFT/STOCK PENETRATION — receiving bore/thread not modeled; NOT physical PASS'
 if k=='TOOL_VS_VISIBLE_DRIVE_AABB':return 'CONCAVE DRIVE AABB candidate; prior visible hex-fit evidence only, not tool/hand certification'
 if k=='FOOT_RECEIVING_CANDIDATE':return 'SOURCE FOOT ASSOCIATION; receiving geometry unverified'
 if k=='BRACKET_CONTACT_CANDIDATE':return 'BRACKET CONTACT/EMBED CANDIDATE; receiving geometry unverified'
 if k=='EXTERIOR_STACK_UNVERIFIED':return 'POSED EXTERIOR STACK ONLY; receiver/grip/retention HOLD'
 if r['event'].startswith('hardware-B-') and k in ['UNRELATED_FASTENER_CANDIDATE','TOOL_VS_INSTALLED_CANDIDATE']:return 'S04 DEFECT / ACCESS HOLD — preserved baseline result; B2/B4 not installed in guarded run, B1/B3 stroke limited'
 return 'UNRESOLVED — requires review'
save('COLLISION-CLASSIFICATION.json',dict(method='41 samples per motion/hardware event; per-mesh AABBs in common-rig coordinates; counts are grouped pairs/events, not unique physical collisions. No failing pairs removed or thresholds raised. Receiving and concave-drive candidates retained. Head/tool solid witnesses supplement AABBs.',initial=[dict(**r,classification=classify(r,True)) for r in initial],guarded=[dict(**r,classification=classify(r)) for r in current],baselineCount=len(initial),guardedCount=len(current),qualification='Reduction is due to explicitly held B2/B4 and bounded key stroke, not a repair of the invalid baseline heads or proof of full assembly.'))
protected=load(B/'phase-a-v1/evidence/protected-baseline.json');assert all((ROOT/f).exists() and sha(ROOT/f)==h for f,h in protected.items())
historical=[]
for manifest in B.glob('*/REVIEW-DELIVERY-MANIFEST.json'):
 if manifest.parent==P:continue
 for row in load(manifest):
  f=Path(row['path']);f=f if f.is_absolute() else manifest.parent/f;assert sha(f)==row['sha256'];historical.append(dict(revision=manifest.parent.name,file=f.name,match=True))
frozen=[]
for rev,name in [('f-illustrative-proof-v1','FROZEN-LOCAL-PROOF.json'),('part-first-sequence-v1','FROZEN-FOCUSED-PROOF.json'),('timeline-integration-plan-v1','FROZEN-INTEGRATION-PLAN.json')]:
 for f,h in load(B/rev/name)['files'].items():assert sha(f)==h
 frozen.append(rev)
for rev in ['rail-fit-correction-v1','p0-connections-v1','f-illustrative-proof-v1','part-first-sequence-v1']:
 for f,h in load(B/rev/'SOURCE-FINGERPRINTS.json')['files'].items():assert sha(ROOT/f)==h
save('PROTECTED-ASSET-VERIFICATION.json',dict(status='PASS',protectedPaths=len(protected),changes=0,previousDeliveryChecks=len(historical),previousDeliveries=historical,frozenPackages=frozen,Product01='UNCHANGED',JULIETTE='UNCHANGED',previousEvidence='UNCHANGED'))
src=ROOT/'src/products/product03-pet-crate-w114586144/timeline-integration-v1'
save('SOURCE-FINGERPRINTS.json',dict(files={str(f.relative_to(ROOT)):sha(f) for f in src.glob('*.ts')},genericRendererSha256=sha(ROOT/'scripts/render-mechanism-diagnostics.ts'),approvedModel='Directly reused part-first-sequence-v1/model.ts; no geometry changes'))
(P/'UNCERTAINTIES-AND-HOLDS.md').write_text('''# Unresolved issues — no confidence upgrade

- P0 NEW S04: actual prototype B1/B2 and B3/B4 head solids overlap. Witness points are inside both head solids by0.3 depth display units. Not an OEM defect claim. B2/B4 remain visibly uninstalled; subsequent checkpoints are conditional diagnostic states. Visible hardware sizing/placement needs a separately reviewed correction, not invented holes or dimensions.
- P0 original unrestricted L rotation crosses adjacent divider11; actual tool vertices penetrate beyond its0.8 visual bevel. Guarded B1/B3 use a60-degree illustrative key stroke away from the divider. B2/B4 tool operations are HELD. No hand/tool-access certification follows.
- Source C13/C14 end allocation remains inferred. Step18 insetI versus summaryJ conflict remains; J-above-I is provisional, not OEM-confirmed.
- S17/18 exterior H/tab/G association is posed only. Stud, receiver, O wrench grip and actual retention are unknown. No fake tightening is animated.
- S19 N4 remains staged. Door/retainer release/access is unknown; no invented latch or functional opening is shown.
- All dimensions are display approximations except source-labeled hardware nominal designations. No overall/panel measurements, receiving bores, buried threads, torque, hand envelope, hinge limits or load certification established.
- Foot preparation, supported module inversion/return and late-board route are explicit presentation staging. S14 route centers outside sideposts then moves in depth; not a certified installation trajectory.
- Earlier B/C/D/E actions mean initial symbolic seating, not final tightening. SourceS10/S12 firm-lock language retained as source intent, not proven physical action. The15-second alignment/recheck segment is presentation only and does not invent OEM step20 or torque settings.
- Repeated fastener cuts may be too fast for final teaching. Current264 seconds is a planning/evaluation budget, not a finished film or accepted duration.

No new source acquisition, geometry, hidden receiving details or physical confidence upgrade. Human is the sole final approver of eventual films.
''')
(P/'DIRECTOR-REVIEW.md').write_text('''# PRODUCT03 — COMPACT264 INTEGRATION QA / FOCUSED CHECKPOINT REVIEW

Review ID: PRODUCT03-COMPACT264-INTEGRATION-V1-20261023

## Outcome: software integration PASS; S04 geometry/access HOLD

The actual prior Director approved the264-second plan only, authorizing this bounded offline evaluator,19-step QA, endpoint PNGs and a few short motion proofs. This is that evidence package. It is NOT a264-second film, whole-product acceptance or production authorization. STOP after this review; further production requires a new human scope decision.

Absolute-time native Three.js evaluator reuses the accepted part-first geometry and AssemblyGraph.19 source steps;20 numbered components;100 hardware/accessory units +3 tools. Source quantities unchanged.239s source operations +15s presentation alignment/recheck +10s canonical target =264s. The15s segment is not an OEM step. All19 endpoints and42 original diagnostic PNGs are delivered, with actual states. S04 onward is prominently CONDITIONAL because B2/B4 cannot truthfully be installed.

## New verified blocker — do not approve away

Initial complete candidate audit preserved242 grouped AABB candidates, including11 unrelated B/tool candidates. Two real solid head overlaps are independently verified: B1/B2 witness[-175.5,900.5,220], B3/B4 witness[175.5,900.5,220]. Each point lies inside both actual prototype head solids. An original unrestricted L rotation also penetrates divider11 at46.95s; actual vertex witnesses are delivered. These are prototype defects/assumptions, not evidence that the OEM product is defective.

Guarded runtime leaves B2/B4 uninstalled, with no tool/false seating. B1/B3 use a limited60-degree illustrative key stroke away from the divider. No head resizing, hole relocation, hidden receiver, shaft clipping, threshold increase or collision-pair suppression.225 grouped raw candidates remain classified, including shaft/solid-stock and concave-drive AABBs; zero unrelated guarded candidates is NOT a whole-assembly physical PASS. It reflects the explicit HOLD and staged limited key stroke. Downstream source coverage is conditional diagnostic only.

## Actual media / QA

Two silent720p24fps10-second MP4s, each240 actual PNG frames: S01 rail contact before screw/tool; S04 first B/key plus explicit B2 HOLD. Full decode/480 PNG decode and completed state manifests pass. Camera changes are deliberate forward cuts and listed in CAMERA-CUT-REGISTER.json; do not call these a continuous camera move.42 checkpoints include19 starts/endpoints, two actual head-defect macros and two S14 route/contact views. S14 prepared rail5 now centers outside the sideposts before depth approach; prepared foot follows. This is a declared display path, not an OEM trajectory.

2641 software samples pass visibility retention, finite transforms, part-contact-before-current-screws, repeatable arbitrary/backward seek. Three focused tests additionally check retained poses/prepared-foot offsets, exact source counts and explicit pending/posed states. TypeScript passes.938 protected paths, historical review deliveries and frozen accepted proof/plan hashes match. No new full film, audio, Product01 or JULIETTE changes.

Final guarded state:20 structural components;82 initial hardware seats;12 exterior units posed-only;6 pending (B2/B4 andN4). Source quantities reconcile without pretending all100 units are fastened. C13/C14, I/J, receiving/retention/tool access, support/reorientation and door access remain OPEN.

## Requested explicit decision

Please inspect actual ZIP hashes, endpoint images and BOTH actual MP4s. Decide whether the bounded software integration/checkpoint evidence is accepted, and separately retain or reject the S04 geometric/access HOLD and source holds. Do not grant full render/finalLong/Short/audio authority or physical certification. Record precisely what further human scope/evidence would be required. No new research or source acquisition is requested. This milestone ends after recording your complete actual response.
''')
files=['DIRECTOR-REVIEW.md','AUTHORITY.json','INTEGRATION-QA.json','19-STEP-ENDPOINTS.json','RETENTION-AND-SEEK.json','RAW-INSTALLATION-AND-TOOL-CANDIDATES.json','COLLISION-CLASSIFICATION.json','VERIFIED-S4-DEFECTS.json','UNCERTAINTIES-AND-HOLDS.md','MEDIA-QA.json','CAMERA-CUT-REGISTER.json','VIDEO-FRAME-MANIFEST.json','PROTECTED-ASSET-VERIFICATION.json','SOURCE-FINGERPRINTS.json','01-19-STEP-CONTACT-SHEET.jpg','02-S04-VERIFIED-HEAD-DEFECT.jpg','03-MOTION-PROOF-CONTACT-SHEET.jpg','evidence/tests.log','evidence/typecheck-with-tests.log','evidence/OEM-PDF-P05-S03-S04.png',*[r['path'] for r in media]]
files += [str(f.relative_to(P)) for f in sorted((P/'checkpoints').glob('*'))]
files += [str(f.relative_to(P)) for f in sorted((P/'evidence/initial-candidate').glob('*.json'))]
for folder in ['proof-S01','proof-S04']:files += [f'{folder}/{n}' for n in ['offline-network.json','selected-diagnostic-manifest.json']]
files += [str(f.relative_to(P)) for f in (P/'evidence/initial-candidate').glob('*.ts')]
files += [str(f.relative_to(P)) for f in src.glob('*.ts')] if False else []
# Include current source snapshots as evidence; paths stay local to the review ZIP.
for f in src.glob('*.ts'):
 target=P/'evidence/source'/f.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(f,target);files.append(str(target.relative_to(P)))
manifest=[dict(path=n,bytes=(P/n).stat().st_size,sha256=sha(P/n)) for n in files];save('PAYLOAD-SHA256.json',manifest)
z=P/'PRODUCT03-compact264-integration-v1-review.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as a:
 for n in files+['PAYLOAD-SHA256.json']:a.write(P/n,n)
with zipfile.ZipFile(z) as a:assert all(hashlib.sha256(a.read(r['path'])).hexdigest()==r['sha256'] for r in manifest)
delivery=[z,P/'DIRECTOR-REVIEW.md',*[P/r['path'] for r in media],P/'01-19-STEP-CONTACT-SHEET.jpg',P/'02-S04-VERIFIED-HEAD-DEFECT.jpg',P/'03-MOTION-PROOF-CONTACT-SHEET.jpg']
save('REVIEW-DELIVERY-MANIFEST.json',[dict(path=str(f.resolve()),bytes=f.stat().st_size,sha256=sha(f)) for f in delivery]);(P/'DELIVERY-SHA256.txt').write_text(''.join(f'{sha(f)}  {f.name}\n' for f in delivery))
print(json.dumps(dict(payloads=len(manifest),zip=z.name,bytes=z.stat().st_size,sha256=sha(z),media=media,status='SOFTWARE QA PASS / S04 HOLD / DIRECTOR REVIEW REQUIRED'),indent=2))
