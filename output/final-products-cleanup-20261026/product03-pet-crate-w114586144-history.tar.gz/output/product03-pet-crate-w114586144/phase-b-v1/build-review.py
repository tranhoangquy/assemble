from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,re,shutil
from datetime import datetime
from zoneinfo import ZoneInfo
b=Path(__file__).resolve().parent; root=b.parents[2]; a=b.parent/'phase-a-v1'; stills=b/'stills-reviewed'; delivery=b/'review-files'; delivery.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
font_path='/System/Library/Fonts/Supplemental/Arial.ttf'
font=lambda n:ImageFont.truetype(font_path,n)
images=sorted(stills.glob('*.png')); assert len(images)==16
for p in images:
 with Image.open(p) as im: assert im.size==(1280,720); im.verify()
for n,dest in [('01-crafted-overall.png','01-Crafted-Frame.jpg'),('02-quiet-oak-overall.png','02-Quiet-Oak.jpg')]: Image.open(stills/n).convert('RGB').save(delivery/dest,quality=94,subsampling=0)
def sheet(names,out):
 canvas=Image.new('RGB',(1600,450*((len(names)+1)//2)),'#e9e6df')
 for i,n in enumerate(names):
  im=Image.open(stills/n).convert('RGB').resize((800,450),Image.Resampling.LANCZOS); canvas.paste(im,((i%2)*800,(i//2)*450))
 canvas.save(delivery/out,quality=94,subsampling=0)
sheet(['03-front-identity.png','04-rear-identity.png','05-exploded-20-components.png','06-upper-module.png','13-parts-inventory.png','14-floor-supports.png'],'03-GEOMETRY-REVIEW.jpg')
sheet(['07-wood-crafted.png','15-wood-quiet-oak.png','08-metal-lattice.png','09-screw-C-D.png','10-hinge-detail.png','11-I-J-unconfirmed.png','12-hardware-tools.png','16-tools-L-M-O.png'],'04-MATERIAL-HARDWARE-REVIEW.jpg')
# Number visible callout glyphs, never invent an unobserved sixth receiving location.
raw=Image.open(a/'evidence/pages/page-10.png').convert('RGB'); annotated=raw.copy(); dr=ImageDraw.Draw(annotated); sx=raw.width/1096; sy=raw.height/1550
positions=[('C13-01',668,323),('C13-02',613,382),('C13-03',509,442),('C13-04',429,471),('C14-01',696,937),('C14-02',685,999),('C14-03',589,1043),('C14-04',410,1136),('C14-05',63,1256)]
rows=[]
for label,x,y in positions:
 x=round(x*sx);y=round(y*sy); dr.ellipse((x-8,y-8,x+8,y+8),outline='#ba3b25',width=3)
 tx=min(max(x+15,15),raw.width-130);ty=y-24; dr.rectangle((tx-3,ty-2,tx+115,ty+20),fill='#fff5e5');dr.text((tx,ty),label,font=font(15),fill='#8e2b1d')
 rows.append({'callout':label,'PDF_page':10,'printed_page':9,'pixel_marker':[x,y],'observed':'Visible C glyph/callout region in the OEM illustration','receiver_ownership':'UNRESOLVED at per-end level; diagram association only','thread_or_bore_coordinates':'UNKNOWN','confidence':'VERIFIED visible label region; NOT verified physical receiving point'})
rows.append({'callout':'C14-06','PDF_page':10,'printed_page':9,'pixel_marker':None,'observed':'Sixth unit required by printed C x6 callout; no sixth individual glyph confidently localized','receiver_ownership':'UNKNOWN — do not fabricate a location','confidence':'CONFIRMED quantity only'})
(b/'evidence').mkdir(exist_ok=True); annotated.save(b/'evidence/C13-C14-callouts-annotated.png')
shutil.copyfile(a/'evidence/pages/page-10.png',b/'evidence/OEM-PDF-page10-original.png')
conflict=Image.open(a/'evidence/step18-I-J-conflict.png').convert('RGB'); combo=Image.new('RGB',(1800,1550),'#f4f1e9'); annotated.thumbnail((1096,1550));combo.paste(annotated,(0,0));conflict.thumbnail((650,1000));combo.paste(conflict,(1125,100));cd=ImageDraw.Draw(combo);cd.text((1130,22),'SOURCE: local 13-page manual',font=font(23),fill='#292c2f');cd.text((1130,57),'S18 inset I / summary J conflict',font=font(20),fill='#9a3f28');
for j,t in enumerate(['Left: PDF p10 / printed9','C13: four visible callouts','C14: five visible callouts','C14 sixth: count-only, unlocated','','Red markers are illustration pixels,','NOT measured bore positions.','End allocation remains unresolved.','','Right: PDF p12 S18 source crop.','I/J remains a working hypothesis.']): cd.text((1130,1135+j*29),t,font=font(20),fill='#3d3730')
combo.save(delivery/'05-OEM-C-IJ-EVIDENCE.jpg',quality=94,subsampling=0)
(b/'C-POSITION-MATRIX.json').write_text(json.dumps({'source_pdf_sha256':sha(a/'source/human-provided-pet-crate-manual.pdf'),'source_image_sha256':sha(b/'evidence/OEM-PDF-page10-original.png'),'method':'Human visual read of numbered step drawing, source-space annotation only','C_S13':4,'C_S14':6,'total':10,'individual_callout_regions_confidently_localized':9,'rows':rows,'conclusion':'NO physical-confidence upgrade. Hypothesis four remaining rail6 ends plus two rail5 ends NOT accepted as source fact.'},indent=2)+'\n')
ledger=json.loads((b/'COMPONENT-GEOMETRY-LEDGER.json').read_text())
protected=json.loads((a/'evidence/protected-baseline.json').read_text()); changed=[]
for p,h in protected.items():
 if not (root/p).is_file() or sha(root/p)!=h: changed.append(p)
manifest=json.loads((stills/'diagnostic-manifest.json').read_text()); network=json.loads((stills/'offline-network.json').read_text())
assert all(not x['networkResourceRequests'] and x['registeredPartInstances']==20 and x['registeredHardwareUnits']==103 for x in manifest)
full=(b/'typecheck-full-final.log').read_text(); full_errors=full.splitlines(); historical=all(x.startswith('output/idmarket-juliette-18094/') for x in full_errors if x.strip())
qa={'revision':'PRODUCT03-PHASE-B-V1-REVIEWED-20261020','recorded_at':datetime.now(ZoneInfo('Asia/Ho_Chi_Minh')).isoformat(),'prototype_components':20,'source_part_types':15,'A_O_instances':103,'installed_accessory_units':100,'tools':3,'test_results':'PASS — 3/3 inventory, reset, finite-mesh/external-only checks; test-results-reviewed.log','source_typecheck':'PASS — current src and scripts, output historical snapshots excluded in explicit review tsconfig','root_typecheck':{'status':'FAIL','error_lines':len(full_errors),'all_errors_in_preserved_historical_JULIETTE_snapshots':historical,'log':'typecheck-full-final.log','no_history_changed_to_hide_errors':True},'stills':{'count':16,'native_resolution':[1280,720],'source':'Actual Three.js / WebGL rendered stills using existing render-mechanism-diagnostics.ts; no AI image generation or video','all_pngs_verified':True},'offline_network':network,'protected':{'paths_checked':len(protected),'changed':changed,'status':'PASS' if not changed else 'FAIL','scope':'Existing 938-path Phase A protected manifest; not exhaustive hashing of every historical media frame'},'unverified':['All product dimensions/proportions','Mechanical contact and screw/hand/tool access','C13/C14 per-end allocation, including unlocated sixth S14 glyph','I/J identity and lock motion','Pet fit/load/capacity and material chemistry'],'motion_and_audio':'NOT_RUN — NOT_AUTHORIZED','phase_C':'NOT_AUTHORIZED by human; Director cannot independently expand scope','initial_diagnostics':['Fixed an initial TypeScript delimiter/tuple issue','tsx CLI IPC failed EPERM; used node --import tsx','Local Chromium MachPort launch blocked by sandbox; ran approved local offline process','Initial grain overflow and tile seam corrected before review; earlier stills retained'],'shared_script_change':'Optional AUDIT_OFFLINE=1 context blocks requests/service workers and background network; default path unchanged; no new exporter or catalog registration','director_status':'REQUIRES_DIRECTOR_REVIEW'}
(b/'PHASE-B-QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n'); shutil.copyfile(b/'PHASE-B-QA.json',delivery/'PHASE-B-QA.json')
parts_table='| Runtime ID | Position (display units) | Bounds extent (display units) |\n|---|---|---|\n'
for p in ledger['parts']:
 size=[round(y-x,2) for x,y in zip(p['displayBounds']['min'],p['displayBounds']['max'])];parts_table+=f"| {p['id']} | {p['displayPosition']} | {size} |\n"
c_table='| Callout ID | Source page | Marker / evidence | Physical end allocation |\n|---|---|---|---|\n'
for row in rows:c_table+=f"| {row['callout']} | PDF10 / printed9 | {row['pixel_marker'] or 'Count-only; no localized glyph'} | UNRESOLVED |\n"
report=f'''# Product #03 - Phase B visual and geometry prototype review

Review ID: PRODUCT03-PHASE-B-V1-REVIEWED-20261020. **REQUIRES DIRECTOR REVIEW.** Human authorizes Phase B prototypes and revision loop only; Phase C and complete Long/Short production remain NOT AUTHORIZED. Please do not expand that human boundary.

## Actual outputs

20 independent provisional components matching 15 source IDs, 103 A-O prototype instances (100 hardware/accessories, 3 tools). Two finishes: Crafted Frame brown/charcoal and Quiet Oak pale wood/warm graphite. 16 actual native 1280x720 WebGL stills cover overall/front/rear/exploded, upper module, both wood finishes, mesh/metal, C/D, hinge, I/J, all 20 parts, hardware and tools, floor supports. Composite JPEG review sheets contain those actual rendered pixels, not generated illustration or motion proof.

Source: local 13-page manual SHA256 `{sha(a/'source/human-provided-pet-crate-manual.pdf')}`. It shows open cubbies, not drawer boxes/slides. Commercial model identity remains metadata-only. All visibly depicted hinges, handles and welded mesh/braces are constituent features, not invented loose OEM IDs. Component count is not a count of every welded wire.

## What is modeled and what is deliberately unverified

Product display coordinates use an arbitrary 1200-wide visual scale, NOT manufacturer millimetres. All geometry, camera, finish and size evidence is labeled VISUAL_APPROXIMATION. The ProductDefinition unit:mm field is an engine adapter only and must never be exported as confirmed dimensions. No engineering measurement is derived from perspective or relative hardware scale.

Hardware B-F has external drive/head/shaft/tip silhouettes from the table/insets; helix/thread geometry is omitted. G/H/K and hinge leaves have source-visible external apertures, not invented concealed panel bores. No hidden receiving bore, mating thread, torque, stop or access guarantee was created. K and hinge aperture dimensions, decorative wire pitch, cross-sections and all finish parameters remain approximations. L/M/O are separate tool samples, never installed product parts. I and J are non-certified silhouette samples with an explicit hypothesis caption; no locking motion is shown.

Most hardware is modeled in a separate loose tray. Overall stills place the five A feet only at source-associated positions. These are finished-shape studies, not proof that all 100 hardware units have been fitted. Exploded and inventory views are static display arrangements, never manufacturer installation trajectories.

The hinge placement, closure gaps and tube intersections are NOT a physical-fit PASS. There is no connection animation, concealed receiver, hand/driver simulation or certified floor support. No repeated/forward assembly continuity is claimed from static stills; only canonical reset is tested.

## Dimension and approximation ledger

Every row below is generated from the actual prototype mesh bounds. Values are unmeasured **display units**, not product specifications. ID-to-shape source: PDF p3 parts table; PDF p1 exploded; numbered steps in PDF pp4-13. Panel proportions, tube width18, mesh pitch54, wire width1.9 and all visible edge radii are art/model assumptions. No such value is source-confirmed.

{parts_table}
Primary material controls: Crafted wood #77533B / frame #292C2F / steel #A3A9AC; Quiet Oak wood #B19A76 / frame #484A45 / steel #B4B7B4. Wood roughness .62, frame .45, steel .28; metalness frame .5 / steel .76. These are creative parameters only, not material grades/species or OEM finish confirmation. Procedural texture seeds/UV offsets differ per panel and all maps/environment lights are generated locally. Initial grain artifacts were corrected before this delivery; prior images remain preserved.

## C distribution: actual source comparison

Actual source PDF p10/printed9 is supplied with red labels on nine visually localized C glyph/callout regions. Coordinates are source-image pixels, not hole positions. Printed S13 C4 + S14 C6 =10 remains the only verified quantity allocation here. S14 shows five individual glyph regions confidently read; the sixth is count-only/unlocated. A close-up inset illustrates a generic rail end receiver, not enough to certify ownership of every fastener.

{c_table}
The hypothesis that S14 uses four remaining rail6 ends plus two rail5 ends remains **INFERRED / NOT APPROVED**. No extra C, carrier, receiving hole or hidden operation was invented to force closure. Position annotations are not a resolution of physical fit or tool access. The original source image is preserved separately from annotated evidence.

## Unresolved connection register

- P03-U01: W114586144 identity is metadata-only; no drawers in the local inventory/steps.
- P03-U02/U15: overall/part dimensions and exact hardware engineering specifications remain UNKNOWN. Visual approximation is authorized for this phase only.
- P03-U03: J upper/S17 and I lower/S18 remain the Director-accepted working hypothesis, not OEM truth; summary/inset conflict shown in actual source crop.
- P03-U04: per-end C allocation stays unresolved, especially C14-06.
- P03-U05/U06: no concealed bore/thread/carrier choice; seven D of13 and ten D of15 still need exact backing/receiving mapping before a truthful detailed tightening sequence.
- P03-U07/U08/U09: supported inversion/turnover, alignment-before-tightening and installed-state tool/hand access remain to be established; no animation or torque claim now.
- P03-U10/U11/U12: hinge axes/limits, factory studs, latch action, floor14 seating, pad N optionality/contact and pet capacity/load are unverified.
- P03-U13: both finish palettes are creative proposals, not manufacturer-confirmed materials.
- P03-U14: source catalog overlaps text; previously recorded PDF font warnings preserved. No source repair or new publisher evidence claimed.

## Validation and preservation

- 3/3 targeted tests PASS: all IDs/counts, canonical reset after exploded/backward selections, finite mesh geometry/external-only hardware.
- Current src/scripts TypeScript check PASS using explicit review config. Root TypeScript check remains FAIL with {len(full_errors)} diagnostics from preserved JULIETTE output source snapshots. All diagnostics in those historical snapshot paths: {historical}. We did not edit history, suppress that raw failure or label the whole repository PASS.
- All 16 PNGs decoded and checked at1280x720. Renderer completed without page errors. Offline context/service workers blocked/all HTTP requests aborted; actual attempted requests: {len(network['attemptedRequests'])}. No general browsing, external assets, downloads or paid services.
- Existing still infrastructure reused. The only shared-script addition is optional AUDIT_OFFLINE=1 safety; default mode is unchanged. No new exporter, schema, timeline, catalog entry or production profile.
- {len(protected)} protected source/evidence/media manifest paths checked; changes: {len(changed)}. Product01 and discontinued JULIETTE remain untouched. No audio, Long/Short, complete assembly animation or production geometry freeze.

## Director decision requested

Choose the finish and review shape/material/hardware clarity. Return explicit PASS / REVISION_REQUIRED / BLOCKED / NEEDS_USER_APPROVAL with any revisions restricted to Phase B. Do not certify dimensional fit or promote I/J/C hypotheses. If Phase B passes and the next work is Phase C, record that it needs separate human authorization: the current human directive explicitly excludes Phase C and full production. No Director-only scope expansion is permitted. Human alone finally accepts the two completed films.
'''
(b/'PHASE-B-REVIEW.md').write_text(report); (delivery/'PHASE-B-REVIEW.md').write_text(report)
# Freeze the exact implementation paired with the actual reviewed frames.
snapshot=b/'evidence/reviewed-source';snapshot.mkdir(exist_ok=True)
for f in (root/'src/products/product03-pet-crate-w114586144/prototype-v1').glob('*.ts'):shutil.copyfile(f,snapshot/f.name)
shutil.copyfile(root/'scripts/render-mechanism-diagnostics.ts',snapshot/'render-mechanism-diagnostics.ts')
files=sorted(p for p in delivery.iterdir() if p.is_file() and p.name!='REVIEW-SHA256.txt')
(delivery/'REVIEW-SHA256.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in files))
(b/'REVIEW-DELIVERY-MANIFEST.json').write_text(json.dumps([{'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files+[delivery/'REVIEW-SHA256.txt']],indent=2)+'\n')
print(json.dumps({'files':len(files)+1,'source_stills':16,'QA':qa['protected'],'network_attempts':len(network['attemptedRequests']),'delivery':str(delivery)},indent=2))
