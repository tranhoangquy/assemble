# Product #03 - Phase B visual and geometry prototype review

Review ID: PRODUCT03-PHASE-B-V1-REVIEWED-20261020. **REQUIRES DIRECTOR REVIEW.** Human authorizes Phase B prototypes and revision loop only; Phase C and complete Long/Short production remain NOT AUTHORIZED. Please do not expand that human boundary.

## Actual outputs

20 independent provisional components matching 15 source IDs, 103 A-O prototype instances (100 hardware/accessories, 3 tools). Two finishes: Crafted Frame brown/charcoal and Quiet Oak pale wood/warm graphite. 16 actual native 1280x720 WebGL stills cover overall/front/rear/exploded, upper module, both wood finishes, mesh/metal, C/D, hinge, I/J, all 20 parts, hardware and tools, floor supports. Composite JPEG review sheets contain those actual rendered pixels, not generated illustration or motion proof.

Source: local 13-page manual SHA256 `70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29`. It shows open cubbies, not drawer boxes/slides. Commercial model identity remains metadata-only. All visibly depicted hinges, handles and welded mesh/braces are constituent features, not invented loose OEM IDs. Component count is not a count of every welded wire.

## What is modeled and what is deliberately unverified

Product display coordinates use an arbitrary 1200-wide visual scale, NOT manufacturer millimetres. All geometry, camera, finish and size evidence is labeled VISUAL_APPROXIMATION. The ProductDefinition unit:mm field is an engine adapter only and must never be exported as confirmed dimensions. No engineering measurement is derived from perspective or relative hardware scale.

Hardware B-F has external drive/head/shaft/tip silhouettes from the table/insets; helix/thread geometry is omitted. G/H/K and hinge leaves have source-visible external apertures, not invented concealed panel bores. No hidden receiving bore, mating thread, torque, stop or access guarantee was created. K and hinge aperture dimensions, decorative wire pitch, cross-sections and all finish parameters remain approximations. L/M/O are separate tool samples, never installed product parts. I and J are non-certified silhouette samples with an explicit hypothesis caption; no locking motion is shown.

Most hardware is modeled in a separate loose tray. Overall stills place the five A feet only at source-associated positions. These are finished-shape studies, not proof that all 100 hardware units have been fitted. Exploded and inventory views are static display arrangements, never manufacturer installation trajectories.

The hinge placement, closure gaps and tube intersections are NOT a physical-fit PASS. There is no connection animation, concealed receiver, hand/driver simulation or certified floor support. No repeated/forward assembly continuity is claimed from static stills; only canonical reset is tested.

## Dimension and approximation ledger

Every row below is generated from the actual prototype mesh bounds. Values are unmeasured **display units**, not product specifications. ID-to-shape source: PDF p3 parts table; PDF p1 exploded; numbered steps in PDF pp4-13. Panel proportions, tube width18, mesh pitch54, wire width1.9 and all visible edge radii are art/model assumptions. No such value is source-confirmed.

| Runtime ID | Position (display units) | Bounds extent (display units) |
|---|---|---|
| part-1-1 | [-585, 0, 0] | [18.0, 975.78, 590] |
| part-2-1 | [585, 0, 0] | [18.0, 975.78, 590] |
| part-4-1 | [0, 408, -286] | [1170, 608, 18] |
| part-3-1 | [0, 712, 286] | [1152, 26.5, 19.5] |
| part-5-1 | [0, 62, 286] | [1152, 53.0, 19.5] |
| part-6-1 | [-350, 60, 0] | [18, 18, 560] |
| part-6-2 | [-116.66666666666666, 60, 0] | [18.0, 18, 560] |
| part-6-3 | [116.66666666666669, 60, 0] | [18.0, 18, 560] |
| part-6-4 | [350, 60, 0] | [18, 18, 560] |
| part-7-1 | [-289, 408, 302] | [576, 602, 34.3] |
| part-8-1 | [289, 408, 302] | [576, 602, 34.3] |
| part-9-1 | [0, 914, 0] | [1152, 18, 572] |
| part-10-1 | [-567, 825, 0] | [18, 160, 558] |
| part-11-1 | [-189, 825, 0] | [18, 160, 558] |
| part-10-2 | [567, 825, 0] | [18, 160, 558] |
| part-11-2 | [189, 825, 0] | [18, 160, 558] |
| part-12-1 | [0, 825, -270] | [1116, 160, 18] |
| part-13-1 | [0, 954, -270] | [1152, 60, 18] |
| part-15-1 | [0, 736, 0] | [1152, 18, 558] |
| part-14-1 | [0, 88, 0] | [1146, 18, 550] |

Primary material controls: Crafted wood #77533B / frame #292C2F / steel #A3A9AC; Quiet Oak wood #B19A76 / frame #484A45 / steel #B4B7B4. Wood roughness .62, frame .45, steel .28; metalness frame .5 / steel .76. These are creative parameters only, not material grades/species or OEM finish confirmation. Procedural texture seeds/UV offsets differ per panel and all maps/environment lights are generated locally. Initial grain artifacts were corrected before this delivery; prior images remain preserved.

## C distribution: actual source comparison

Actual source PDF p10/printed9 is supplied with red labels on nine visually localized C glyph/callout regions. Coordinates are source-image pixels, not hole positions. Printed S13 C4 + S14 C6 =10 remains the only verified quantity allocation here. S14 shows five individual glyph regions confidently read; the sixth is count-only/unlocated. A close-up inset illustrates a generic rail end receiver, not enough to certify ownership of every fastener.

| Callout ID | Source page | Marker / evidence | Physical end allocation |
|---|---|---|---|
| C13-01 | PDF10 / printed9 | [668, 323] | UNRESOLVED |
| C13-02 | PDF10 / printed9 | [613, 382] | UNRESOLVED |
| C13-03 | PDF10 / printed9 | [509, 442] | UNRESOLVED |
| C13-04 | PDF10 / printed9 | [429, 471] | UNRESOLVED |
| C14-01 | PDF10 / printed9 | [696, 937] | UNRESOLVED |
| C14-02 | PDF10 / printed9 | [685, 999] | UNRESOLVED |
| C14-03 | PDF10 / printed9 | [589, 1043] | UNRESOLVED |
| C14-04 | PDF10 / printed9 | [410, 1136] | UNRESOLVED |
| C14-05 | PDF10 / printed9 | [63, 1256] | UNRESOLVED |
| C14-06 | PDF10 / printed9 | Count-only; no localized glyph | UNRESOLVED |

The hypothesis that S14 uses four remaining rail6 ends plus two rail5 ends remains **INFERRED / NOT APPROVED**. No extra C, carrier, receiving hole or hidden operation was invented to force closure. Position annotations are not a resolution of physical fit or tool access. The original source image is preserved separately from annotated evidence.

## Unresolved connection register

- P03-U01: W114586144 identity is metadata-only; no drawers in the local inventory/steps.
- P03-U02/U15: overall/part dimensions and exact hardware engineering specifications remain UNKNOWN. Visual approximation is authorized for this phase only.
- P03-U03: J upper/S17 and I lower/S18 remain the Director-accepted working hypothesis, not OEM truth; summary/inset conflict shown in actual source crop.
- P03-U04: per-end C allocation stays unresolved, especially C14-06.
- P03-U05/U06: no concealed bore/thread/carrier choice; seven D of13 and ten D of15 still need exact backing/receiving mapping before a truthful detailed tightening sequence.
- P03-U07/U08/U09: supported inversion/turnover, alignment-before-tightening and installed-state tool/hand access remain to be established; no animation or torque claim now.
- P03-U10/U11/U12: hinge axes/limits, factory studs, latch action, floor14 seating, pad N optionality/contact and pet capacity/load are unverified.
- P03-U13: both finish palettes are creative proposals, not manufacturer-confirmed materials.
- P03-U14: source catalog overlaps text; previously recorded PDF font warnings preserved. No source repair or new publisher evidence claimed.

## Validation and preservation

- 3/3 targeted tests PASS: all IDs/counts, canonical reset after exploded/backward selections, finite mesh geometry/external-only hardware.
- Current src/scripts TypeScript check PASS using explicit review config. Root TypeScript check remains FAIL with 50 diagnostics from preserved JULIETTE output source snapshots. All diagnostics in those historical snapshot paths: True. We did not edit history, suppress that raw failure or label the whole repository PASS.
- All 16 PNGs decoded and checked at1280x720. Renderer completed without page errors. Offline context/service workers blocked/all HTTP requests aborted; actual attempted requests: 0. No general browsing, external assets, downloads or paid services.
- Existing still infrastructure reused. The only shared-script addition is optional AUDIT_OFFLINE=1 safety; default mode is unchanged. No new exporter, schema, timeline, catalog entry or production profile.
- 938 protected source/evidence/media manifest paths checked; changes: 0. Product01 and discontinued JULIETTE remain untouched. No audio, Long/Short, complete assembly animation or production geometry freeze.

## Director decision requested

Choose the finish and review shape/material/hardware clarity. Return explicit PASS / REVISION_REQUIRED / BLOCKED / NEEDS_USER_APPROVAL with any revisions restricted to Phase B. Do not certify dimensional fit or promote I/J/C hypotheses. If Phase B passes and the next work is Phase C, record that it needs separate human authorization: the current human directive explicitly excludes Phase C and full production. No Director-only scope expansion is permitted. Human alone finally accepts the two completed films.
