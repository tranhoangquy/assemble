# PRODUCT03 — Targeted Motion Proofs V1

**Review ID: PRODUCT03-TARGETED-MOTION-PROOFS-V1-20261023**

Human-authorized as-is diagnostic capture is complete. Please watch the three actual MP4s and issue a formal visual review. This is evidence collection only: no source, geometry, camera, timing, animation, lighting or diagnostic-HUD changes. The accepted278s V2 baseline is preserved.

| Proof | Global window (end exclusive) | Duration | Frames | Format |
|---|---|---:|---:|---|
| PROOF-01-108-124.mp4 | 108–124s | 16s | 384 |1280×720 H.264,24fps,no audio|
| PROOF-02-185-209.mp4 | 185–209s | 24s | 576 |1280×720 H.264,24fps,no audio|
| PROOF-03-209-228.mp4 | 209–228s | 19s | 456 |1280×720 H.264,24fps,no audio|

All1416 camera/state records match frozen V2; PNG CRC/full image decode and MP4 full decode/PTS/frame counts/faststart pass. Six chunks completed first attempt; three seams have continuous index/time.95 original review PNGs plus four contact sheets, capture metadata, offline logs and SHA256 payload manifest accompany the actual videos.

## Review priorities

- P1: A4/A5 preparation legibility, whole-rig180° staging, two side-frame approaches, first D/L operations and preserved K/B. D33 finishes outside the window: do not infer all ten D were reviewed.
- P2: last6/C12, late5+A5, C13–C18 readability/occlusion, return upright and floor14 without a fastener. C13/C14 source allocation remains OPEN.
- P3: door7/E1–4 then door8/E5–8, M/leaf/head readability and retained first door. No door swing or S17–S19 added.

Observed concerns are unchanged abrupt wide/macro cuts, short repeated-operation holds, small preparation details and some occluded tool targets. See VISUAL-FINDINGS.md for exact original-frame references and the distinction between observation and unverified physical interpretation. No new physical penetration or whole-product visual PASS is claimed from samples.

## Explicit decision requested

Please report PASS / REVISION_REQUIRED / FAIL for the targeted visual review, identify scenes usable unchanged and any demonstrated P0 versus readability/timing concerns. If a separate correction milestone is recommended, propose it only; do not interpret this capture-only task as editing authority. **Stop after review.** No full278s/final Long/Short/audio/mastering or new geometry/research.

K22/10 UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN; S17/S18 POSE-ONLY; S19 pads/door HOLD. Historical raw collision FAIL and physical receiving/access limitations are preserved. Product01 and JULIETTE are unchanged. Human alone grants final film acceptance.

## Video SHA256

- `6c99ed24aa9d939d944eadaa337b1079b50ea5b7f6812cdd9f074480287bf4f6` — PROOF-01-108-124.mp4
- `8f4cceca9850c840dee5c3ec06e27bfb7110bfb72551ef0cb1c512389292c65c` — PROOF-02-185-209.mp4
- `9d49c5ef2f198c41ec99a4b1276825981d346bfa5fec83abfbad36ecb2721cb7` — PROOF-03-209-228.mp4

Actual evidence ZIP is separately attached with its payload SHA256 manifest. Technical capture PASS is not a creative, physical or final-film acceptance.
