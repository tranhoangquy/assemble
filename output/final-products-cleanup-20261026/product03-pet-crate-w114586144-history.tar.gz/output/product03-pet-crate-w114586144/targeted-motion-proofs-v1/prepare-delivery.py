from pathlib import Path
import json,hashlib,zipfile
P=Path(__file__).resolve().parent
load=lambda f:json.loads(f.read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
qa=load(P/'PROOF-CAPTURE-QA.json');assert sum(v['frames']for v in qa['media'])==1416 and sum(v['duration']for v in qa['media'])==59
assert load(P/'PROTECTED-ASSET-VERIFICATION.json')['status']=='PASS'
for m in qa['media']:assert sha(P/m['file'])==m['sha256']
for r in load(P/'SELECTED-ORIGINALS-MANIFEST.json'):assert sha(P/r['selectedPath'])==r['sha256']
for chunk in load(P/'CAPTURE-JOB.json')['chunks'].values():assert chunk['status']=='COMPLETE'and chunk['attempt']==1
(P/'LOCAL-REPRODUCTION.md').write_text('''# Local capture record

This milestone is complete and immutable. These are provenance commands, not permission to start a new capture or fix. Offline only; the sole external action is the human-authorized existing Assemble review handoff.

- `capture-entry.ts` imports the exact frozen V2 preview and schedules only requested timestamp checkpoints. Every frame name selects its original motion camera. No render function or production module is replaced.
- `capture-bounded.py` invokes the existing diagnostic renderer in6fresh sequential jobs, with blocked network requests. The atomic CAPTURE-JOB.json records compatibility hashes, chunk status, exact frame indices and all original PNG hashes. Only complete validated chunks may be resumed; partial attempts are preserved. This run had0retries.
- `compare-evaluator.ts` compares every actual captured camera/state with frozen V2 at the same global timestamp, plus backward/repeated seeks and retained state checks. It does not generate product imagery.
- `encode-and-qa.py` encodes each continuous PNG sequence once using local ffmpeg H.264,1280×720,24fps,yuv420p,CRF20,faststart,no audio; ffprobe counts/PTS and full ffmpeg decode are checked. No timing or image edits.
- `select-operation-frames.py` copies supplemental original E/C frames; no renderer call or image manipulation beyond the labeled contact-sheet thumbnails.
- `verify-preservation.py` checks118source/renderer files,938protected paths,99historical deliveries and8frozen manifest sets. Archived preflight manifests are historical snapshots, distinct from final delivered manifests; neither is changed.

All1416native PNGs and their chunk manifests remain local under `chunks/` and `frames/`. The evidenceZIP carries95selected original PNGs and the full1416-frame hash manifest, all chunk camera/state manifests/offline logs,4contact sheets,QA/source/assumption/observation reports and the3actualMP4s. It omits the redundant full1416-PNG payload; no frames were removed from the videos.

Software1e-8comparison is not an OEM fit tolerance. No hidden receiver, physical collision/access certification, torque, source-ambiguity resolution or whole-film acceptance was performed. Stop after the actual Director review decision; future corrections require separately authorized scope.
''')
exclude={'REVIEW-DELIVERY-MANIFEST.json','PAYLOAD-SHA256.json','DELIVERY-SHA256.txt','ZIP-VERIFICATION.json'}
files={f for f in P.iterdir()if f.is_file()and f.name not in exclude and f.suffix in ['.json','.md','.py','.ts','.jpg','.mp4']}
files.update(f for f in (P/'selected-originals').rglob('*.png'))
files.update(f for f in (P/'evidence').iterdir()if f.is_file()and f.name!='package.log')
files.update(f for f in (P/'chunks').rglob('*.json'))
payload=[{'path':str(f.relative_to(P)),'bytes':f.stat().st_size,'sha256':sha(f)}for f in sorted(files)]
(P/'PAYLOAD-SHA256.json').write_text(json.dumps(payload,indent=2)+'\n')
z=P/'PRODUCT03-targeted-motion-proofs-v1-evidence.zip'
assert not z.exists(),'Never overwrite an existing review package'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,6)as out:
 for row in payload:out.write(P/row['path'],row['path'])
 out.write(P/'PAYLOAD-SHA256.json','PAYLOAD-SHA256.json')
with zipfile.ZipFile(z)as archive:
 assert archive.testzip()is None
 saved=json.loads(archive.read('PAYLOAD-SHA256.json'));assert saved==payload
 assert set(archive.namelist())=={r['path']for r in payload}|{'PAYLOAD-SHA256.json'}
 for row in payload:
  b=archive.read(row['path']);assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']
(P/'ZIP-VERIFICATION.json').write_text(json.dumps({'status':'PASS','zip':z.name,'bytes':z.stat().st_size,'sha256':sha(z),'payloads':len(payload),'verifiedPayloads':len(payload),'manifest': 'PAYLOAD-SHA256.json','actualMP4s':3,'originalPNGs':95,'fullFrameHashRecords':1416,'directorDecision':'PENDING_ACTUAL_SUBMISSION'},indent=2)+'\n')
# Ten actual attachments:3MP4,ZIP,3review documents,3window contact sheets. Supplemental sheet andQA are insideZIP.
names=[m['file']for m in qa['media']]+[z.name,'DIRECTOR-REVIEW.md','VISUAL-FINDINGS.md','SOURCE-AND-ASSUMPTION-REGISTER.md','CONTACT-SHEET-P1.jpg','CONTACT-SHEET-P2.jpg','CONTACT-SHEET-P3.jpg']
delivery=[{'path':str(P/n),'bytes':(P/n).stat().st_size,'sha256':sha(P/n)}for n in names];assert len(delivery)==10
(P/'REVIEW-DELIVERY-MANIFEST.json').write_text(json.dumps(delivery,indent=2)+'\n');(P/'DELIVERY-SHA256.txt').write_text(''.join(f"{v['sha256']}  {Path(v['path']).name}\n"for v in delivery))
print(json.dumps({'status':'READY FOR ACTUAL ASSEMBLE HANDOFF','zip':z.name,'bytes':z.stat().st_size,'sha256':sha(z),'payloadsVerified':len(payload),'attachments':len(delivery),'actualMP4s':3},indent=2))
