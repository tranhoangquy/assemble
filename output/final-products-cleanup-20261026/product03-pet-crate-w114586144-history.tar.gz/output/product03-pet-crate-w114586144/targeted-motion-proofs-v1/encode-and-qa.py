from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,subprocess,shutil,struct,datetime
P=Path(__file__).resolve().parent
def load(f):return json.loads(Path(f).read_text())
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def save(n,v):(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True).stdout
identity=load(P/'BASELINE-AND-CAPTURE-IDENTITY.json');job=load(P/'CAPTURE-JOB.json');frames=load(P/'FRAME-SHA256-MANIFEST.json');assert job['status']=='ALL_FRAMES_VALIDATED'and len(frames)==1416
comparison=load(P/'EVALUATOR-FRAME-COMPARISON.json');assert all(comparison[k]for k in ['allMatch','retainedBK','feetFollowHost','firstDoorRetainedDuringSecond','noAddedDoorSwing','deterministic'])
media=[];seams=[]
for ordinal,p in enumerate(identity['proofs'],1):
 rows=[r for r in frames if r['proof']==p['id']];assert [r['index']for r in rows]==list(range(p['frames']))
 for r in rows:assert sha(P/r['continuousPath'])==r['sha256']
 for c in p['chunks'][1:]:
  i=c['start'];a,b=rows[i-1],rows[i];assert abs(b['time']-a['time']-1/24)<1e-9;seams.append(dict(proof=p['id'],before=a,after=b,frameIndexContinuous=True,timeContinuous=True,qualification='Equal content during genuine holds is permitted; no content-based deduplication or frame repetition introduced.'))
 f=P/f"PROOF-{ordinal:02d}-{p['start']}-{p['end']}.mp4"
 run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-framerate','24','-start_number','0','-i',str(P/'frames'/p['id']/'frame-%06d.png'),'-frames:v',str(p['frames']),'-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-an','-movflags','+faststart',str(f)])
 info=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(f)]));save(f'evidence/PROOF-{ordinal:02d}-ffprobe.json',info);assert len(info['streams'])==1;s=info['streams'][0]
 assert s['codec_name']=='h264'and s['width']==1280 and s['height']==720 and s['r_frame_rate']==s['avg_frame_rate']=='24/1'and int(s['nb_read_frames'])==p['frames']and abs(float(info['format']['duration'])-p['seconds'])<1e-6
 decode=subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(f),'-f','null','-'],capture_output=True,text=True);(P/f'evidence/PROOF-{ordinal:02d}-full-decode.log').write_text(decode.stderr);assert decode.returncode==0 and not decode.stderr.strip()
 pts=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(f)]))['frames'];assert len(pts)==p['frames']and all(abs(float(r['best_effort_timestamp_time'])-i/24)<1e-6 for i,r in enumerate(pts));save(f'evidence/PROOF-{ordinal:02d}-frame-pts.json',pts)
 atoms=[]
 with f.open('rb')as stream:
  while stream.tell()<f.stat().st_size:
   offset=stream.tell();header=stream.read(8)
   if len(header)<8:break
   size,code=struct.unpack('>I4s',header)
   if size==1:size=struct.unpack('>Q',stream.read(8))[0]
   if size==0:size=f.stat().st_size-offset
   atoms.append(dict(type=code.decode('ascii'),offset=offset,size=size));stream.seek(offset+size)
 assert next(r['offset']for r in atoms if r['type']=='moov')<next(r['offset']for r in atoms if r['type']=='mdat')
 media.append(dict(proof=p['id'],file=f.name,globalStart=p['start'],globalEndExclusive=p['end'],lastGlobalTime=p['start']+(p['frames']-1)/24,duration=p['seconds'],frames=p['frames'],codec=s['codec_name'],width=1280,height=720,fps='24/1',audioStreams=0,fullDecode='PASS',framePTS='PASS',faststart=True,sha256=sha(f),bytes=f.stat().st_size))
save('CHUNK-SEAM-QA.json',seams)
selected={
'P1':[108,108.5,109.6,109.8,110.9,112,112.7,113.4,113.5,115.5,117.5,117.9,118.9,119.9,120.375,121.625,123.9583333333],
'P2':[185,185.5,186.75,186.9583333333,188.25,189.25,190.75,191.5,192.25,192.625,195.4583333333,198.25,202.5,203,204,205,205.1666666667,206.125,207.1666666667,208.9583333333],
'P3':[209,209.25,210.25,211.25,211.625,212.6666666667,213.75,215.5833333333,218.25,218.75,219.75,220.75,221.125,222.1666666667,223.25,225.125,227.75,227.9583333333]}
selectedRows=[];font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18);big=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',28)
for p in identity['proofs']:
 indices={max(0,min(p['frames']-1,round((t-p['start'])*24)))for t in selected[p['id']]}
 for c in p['chunks'][1:]:indices.update([c['start']-1,c['start']])
 # Include adjacent originals at key abrupt camera switches, without retiming.
 extras={'P1':[117.9,120.3727272727,121.6090909091],'P2':[188.25,192.6,202.5],'P3':[211.6,218.25,221.1,227.75]}
 for t in extras[p['id']]:
  i=int((t-p['start'])*24);indices.update([i,i+1])
 rows=[r for r in frames if r['proof']==p['id']];dest=P/'selected-originals'/p['id'];dest.mkdir(parents=True,exist_ok=True);items=[]
 for i in sorted(indices):
  r=rows[i];f=dest/f"{p['id']}-frame-{i:06d}.png";shutil.copyfile(P/r['continuousPath'],f);assert sha(f)==r['sha256'];selectedRows.append(dict(**r,selectedPath=str(f.relative_to(P)),handling='Exact original native PNG byte copy, not extracted/upscaled from MP4'));items.append((f,r))
 cols=4;rowsN=(len(items)+cols-1)//cols;im=Image.new('RGB',(1920,70+rowsN*302),'#f3efe6');draw=ImageDraw.Draw(im);draw.text((18,16),f"{p['id']} / AS-IS V2 MOTION PROOF / {p['start']}-{p['end']}s / ORIGINAL FRAMES",font=big,fill='#292c2f')
 for j,(f,r)in enumerate(items):
  x=j%cols*480;y=70+j//cols*302
  with Image.open(f)as native:im.paste(native.convert('RGB').resize((480,270)),(x,y))
  draw.text((x+6,y+274),f"f{r['index']:04d} / global {r['time']:.6f}s",font=font,fill='#805534')
 im.save(P/f"CONTACT-SHEET-{p['id']}.jpg",quality=94)
save('SELECTED-ORIGINALS-MANIFEST.json',selectedRows)
save('PROOF-CAPTURE-QA.json',dict(milestone='PRODUCT03-TARGETED-MOTION-PROOFS-V1',technicalStatus='PASS — actual native diagnostic capture/media QA; Director visual review required',media=media,totalFrames=1416,totalSeconds=59,frameSchedule='Continuous index perproof; global=start+index/24,endexclusive; single final encode perproof, no chunk MP4 splice or creative retiming',nativePNGs='1416 PNG CRC/full image decodes and1280x720 validated by capture runner',chunkSeams='3 joins PASS; before/after originals and timestamps retained',completedChunks=6,workers=1,retries=sum(max(0,r['attempt']-1)for r in job['chunks'].values()),offline='All6 renderer jobs blockedallrequests,0attempts; no external source acquisition',camera='Frozen original render function unchanged; names include-frame- so original camera(time,false) used. All1416captured camera/state metadata match independent frozen evaluator.',evaluatorComparison=comparison,selectedOriginals=len(selectedRows),sourceEdits='NONE; hash verification recorded separately',audio='NONE, allthree files exactly1video stream',visualStatus='REQUIRES ACTUAL DIRECTOR VISUAL REVIEW; see observations/limitations',physicalConfidence='NOT_CERTIFIED; no OEM/receiver/access confidence upgrade'))
print(json.dumps(dict(media=media,selectedOriginals=len(selectedRows),status='MEDIA QA PASS — DIRECTOR REVIEW REQUIRED'),indent=2))
