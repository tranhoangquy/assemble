# Actual as-is V2 motion capture — observations for Director review

Review: **PRODUCT03-TARGETED-MOTION-PROOFS-V1-20261023**. No correction was made. Technical capture/media QA passes; instructional and creative acceptance are **not claimed**. Findings below combine inspection of the 95 selected original PNGs/contact sheets with recorded per-frame evaluator metadata. The actual continuous MP4s are supplied for the Director's temporal assessment; a contact sheet alone is not proof of perceived motion quality. No fresh physical collision/access audit was performed.

Frame numbers below are zero-based within each proof. Global time = window start + frame/24. Every referenced PNG is byte-identical to the native renderer output. Adjacent frames at capture chunk seams are included, independently of any camera cuts.

## P1 — 108–124s, 384 frames

- **Preparation is present but visually small.** The opening wide view shows the upper wood module, separated side frames and a prepared rail. A4/A5 are difficult to distinguish individually at this scale (f0/108s, f12/108.5s, f38/109.583333s). This limits teaching clarity; it does not establish that a prepared object is missing.
- **The whole presentation rig turns.** f96/112s, f113/112.708333s and f130/113.416667s show the wood module and separated prepared frames undergoing the existing 180° presentation rotation. This is an unsupported illustrative reorientation, not a demonstrated safe lifting/support procedure. The next placement starts at113.5s, only0.1s after the planned turn ends.
- **Frame approach/contact precedes the sampled D operations.** f132/113.5s → f180/115.5s → f228/117.5s show the two side frames reaching the existing module. The scene then cuts from wide to a close-up between f237/117.875s and f238/117.916667s. The close-up abruptly changes subject scale; no interpolation/cut was added by capture.
- **D30 is easier to read than the compressed repeats.** Tool L and the exterior head are visible around f262/118.916667s and f286/119.916667s; the tool is withdrawing by f296/120.333333s. D31 starts immediately at f297/120.375s, followed by the cut to D32 between f326/121.583333s and f327/121.625s. The original planned tool-free hold for repeated D operations is0.037091s, less than one24fps frame. Whether the pace/cuts are understandable requires playback review.
- **Window boundary qualification:** P1 includes D30–D32 and only part of D33; D33 ends124.081818s, outside this window. It does **not** verify all ten S08 D screws. Its last frame is123.958333s; an in-progress tool is intentional at this evidence-window end, not an export truncation defect.
- **Retention:** all six K/B registry actors remain visible/enabled and seated in every captured state. Their image visibility varies with wood/mesh occlusion and macro framing. A feet retain their local offset relative to their host after each completed foot operation. This is transform continuity, not measured mating or retention certification.

## P2 — 185–209s, 576 frames

- **The clip starts in an existing C11 operation**, then returns to a wide view for the last rail6 at185.5s. The final rail and C12 are represented before S14. The cut back to wide at188.25s is preserved (f78/f79); it is not a chunk seam.
- **Late rail5/A5 staging is visible.** f102/189.25s, f138/190.75s, f156/191.5s and f174/192.25s show the current approach around the installed side posts and into the front-carrier position. This is a fast, multi-part silhouette; whether the path appears to pass through another member must be assessed in the actual MP4. A projected overlap alone is insufficient to declare a new solid penetration. No safe human installation path or support is established.
- **C13–C18 are all represented**, after rail5 contact, in the current illustrative allocation. The supplemental screw/tool sheet includes each planned engagement and post-withdrawal sample. C13's target/tool are difficult to see behind the front rail in f210/193.75s; later C operations show L and exterior heads more clearly (e.g. C14 f264/196s, C15 f298/197.416667s). This is a visible occlusion/readability concern, not an unperformed operation inferred from absence in the image. Exact C13/C14 source end ownership remains OPEN.
- **The feet show separated stem/disc silhouettes near the inverted post ends.** For example f183/192.625s and f318/198.25s preserve the current appearance. Their host-relative offsets are stable; the images do not establish a seated thread, hidden receiver, intended spacer or physical support. No gap was silently closed.
- **Turn and unfastened floor placement are clear in the sampled sequence.** f432/203s → f456/204s → f480/205s show the return upright. Floor14 follows at205.15–207.15s; f484/205.166667s, f507/206.125s and f532/207.166667s show its approach and final position. No new floor screw/tool was added. The post-turn hold is only0.15s in the unchanged schedule.

## P3 — 209–228s, 456 frames

- **Door7 approaches before E1–E4; door8 approaches before E5–E8.** f6/209.25s → f54/211.25s, then f234/218.75s → f282/220.75s show the two door translations. The first door remains visibly present in the wide view during second-door placement and is retained in every captured evaluator state from218.75s onward.
- **The first essential E operations have readable leaf/head/tool close-ups.** E1 f88/212.666667s and E5 f316/222.166667s show M approaching the leaf-side exterior head. Supplementary originals cover E1–E8 at planned tool engagement and withdrawal. These are existing qualitative exterior illustrations, not proof of hidden thread engagement or factory hinge retention.
- **Cuts jump between wide, lower hinge and upper hinge views.** The first wide-to-macro cut is f62/211.583333s → f63/211.625s; the equivalent second-door cut is f290/221.083333s → f291/221.125s. Later repeats have very brief tool-free holds (0.0399s, below one24fps frame). Inspect the MP4 for perceived popping and loss of orientation; capture does not soften or retime them.
- **Occlusion is not a state reset.** The first door is outside some right-side macro frames, but remains installed. Mesh/frame members and the existing diagnostic HUD overlap some details. The HUD, generic illustrative warnings and original stage labels were intentionally preserved.
- **No door swing or later steps were added.** Both presentation pivot angles remain0 for all captured frames. P3 ends at227.958333s with eight E initial seats and both doors retained; it does not execute S17–S19, demonstrate load/hinge limits or grant functional opening approval.

## Evidence integrity and unresolved questions

All1416 original camera/state samples match independently evaluated frozen V2 at the same absolute timestamps. All six chunks completed on their first attempt. The three joins are P1 f191→192 (115.958333→116s), P2 f287→288 (196.958333→197s), and P3 f227→228 (218.458333→218.5s). Each has exactly one frame interval; no dropped/repeated index or creative deduplication. Equal-looking images during an existing hold are legitimate.

No new **confirmed physical** defect is asserted solely from these sampled projections. Visible hard cuts, small preparation details, target occlusion and short holds are direct review concerns. The continuous videos must determine whether any action is too fast, misleading or visibly intersects an unrelated solid. Technical PASS is not a visual PASS and does not dismiss existing historical raw collision FAILs.

Director questions: Which portions are sufficiently clear to keep? Does any actual motion establish a new visible P0 defect? Are timing/camera corrections needed in a separately human-authorized milestone? Do not treat the answers as authority to edit in this capture-only task.

**STOP — AWAIT DIRECTOR VISUAL REVIEW. No fixes or next milestone executed.**
