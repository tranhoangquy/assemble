# Source and assumption register — unchanged V2 capture

## Baseline and capture provenance

- Human authorization: PRODUCT03-TARGETED-MOTION-PROOFS-V1, bounded offline as-is diagnostic capture. Current baseline: accepted S04 Integration V2,278-second absolute evaluator. Its98-file freeze manifest SHA256 is `44dac15be4a8aae49504c6a62a94bd2d385d80d8943b49afab766da15c331f70`.
- Frozen implementation: `src/products/product03-pet-crate-w114586144/s04-integration-v2/{runtime,timeline,preview}.ts`, with its unchanged inherited V1/accepted S04 models. Exact118 product/engine/renderer fingerprints are in BASELINE-AND-CAPTURE-IDENTITY.json. All remain unchanged.
- Existing local renderer: `scripts/render-mechanism-diagnostics.ts`, SHA256 `8f02345232ad4e3287d9c808736f7e074751eb4dca978ffbc0ed3ee506fe8313`. No new exporter, application build, renderer design, geometry, animation or camera was introduced.
- The output-only `capture-entry.ts` imports the frozen preview and replaces only the contents of its original checkpoint list with the requested global timestamps. It does not replace render(), alter the scene or construct a new camera. Every filename includes `-frame-` and does not begin `K-`, so the original render function uses its unchanged `camera(time,false)` motion-camera selector. Studio, lights, materials and diagnostic HUD remain exactly as implemented.
- Six sequential fresh offline capture jobs:192+192,288+288,228+228 frames. Request blocking/DNS/background-network restrictions were enabled; all six offline logs record zero attempted external requests. No browser session is used for rendering. Only the explicitly permitted existing Assemble conversation is used for the final report/file handoff.
- Timestamp convention: index i uses global `start+i/24`, with end exclusive. Last timestamps: P1 123.95833333333333; P2 208.95833333333334; P3 227.95833333333334. This is the exact discrete schedule for16/24/19 seconds at24fps, not an omitted final frame.
- Continuous native PNG sequences were hardlinked from validated chunks and encoded once per proof to H.264/yuv420p MP4. No MP4 chunk splicing, rate adjustment, image interpolation, duplicate removal, crop, upscale or audio.95 selected native PNGs are byte-identical copies; contact sheets alone are downscaled labeled summaries. All1416 original PNG hashes are retained locally and listed in FRAME-SHA256-MANIFEST.json.
- EVALUATOR-FRAME-COMPARISON.json verifies all1416 actual camera/state records against the unchanged evaluator; numeric1e-8 comparison is a software equality criterion, not an OEM tolerance. Repeated/backward seek, K/B retention, feet host offsets, first-door retention and zero door swing were checked. No new physical collision/access test was performed.

## Source authority and unchanged limitations

| Topic | Current evidence/confidence | Allowed conclusion |
|---|---|---|
| Manual | Human-provided13-page local INSTALLATION INSTRUCTION; SHA256 `70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29` | Documentary order/quantities; metadata W114586144 commercial identity remains unverified. No drawers added. No new online acquisition. |
| Panel/overall dimensions | UNMEASURED display approximations | No certified dimensions, load/fit or manufacturing tolerance. |
| S04 K/B | Accepted bounded two-bolt geometry/motion, unchanged | K22/10 UNMEASURED; B1–B4 retained, no receiving/grip/torque/tool-access certification. |
| F | Accepted NONLITERAL visual reconstruction, unchanged | No OEM axis, receiver or physical connection upgrade; current generic HUD is not a new F-specific disclosure correction. |
| C in S13/S14 | C4 and C6 quantities documented; selected end allocation remains OPEN | P2 displays the existing C12–C18 illustration. Watching the animation cannot resolve source ambiguity. |
| Screw/hinge receivers | Exterior qualitative targets; hidden bores/threads/retention unresolved | Full existing shafts and exterior contacts remain. No added receiver, invented thread, shaft clipping or certified engagement. |
| Tools and tightening | L/M illustrative axial choreography; align-before-final-tightening instruction retained | Initial seats are not verified final torque or certified hand/tool access. No new tool geometry. |
| Reorientation/support | Existing rigid presentation inversion/return | Not a demonstrated physical lifting fixture, safe handling method or supported installation trajectory. |
| Late carrier5 | Existing outside-post/inward staging | Real installation/access is unverified. An attractive view cannot certify access. |
| Doors | Existing limited static hinge hypothesis, E8 illustration; pivots0 | No new hinge animation, opening limit, functional fit or retention claim. |
| I/J | OPEN | S17/S18 remain POSE-ONLY and are outside the proof windows. |
| S19 | Pads/door HOLD | No added pad fastening, latch release or functional door opening. |
| Raw collision history | Historical FAIL and all candidates preserved | No exclusions/threshold changes or physical PASS. Software/state continuity is distinct from physical acceptance. |
| Production scope | Only three diagnostic windows59s | No full278s render, final Long/Short, audio, mastering, research or source correction. Human remains sole final acceptance authority. |

PROTECTED-ASSET-VERIFICATION.json checks938 Product01/JULIETTE protected paths,99 historical delivered files,118 source/engine/renderer files and eight frozen manifest sets, including the prior read-only audit. All match; no earlier evidence was overwritten.

**The Director may review these videos internally; this package does not authorize corrections or production. STOP after the actual review decision.**
