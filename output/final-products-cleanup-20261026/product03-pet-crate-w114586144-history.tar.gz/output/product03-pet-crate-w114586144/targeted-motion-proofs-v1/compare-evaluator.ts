/** Numerical comparison of captured metadata with the exact frozen evaluator.
 * This helper does not render frames or modify any application source. */
import * as T from 'three';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createRuntime} from '../../../src/products/product03-pet-crate-w114586144/s04-integration-v2/runtime';
import {hardware} from '../../../src/products/product03-pet-crate-w114586144/s04-integration-v2/timeline';
const root=new URL('./',import.meta.url),load=(n:string)=>JSON.parse(readFileSync(new URL(n,root),'utf8')),save=(n:string,v:unknown)=>writeFileSync(new URL(n,root),JSON.stringify(v,null,2));
const config=load('BASELINE-AND-CAPTURE-IDENTITY.json'),job=load('CAPTURE-JOB.json'),r=createRuntime();
if(job.status!=='ALL_FRAMES_VALIDATED')throw Error('Capture incomplete');
const near=(a:number[],b:number[])=>a.length===b.length&&a.every((v,i)=>Math.abs(v-b[i])<1e-8),equal=(a:unknown,b:unknown)=>JSON.stringify(a)===JSON.stringify(b),hash=(v:unknown)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const report:unknown[]=[],keyframes:unknown[]=[],bk=['hardware-K-1','hardware-K-2',...Array.from({length:4},(_,i)=>`hardware-B-${i+1}`)];let allMatch=true,retained=true,feetFollow=true,firstDoorRetained=true,noDoorSwing=true;const fixed=new Map<string,number[]>();
for(const p of config.proofs){
 let count=0;const mismatches:unknown[]=[];
 for(let chunk=1;chunk<=p.chunks.length;chunk++){
  const record=job.chunks[`${p.id}-C${chunk}`],rows=load(record.directory+'/selected-diagnostic-manifest.json');
  for(const row of rows){
   const c=r.camera(row.time),s=r.evaluate(row.time),same=near(c.position.toArray(),row.camera.position)&&near(c.quaternion.toArray(),row.camera.quaternion)&&equal(s.visible,row.state.visible)&&equal(s.hardwareSeated,row.state.hardwareSeated)&&equal(s.installed,row.state.installed)&&equal(s.prepared,row.state.prepared)&&s.stage===row.state.stage&&s.step===row.state.step;
   if(!same){allMatch=false;mismatches.push({time:row.time,name:row.name});}
   for(const id of bk){const o=r.r.registry.require(id);retained&&=o.visible&&s.hardwareSeated.includes(id);}
   for(let i=1;i<=5;i++){const id=`hardware-A-${i}`,o=r.r.registry.require(id),h=hardware.find(h=>h.id===id)!;if(row.time<h.end)continue;const rel=o.position.clone().sub(r.r.registry.require(h.host).position).toArray();if(fixed.has(id))feetFollow&&=near(rel,fixed.get(id)!);else fixed.set(id,rel);}
   if(p.id==='P3'&&row.time>=218.75)firstDoorRetained&&=r.r.registry.require('part-7-1').visible&&['hardware-E-1','hardware-E-2','hardware-E-3','hardware-E-4'].every(id=>s.hardwareSeated.includes(id));
   for(const code of ['7','8']){const pivot=r.r.root.children.find(o=>o.name===`presentation-door-pivot-${code}`)!;noDoorSwing&&=Math.abs(pivot.rotation.y)<1e-12;}
   if(count%24===0||count===p.frames-1)keyframes.push({proof:p.id,index:count,time:row.time,step:s.step,stage:s.stage,rigQuaternion:r.rig.quaternion.toArray(),prepared:s.prepared,initialSeats:s.hardwareSeated.length,door7Visible:r.r.registry.require('part-7-1').visible,door8Visible:r.r.registry.require('part-8-1').visible,BKRetained:retained,relativeFeet:Object.fromEntries(fixed),stateHash:hash(r.digest())});
   count++;
  }
 }
 if(count!==p.frames)throw Error('Wrong count');report.push({proof:p.id,framesCompared:count,match:mismatches.length===0,mismatches});
}
const seen=new Map<string,string>();let deterministic=true;
for(const p of config.proofs)for(const t of [p.start,p.end-1/24,p.start+1,p.start+2,p.start,p.end-1/24]){r.camera(t);r.evaluate(t);const k=`${p.id}-${t}`,h=hash(r.digest());if(seen.has(k))deterministic&&=seen.get(k)===h;seen.set(k,h);}
save('EVALUATOR-FRAME-COMPARISON.json',{allMatch,framesCompared:1416,report,retainedBK:retained,feetFollowHost:feetFollow,firstDoorRetainedDuringSecond:firstDoorRetained,noAddedDoorSwing:noDoorSwing,deterministic,criteria:'Numerical pose/camera equality1e-8, not physical tolerance. Captured metadata compared with existing frozenV2 at same absolute time; source hashes independently unchanged. Not visual or physical certification.'});save('CAPTURED-STATE-TRACE.json',keyframes);
console.log(JSON.stringify({allMatch,retained,feetFollow,firstDoorRetained,noDoorSwing,deterministic}));
