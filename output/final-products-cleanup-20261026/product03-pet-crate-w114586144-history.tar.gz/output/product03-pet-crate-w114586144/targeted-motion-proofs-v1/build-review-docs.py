from pathlib import Path
import json
P=Path(__file__).resolve().parent
(P/'VISUAL-FINDINGS.md').write_text('''# Actual as-is V2 motion capture — observations for Director review

Review: **PRODUCT03-TARGETED-MOTION-PROOFS-V1-20261023**. No correction was made. Technical capture/media QA passes; instructional and creative acceptance are **not claimed**. Findings below combine inspection of the 95 selected original PNGs/contact sheets with recorded per-frame evaluator metadata. The actual continuous MP4s are supplied for the Director's temporal assessment; a contact sheet alone is not proof of perceived motion quality. No fresh physical collision/access audit was performed.

Frame numbers below are zero-based within each proof. Global time = window start + frame/24. Every referenced PNG is byte-identical to the native renderer output. Adjacent frames at capture chunk seams are included, independently of any camera cuts.

## P1 — 108–124s, 384 frames

- **Preparation is present but visually small.** The opening wide view shows the upper wood module, separated side frames and a prepared rail. A4/A5 are difficult to distinguish individually at this scale (f0/108s, f12/108.5s, f38/109.583333s). This limits teaching clarity; it does not establish that a prepared object is missing.
- **The whole presentation rig turns.** f96/112s, f113/112.708333s and f130/113.416667s show the wood module and separated prepared frames undergoing the existing 180° presentation rotation. This is an unsupported illustrative reorientation, not a demonstrated safe lifting/support procedure. The next placement starts at113.5s, only0.1s after the planned turn ends.
- **Frame approach/contact precedes the sampled D operations.** f132/113.5s → f180/115.5s → f228/117.5s show the two side frames reaching the existing module. The scene then cuts from wide to a close-up between f237/117.875s and f238/117.916667s. The close-up abruptly changes subject scale; no interpolation/cut was added by capture.
- **D30 is easier to read than the compressed repeats.** Tool L and the exterior head are visible around f262/118.916667s and f286/119.916667s; the tool is withdrawing by f296/120.333333s. D31 starts immediately at f297/120.375s, followed by the cut to D32 between f326/121.583333s and f327/121.625s. The original planned tool-free hold for repeated D operations is0.037091s, less than one24fps frame. Whether the pace/cuts are understandable requires playback review.
- **Window boundary qualification:** P1 includes D30–D32 and only part of D33; D33 ends124.081818s, outside this window. It does **not** verify all ten S08 D screws. Its last frame is123.958333s; an in-progress tool is intentional at this evidence-window end, not an export truncation defect.
- **Retention:** all six K/B registry actors remain visible/enabled and seated in every captured state. Their image visibility varies with wood/mesh occlusion and macro framing. A feet retain their local offset relative to their host after each completed foot operation. This is transform continuity, not measured mating or retention certification.

## P2 — 185–209s, 576 frames

- **The clip starts in an existing C11 operation**, then returns to a wide view for the last rail6 at185.5s. The final rail and C12 are represented before S14. The cut back to wide at188.25s is preserved (f78/f79); it is not a chunk seam.
- **Late rail5/A5 staging is visible.** f102/189.25s, f138/190.75s, f156/191.5s and f174/192.25s show the current approach around the installed side posts and into the front-carrier position. This is a fast, multi-part silhouette; whether the path appears to pass through another member must be assessed in the actual MP4. A projected overlap alone is insufficient to declare a new solid penetration. No safe human installation path or support is established.
- **C13–C18 are all represented**, after rail5 contact, in the current illustrative allocation. The supplemental screw/tool sheet includes each planned engagement and post-withdrawal sample. C13's target/tool are difficult to see behind the front rail in f210/193.75s; later C operations show L and exterior heads more clearly (e.g. C14 f264/196s, C15 f298/197.416667s). This is a visible occlusion/readability concern, not an unperformed operation inferred from absence in the image. Exact C13/C14 source end ownership remains OPEN.
- **The feet show separated stem/disc silhouettes near the inverted post ends.** For example f183/192.625s and f318/198.25s preserve the current appearance. Their host-relative offsets are stable; the images do not establish a seated thread, hidden receiver, intended spacer or physical support. No gap was silently closed.
- **Turn and unfastened floor placement are clear in the sampled sequence.** f432/203s → f456/204s → f480/205s show the return upright. Floor14 follows at205.15–207.15s; f484/205.166667s, f507/206.125s and f532/207.166667s show its approach and final position. No new floor screw/tool was added. The post-turn hold is only0.15s in the unchanged schedule.

## P3 — 209–228s, 456 frames

- **Door7 approaches before E1–E4; door8 approaches before E5–E8.** f6/209.25s → f54/211.25s, then f234/218.75s → f282/220.75s show the two door translations. The first door remains visibly present in the wide view during second-door placement and is retained in every captured evaluator state from218.75s onward.
- **The first essential E operations have readable leaf/head/tool close-ups.** E1 f88/212.666667s and E5 f316/222.166667s show M approaching the leaf-side exterior head. Supplementary originals cover E1–E8 at planned tool engagement and withdrawal. These are existing qualitative exterior illustrations, not proof of hidden thread engagement or factory hinge retention.
- **Cuts jump between wide, lower hinge and upper hinge views.** The first wide-to-macro cut is f62/211.583333s → f63/211.625s; the equivalent second-door cut is f290/221.083333s → f291/221.125s. Later repeats have very brief tool-free holds (0.0399s, below one24fps frame). Inspect the MP4 for perceived popping and loss of orientation; capture does not soften or retime them.
- **Occlusion is not a state reset.** The first door is outside some right-side macro frames, but remains installed. Mesh/frame members and the existing diagnostic HUD overlap some details. The HUD, generic illustrative warnings and original stage labels were intentionally preserved.
- **No door swing or later steps were added.** Both presentation pivot angles remain0 for all captured frames. P3 ends at227.958333s with eight E initial seats and both doors retained; it does not execute S17–S19, demonstrate load/hinge limits or grant functional opening approval.

## Evidence integrity and unresolved questions

All1416 original camera/state samples match independently evaluated frozen V2 at the same absolute timestamps. All six chunks completed on their first attempt. The three joins are P1 f191→192 (115.958333→116s), P2 f287→288 (196.958333→197s), and P3 f227→228 (218.458333→218.5s). Each has exactly one frame interval; no dropped/repeated index or creative deduplication. Equal-looking images during an existing hold are legitimate.

No new **confirmed physical** defect is asserted solely from these sampled projections. Visible hard cuts, small preparation details, target occlusion and short holds are direct review concerns. The continuous videos must determine whether any action is too fast, misleading or visibly intersects an unrelated solid. Technical PASS is not a visual PASS and does not dismiss existing historical raw collision FAILs.

Director questions: Which portions are sufficiently clear to keep? Does any actual motion establish a new visible P0 defect? Are timing/camera corrections needed in a separately human-authorized milestone? Do not treat the answers as authority to edit in this capture-only task.

**STOP — AWAIT DIRECTOR VISUAL REVIEW. No fixes or next milestone executed.**
''')
(P/'SOURCE-AND-ASSUMPTION-REGISTER.md').write_text('''# Source and assumption register — unchanged V2 capture

## Baseline and capture provenance

- Human authorization: PRODUCT03-TARGETED-MOTION-PROOFS-V1, bounded offline as-is diagnostic capture. Current baseline: accepted S04 Integration V2,278-second absolute evaluator. Its98-file freeze manifest SHA256 is `44dac15be4a8aae49504c6a62a94bd2d385d80d8943b49afab766da15c331f70`.
- Frozen implementation: `src/products/product03-pet-crate-w114586144/s04-integration-v2/{runtime,timeline,preview}.ts`, with its unchanged inherited V1/accepted S04 models. Exact118 product/engine/renderer fingerprints are in BASELINE-AND-CAPTURE-IDENTITY.json. All remain unchanged.
- Existing local renderer: `scripts/render-mechanism-diagnostics.ts`, SHA256 `8f02345232ad4e3287d9c808736f7e074751eb4dca978ffbc0ed3ee506fe8313`. No new exporter, application build, renderer design, geometry, animation or camera was introduced.
- The output-only `capture-entry.ts` imports the frozen preview and replaces only the contents of its original checkpoint list with the requested global timestamps. It does not replace render(), alter the scene or construct a new camera. Every filename includes `-frame-` and does not begin `K-`, so the original render function uses its unchanged `camera(time,false)` motion-camera selector. Studio, lights, materials and diagnostic HUD remain exactly as implemented.
- Six sequential fresh offline capture jobs:192+192,288+288,228+228 frames. Request blocking/DNS/background-network restrictions were enabled; all six offline logs record zero attempted external requests. No browser session is used for rendering. Only the explicitly permitted existing Assemble conversation is used for the final report/file handoff.
- Timestamp convention: index i uses global `start+i/24`, with end exclusive. Last timestamps: P1 123.95833333333333; P2 208.95833333333334; P3 227.95833333333334. This is the exact discrete schedule for16/24/19 seconds at24fps, not an omitted final frame.
- Continuous native PNG sequences were hardlinked from validated chunks and encoded once per proof to H.264/yuv420p MP4. No MP4 chunk splicing, rate adjustment, image interpolation, duplicate removal, crop, upscale or audio.95 selected native PNGs are byte-identical copies; contact sheets alone are downscaled labeled summaries. All1416 original PNG hashes are retained locally and listed in FRAME-SHA256-MANIFEST.json.
- EVALUATOR-FRAME-COMPARISON.json verifies all1416 actual camera/state records against the unchanged evaluator; numeric1e-8 comparison is a software equality criterion, not an OEM tolerance. Repeated/backward seek, K/B retention, feet host offsets, first-door retention and zero door swing were checked. No new physical collision/access test was performed.

## Source authority and unchanged limitations

| Topic | Current evidence/confidence | Allowed conclusion |
|---|---|---|
| Manual | Human-provided13-page local INSTALLATION INSTRUCTION; SHA256 `70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29` | Documentary order/quantities; metadata W114586144 commercial identity remains unverified. No drawers added. No new online acquisition. |
| Panel/overall dimensions | UNMEASURED display approximations | No certified dimensions, load/fit or manufacturing tolerance. |
| S04 K/B | Accepted bounded two-bolt geometry/motion, unchanged | K22/10 UNMEASURED; B1–B4 retained, no receiving/grip/torque/tool-access certification. |
| F | Accepted NONLITERAL visual reconstruction, unchanged | No OEM axis, receiver or physical connection upgrade; current generic HUD is not a new F-specific disclosure correction. |
| C in S13/S14 | C4 and C6 quantities documented; selected end allocation remains OPEN | P2 displays the existing C12–C18 illustration. Watching the animation cannot resolve source ambiguity. |
| Screw/hinge receivers | Exterior qualitative targets; hidden bores/threads/retention unresolved | Full existing shafts and exterior contacts remain. No added receiver, invented thread, shaft clipping or certified engagement. |
| Tools and tightening | L/M illustrative axial choreography; align-before-final-tightening instruction retained | Initial seats are not verified final torque or certified hand/tool access. No new tool geometry. |
| Reorientation/support | Existing rigid presentation inversion/return | Not a demonstrated physical lifting fixture, safe handling method or supported installation trajectory. |
| Late carrier5 | Existing outside-post/inward staging | Real installation/access is unverified. An attractive view cannot certify access. |
| Doors | Existing limited static hinge hypothesis, E8 illustration; pivots0 | No new hinge animation, opening limit, functional fit or retention claim. |
| I/J | OPEN | S17/S18 remain POSE-ONLY and are outside the proof windows. |
| S19 | Pads/door HOLD | No added pad fastening, latch release or functional door opening. |
| Raw collision history | Historical FAIL and all candidates preserved | No exclusions/threshold changes or physical PASS. Software/state continuity is distinct from physical acceptance. |
| Production scope | Only three diagnostic windows59s | No full278s render, final Long/Short, audio, mastering, research or source correction. Human remains sole final acceptance authority. |

PROTECTED-ASSET-VERIFICATION.json checks938 Product01/JULIETTE protected paths,99 historical delivered files,118 source/engine/renderer files and eight frozen manifest sets, including the prior read-only audit. All match; no earlier evidence was overwritten.

**The Director may review these videos internally; this package does not authorize corrections or production. STOP after the actual review decision.**
''')
qa=json.loads((P/'PROOF-CAPTURE-QA.json').read_text())
lines=['# PRODUCT03 — Targeted Motion Proofs V1','', '**Review ID: PRODUCT03-TARGETED-MOTION-PROOFS-V1-20261023**','', 'Human-authorized as-is diagnostic capture is complete. Please watch the three actual MP4s and issue a formal visual review. This is evidence collection only: no source, geometry, camera, timing, animation, lighting or diagnostic-HUD changes. The accepted278s V2 baseline is preserved.','', '| Proof | Global window (end exclusive) | Duration | Frames | Format |','|---|---|---:|---:|---|']
for m in qa['media']:lines.append(f"| {m['file']} | {m['globalStart']}–{m['globalEndExclusive']}s | {m['duration']}s | {m['frames']} |1280×720 H.264,24fps,no audio|")
lines+=['','All1416 camera/state records match frozen V2; PNG CRC/full image decode and MP4 full decode/PTS/frame counts/faststart pass. Six chunks completed first attempt; three seams have continuous index/time.95 original review PNGs plus four contact sheets, capture metadata, offline logs and SHA256 payload manifest accompany the actual videos.','', '## Review priorities','', '- P1: A4/A5 preparation legibility, whole-rig180° staging, two side-frame approaches, first D/L operations and preserved K/B. D33 finishes outside the window: do not infer all ten D were reviewed.','- P2: last6/C12, late5+A5, C13–C18 readability/occlusion, return upright and floor14 without a fastener. C13/C14 source allocation remains OPEN.','- P3: door7/E1–4 then door8/E5–8, M/leaf/head readability and retained first door. No door swing or S17–S19 added.','', 'Observed concerns are unchanged abrupt wide/macro cuts, short repeated-operation holds, small preparation details and some occluded tool targets. See VISUAL-FINDINGS.md for exact original-frame references and the distinction between observation and unverified physical interpretation. No new physical penetration or whole-product visual PASS is claimed from samples.','', '## Explicit decision requested','', 'Please report PASS / REVISION_REQUIRED / FAIL for the targeted visual review, identify scenes usable unchanged and any demonstrated P0 versus readability/timing concerns. If a separate correction milestone is recommended, propose it only; do not interpret this capture-only task as editing authority. **Stop after review.** No full278s/final Long/Short/audio/mastering or new geometry/research.','', 'K22/10 UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN; S17/S18 POSE-ONLY; S19 pads/door HOLD. Historical raw collision FAIL and physical receiving/access limitations are preserved. Product01 and JULIETTE are unchanged. Human alone grants final film acceptance.','', '## Video SHA256','']
for m in qa['media']:lines.append(f"- `{m['sha256']}` — {m['file']}")
lines+=['','Actual evidence ZIP is separately attached with its payload SHA256 manifest. Technical capture PASS is not a creative, physical or final-film acceptance.']
(P/'DIRECTOR-REVIEW.md').write_text('\n'.join(lines)+'\n')
print('3 review documents written; no production changes')
