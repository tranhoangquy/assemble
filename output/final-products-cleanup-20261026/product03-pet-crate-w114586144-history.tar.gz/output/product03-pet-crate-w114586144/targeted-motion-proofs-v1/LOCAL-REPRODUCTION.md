# Local capture record

This milestone is complete and immutable. These are provenance commands, not permission to start a new capture or fix. Offline only; the sole external action is the human-authorized existing Assemble review handoff.

- `capture-entry.ts` imports the exact frozen V2 preview and schedules only requested timestamp checkpoints. Every frame name selects its original motion camera. No render function or production module is replaced.
- `capture-bounded.py` invokes the existing diagnostic renderer in6fresh sequential jobs, with blocked network requests. The atomic CAPTURE-JOB.json records compatibility hashes, chunk status, exact frame indices and all original PNG hashes. Only complete validated chunks may be resumed; partial attempts are preserved. This run had0retries.
- `compare-evaluator.ts` compares every actual captured camera/state with frozen V2 at the same global timestamp, plus backward/repeated seeks and retained state checks. It does not generate product imagery.
- `encode-and-qa.py` encodes each continuous PNG sequence once using local ffmpeg H.264,1280×720,24fps,yuv420p,CRF20,faststart,no audio; ffprobe counts/PTS and full ffmpeg decode are checked. No timing or image edits.
- `select-operation-frames.py` copies supplemental original E/C frames; no renderer call or image manipulation beyond the labeled contact-sheet thumbnails.
- `verify-preservation.py` checks118source/renderer files,938protected paths,99historical deliveries and8frozen manifest sets. Archived preflight manifests are historical snapshots, distinct from final delivered manifests; neither is changed.

All1416native PNGs and their chunk manifests remain local under `chunks/` and `frames/`. The evidenceZIP carries95selected original PNGs and the full1416-frame hash manifest, all chunk camera/state manifests/offline logs,4contact sheets,QA/source/assumption/observation reports and the3actualMP4s. It omits the redundant full1416-PNG payload; no frames were removed from the videos.

Software1e-8comparison is not an OEM fit tolerance. No hidden receiver, physical collision/access certification, torque, source-ambiguity resolution or whole-film acceptance was performed. Stop after the actual Director review decision; future corrections require separately authorized scope.
