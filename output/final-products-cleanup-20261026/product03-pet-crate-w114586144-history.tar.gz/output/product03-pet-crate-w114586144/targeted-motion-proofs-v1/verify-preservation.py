from pathlib import Path
import json,hashlib,datetime
ROOT=Path.cwd();R=ROOT/'output/product03-pet-crate-w114586144';P=Path(__file__).resolve().parent

def load(p):return json.loads(p.read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()
def resolve(s,owner):
 p=Path(s)
 if p.is_absolute():return p
 for base in [ROOT,R,owner.parent]:
  if (base/p).is_file():return base/p
 raise RuntimeError('Missing baseline path '+s)
def verify(entries,owner):
 out=[]
 for s,h in entries.items():
  p=resolve(s,owner);actual=sha(p);out.append({'path':str(p.relative_to(ROOT)),'expected':h,'actual':actual,'match':actual==h})
 return out
cfg=load(P/'BASELINE-AND-CAPTURE-IDENTITY.json');checks={}
checks['sourceAndRenderer']=verify(cfg['sourceFiles'],P/'BASELINE-AND-CAPTURE-IDENTITY.json')
base=R/'phase-a-v1/evidence/protected-baseline.json';checks['protectedProduct01Juliette']=verify(load(base),base)
delivery={}
for manifest in R.glob('*/REVIEW-DELIVERY-MANIFEST.json'):
 if P in manifest.parents:continue
 entries=load(manifest)
 for v in entries:
  p=resolve(v['path'],manifest);key=str(p)
  if key in delivery:assert delivery[key]==v['sha256']
  delivery[key]=v['sha256']
checks['historicalDeliveredFiles']=verify(delivery,R/'CURRENT-PROJECT-STATE.json')
freezeNames=['f-illustrative-proof-v1/FROZEN-LOCAL-PROOF.json','part-first-sequence-v1/FROZEN-FOCUSED-PROOF.json','timeline-integration-plan-v1/FROZEN-INTEGRATION-PLAN.json','timeline-integration-v1/FROZEN-INTEGRATION-EVIDENCE.json','s04-two-bolt-proof-v1/FROZEN-S04-PROOF.json','s04-integration-v2/FROZEN-INTEGRATION-V2.json','p0-teaching-continuity-audit-v1/FROZEN-READ-ONLY-AUDIT.json','phase-d-illustrative-v2/FROZEN-BLOCKING-SHA256.json']
freezes=[]
for n in freezeNames:
 f=R/n;rows=verify(load(f)['files'],f);checks[n]=rows;freezes.append({'manifest':n,'manifestSha256':sha(f),'checked':len(rows),'changes':sum(not v['match'] for v in rows)})
manual=R/'phase-a-v1/source/human-provided-pet-crate-manual.pdf';manualExpected='70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29';assert sha(manual)==manualExpected
failures=[v for values in checks.values() for v in values if not v['match']]
report={'status':'PASS' if not failures else 'FAIL','verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceAndRendererFiles':len(checks['sourceAndRenderer']),'sourceChanges':sum(not v['match']for v in checks['sourceAndRenderer']),'protectedPaths':len(checks['protectedProduct01Juliette']),'protectedChanges':sum(not v['match']for v in checks['protectedProduct01Juliette']),'historicalDeliveredFiles':len(checks['historicalDeliveredFiles']),'historicalManifestScope':'Authoritative top-level delivered manifests; archived preflight manifests remain historical snapshots, not current hashes', 'historicalChanges':sum(not v['match']for v in checks['historicalDeliveredFiles']),'frozenManifests':freezes,'manualSha256':sha(manual),'Product01':'UNCHANGED','JULIETTE':'UNCHANGED','historicalFAIL':'PRESERVED; no new collision exclusions, thresholds or sweeps','captureScope':'1416 new diagnostic PNG frames,3 short native silent MP4s only; no product/evaluator/camera/timing/geometry/animation changes','failures':failures}
(P/'evidence/PRESERVATION-PATH-HASHES.json').write_text(json.dumps(checks,indent=2)+'\n');(P/'PROTECTED-ASSET-VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert not failures
