from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,shutil
P=Path(__file__).resolve().parent;A=P.parent/'p0-teaching-continuity-audit-v1'
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
config=load(P/'BASELINE-AND-CAPTURE-IDENTITY.json');frames=load(P/'FRAME-SHA256-MANIFEST.json');selected=load(P/'SELECTED-ORIGINALS-MANIFEST.json');existing={r['selectedPath'] for r in selected};detail=[]
for h in load(A/'OPERATION-EVIDENCE.json')['hardware']:
 if h['id'].startswith('hardware-E-'):proof='P3'
 elif h['id'].startswith('hardware-C-') and h['step']==14:proof='P2'
 else:continue
 p=next(p for p in config['proofs'] if p['id']==proof);rows=[r for r in frames if r['proof']==proof]
 for phase,t in [('toolEngaged',h['phaseTimes']['toolEngaged']),('toolWithdrawn',h['end']-1/48)]:
  i=round((t-p['start'])*24);assert 0<=i<p['frames'];r=rows[i];dest=P/'selected-originals'/proof/f'{proof}-frame-{i:06d}.png';rel=str(dest.relative_to(P))
  if rel not in existing:
   shutil.copyfile(P/r['continuousPath'],dest);assert sha(dest)==r['sha256'];selected.append(dict(**r,selectedPath=rel,handling='Exact original native PNG byte copy; supplementary operation evidence'));existing.add(rel)
  detail.append(dict(proof=proof,operation=h['id'],phase=phase,time=r['time'],frameIndex=i,original=rel,actualMetadata='Captured at exact original frame; phase label comes from frozen operation plan, not proof of physical engagement'))
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',16);big=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',26)
im=Image.new('RGB',(1920,70+((len(detail)+3)//4)*304),'#f3efe6');d=ImageDraw.Draw(im);d.text((16,18),'C13–18 / E1–8 — EXISTING ORIGINAL FRAMES / NO CHANGES',font=big,fill='#292c2f')
for j,r in enumerate(detail):
 x=j%4*480;y=70+j//4*304
 with Image.open(P/r['original'])as native:im.paste(native.convert('RGB').resize((480,270)),(x,y))
 d.text((x+5,y+272),f"{r['operation']} / {r['phase']} / {r['time']:.6f}s",font=font,fill='#805534')
im.save(P/'CONTACT-SHEET-SCREW-TOOL.jpg',quality=94)
selected.sort(key=lambda r:(r['proof'],r['index']));(P/'SELECTED-ORIGINALS-MANIFEST.json').write_text(json.dumps(selected,indent=2)+'\n');(P/'OPERATION-FRAME-EVIDENCE.json').write_text(json.dumps(detail,indent=2)+'\n')
qa=load(P/'PROOF-CAPTURE-QA.json');qa['selectedOriginals']=len(selected);qa['supplementaryOperationFrames']=len(detail);(P/'PROOF-CAPTURE-QA.json').write_text(json.dumps(qa,indent=2)+'\n');print({'totalSelected':len(selected),'operationSamples':len(detail)})
