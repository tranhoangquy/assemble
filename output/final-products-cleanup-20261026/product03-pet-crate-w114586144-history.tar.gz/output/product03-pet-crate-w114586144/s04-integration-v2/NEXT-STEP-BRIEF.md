# PRODUCT03 — NEXT STEP: ACCEPTED S04 → VERSIONED INTEGRATION V2

Review ID: PRODUCT03-S04-INTEGRATION-NEXT-SCOPE-20261023

The human now explicitly asks Codex to talk with Assemble and do the next step: “trao đổi với wweb làm bước tiếp theo đi”. This is new human authority after the focused S04 STOP, interpreted narrowly as integrating the accepted S04 correction and running related QA. It does not authorize complete-film production, Long/Short or audio.

## Concrete next implementation

1. Create a versioned integration V2; preserve frozen264s integration and accepted28s proof/source/QA unchanged.
2. Reuse EXACT accepted K22/10 unmeasured display geometry and B4 poses/tool motions. No new geometry or hidden receiving details. Carry both B per K into all later forward assembly states, seeking and endpoints.
3. Replace S04's14s budget with the approved28s operation rather than accelerating it. Keep S01–S03 unchanged; shift S05–S19 and later presentation segments +14s. Proposed total278s =253s source operations +15s presentation alignment +10s target showcase allowance. This is an evaluator/planning duration, not authorization to render278s.
4. Keep19 source steps,20 numbered parts,100 accessories+3 tools and all prior dependencies. Proposed final accounting84 initial seats +12 pose-only exterior stack units +4 held N pads =100. No claim all100 are fastened or physically validated.
5. Revalidate arbitrary/backward seek, retained world/local transforms including module reorientation and prepared feet; prove S03→S04→S05 continuity. Check K/B pairs, tool paths, all19 endpoints and later interference against actual installed scene. Preserve raw failures and classify AABB candidates with actual-geometry refinement where necessary; no dropped pairs/threshold changes.
6. Review outputs: timing diff, source/assumption ledger,19 endpoint PNGs, a short actual integrated S04/adjacent-boundary motion proof, retention/seek/path regression, protected/source hash verification and byte-preserving ZIP.

## Permanent limitations

K22/10 is unmeasured, illustrative; no OEM dimensions/bores/threads/torque/tool-hand certification. C13/C14 and I/J remain OPEN. S17/S18 pose-only and S19 pads/door-access HOLD stay intact. Source alignment-before-final-tightening distinction stays. No new physical evidence is claimed. Product01/JULIETTE/historical evidence unchanged. Offline work; Internet exception is this Assemble conversation only. No external references, paid service, publication or new product.

## Requested decision

Please provide one explicit implementable next directive within this human-authorized bounded integration scope. Accept/revise278s and identify exact required QA/review boundary. Existing accepted S04 video/58-payload evidence is already in this conversation; do not reopen or request duplicate uploads unless needed. No new full-film/audio/mastering permission is requested. Human alone accepts eventual films.
