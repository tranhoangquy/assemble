# V2 assumptions and retained holds

No new geometry. All123 registered geometry trees match the accepted S04 proof, including20 components,100 accessory units and3 tools. Source PDFp5 depicts K2/B4. K22-unit legs/10-unit offset remain UNMEASURED display approximations accepted only for exterior visual storytelling. B/tool geometry and visible K holes unchanged. Original accepted S04 numerical contacts/head separation propagate by exact geometry and local-pose identity; see accepted S04-PAIR-AND-MOTION-QA.json. No manufactured dimensions/tolerances claimed.

41–69s reuses the accepted14s left and14s right absolute pose evaluator inside the new scene. First bolt stays installed during the second, and the completed left connection remains installed in the right shot and all subsequent steps. No prior MP4 replay or edited screenshot substitution.

The final model contains84 initial-seat accessory units,12 pose-only and4 held N pads. Initial-seat is an illustrative display state, not certified tightening. S17/S18 remain pose-only; S19 pads/door release remain HOLD. C13/C14 exact allocation and I/J source contradiction remain OPEN. F remains a disclosed nonliteral visual reconstruction. Hidden receivers, actual final retention, torque, hand/tool support/access, load, fit, hinge limits and dimensions are not certified. Common-rig inversion is presentation staging, not a demonstrated supported physical lift.

Raw233 conservative AABB candidates retained:154 receiving stock,77 concave-drive bounds and2 B/B unrelated bounds. The two B pairs are separated using actual world-transformed mesh-vertex bounds. All154/77 receiving/grip questions remain unresolved physically. No body versus retained unrelated geometry/tool versus unrelated structure candidates in this sampled audit; this is not proof of real hand accessibility or an unsampled continuous path.

Time is canonicalized to nanoseconds locally at S04 to avoid IEEE subtraction selecting the wrong exact visibility branch at57.7/62.7s. This is animation timestamp precision, not a collision/fit threshold change. First validation and typecheck failures remain in evidence; the first summary incorrectly allowed its PASS label with exactS04=false. Final summary gates every software assertion. Final focused tests3/3 and scoped TypeScript pass. No frozen sources modified.

Only32 documentary review stills and36s motion proof are rendered from V2. The278s full film, Long/Short/audio/mastering remain NOT RUN/NOT AUTHORIZED. Product01/JULIETTE preserved. Human is sole final approver.
