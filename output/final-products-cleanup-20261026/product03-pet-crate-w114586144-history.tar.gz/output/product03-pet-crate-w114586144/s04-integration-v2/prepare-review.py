from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import hashlib,json,subprocess,zipfile,shutil,collections
P=Path(__file__).resolve().parent;B=P.parent;ROOT=P.parents[2]
def load(p):return json.loads(Path(p).read_text())
def save(n,v):(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True).stdout
qa=load(P/'INTEGRATION-QA.json');assert all(qa['software'].values()) and qa['propagation'] and not qa['unresolved']
assert qa['inventory']==dict(numberedInstances=20,hardwareUnits=100,uniqueHardware=100,tools=3)
assert qa['graph']==dict(steps=19,cycles=[],missing=[])
assert '3 passed' in (P/'evidence/tests.log').read_text() and not (P/'evidence/typecheck-final.log').read_text().strip()
assert all(r['matchesAcceptedS04'] for r in load(P/'EXACT-ACCEPTED-GEOMETRY.json'))
boundary=load(P/'BOUNDARY-CONTINUITY.json');boundaryChecks=[]
for t in [41,55,69]:
 rows=[r for r in boundary if r['boundary']==t];common=set.intersection(*(set(r['poses']) for r in rows));delta=max(abs(a-b) for id in common for a,b in zip(rows[0]['poses'][id],rows[-1]['poses'][id]));assert delta<1e-8
 boundaryChecks.append(dict(boundary=t,retainedActors=len(common),maximumLocalPoseDelta=delta,status='PASS'))
save('BOUNDARY-QA.json',boundaryChecks)
proposal=load(P/'PROPOSED-TIMING.json');save('TIMING-DIFF.json',dict(status='IMPLEMENTED — actual278s evaluator; full film NOT RENDERED',previousDuration=264,actualDuration=278,S04=dict(start=41,end=69,duration=28),S05Start=69,alignment=dict(start=247,end=262),S19=dict(start=262,end=268),showcase=dict(start=268,end=278),steps=proposal['steps']))
media=[];frames=[]
for id,start in [('A',39),('B',51),('C',63)]:
 d=P/f'frames-{id}';m=load(d/'selected-diagnostic-manifest.json');expected=[f'{id}-frame-{i:06d}.png' for i in range(288)];assert [r['name'] for r in m]==expected
 assert not load(d/'offline-network.json')['attemptedRequests']
 for i,r in enumerate(m):
  assert abs(r['time']-(start+i/24))<1e-9 and not r['networkRequests'] and r['state']['clippingPlanes']==0
  f=d/r['name']
  with Image.open(f) as im:im.load();assert im.size==(1280,720)
  frames.append(dict(path=str(f.relative_to(P)),time=r['time'],sha256=sha(f),bytes=f.stat().st_size))
 f=P/f'PRODUCT03-S04-integration-v2-{id}-720p.mp4'
 run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-framerate','24','-i',str(d/(id+'-frame-%06d.png')),'-frames:v','288','-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-an','-movflags','+faststart',str(f)]);media.append(f)
concat=P/'evidence/concat.txt';concat.write_text(''.join("file '../"+f.name+"'\n" for f in media))
combined=P/'PRODUCT03-S04-integration-v2-proof-720p.mp4';run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-f','concat','-safe','0','-i',str(concat),'-c','copy','-movflags','+faststart',str(combined)]);media.append(combined)
mediaQA=[]
for f,seconds in zip(media,[12,12,12,36]):
 info=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(f)]));assert len(info['streams'])==1;s=info['streams'][0]
 assert s['width']==1280 and s['height']==720 and s['r_frame_rate']=='24/1' and int(s['nb_read_frames'])==seconds*24 and abs(float(info['format']['duration'])-seconds)<.001
 run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(f),'-f','null','-']);mediaQA.append(dict(path=f.name,sha256=sha(f),bytes=f.stat().st_size,seconds=seconds,frames=seconds*24,audioStreams=0,fullDecode='PASS'))
save('MEDIA-QA.json',dict(media=mediaQA,pngFrames=864,allPNGDecode='PASS',globalWindow=dict(start=39,last=75-1/24),method='3 fresh offline jobs,contiguous absolute frame times39+i/24; no old video reuse. Stream-copy concatenation of the3 newly encoded chunks.',camera='Accepted fixed S04 left/right cameras; explicit forward cuts at41/55/69. Existing V1 cuts outside S04 retained, not a continuous-camera claim.',offline='0 attempted requests in all final jobs; no audio/full-film render'))
save('VIDEO-FRAME-MANIFEST.json',frames)
cp=P/'checkpoints';cm=load(cp/'selected-diagnostic-manifest.json');assert len(cm)==32 and not load(cp/'offline-network.json')['attemptedRequests']
for r in cm:
 assert not r['networkRequests']
 with Image.open(cp/r['name']) as im:im.load();assert im.size==(1280,720)
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',20);big=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',28)
def sheet(name,title,items,cols=4):
 rows=(len(items)+cols-1)//cols;im=Image.new('RGB',(480*cols,70+rows*302),'#f3efe6');d=ImageDraw.Draw(im);d.text((18,15),title,font=big,fill='#292c2f')
 for i,(path,label) in enumerate(items):
  x=i%cols*480;y=70+i//cols*302;im.paste(Image.open(path).convert('RGB').resize((480,270)),(x,y));d.text((x+8,y+273),label,font=font,fill='#805534')
 im.save(P/name,quality=93)
sheet('01-19-STEP-ENDPOINTS.jpg','V2 / 19 SOURCE STEPS / RETAINED ASSEMBLY STATE',[(cp/f'S{i:02d}-endpoint.png',f'S{i:02d} endpoint')for i in range(1,20)])
sheet('02-BOUNDARY-AND-RETENTION.jpg','V2 / BOUNDARIES AND LATE K+B RETENTION',[(cp/r['name'],f"t={r['time']:.4f}s")for r in cm if r['name'].startswith(('boundary','K-'))])
sheet('03-ACTUAL-INTEGRATED-MOTION.jpg','ACTUAL V2 / PANELS FIRST, THEN K AND BOTH B / t39-75s',[(P/f'frames-{id}/{id}-frame-{i:06d}.png',label)for id,i,label in [('A',0,'39s / retained S03'),('A',101,'43.208s / K contact'),('A',192,'47s / first B'),('B',0,'51s / second B'),('B',96,'55s / mirrored K'),('B',240,'61s / third B'),('C',96,'67s / fourth B'),('C',264,'74s / retained into S05')]])
protected=load(B/'phase-a-v1/evidence/protected-baseline.json');assert all((ROOT/f).exists() and sha(ROOT/f)==h for f,h in protected.items());historical=[]
for manifest in B.glob('*/REVIEW-DELIVERY-MANIFEST.json'):
 if manifest.parent==P:continue
 for r in load(manifest):
  f=Path(r['path']);f=f if f.is_absolute() else manifest.parent/f;assert sha(f)==r['sha256'];historical.append(dict(revision=manifest.parent.name,file=f.name,match=True))
frozen=[]
for rev,name in [('f-illustrative-proof-v1','FROZEN-LOCAL-PROOF.json'),('part-first-sequence-v1','FROZEN-FOCUSED-PROOF.json'),('timeline-integration-plan-v1','FROZEN-INTEGRATION-PLAN.json'),('timeline-integration-v1','FROZEN-INTEGRATION-EVIDENCE.json'),('s04-two-bolt-proof-v1','FROZEN-S04-PROOF.json')]:
 for f,h in load(B/rev/name)['files'].items():assert sha(f)==h
 frozen.append(rev)
for rev in ['rail-fit-correction-v1','p0-connections-v1','f-illustrative-proof-v1','part-first-sequence-v1','timeline-integration-v1','s04-two-bolt-proof-v1']:
 for f,h in load(B/rev/'SOURCE-FINGERPRINTS.json')['files'].items():assert sha(ROOT/f)==h
save('PROTECTED-ASSET-VERIFICATION.json',dict(status='PASS',paths=len(protected),changes=0,historicalDeliveryFiles=len(historical),frozenProofs=frozen,Product01='UNCHANGED',JULIETTE='UNCHANGED',previousEvidence='UNCHANGED'))
src=ROOT/'src/products/product03-pet-crate-w114586144/s04-integration-v2';source=B/'phase-a-v1/source/human-provided-pet-crate-manual.pdf';assert sha(source)=='70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29'
save('SOURCE-FINGERPRINTS.json',dict(files={str(f.relative_to(ROOT)):sha(f)for f in src.glob('*.ts')},sourcePDF=sha(source),genericRenderer=sha(ROOT/'scripts/render-mechanism-diagnostics.ts')))
assert sha(ROOT/'scripts/render-mechanism-diagnostics.ts')==load(B/'s04-two-bolt-proof-v1/SOURCE-FINGERPRINTS.json')['genericRenderer']
for old,new in [('S04-PAIR-AND-MOTION-QA.json','ACCEPTED-S04-CONTACT-QA.json'),('director-review/DECISION.json','ACCEPTED-S04-DECISION.json')]:shutil.copyfile(B/'s04-two-bolt-proof-v1'/old,P/'evidence'/new)
shutil.copyfile(B/'phase-a-v1/evidence/pages/page-05.png',P/'evidence/OEM-PDF-P05.png')
raw=load(P/'RAW-INSTALLATION-AND-TOOL-CANDIDATES.json');refine=load(P/'PRECISE-B-PAIR-REFINEMENT.json');classified=[]
for r in raw:
 if r['kind']=='UNRELATED_FASTENER_CANDIDATE':
  match=next(f for f in refine if (f['event'],f['a'],f['b'])==(r['event'],r['a'],r['b']));assert match['preciseOverlapSamples']==0;label='Conservative AABB false positive; actual transformed mesh-vertex bounds separated by>=1.200034 model units in101 samples. Raw pair retained.'
 elif r['kind']=='RECEIVING_STOCK_RAW_CANDIDATE':label='RAW receiving stock/visible K opening bounds; buried wood bores/threads/retention not established. NOT physical collision PASS.'
 else:label='RAW concave visible-drive bounding candidate; not proof of a solid collision or certified grip/access. Prior accepted illustrative tool and geometry unchanged.'
 classified.append(dict(**r,classification=label))
save('RAW-CANDIDATE-CLASSIFICATION.json',dict(counts=dict(collections.Counter(r['kind']for r in raw)),pairs=classified,scope='41 samples per body/hardware event; not continuous collision proof or human accessibility certification. No original pair excluded.'))
(P/'ASSUMPTIONS-AND-OPEN-ISSUES.md').write_text('''# V2 assumptions and retained holds

No new geometry. All123 registered geometry trees match the accepted S04 proof, including20 components,100 accessory units and3 tools. Source PDFp5 depicts K2/B4. K22-unit legs/10-unit offset remain UNMEASURED display approximations accepted only for exterior visual storytelling. B/tool geometry and visible K holes unchanged. Original accepted S04 numerical contacts/head separation propagate by exact geometry and local-pose identity; see accepted S04-PAIR-AND-MOTION-QA.json. No manufactured dimensions/tolerances claimed.

41–69s reuses the accepted14s left and14s right absolute pose evaluator inside the new scene. First bolt stays installed during the second, and the completed left connection remains installed in the right shot and all subsequent steps. No prior MP4 replay or edited screenshot substitution.

The final model contains84 initial-seat accessory units,12 pose-only and4 held N pads. Initial-seat is an illustrative display state, not certified tightening. S17/S18 remain pose-only; S19 pads/door release remain HOLD. C13/C14 exact allocation and I/J source contradiction remain OPEN. F remains a disclosed nonliteral visual reconstruction. Hidden receivers, actual final retention, torque, hand/tool support/access, load, fit, hinge limits and dimensions are not certified. Common-rig inversion is presentation staging, not a demonstrated supported physical lift.

Raw233 conservative AABB candidates retained:154 receiving stock,77 concave-drive bounds and2 B/B unrelated bounds. The two B pairs are separated using actual world-transformed mesh-vertex bounds. All154/77 receiving/grip questions remain unresolved physically. No body versus retained unrelated geometry/tool versus unrelated structure candidates in this sampled audit; this is not proof of real hand accessibility or an unsampled continuous path.

Time is canonicalized to nanoseconds locally at S04 to avoid IEEE subtraction selecting the wrong exact visibility branch at57.7/62.7s. This is animation timestamp precision, not a collision/fit threshold change. First validation and typecheck failures remain in evidence; the first summary incorrectly allowed its PASS label with exactS04=false. Final summary gates every software assertion. Final focused tests3/3 and scoped TypeScript pass. No frozen sources modified.

Only32 documentary review stills and36s motion proof are rendered from V2. The278s full film, Long/Short/audio/mastering remain NOT RUN/NOT AUTHORIZED. Product01/JULIETTE preserved. Human is sole final approver.
''')
(P/'DIRECTOR-REVIEW.md').write_text(f'''# PRODUCT03 — S04 INTEGRATION V2 / ACTUAL RESULTS

Review ID: PRODUCT03-S04-INTEGRATION-V2-20261023

Executed your actual bounded directive PRODUCT03-S04-INTEGRATION-NEXT-SCOPE-20261023 after the human requested direct collaboration and the next step. Please review this completed integration milestone, not a new full-film production request.

## Implemented evaluator

Versioned278s absolute-time evaluator; frozen264s V1 and accepted28s S04 proof untouched. S01–S03 unchanged; S04 now41–69s, S05 begins69s; all downstream operations+14s; alignment247–262, S19 262–268, showcase268–278. Same19 source steps/dependencies,20 components,100 accessories+3 tools. No new geometry/exporter/engine changes.

Final scene uses exact accepted S04 geometry; absolute actor poses for unchanged operations come from frozen V1 at mapped time. K/B and S04 L use the accepted proof evaluator. All123 geometry trees match accepted proof hashes. This is actual3D state integration, not a video splice. Four B and both K stay installed through all later endpoints, common-rig inversion, camera evaluation and backwards seeks.

## Actual review artifacts

New36s native1280×720/24fps silent MP4 covers global39→75s continuously in time: prior S03, leftK/B1/B2, rightK/B3/B4, transition into S05.864 newly rendered PNG frames from three bounded fresh offline jobs; stream-copy concatenation only between these new chunks. No old MP4 reuse. Fixed accepted S04 cameras; explicit forward cuts at41/55/69s and existing V1 cuts outside S04. Full decode/frame/duration/audio checks PASS.32 new PNGs include19 step endpoints,9 exact boundary checkpoints and4 retained-interface macros at132/278s. Contact sheets and every original image included.

## QA and limitations

2781 forward samples, arbitrary/backward seek, repeated camera calls, finite transforms, installed visibility/local pose retention, hardware after component contact, exact S04 equivalence, unchanged S01–S03/later nonBK poses PASS. Boundary common installed transforms remain unchanged; relative K/B matrices propagate through every S05–S19 endpoint and inversion. Final20 structural,84 initial seats,12 pose-only,4 held pads; these are NOT certified physical fastening counts.3 focused tests and scoped TypeScript PASS.

233 raw AABB candidates preserved/classified:154 receiving stock,77 concave-drive bounds and2 B/B conservative candidates. Actual transformed mesh-vertex bounds separate both B pairs by at least1.200034 model units in101 samples per pair; no pair removed or tolerance weakened. No sampled unrelated body/tool path defect remains in this scope. Hidden receiving/grip/hand access remain physically unverified; raw historical FAIL and source holds are not rewritten. Exact original K wood contact/head seat geometry is retained, not manufactured fit certification.

First exact visibility comparison detected IEEE subtraction branch differences at57.7/62.7s. Local timestamp canonicalization fixes them. The first summary label also incorrectly ignored that boolean; final label gates all assertions. Initial evidence retained. A TypeScript implicit-array-type error was repaired without changing geometry or thresholds.

Protected verification:938 paths unchanged;{len(historical)} historical delivered files and frozen source/evidence hashes match. Product01/JULIETTE unchanged. ManualSHA256 {sha(source)}. No Internet except this existing Assemble handoff.

## Requested decision / boundary

Decide PASS / REVISION_REQUIRED / FAIL for bounded S04 V2 integration using ACTUAL MP4, all19 endpoints, boundary/late macros, numerical QA and byte-verified ZIP. Explicitly retain K22/10 UNMEASURED, C13/C14 and I/J OPEN, F nonliteral, S17/S18 pose-only and S19/door HOLD. No physical-confidence upgrade or full film acceptance. If adequate, close this integration milestone and state the next permissible review scope; work beyond your bounded directive requires human authorization. No complete278s render, finalLong/Short, audio, new geometry/research/purchases/publishing performed.

MP4SHA256: {sha(combined)}
''')
files=['DIRECTOR-REVIEW.md','ASSUMPTIONS-AND-OPEN-ISSUES.md','HUMAN-AUTHORIZATION.json','AUTHORITY.json','TIMING-DIFF.json','INTEGRATION-QA.json','19-STEP-ENDPOINTS.json','EXACT-ACCEPTED-GEOMETRY.json','RETENTION-AND-SEEK.json','S04-INTEGRATION-EQUIVALENCE.json','BOUNDARY-CONTINUITY.json','BOUNDARY-QA.json','BK-PROPAGATION.json','RAW-INSTALLATION-AND-TOOL-CANDIDATES.json','RAW-CANDIDATE-CLASSIFICATION.json','PRECISE-B-PAIR-REFINEMENT.json','MEDIA-QA.json','VIDEO-FRAME-MANIFEST.json','PROTECTED-ASSET-VERIFICATION.json','SOURCE-FINGERPRINTS.json','01-19-STEP-ENDPOINTS.jpg','02-BOUNDARY-AND-RETENTION.jpg','03-ACTUAL-INTEGRATED-MOTION.jpg','director-review/ACTUAL-IMPLEMENTATION-DIRECTIVE.txt','director-review/NEXT-SCOPE-DECISION.json','evidence/tests.log','evidence/typecheck.log','evidence/typecheck-final.log','evidence/validate.log','evidence/validate-final.log','evidence/ACCEPTED-S04-CONTACT-QA.json','evidence/ACCEPTED-S04-DECISION.json','evidence/OEM-PDF-P05.png',*[str(f.relative_to(P))for f in (P/'evidence/initial-validation').glob('*')],*[str(f.relative_to(P))for f in cp.glob('*')],*[f.name for f in media]]
for id in ['A','B','C']:files += [f'frames-{id}/{n}'for n in ['selected-diagnostic-manifest.json','offline-network.json']]
for f in src.glob('*.ts'):
 target=P/'evidence/frozen-source'/f.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(f,target)
# No browser history/whole-conversation snapshots or unrelated local data in ZIP.
manifest=[dict(path=n,bytes=(P/n).stat().st_size,sha256=sha(P/n))for n in files];save('PAYLOAD-SHA256.json',manifest)
z=P/'PRODUCT03-S04-integration-v2-review.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED)as a:
 for n in files+['PAYLOAD-SHA256.json']:a.write(P/n,n)
with zipfile.ZipFile(z)as a:assert all(hashlib.sha256(a.read(r['path'])).hexdigest()==r['sha256']for r in manifest)
delivery=[z,combined,P/'DIRECTOR-REVIEW.md',P/'01-19-STEP-ENDPOINTS.jpg',P/'02-BOUNDARY-AND-RETENTION.jpg',P/'03-ACTUAL-INTEGRATED-MOTION.jpg'];save('REVIEW-DELIVERY-MANIFEST.json',[dict(path=str(f),bytes=f.stat().st_size,sha256=sha(f))for f in delivery]);(P/'DELIVERY-SHA256.txt').write_text(''.join(f'{sha(f)}  {f.name}\n'for f in delivery))
print(json.dumps(dict(payloads=len(manifest),zip=dict(name=z.name,bytes=z.stat().st_size,sha256=sha(z)),video=mediaQA[-1],status='ACTUAL RESULTS — DIRECTOR REVIEW REQUIRED'),indent=2))
