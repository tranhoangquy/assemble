#19-step operation / exception map

Proposal only. These are editorial timing budgets and source associations, NOT manufacturer assembly times, dimensions or access certification.

|Step / PDF|Hardware|Sequence class / tool|Required ordering and preserved uncertainty|
|---|---|---|---|
|S01 /p4|{'D': 4}|PART_FIRST / L|12 established; align both10 ends before final snug/seating. D4 on retained module; no independent final torque claim.|
|S02 /p4|{'D': 4}|PART_FIRST / L|Keep source metal-nut/hole orientation on11. Both dividers retained. D4 counts; hidden receiver omitted.|
|S03 /p5|{'D': 4}|PART_FIRST / L|9 contacts retained10/11 before D4. No downward panel movement through staged screws.|
|S04 /p5|{'B': 4, 'K': 2}|PART_FIRST / L|Seat K bracket on both existing mating faces BEFORE B; two B per K. ToolL mapping qualitative; no receiver invention.|
|S05 /p6|{'D': 7}|PART_FIRST / L|13 contacts9/10 before D7. Retain reviewed unmeasured backing assignments; first new face is taught, repetitions use labeled forward cuts.|
|S06 /p6|{'D': 10}|PART_FIRST / L|15 contacts all retained divider/side edges before D10. No early shaft/body crossing. Repeats may shorten only after the first readable action.|
|S07 /p7|{'A': 5}|PREPARED_FEET / HAND/NO INVENTED TOOL|A5 belongs to prepared1/2/5. These are prepared workpieces, not cabinet-installed sides/rail yet. PreserveA-to-host transforms; do not add a screwdriver operation.|
|S08 /p7|{'D': 10}|PART_FIRST / L|Move each prepared side with its feet as one assembly. Both square-pipe orientations fromp7. Contact first; then D10. Retain four reviewed provisionalZ±190 positions.|
|S09 /p8|{'C': 4}|PART_FIRST / L|Rear4 between sides, retained contact before C4. Full shafts; exterior symbolic engagement, no invented internal threaded receiver.|
|S10 /p8|{'F': 4}|RETAIN_EXISTING_CONTACT_THEN_FASTENER / M|Rear4 is ALREADY installed byS9; do not re-install or reset it. Verify retained lap, then F4 and M. Source Lock firmly follows alignment; nonliteral rear4/13 relationship remains labeled.|
|S11 /p9|{'C': 4}|PART_FIRST / L|Front3 approaches correct tab/handle orientation and contacts sides before C4. Keep existing source component identity; no fabricated subparts.|
|S12 /p9|{'F': 4}|RETAIN_EXISTING_CONTACT_THEN_FASTENER / M|Front3 is ALREADY installed byS11. Verify retained lap beforeF4/M; do not repeat panel motion. Front15 EDGE entry stays explicitly nonliteral. Source firm instruction retained.|
|S13 /p10|{'C': 4}|PART_FIRST / L|Four6 rails placed chronologically, one main motion at a time. C4 exact end allocation remains a hypothesis. No newly invented receiver/capture or confidence upgrade.|
|S14 /p10|{'C': 6}|PART_FIRST / L|Move prepared5 WITH A5 fromS7, retaining rails6 and all prior parts. C6 source count; proposed four opposite6 ends + two5 ends stays INFERRED.|
|S15 /p11|{}|SUPPORT_ONLY / NONE|Show declared rigid reorientation/support staging, retain subassemblies; lower14 onto four6 supports. No screw, key, adhesive or added fixing.|
|S16 /p11|{'E': 8}|PART_FIRST / M|Support/place each door7/8, align existing hinge leaves beforeE8/M. Factory hinge parts remain within doors; no new loose studs/pins or engineering opening limit.|
|S17 /p12|{'G': 2, 'H': 2, 'J': 2}|H_TAB_G_STACK / O — GRIP UNVERIFIED|Specific source stack H→J→G on existing depicted stud. No new screw/panel operation. O possible forG only after visible grip/access check; do not fabricate stud geometry.|
|S18 /p12|{'G': 2, 'H': 2, 'I': 2}|H_TAB_G_STACK_WITH_IJ_CONFLICT / O — GRIP UNVERIFIED|Provisional H→I→G preserves insetI vs summaryJ conflict. Do not silently choose a manufacturer correction or animate an unsupported retention mechanism.|
|S19 /p13|{'N': 4}|PAD_ACCESSORY / NONE|N4 accessory pads after final alignment check; source release-liner/optional-EVA ambiguity retained. No driver or extra screw. Existing illustrative door pose is not a certified motion limit.|

Do not apply a screw recipe to A feet, H/tab/G stacks, support-only14 orN pads. F steps begin from retained structural contact established inS9/S11; no re-installation. Prepared components1/2/5 carry feetA to later attachmentS8/S14.

PDFp2 says to align pieces before FINAL tightening. The accepted focused clips show symbolic seating, not torque. Integration distinguishes initial seating from final recheck. F10/F12 specific firm instructions remain at the source steps after their relevant interface is aligned. A15s alignment/recheck interlude is proposed afterS18 and beforeS19; it is presentation staging, not a new OEM step or specified torque sequence.

Tool assignment: source inventoryp1 listsL M4, screwdriverM and wrenchO. D hex/L and E/F cross/M follow visible drives; no new powered tool. B/C hex/L compatibility must be checked in the modeled visible recess. O/G grip and access have NOT been validated; this cannot become a fake nut-tightening animation.
