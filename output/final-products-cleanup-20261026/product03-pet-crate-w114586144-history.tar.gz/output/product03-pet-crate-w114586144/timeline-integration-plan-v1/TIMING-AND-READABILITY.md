# Timing and readability assessment

Original runtime:148s source assembly +10s showcase =158s. Proposed timings are review budgets; no runtime source has changed.

|Step|Old s|Compact s|Expanded s|
|---|---:|---:|---:|
|S01|14|18|18|
|S02|8|13|17|
|S03|7|10|10|
|S04|9|14|17|
|S05|7|16|20|
|S06|8|19|24|
|S07|8|8|10|
|S08|10|20|26|
|S09|7|12|15|
|S10|6|10|12|
|S11|6|10|15|
|S12|5|9|12|
|S13|7|16|21|
|S14|7|14|18|
|S15|8|6|6|
|S16|12|19|23|
|S17|7|10|12|
|S18|6|9|12|
|S19|6|6|6|
|19 source steps total|148|239|294|
|Alignment/recheck interlude|0|15|20|
|Existing showcase allowance|10|10|10|
|Total|158|264|324|

Recommend264s as a FAST SEMANTIC blocking proposal, not a final-film duration commitment. First new connection/tool gets a clear teach view; already understood repetitions may use1–1.5s labeled forward cuts, preserving the approved order and cumulative installed state. Each important new approach/contact still has a readable hold. The324s alternative retains longer first-occurrence explanations at more interfaces. Do not stretch every action globally.

158s is not recommended under the human’s corrected teaching requirement. S6 originally allocates8s to positioning15 plusD10: even with zero panel/contact time that is0.8s per screw/tool cycle. S8 allocates10s to two prepared frames plusD10. S16 allocates12s to both doors plusE8. The accepted10s focused examples teach one important connection, not all7/10/8 fasteners. Keeping158s would need aggressive omitted/overlapping tool phases or unexplained state jumps. These are editorial feasibility findings, not a claim that every possible montage must exceed158s.

Compact budgets assume transparent repeat compression after the first clear example. Do not imply every repeated tool cycle is displayed at real time. If checkpoints show1–1.5s repeats unreadable, extend that local operation rather than speeding parts/cameras or hiding a connection. No chosen duration may erase source operations or increase source confidence.

Compact source stepS18 ends at233s. Proposed15s final alignment/recheck is233–248s; S19 is248–254s; showcase254–264s. OEM graph remains19 steps. Expanded proposal:294s source operations +20s recheck +10s showcase =324s.
