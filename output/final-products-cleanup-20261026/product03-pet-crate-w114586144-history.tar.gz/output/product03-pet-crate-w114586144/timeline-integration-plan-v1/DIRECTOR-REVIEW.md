# PRODUCT03 — COMPLETE TIMELINE INTEGRATION PLAN V1

Review ID: PRODUCT03-COMPLETE-TIMELINE-INTEGRATION-PLAN-V1-20261022

Prepared in direct response to your actual PART-FIRST focusedPASS. The accepted46s proof, source deltas and original before/after evidence are frozen. This is the requested19-step integration PROPOSAL ONLY: no new runtime, geometry, animation, render or audio.

## Recommendation and decision requested

Recommend a264s compact illustrative PhaseD blocking budget:239s source operations +15s final alignment/recheck +10s existing showcase allowance.324s is the fuller-teaching alternative. The158s original has148s for assembly; S6’sD10/panel in8s, S8’sD10/twoframes in10s andS16’sE8/twodoors in12s cannot retain the new clear teaching phases at our proposed budgets. Do not keep158s through early hardware, state resets, omitted source operations or global acceleration. Durations here are editorial proposals, not final-film commitments or OEM assembly times.

Please choose/revise the timing and issue an explicit scoped decision on the operation/exception plan and proposed NEXT integration scope: isolated offline timeline implementation, complete technical/retention QA and targeted endpoints/short critical proofs only. No automatic whole-film render, finalLong/Short or audio is requested or started. A plan approval must not be labeled full-timeline validation or final acceptance.

## Integration truth

All19 OEM dependencies,20 component instances,100 hardware/accessory units+3 tools remain. The map covers every step and every source hardware quantity.12 steps need part/bracket-contact before current fasteners. S10/S12 retain structural contact fromS9/S11 and addF/M without re-installing a panel. S7 feetA remain on prepared1/2/5; S15 adds no fastener/tool; S17/S18 retainH→tab→G stacks; S19 pads add no screw. O/G tool grip is unverified and cannot be invented.

Sourcep2 says wait for aligned pieces before FINAL tightening. EarlierB/C/D/E actions therefore represent initial seating/alignment, not torque. SourceF10/F12 firm instructions remain after relevant interface alignment. Proposed15s alignment/recheck afterS18, beforeS19 opening/pad action, is presentation choreography, not OEMstep20 or a new fastening method. Original source instruction image is included. I/J andC13/C14 uncertainty stays open.

The new evaluator must start from the latest accepted snapshot and preserve actual part/hardware states at every forward cut and arbitrary seek. HistoricalPhaseD.evaluate cannot be reused unchanged because it restores obsolete transforms and clipped shafts. No engine/exporter/schema rewrite. ToolL/hexB-C-D andM/crossE-F remain qualitative source-compatible assignments, not certified tool access. FourS8 position changes andD/L visible-drive changes stay explicitly illustrative. No hidden bore/thread/receiver is added.

PLAN-QA verifies graph/count coverage and timing sums only. Complete installation paths, collisions, tool/future access, whole-product visualQA and full-film rendering remain NOT RUN.938 protected paths, frozen46s proof and accepted source fingerprints match. Human alone accepts the eventual two completed films. No general Internet, purchase, manufacturer contact, Product01/JULIETTE edit or final production is authorized by this plan.
