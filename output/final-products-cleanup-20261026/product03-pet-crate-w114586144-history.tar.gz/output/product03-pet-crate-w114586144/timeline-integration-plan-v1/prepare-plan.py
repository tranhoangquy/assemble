from pathlib import Path
from collections import Counter
import json,hashlib,csv,zipfile,shutil
P=Path(__file__).resolve().parent;B=P.parent;ROOT=P.parents[2]
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,v):(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
facts=load(P/'evidence/ORIGINAL-TIMELINE-FACTS.json')
compact=[18,13,10,14,16,19,8,20,12,10,10,9,16,14,6,19,10,9,6]
expanded=[18,17,10,17,20,24,10,26,15,12,15,12,21,18,6,23,12,12,6]
tools=['L','L','L','L','L','L','HAND/NO INVENTED TOOL','L','L','M','L','M','L','L','NONE','M','O — GRIP UNVERIFIED','O — GRIP UNVERIFIED','NONE']
classes=['PART_FIRST']*19
for n in [10,12]:classes[n-1]='RETAIN_EXISTING_CONTACT_THEN_FASTENER'
for n,c in [(7,'PREPARED_FEET'),(15,'SUPPORT_ONLY'),(17,'H_TAB_G_STACK'),(18,'H_TAB_G_STACK_WITH_IJ_CONFLICT'),(19,'PAD_ACCESSORY')]:classes[n-1]=c
notes={
1:'12 established; align both10 ends before final snug/seating. D4 on retained module; no independent final torque claim.',
2:'Keep source metal-nut/hole orientation on11. Both dividers retained. D4 counts; hidden receiver omitted.',
3:'9 contacts retained10/11 before D4. No downward panel movement through staged screws.',
4:'Seat K bracket on both existing mating faces BEFORE B; two B per K. ToolL mapping qualitative; no receiver invention.',
5:'13 contacts9/10 before D7. Retain reviewed unmeasured backing assignments; first new face is taught, repetitions use labeled forward cuts.',
6:'15 contacts all retained divider/side edges before D10. No early shaft/body crossing. Repeats may shorten only after the first readable action.',
7:'A5 belongs to prepared1/2/5. These are prepared workpieces, not cabinet-installed sides/rail yet. PreserveA-to-host transforms; do not add a screwdriver operation.',
8:'Move each prepared side with its feet as one assembly. Both square-pipe orientations fromp7. Contact first; then D10. Retain four reviewed provisionalZ±190 positions.',
9:'Rear4 between sides, retained contact before C4. Full shafts; exterior symbolic engagement, no invented internal threaded receiver.',
10:'Rear4 is ALREADY installed byS9; do not re-install or reset it. Verify retained lap, then F4 and M. Source Lock firmly follows alignment; nonliteral rear4/13 relationship remains labeled.',
11:'Front3 approaches correct tab/handle orientation and contacts sides before C4. Keep existing source component identity; no fabricated subparts.',
12:'Front3 is ALREADY installed byS11. Verify retained lap beforeF4/M; do not repeat panel motion. Front15 EDGE entry stays explicitly nonliteral. Source firm instruction retained.',
13:'Four6 rails placed chronologically, one main motion at a time. C4 exact end allocation remains a hypothesis. No newly invented receiver/capture or confidence upgrade.',
14:'Move prepared5 WITH A5 fromS7, retaining rails6 and all prior parts. C6 source count; proposed four opposite6 ends + two5 ends stays INFERRED.',
15:'Show declared rigid reorientation/support staging, retain subassemblies; lower14 onto four6 supports. No screw, key, adhesive or added fixing.',
16:'Support/place each door7/8, align existing hinge leaves beforeE8/M. Factory hinge parts remain within doors; no new loose studs/pins or engineering opening limit.',
17:'Specific source stack H→J→G on existing depicted stud. No new screw/panel operation. O possible forG only after visible grip/access check; do not fabricate stud geometry.',
18:'Provisional H→I→G preserves insetI vs summaryJ conflict. Do not silently choose a manufacturer correction or animate an unsupported retention mechanism.',
19:'N4 accessory pads after final alignment check; source release-liner/optional-EVA ambiguity retained. No driver or extra screw. Existing illustrative door pose is not a certified motion limit.',
}
def timeline(durations,interlude):
 clock=0;rows=[]
 for i,(source,old,duration,tool,kind) in enumerate(zip(facts['sourceSteps'],facts['steps'],durations,tools,classes)):
  if i==18:clock+=interlude
  rows.append(dict(id=source['id'],pdf=source['pdf_page'],dependsOn=source['sequence_prerequisites'],sourceHardware=source['hardware'],oldDuration=old['duration'],proposedDuration=duration,start=clock,end=clock+duration,operationClass=kind,tool=tool,operation=source['action'],plan=notes[i+1],physicalConfidence='NOT_UPGRADED'))
  clock+=duration
 return dict(steps=rows,sourceStepSeconds=sum(durations),alignmentInterludeSeconds=interlude,assemblyElapsed=clock,showcaseSeconds=10,total=clock+10)
fast=timeline(compact,15);slow=timeline(expanded,20)
assert fast['total']==264 and slow['total']==324
counts=Counter()
for s in facts['sourceSteps']:counts.update(s['hardware'])
assert sum(counts.values())==100 and sum(counts[c] for c in 'BCDEF')==77
assert len(facts['steps'])==19 and len([p for p in facts['placements'] if p['id'].startswith('part-')])==20
for n,row in enumerate(fast['steps']):assert row['dependsOn']==([] if n==0 else [fast['steps'][n-1]['id']])
save('INTEGRATION-PLAN.json',dict(review='PRODUCT03-COMPLETE-TIMELINE-INTEGRATION-PLAN-V1-20261022',status='PROPOSAL ONLY — NO IMPLEMENTATION OR FULL RENDER',recommended=fast,expandedAlternative=slow,original=dict(assemblySeconds=148,showcaseSeconds=10,total=158),sourceInventory=dict(counts),threadedFasteners=77,numberedInstances=20,sourceSteps=19,
 finalAlignment=dict(after='S18',before='S19',type='PRESENTATION INTERLUDE, NOT OEM STEP20',source='PDFp2 global align-before-final-tightening; S10/S12 explicit firm instructions retained',mode='EarlierB/C/D/E shown as initial seating/alignment, not manufactured torque. SourceF firm after aligned source interface. Final alignment/recheck with transparent condensed repeated operations; no part/screw reinsertion.',confidence='Presentation choreography inferred; no certified support/tool access'),
 representation='Human-authorized illustrativePhaseD only; C13/C14,IJ,raw receiving overlaps/access remain unresolved',requestedNextScope='Review plan and choose timing. Propose bounded offline full-timeline code integration+determinism/retention/targeted checkpoints ONLY after explicit scoped decision; no complete-film render, finalLong/Short or audio.',
 forbidden=['Rewrite old source/render','Omit hardware to meet158s','Change OEM step count/order','Hide prior installed parts','Use clipping on shafts','Invent hidden bores/threads/receivers','Upgrade physical confidence','General Internet','Payments','Product01/JULIETTE edits']))
with (P/'STEP-TIMING-COMPARISON.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['Step','PDF','OldSeconds','CompactSeconds','ExpandedSeconds','CompactStart','CompactEnd','Class','Tool','SourceHardware'])
 for a,b in zip(fast['steps'],slow['steps']):w.writerow([a['id'],a['pdf'],a['oldDuration'],a['proposedDuration'],b['proposedDuration'],a['start'],a['end'],a['operationClass'],a['tool'],json.dumps(a['sourceHardware'])])
lines=['#19-step operation / exception map','','Proposal only. These are editorial timing budgets and source associations, NOT manufacturer assembly times, dimensions or access certification.','',
'|Step / PDF|Hardware|Sequence class / tool|Required ordering and preserved uncertainty|','|---|---|---|---|']
for r in fast['steps']:lines.append('|'+r['id']+' /p'+str(r['pdf'])+'|'+str(r['sourceHardware'])+'|'+r['operationClass']+' / '+r['tool']+'|'+r['plan']+'|')
lines+=['','Do not apply a screw recipe to A feet, H/tab/G stacks, support-only14 orN pads. F steps begin from retained structural contact established inS9/S11; no re-installation. Prepared components1/2/5 carry feetA to later attachmentS8/S14.','',
'PDFp2 says to align pieces before FINAL tightening. The accepted focused clips show symbolic seating, not torque. Integration distinguishes initial seating from final recheck. F10/F12 specific firm instructions remain at the source steps after their relevant interface is aligned. A15s alignment/recheck interlude is proposed afterS18 and beforeS19; it is presentation staging, not a new OEM step or specified torque sequence.','',
'Tool assignment: source inventoryp1 listsL M4, screwdriverM and wrenchO. D hex/L and E/F cross/M follow visible drives; no new powered tool. B/C hex/L compatibility must be checked in the modeled visible recess. O/G grip and access have NOT been validated; this cannot become a fake nut-tightening animation.']
(P/'OPERATION-AND-EXCEPTION-MAP.md').write_text('\n'.join(lines)+'\n')
lines=['# Timing and readability assessment','','Original runtime:148s source assembly +10s showcase =158s. Proposed timings are review budgets; no runtime source has changed.','',
'|Step|Old s|Compact s|Expanded s|','|---|---:|---:|---:|']
for a,b in zip(fast['steps'],slow['steps']):lines.append(f"|{a['id']}|{a['oldDuration']}|{a['proposedDuration']}|{b['proposedDuration']}|")
lines += [f"|19 source steps total|148|{fast['sourceStepSeconds']}|{slow['sourceStepSeconds']}|",'|Alignment/recheck interlude|0|15|20|','|Existing showcase allowance|10|10|10|','|Total|158|264|324|','',
'Recommend264s as a FAST SEMANTIC blocking proposal, not a final-film duration commitment. First new connection/tool gets a clear teach view; already understood repetitions may use1–1.5s labeled forward cuts, preserving the approved order and cumulative installed state. Each important new approach/contact still has a readable hold. The324s alternative retains longer first-occurrence explanations at more interfaces. Do not stretch every action globally.','',
'158s is not recommended under the human’s corrected teaching requirement. S6 originally allocates8s to positioning15 plusD10: even with zero panel/contact time that is0.8s per screw/tool cycle. S8 allocates10s to two prepared frames plusD10. S16 allocates12s to both doors plusE8. The accepted10s focused examples teach one important connection, not all7/10/8 fasteners. Keeping158s would need aggressive omitted/overlapping tool phases or unexplained state jumps. These are editorial feasibility findings, not a claim that every possible montage must exceed158s.','',
'Compact budgets assume transparent repeat compression after the first clear example. Do not imply every repeated tool cycle is displayed at real time. If checkpoints show1–1.5s repeats unreadable, extend that local operation rather than speeding parts/cameras or hiding a connection. No chosen duration may erase source operations or increase source confidence.','',
'Compact source stepS18 ends at233s. Proposed15s final alignment/recheck is233–248s; S19 is248–254s; showcase254–264s. OEM graph remains19 steps. Expanded proposal:294s source operations +20s recheck +10s showcase =324s.']
(P/'TIMING-AND-READABILITY.md').write_text('\n'.join(lines)+'\n')
(P/'IMPLEMENTATION-AND-QA-SCOPE.md').write_text('''# Proposed bounded integration scope

No implementation or full render is performed by this plan. Requested next scope, if explicitly approved: one isolated PhaseD integration revision, reusing existing architecture, latest accepted visible geometry and source graph. No finalLong/Short/audio.

1. Build a new absolute-time evaluator from the accepted part-first model snapshot. Do not call historical PhaseD.evaluate every frame: it restores obsolete geometry, early hardware timing and shaft clipping. Keep old files immutable. Reuse ObjectRegistry snapshots/AssemblyGraph, existing typed actions, camera and diagnostic/export infrastructure; no new engine/schema/exporter.
2. Preserve all19 OEM dependencies,20 numbered instances and100 hardware/accessory units+3 tools.1/2/5 are prepared assemblies atS7, not already attached to the cabinet. Their feet follow parent transforms intoS8/S14. Reuse existing visible tool identities; tools may enter/leave the frame, installed parts/hardware may not disappear.
3. Absolute action times enforce PART_CONTACT <= CURRENT_FASTENER_VISIBLE <= TIP_ALIGNED <= TOOL_ENGAGED <= SEATING <= TOOL_WITHDRAWN. Current fasteners start outside the frame AFTER part contact. Earlier installed fasteners remain visible. Source-specific exceptions are explicit in the operation map. No screw/part is reinserted during final recheck.
4. Initial seating stays distinct from source final-tightening instructions. Show sourceF firm seating after interface alignment; final alignment/recheck interlude introduces no extra OEM part, source step, torque, pitch or manufactured specification.
5. First teach shot: orientation/target → unobstructed contact macro → screw tip → compatible tool/drive → installed hold. Repeated cuts move forward with a clear repeat count and retained state. No camera cut conceals a collision or creates an unexplained reset. Verify framing and tool tip throughout the action.
6. Before any complete render, run complete endpoint/arbitrary/backward-seek tests; sample all structural and screw/tool paths against the actual installed state. Record raw intersections before classifying. Never remove same-host stock or collision pairs to createPASS. Separate unmodeled receiving-stock overlap from genuine unrelated collision. Check future-access/closure order and staged5 insertion specifically. Exact hand/tool access is not certified by proxy clearance.
7. Produce representative stills of all19 endpoints plus a few short NEW critical connection motion windows only if that implementation scope is approved. Preserve accepted46s andF24s proofs. Validate native frame count/dimensions, continuity, offscreen visibility transitions, full decode and no audio. Use isolated offline rendering; no authenticated session for local rendering, no general Internet.
8. Source-qualified HOLDs stay visible: C13/C14 end allocation, I/J contradiction, actual receivers, O/G grip, support/reorientation, hinge/retention details and real installation access. Do not invent a stud, hole, thread, torque or physical-fit claim. If a proposed operation cannot be drawn truthfully within the human’s illustrative authorization, stop that operation and report the exact blocker rather than fake it.
9. Submit the integration QA/checkpoints to Assemble before a whole-film render. A planPASS is not integrated-timelinePASS, full-filmPASS or human final acceptance. Full-film export needs its own applicable gates and explicit scoped review decision. FinalLong/Short/audio remains outside current production scope.
''')
protected=load(B/'phase-a-v1/evidence/protected-baseline.json');assert all(sha(ROOT/f)==h for f,h in protected.items())
proof=load(B/'part-first-sequence-v1/FROZEN-FOCUSED-PROOF.json');assert all(sha(f)==h for f,h in proof['files'].items())
fingerprints=[]
for revision in ['part-first-sequence-v1','f-illustrative-proof-v1','p0-connections-v1','rail-fit-correction-v1']:
 for f,h in load(B/revision/'SOURCE-FINGERPRINTS.json')['files'].items():assert sha(ROOT/f)==h;fingerprints.append(f)
save('PLAN-QA.json',dict(status='PASS — DOCUMENTARY PLAN CONSISTENCY ONLY',steps=19,numberedInstances=20,hardwareAccessories=100,tools=3,threadedFasteners=77,counts=dict(counts),dependencyOrderPreserved=True,compactTotal=264,expandedTotal=324,exceptionCoverage='All19 classified; foot/support/stack/pad and pre-establishedF contacts distinguished',protectedPaths=len(protected),protectedChanges=0,frozenFocusedProof='ALL HASHES MATCH',acceptedSourceChecks=len(fingerprints),newRuntimeGeometryAnimationRenderAudio='NONE',sourceUncertainties='NOT_RESOLVED; no physical-confidence upgrade'))
shutil.copyfile(B/'part-first-sequence-v1/director-review/DECISION.json',P/'FOCUSED-DIRECTOR-DECISION.json')
shutil.copyfile(B/'phase-a-v1/evidence/pages/page-02.png',P/'evidence/ORIGINAL-ALIGNMENT-INSTRUCTION.png')
(P/'DIRECTOR-REVIEW.md').write_text('''# PRODUCT03 — COMPLETE TIMELINE INTEGRATION PLAN V1

Review ID: PRODUCT03-COMPLETE-TIMELINE-INTEGRATION-PLAN-V1-20261022

Prepared in direct response to your actual PART-FIRST focusedPASS. The accepted46s proof, source deltas and original before/after evidence are frozen. This is the requested19-step integration PROPOSAL ONLY: no new runtime, geometry, animation, render or audio.

## Recommendation and decision requested

Recommend a264s compact illustrative PhaseD blocking budget:239s source operations +15s final alignment/recheck +10s existing showcase allowance.324s is the fuller-teaching alternative. The158s original has148s for assembly; S6’sD10/panel in8s, S8’sD10/twoframes in10s andS16’sE8/twodoors in12s cannot retain the new clear teaching phases at our proposed budgets. Do not keep158s through early hardware, state resets, omitted source operations or global acceleration. Durations here are editorial proposals, not final-film commitments or OEM assembly times.

Please choose/revise the timing and issue an explicit scoped decision on the operation/exception plan and proposed NEXT integration scope: isolated offline timeline implementation, complete technical/retention QA and targeted endpoints/short critical proofs only. No automatic whole-film render, finalLong/Short or audio is requested or started. A plan approval must not be labeled full-timeline validation or final acceptance.

## Integration truth

All19 OEM dependencies,20 component instances,100 hardware/accessory units+3 tools remain. The map covers every step and every source hardware quantity.12 steps need part/bracket-contact before current fasteners. S10/S12 retain structural contact fromS9/S11 and addF/M without re-installing a panel. S7 feetA remain on prepared1/2/5; S15 adds no fastener/tool; S17/S18 retainH→tab→G stacks; S19 pads add no screw. O/G tool grip is unverified and cannot be invented.

Sourcep2 says wait for aligned pieces before FINAL tightening. EarlierB/C/D/E actions therefore represent initial seating/alignment, not torque. SourceF10/F12 firm instructions remain after relevant interface alignment. Proposed15s alignment/recheck afterS18, beforeS19 opening/pad action, is presentation choreography, not OEMstep20 or a new fastening method. Original source instruction image is included. I/J andC13/C14 uncertainty stays open.

The new evaluator must start from the latest accepted snapshot and preserve actual part/hardware states at every forward cut and arbitrary seek. HistoricalPhaseD.evaluate cannot be reused unchanged because it restores obsolete transforms and clipped shafts. No engine/exporter/schema rewrite. ToolL/hexB-C-D andM/crossE-F remain qualitative source-compatible assignments, not certified tool access. FourS8 position changes andD/L visible-drive changes stay explicitly illustrative. No hidden bore/thread/receiver is added.

PLAN-QA verifies graph/count coverage and timing sums only. Complete installation paths, collisions, tool/future access, whole-product visualQA and full-film rendering remain NOT RUN.938 protected paths, frozen46s proof and accepted source fingerprints match. Human alone accepts the eventual two completed films. No general Internet, purchase, manufacturer contact, Product01/JULIETTE edit or final production is authorized by this plan.
''')
files=['DIRECTOR-REVIEW.md','INTEGRATION-PLAN.json','OPERATION-AND-EXCEPTION-MAP.md','TIMING-AND-READABILITY.md','IMPLEMENTATION-AND-QA-SCOPE.md','STEP-TIMING-COMPARISON.csv','PLAN-QA.json','AUTHORITY.json','FOCUSED-DIRECTOR-DECISION.json','evidence/ORIGINAL-TIMELINE-FACTS.json','evidence/ORIGINAL-ALIGNMENT-INSTRUCTION.png']
manifest=[dict(path=n,bytes=(P/n).stat().st_size,sha256=sha(P/n)) for n in files];save('PAYLOAD-SHA256.json',manifest)
z=P/'PRODUCT03-timeline-integration-plan-v1-review.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as a:
 for n in files+['PAYLOAD-SHA256.json']:a.write(P/n,n)
with zipfile.ZipFile(z) as a:assert all(hashlib.sha256(a.read(r['path'])).hexdigest()==r['sha256'] for r in manifest)
delivery=[z,P/'DIRECTOR-REVIEW.md'];save('REVIEW-DELIVERY-MANIFEST.json',[dict(path=str(f.resolve()),bytes=f.stat().st_size,sha256=sha(f)) for f in delivery]);(P/'DELIVERY-SHA256.txt').write_text(''.join(f'{sha(f)}  {f.name}\n' for f in delivery))
print(json.dumps(dict(zip=z.name,sha256=sha(z),payloads=len(manifest),compact=fast['total'],expanded=slow['total'],status='PLAN REVIEW REQUIRED'),indent=2))
