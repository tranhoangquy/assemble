/** Read-only numerical analysis: no renderer, scene export, source mutation or new product geometry. */
import * as T from 'three';
import {writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createRuntime} from '../../../src/products/product03-pet-crate-w114586144/s04-integration-v2/runtime';
import {steps,bodies,hardware,placements} from '../../../src/products/product03-pet-crate-w114586144/s04-integration-v2/timeline';
const save=(n:string,v:unknown)=>writeFileSync(new URL(n,import.meta.url),JSON.stringify(v,null,2));
const r=createRuntime(),subset=steps.filter(s=>s.number>=5&&s.number<=16),events=hardware.filter(h=>h.step>=5&&h.step<=16),struct=bodies.filter(b=>b.step>=5&&b.step<=16);
const hash=(v:unknown)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const pose=(o:T.Object3D)=>[...o.position.toArray(),...o.quaternion.toArray(),...o.scale.toArray()];
const norm=(id:string)=>new T.Vector3(...(placements.find(p=>p.id===id)!.outward??[0,0,1]));
const onScreen=(p:T.Vector3)=>Math.abs(p.x)<=1&&Math.abs(p.y)<=1&&p.z>=-1&&p.z<=1;
function boxProjection(o:T.Object3D,c:T.Camera){const b=new T.Box3().setFromObject(o),q:T.Vector3[]=[];for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z])q.push(new T.Vector3(x,y,z).project(c));return {outside:q.every(p=>p.x< -1)||q.every(p=>p.x>1)||q.every(p=>p.y< -1)||q.every(p=>p.y>1)||q.every(p=>p.z< -1)||q.every(p=>p.z>1),ndcMin:[Math.min(...q.map(p=>p.x)),Math.min(...q.map(p=>p.y))],ndcMax:[Math.max(...q.map(p=>p.x)),Math.max(...q.map(p=>p.y))]};}
const operations=events.map(h=>{const d=h.end-h.start,host=struct.filter(b=>b.id===h.host&&b.contact<=h.start).at(-1);return {...h,duration:d,sourcePage:steps[h.step-1].source.pdf_page,displayPlacement:placements.find(p=>p.id===h.id),hostContact:host?.contact??'retained/prepared source host',phaseTimes:h.kind==='threaded'?{appear:h.start,tipAligned:h.start+.15*d,toolAppear:h.start+.25*d,toolEngaged:h.start+.4*d,positionSeated:h.start+.8*d,rotationEnds:h.start+.87*d,toolHidden:h.start+.97*d,end:h.end}:null,phaseDurations:h.kind==='threaded'?{boltApproach:.15*d,tipHoldBeforeTool:.1*d,feedAndTurn:.4*d,toolWithdrawal:.1*d,toolFreeHold:.03*d}:null};});
save('OPERATION-EVIDENCE.json',{steps:subset,bodies:struct,hardware:operations,qualification:'Exact current evaluator timings/declared targets, not measured OEM geometry or physical access.'});
let finite=true,retainedVisible=true,retainedLocal=true,feetFollow=true;const failures:unknown[]=[],seen=new Map<string,number[]>(),cuts:unknown[]=[],visibilityChanges:unknown[]=[],cameraScan:unknown[]=[];
let prev:{t:number;p:T.Vector3;q:T.Quaternion;step:string;active:string|null;visible:Set<string>}|undefined;
for(let f=69*24;f<=228*24;f++){
 const t=f/24,s=r.evaluate(t),c=r.camera(t),visible=new Set(s.visible);
 for(const id of [...s.installed,...s.hardwareSeated]){const o=r.r.registry.require(id),p=pose(o);if(id.startsWith('hardware-A-')){const h=hardware.find(h=>h.id===id)!;p.splice(0,3,...o.position.clone().sub(r.r.registry.require(h.host).position).toArray());}
  if(seen.has(id)&&p.some((v,i)=>Math.abs(v-seen.get(id)![i])>1e-8)){retainedLocal=false;failures.push({kind:'RETAINED_LOCAL_POSE',t,id});}seen.set(id,p);
 }
 for(const id of seen.keys())if(!visible.has(id)){retainedVisible=false;failures.push({kind:'RETAINED_VISIBILITY',t,id});}
 r.rig.traverse(o=>{finite&&=pose(o).every(Number.isFinite);});
 if(prev){const translation=c.position.distanceTo(prev.p),angle=c.quaternion.angleTo(prev.q)*180/Math.PI;if(translation>40||angle>10)cuts.push({t,step:s.step,translation,angleDegrees:angle,fromHardware:prev.active,toHardware:s.currentHardware?.id??null,kind:'CAMERA_REVIEW_FLAG_NOT_AUTOMATIC_DEFECT'});
  const appeared=s.visible.filter(id=>!prev!.visible.has(id)),hidden=[...prev.visible].filter(id=>!visible.has(id));if(appeared.length||hidden.length)visibilityChanges.push({t,step:s.step,appeared,hidden});
 }
 if(f%24===0)cameraScan.push({t,step:s.step,stage:s.stage,position:c.position.toArray(),quaternion:c.quaternion.toArray(),rigQuaternion:r.rig.quaternion.toArray(),visibleActors:s.visible.length,initialSeats:s.hardwareSeated.length,prepared:s.prepared});
 prev={t,p:c.position.clone(),q:c.quaternion.clone(),step:s.step,active:s.currentHardware?.id??null,visible};
}
const seek:Record<number,string>={};let deterministic=true;for(const t of [69,228,85,112,113.4,132,173,203,205,209,219,69,228,132,205,112,173]){r.evaluate(t);r.camera(t);const h=hash(r.digest());if(seek[t]&&seek[t]!==h)deterministic=false;seek[t]=h;}
save('MOTION-SCAN-SUMMARY.json',{method:'Numerical evaluation only at24Hz,69–228 inclusive; no images/video rendered.',samples:3817,finite,retainedVisible,retainedLocal,deterministic,failures,cameraFlagCriteria:'>40 display units translation or>10degrees rotation between1/24s samples flags review; not mechanical tolerance or proof of perceptual jerk.',cameraFlags:cuts.length,seek,qualifications:'24Hz sampling is not continuous collision proof. Software retention is not instructional visual approval.'});save('CAMERA-REVIEW-FLAGS.json',cuts);save('VISIBILITY-CHANGES.json',visibilityChanges);save('CAMERA-ONE-SECOND-TRACE.json',cameraScan);
const times=[...new Set([...subset.flatMap(s=>[s.start,s.end]),...events.filter(h=>h.kind==='threaded').flatMap(h=>[h.start,h.end]),...struct.flatMap(b=>[b.start,b.contact])])].sort((a,b)=>a-b);
const boundaries=times.map(t=>{const before=r.evaluate(t-1e-6),cb=r.camera(t-1e-6),bp=new Map([...r.r.registry.entries()].map(([id,o])=>[id,pose(o)])),at=r.evaluate(t),ca=r.camera(t),ap=new Map([...r.r.registry.entries()].map(([id,o])=>[id,pose(o)])),after=r.evaluate(t+1e-6),cc=r.camera(t+1e-6);const common=before.installed.concat(before.hardwareSeated).filter(id=>after.visible.includes(id));return{t,sourceStep:at.step,eventStarts:events.filter(h=>Math.abs(h.start-t)<1e-8).map(h=>h.id),eventEnds:events.filter(h=>Math.abs(h.end-t)<1e-8).map(h=>h.id),bodyStarts:struct.filter(b=>Math.abs(b.start-t)<1e-8).map(b=>b.id),bodyContacts:struct.filter(b=>Math.abs(b.contact-t)<1e-8).map(b=>b.id),cameraJump:cb.position.distanceTo(cc.position),cameraAngleDegrees:cb.quaternion.angleTo(cc.quaternion)*180/Math.PI,newVisible:at.visible.filter(id=>!before.visible.includes(id)),hidden:before.visible.filter(id=>!after.visible.includes(id)),retainedActorChanges:common.filter(id=>bp.get(id)!.some((v,i)=>Math.abs(v-ap.get(id)![i])>1e-7)),beforeStage:before.stage,atStage:at.stage,afterStage:after.stage};});save('BOUNDARY-AND-EVENT-EVIDENCE.json',boundaries);
// Projection and first-hit tests are diagnostic proxies; no new camera is authored.
const views:unknown[]=[];
for(const h of events.filter(h=>h.kind==='threaded')){
 const d=h.end-h.start,rows=[];
 for(const u of [.25,.4,.6,.8,.9,.969,.97]){
  const t=h.start+d*u,s=r.evaluate(t),c=r.camera(t),anchor=new T.Vector3(...placements.find(p=>p.id===h.id)!.position).addScaledVector(norm(h.id),3).applyMatrix4(r.rig.matrixWorld),projected=anchor.clone().project(c),tool=r.r.registry.require(`hardware-${h.tool}-1`),active=r.r.registry.require(h.id);
  const meshes:T.Mesh[]=[];r.rig.traverseVisible(o=>{if(o instanceof T.Mesh)meshes.push(o);});const delta=anchor.clone().sub(c.position),ray=new T.Raycaster(c.position,delta.clone().normalize(),.1,delta.length()+.1),hit=ray.intersectObjects(meshes,false)[0];
  let owner:T.Object3D|undefined=hit?.object;while(owner&&owner.parent&&!/^part-|^hardware-|^presentation-stationary-hinge/.test(owner.name))owner=owner.parent;
  rows.push({u,t,stage:s.stage,anchorInFrustum:onScreen(projected),anchorNDC:projected.toArray(),screwVisible:active.visible,toolVisible:tool.visible,toolProjection:tool.visible?boxProjection(tool,c):null,rayFirst:owner?.name??null,hitDistance:hit?.distance??null,anchorDistance:delta.length(),qualification:'Model anchor+3units exterior; first-hit/range is occlusion evidence only, not exact head-pixel readability or tool access.'});
 }
 views.push({id:h.id,step:h.step,rows});
}save('READABILITY-PROXIES.json',views);
const foot=[];for(const t of [111.999999,112,112.7,113.4,115.5,132,188.999999,189,189.25,190.75,192.25,203,204,205,209]){const s=r.evaluate(t);foot.push({t,step:s.step,rigQuaternion:r.rig.quaternion.toArray(),feet:[1,2,3,4,5].map(i=>{const id=`hardware-A-${i}`,h=hardware.find(h=>h.id===id)!,o=r.r.registry.require(id);return{id,host:h.host,visible:o.visible,relative:o.position.clone().sub(r.r.registry.require(h.host).position).toArray()};})});}for(let i=1;i<foot.length;i++)for(let j=0;j<5;j++)feetFollow&&=foot[i].feet[j].relative.every((v,k)=>Math.abs(v-foot[0].feet[j].relative[k])<1e-8);save('PREPARED-FEET-AND-REORIENTATION.json',{feetFollow,samples:foot,orientationWindows:[{step:'S08',start:112,end:113.4,angleDegrees:180},{step:'S15',start:203,end:205,angleDegrees:-180}],qualification:'Rigid presentation staging; support/lifting/hand access not certified.'});
save('ANALYSIS-SUMMARY.json',{steps:subset.length,hardwareOperations:events.length,threadedOperations:events.filter(h=>h.kind==='threaded').length,bodyEvents:struct.length,numericalSamples:3817,finite,retainedVisible,retainedLocal,deterministic,feetFollow,cameraReviewFlags:cuts.length,newRendering:'NOT RUN',sourceEdits:'NONE',motionQuality:'REQUIRES_PROOF; no perceptualPASS inferred from numeric data'});console.log(JSON.stringify({steps:subset.length,hardwareOperations:events.length,finite,retainedVisible,retainedLocal,deterministic,feetFollow,cameraFlags:cuts.length},null,2));
