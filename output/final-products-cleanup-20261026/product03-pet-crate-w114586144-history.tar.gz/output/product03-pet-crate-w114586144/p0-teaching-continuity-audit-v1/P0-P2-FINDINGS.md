# Evidence-ranked findings — read-only

**New verified P0 geometry/state defects:0 found in this bounded analysis.** This is not a whole-product PASS. Existing raw collision FAIL history and source/physical holds remain intact. No current unrendered sequence is declared visually correct merely because its endpoint/quantity is right.

Classification: P0 = demonstrated new invalid assembly/state/solid defect or an operation established as unintelligible; P1 = important readability/continuity risk or evidence gap; P2 = presentation polish. A source-confidence blocker to a faithful engineering claim is listed separately, not fabricated as a new animation defect.

## T01 — P1 / VERIFIED timing compression; perceptual impact needs proof

S05–S16, threaded D/C/F/E. OPERATION-EVIDENCE.json confirms repeated slots1.236364–1.78s for most groups (first slots2.472727–3.8s). The shortest feed/turn phase is0.494545s, withdrawal0.123636s (~3frames), final tool-free hold0.037091s (<1frame at24fps). Example D31 at120.372727–121.609091; E2 at214.26–215.59 has0.0399s tool-free hold. These timings are source-code facts, not an automatic “jerk” or FAIL finding. Accepted local10s D and12s F exemplars do not approve these compressed repeated cycles.

Risk: viewer sees the result too briefly before the next fastener/cut. Plan representative integrated motion before altering pacing. If later authorized, clarify the first essential example and shorten already-understood repeats with explicit forward cuts, retaining all counts. No timing edits made here.

Evidence: OPERATION-EVIDENCE.json; SOURCE-EXCERPTS.md (V1 timeline threading and runtime phases); accepted part-first/F delivery records and images. Manual pp6–11.

## T02 — P1 / VERIFIED camera cuts; disorientation severity not yet established

69–228s. There are83 event-local camera discontinuities above1display-unit across a2µs neighborhood, including already accepted incoming69s S04 boundary. This is a review threshold, not a fit tolerance. The24Hz scan gives130 review flags; some are continuous auto-fit camera movement, so do not call them130 bad cuts or P0 defects.

At172.5s (end F8/S12), camera position changes~3676.795units and rotation~178.996°. At131.5s (end D39/S08), position changes~3475.634units/~89.081°. These are explicit macro→wide cuts from the current camera selector, not structural teleportation. Adjacent repeated fasteners also cut without a guaranteed wide orientation shot. Wide mode fits currently visible part bounds and can move while a staged part approaches; it is not universally fixed per shot.

Plan: independently review screen direction, whether the contact is taught before the cut, and retained state. Camera motion can be a deliberate valid cut; no source/geometry fix is justified by these numbers alone. Source: BOUNDARY-AND-EVENT-EVIDENCE.json, CAMERA-REVIEW-FLAGS.json; V1 runtime lines58–64. Actual endpoint PNGs use wide mode and cannot settle this question.

## T03 — P1 / VERIFIED staging windows; physical support remains UNVERIFIED

S07/S08: prepared1/2/5 appear at104.15s, causing one wide auto-fit jump; this is first introduction, not an installed-state reset. Entire rig turns180° at112–113.4s, then frame1 starts moving at113.5s: only0.1s orientation hold. S14: prepared5+A5 travel laterally outside the front posts189.25–190.75, then inward through192.25. S15: return upright203–205; floor starts205.15, only0.15s later. These are existing declared display paths, not OEM-validated lifting/install trajectories.

Relative feet/host transforms and installed K/B state remain constant. At119.4s rail5/A5 anchors are outside macro framing while object.visible remains true; no disappearance is inferred. A future diagnostic should show context through the inversion/late-carrier/floor sequence before a presentation plan is judged comprehensible. Do not invent a support fixture, safe lift or hand access. Evidence: PREPARED-FEET-AND-REORIENTATION.json; EDGE-CASE-EVIDENCE.json; OEM pp7,10,11; V1 runtime52 and body events.

## T04 — P1 / VERIFIED disclosure omission in review renderer, not reopened F geometry

S10 144–154s and S12 164–173s. Accepted F proof explicitly labels “NONLITERAL F / NOT OEM-CONFIRMED”. Existing V2 review-preview caption code instead displays generic illustrative/no-certification text and K22/10; it does not explicitly show the F-specific nonliteral qualification. This is verified by the frozen caption source; no whole-current S10/S12 motion render exists to inspect beyond its programmed captions. Metadata/reports retain F's limitation.

Keep the scoped accepted F geometry/motion decision closed. Any later authorized proof touching F must carry its explicit nonliteral disclosure, and must not turn source “lock firmly” into certified torque/retention. A diagnostic review caption gap is not declared a new OEM mismatch or physical P0. Evidence: ACCEPTED-F-NONLITERAL-CONTEXT.jpg; SOURCE-EXCERPTS.md V2 preview10–25; accepted F decision; assumptions register. No label/source changed.

## T05 — P1 / EVIDENCE GAP, not a demonstrated motion defect

S08 112–132, S13–S15 173–209 and S16 209–228. Current V2 has static endpoints and numerical traces, but no actual complete integrated motion proof of inversion/ten D, all four rail6 placements/late5+foot/return/floor, or both doors/eight E. Prior S08 and S15 clips are isolated representative actions with fixed orientation; old D1 footage uses superseded geometry and clipping. It cannot substitute for current proof. Source/endpoint retention supports state only.

S16 code keeps door pivots at0 throughout the current path; it moves doors/hinge constituents translationally. No current opening/closing limit is established or demonstrated. E1–4 follow door7 contact211.25; E5–8 follow door8 contact220.75. Factory hinge constituents are not new loose inventory. Do not infer impossible fastening merely from a closed endpoint or import old35° swing as current truth. Proposed proof3 observes actual E/tool/head interfaces and first-door persistence. C13/C14 allocation remains a disclosed source hypothesis in proof2.

## T06 — P2 / VERIFIED diagnostic information density

S05–S16 endpoints (e.g. S06 103.9583s, S16 227.9583s) carry debug counters, timestamp, holds and K-specific text. These are useful review graphics, not final production captions. Source: existing V2 endpoint PNGs and preview10–25. Future production should use readable part/hardware callouts and a short completed-connection hold; no graphic cleanup is authorized/performed by this audit. This does not reopen approved materials or introduce a new render.

## Existing blockers to faithful/physical claims — unchanged

- C13/C14 end allocation (S13/S14) remains an unverified hypothesis, not source-confirmed instruction.
- Hidden receivers, retention, torque, dimensions, support and real hand/tool access remain unverified. K22/10 unmeasured; F nonliteral.
- S17/S18 I/J/retention pose-only and S19 N4/door HOLD remain outside this audit and unresolved.
- Raw historical FAIL is preserved; current233 AABB candidates remain154 receiving,77 drive-bounds,2 refined B/B candidates. No new sweep/pair suppression/threshold change.

These prevent faithful engineering or whole-film acceptance. They do not justify inventing a new P0 collision, rejecting accepted local illustrations, or reopening exhausted research.
