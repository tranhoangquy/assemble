import * as T from 'three';
import {writeFileSync} from 'node:fs';
import {createRuntime} from '../../../src/products/product03-pet-crate-w114586144/s04-integration-v2/runtime';
const r=createRuntime();const rows=[];
for(const t of [104.15,110.9,112,112.7,113.4,117.9,119.4,132,189,190.75,192.25,203,204,205,207.15,209,211.25,218.75,220.75,228]){
 const s=r.evaluate(t),c=r.camera(t),actors=['part-5-1','hardware-A-5','part-1-1','part-2-1','part-7-1','part-8-1'].map(id=>{const o=r.r.registry.require(id),ndc=o.getWorldPosition(new T.Vector3()).project(c);return{id,visible:o.visible,anchorOutside:Math.abs(ndc.x)>1||Math.abs(ndc.y)>1||ndc.z< -1||ndc.z>1,ndc:ndc.toArray()};});
 rows.push({t,step:s.step,actors,pivots:['7','8'].map(code=>{const o=r.r.root.children.find(o=>o.name===`presentation-door-pivot-${code}`)!;return{code,rotation:o.rotation.toArray()};})});
}writeFileSync(new URL('EDGE-CASE-EVIDENCE.json',import.meta.url),JSON.stringify({method:'Existing evaluator read-only; anchor projection is not complete-mesh occlusion certification.',rows},null,2));
