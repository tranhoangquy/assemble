# Targeted motion proof plan — NOT IMPLEMENTED

**Three proposals only. No new render, video, camera, animation or source edits were made.** These are requests for separately bounded future human implementation authority. First capture should use the actual frozen V2 evaluator/time/cameras to reveal its behavior, not silently fix it before review. Any alternate camera, disclosure graphic or timing change must be explicitly scoped/versioned in that future task.

## Proposal1 — preparation / inversion / repeated D teaching

- Source window108–124s,16s,384 native720p24fps frames. S07 tail: A4/A5 and prepared rail5; S08 inversion, both side-frame contacts, first several D operations. Do not imply this samples all10 D.
- Why: first integrated180° reorientation,0.1s post-turn hold, feet host tracking, all prior K/B retention, repeated D cadence and macro cuts. Existing10s S08 exemplar proves none of this full context.
- Required objects: upper module9–13/15 and earlier parts, bothK/B4, prepared1/2/5 andA5; first D30/31/32 and L. Rail5 may leave macro frame but remains present; begin/end with spatial context from actual evaluator. Do not rearrange OEM operations for the camera.
- Observe: outer side-post→module interfaces and exact screw/tool action; source PDFp7 square-pipe orientation. As-is cameras first; if an authorized alternate view is requested later, show the target without moving mechanical paths.
- PASS: preceding installed members persist; correct sequential target/contact/screw/L; no unsupported silent inversion/reset; first essential D legible and repeats understandable; explicit rigid-presentation staging qualification. FAIL/review if a sampled connection is hidden/too fast to interpret or unrelated-solid penetration is actually established. Lack of physical certification remains U, not repaired by plausible imagery.
- Capture estimate:384frames,2fresh192frame jobs; previous local0.165–0.259s/frame gives~63–100s PNG capture plus startup/encode/QA, budget2–3min offline. Estimate only, not benchmark guarantee.

## Proposal2 — last rail6 / late carrier5 / upright floor14

- Source window185–209s,24s,576frames. Includes last6/C12 repeat, all late5+A5 staging and six C, S15 return and floor placement. Earlier rails6 remain present; this is not a new proof of the manufacturer's exact C end allocation.
- Why: late assembly closure/access risk and dependency continuity; old isolated rail proof does not establish whole installed context.0.15s post-return hold may be too short.
- Required objects: all four6, prepared5+fixedA5, both side frames, rear4/front3, earlier C/D/F/K/B; current C12–18/L; then floor14. No new floor fastener/tool.
- Observe: source PDFp10 front carrier tab direction; lateral motion outside side posts then inward approach; contact planes at6/5/frame. Source PDFp11 floor underside→6 supports. Preserve raw receiving uncertainty and explicitly label C13/C14 allocation HYPOTHESIS. No invented hidden receiver/certified access/support rig.
- PASS: all prior rails/screws and A5 retained; actual5 staging readable and no demonstrated unrelated penetration; floor appears only after upright staging, reaches support without new screw/tool; state and orientation understandable. FAIL/review on confirmed reset/wrong joint/visible wrong relation or incomprehensible cut. A generic collision-free proxy cannot certify hand access.
- Estimate:576frames in2×288frame offline jobs;95–149s capture plus startup/encode/QA, budget3–4min. No full-film output.

## Proposal3 — both doors / two E per hinge / retained first door

- Source window209–228s,19s,456frames in2×228 jobs. Full S16 only; do not run S17–S19 or add an opening demonstration.
- Why: no accepted current integrated E fastening motion proof; eight screws and final closed endpoint are insufficient visual evidence. Current static hinge proposal has limited authority.
- Required objects: frame1/2, both doors7/8 with factory hinge constituents, E1–8 and M, floor/prior installed assembly. First door and its four E remain during the second door.
- Observe: actual frame-leaf screw mounting targets, two E for each of four hinges, screwdriver axis and exterior seat. Current cameras as-is first; any proposed alternate macro requires separate scope. No invented hinge screws beyond E8, rotation limits, thread, receiver or support certification.
- PASS: source order/contact before respective E groups, accurate eight-count teaching, explicit tool withdrawal/seat hold, first-door retention; no physical opening/retention claim. FAIL/review if actual leaf/target is concealed or wrong, an established penetration appears, or fast cuts make the operation unreadable. Unresolved actual fastening/hand access remains OPEN.
- Estimate:456frames,75–118s capture plus startup/encode/QA, budget2–3.5min offline.

## Selection trade-off and stopping boundary

Total59s/1416frames proposed across3 clips, each using current absolute timing; no global acceleration or retime. Budgets based on existing V2 PNG timestamps, not a new render. All capture jobs<=288frames reuse existing renderer, no new exporter/cloud/paid assets.

These prioritize evidence absent from current clips. S05/S06 and F compressed repetitions still carry T01/T02/T04; existing accepted exemplars and numerical trace support planning only. These three proofs would NOT grant full S05–S16 motion approval or resolve OEM uncertainties. Review them first before expanding coverage; do not propose extra clips to evade the three-proof cap.

**STOP after Director reviews this audit/plan.** Targeted capture/render and any source/camera/timing/disclosure implementation need a new human-authorized scope. No geometry edits, full278s, Long/Short, audio/mastering or research.
