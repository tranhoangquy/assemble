from pathlib import Path
import json,hashlib,collections,datetime
P=Path(__file__).resolve().parent;ROOT=P.parents[2];B=P.parent
def load(n):return json.loads((P/n).read_text())
def write(n,t):(P/n).write_text(t.strip()+'\n')
def save(n,v):write(n,json.dumps(v,indent=2,ensure_ascii=False))
o=load('OPERATION-EVIDENCE.json');summary=load('ANALYSIS-SUMMARY.json');assert summary['steps']==12 and all(summary[k]for k in ['finite','retainedVisible','retainedLocal','deterministic','feetFollow'])
steps=o['steps'];events=o['hardware'];bound=load('BOUNDARY-AND-EVENT-EVIDENCE.json');hard=[r for r in bound if r['cameraJump']>1]
details={
5:('13 → retained 9/10 rear edges','Rear-normal Z approach69.25–71.25; front face of13 contacts existing rear edges. D13–19 enter from the exterior rear face, then L.','Contact before D starts71.6 (0.35s hold). Seven sequential D retained.','Accepted10s S05 proof shows ONE D13 exemplar, not all7 integrated cycles. New V2 clip39–75 covers panel placement/part of first cycle only.','T01/T02; no whole-step motion acceptance'),
6:('15 → lower edges of10/11/12','15 rises85.25–87.25; upper face meets retained edges. D20–29 approach from underside, then L.','Contact before D87.6 (0.35s). Ten D retained.','Accepted10s S06 proof shows ONE D20 exemplar. Existing V2 endpoint is static; it does not prove ten rapid operations.','T01/T02; motion evidence gap'),
7:('A1–5 → prepared1/2/5','1/2/5 introduced as prepared components104.15; A1–5 seat sequentially104.6–110.9. No L/M/O action is authored.','Frames remain prepared untilS08;5+A5 remain staged untilS14. No independent foot teleport found.','OEM PDFp7; V2 S07 endpoint; prepared-foot relative transforms.','T03/T05; wide staging composition needs proof'),
8:('frames1/2 → retained upper module','Whole-rig180° staging112–113.4; left frame approaches113.5–115.5, right115.5–117.5; outer-post D30–39 begin117.9, then L.','All10D after both frames reach modeled contact. Prepared feet follow their host; both K/B pairs persist.','Accepted10s S08 proof is one right-side D35 example with a static inverted rig. It does not prove this turnover/ten-operation cadence.','T01/T03/T05; proposed proof1'),
9:('rear frame4 → side frames1/2','4 approaches from rear132.25–134.25; ends meet side-frame inner planes. C1–4 from outer side-post faces then L.','C1 starts134.6,0.35s after contact; four C remain installed.','OEM PDFp8; corrected frame4/rail proof genealogy; V2 S09 endpoint; no complete current S09 motion clip.','T01/T02; source qualitative, receivers unknown'),
10:('F1–4 → rear4 / reconstructed13 joint','Previously placed rear/module held. F1–4 sequentially144.75–153.5; M approaches/engages/withdraws. Axis is the explicitly accepted NONLITERAL lateral reconstruction.','No structural reset. This is initial symbolic seating, not proven source “lock firmly” torque.','Accepted12s S10 F proof shows ONE exemplar, not this compressed four-cycle integration. PDFp8 firm-lock intent retained as source evidence.','T01/T04; do not reopen accepted F geometry'),
11:('front header3 → side frames1/2','3 approaches from front154.25–156.25. C5–8 enter external post faces from156.6 with L; header/tab orientation must remain source-consistent.','Existing rear/F state retained; four C installed sequentially.','OEM PDFp9 direction inset; V2 S11 endpoint; current source approach/camera rules.','T01/T02; no independent motion proof'),
12:('F5–8 → header3 / reconstructed15 joint','F5–8 sequentially164.75–172.5, using M. Front association is accepted NONLITERAL F construction, not a recovered OEM receiver/axis.','Retains header and all earlier parts. Initial-seat display does not certify final tightening.','Accepted12s S12 F exemplar; PDFp9 firm-lock intent; V2 endpoint.','T01/T02/T04; largest sampled camera cut at172.5'),
13:('four rails6 → rear4; opposite ends not yet captured','6-1 approaches173.25–175.25, C9 begins175.45. Further rails179.5–180.75,182.5–183.75,185.5–186.75; C10/11/12 start0.2s after contact. L follows.','Rails retain their local poses through S14/S15. Four C total; chosen rear-end ownership is an explicit HYPOTHESIS.','OEM PDFp10; accepted focused rail exterior proof; V2 S13 endpoint; source timing evidence.','T01/T05; proposed proof2. Do not promote C allocation'),
14:('prepared5+A5 → four6 ends and side posts','5 moves laterally outside the front posts189.25–190.75, then inward in depth190.75–192.25. C13–18 begin192.6 with L.','A5 host-relative offset remains fixed. C13–16 → rail6 ends / C17–18 →5 ends is the declared unverified allocation; not an OEM rule.','OEM PDFp10 direction inset; old V1 route checkpoints; V2 S14 endpoint; numerical edge cases.','T03/T05; proposed proof2; no certified access/path'),
15:('floor14 → supports6, no new fastener','Whole rig returns upright203–205. Floor14 lowers205.15–207.15; support contact at modeled underside, then hold to209. No screw/tool.','All earlier members retained. Remaining floor-support/load/lifting details are unverified.','OEM PDFp11; accepted6s floor proof is a static upright exemplar, not V2 turnover.','T03; proposed proof2; no invented floor screw'),
16:('doors7/8 and existing hinge constituents → frames1/2','Door7 approaches209.25–211.25; E1–4 run211.6–218.25 with M. Door8 approaches218.75–220.75; E5–8 run221.1–227.75.','Eight E follow both respective door contacts. First door and E1–4 persist during second. Four hinge groups are factory constituents, not extra OEM parts. Current V2 pivots remain0; no swing demonstrated.','OEM PDFp11, accepted limited static hinge hypothesis, V2 S16 endpoint and numerical door/pivot evidence. Old D1 swing is historical, not V2 evidence.','T01/T05; proposed proof3. Hinge retention/access remain unverified'),
}
lines=['# S05–S16 teaching/continuity matrix','',
'Milestone: PRODUCT03-P0-TEACHING-CONTINUITY-AUDIT-V1. **READ-ONLY AUDIT COMPLETE — DIRECTOR REVIEW REQUIRED.** Baseline: accepted S04 Integration V2,278s. S04 PASS is not reopened.',
'','Evidence classes: **D** local manual image; **S** executable source/numerical trace; **V** existing rendered evidence; **U** not established. A numerical state PASS is not motion/teaching approval. All numeric positions are display units, not OEM measurements.','',
'12/12 steps;14 newly introduced numbered component instances across18 body events;66 accessory operations = D27+C18+F8+E8+A5, including61 threaded cycles and5 foot preparations. Together with the18 earlier accessory units this gives84 initial-seat display states by228s. Source inventory remains20components/100accessories+3tools/19steps.','',
'| Step / V2 time | Local manual PDF/printed | Structural association | Current hardware / tool | Model state | Teaching verdict |',
'|---|---|---|---|---|---|']
for s in steps:
 n=s['number'];hs=[h for h in events if h['step']==n];cnt=collections.Counter(h['id'].split('-')[1]for h in hs);tools=sorted({h['tool']for h in hs if h['tool']});lines.append(f"| {s['id']} / {s['start']}–{s['end']}s | {s['source']['pdf_page']}/{s['source']['printed_page']} | {details[n][0]} | "+(', '.join(f'{k}×{v}'for k,v in cnt.items()) or 'none')+(' / '+','.join(tools)if tools else' / no tool')+f" | Retained numerically; receivers U | {details[n][4]} |")
for s in steps:
 n=s['number'];hs=[h for h in events if h['step']==n];th=[h for h in hs if h['kind']=='threaded'];d=details[n]
 lines +=['',f"## {s['id']} / {s['start']}–{s['end']}s",'',d[1],d[2],f"Evidence: {d[3].rstrip('.')}.",f"Assessment: {d[4]}.",f"Local references: evidence/OEM-PDF-P{s['source']['pdf_page']:02d}.png; evidence/EXISTING-V2-{s['id']}-endpoint.png; OPERATION-EVIDENCE.json/{s['id']}; CONNECTION-TARGET-CROSSWALK.json/step{n}."]
 if th:lines +=[f"Cadence: first threaded slot{th[0]['duration']:.6f}s; shortest repeat{min(h['duration']for h in th):.6f}s. Generic tool-free hold is only3% of each slot ({min(h['duration']for h in th)*.03:.6f}s minimum). No new motion verdict inferred."]
lines+=['','## Cross-step result','','Existing evaluator evaluated at24Hz over69–228s:3,817 samples; finite transforms, installed visibility/local-pose retention, deterministic seek and prepared-foot tracking pass. All modeled relevant target contacts precede current hardware, including door7/8 before their E groups. Zero retained-actor local-pose changes at the analyzed event boundaries. See MOTION-SCAN-SUMMARY.json and CONNECTION-TARGET-CROSSWALK.json. No new collision sweep, images, videos or runtime edits.','',
'Existing step endpoints were made with camera(overview=true). They show product state; they do not establish the macro camera used during current motion. READABILITY-PROXIES.json uses the actual default motion camera: all427 tested anchor projections are inside frustum; first ray hits are the active screw or its tool, not unrelated geometry. This does not certify the whole interface, perceptual clarity, every pixel/time, or hand access.']
write('TEACHING-CONTINUITY-MATRIX.md','\n'.join(lines))

write('P0-P2-FINDINGS.md','''# Evidence-ranked findings — read-only

**New verified P0 geometry/state defects:0 found in this bounded analysis.** This is not a whole-product PASS. Existing raw collision FAIL history and source/physical holds remain intact. No current unrendered sequence is declared visually correct merely because its endpoint/quantity is right.

Classification: P0 = demonstrated new invalid assembly/state/solid defect or an operation established as unintelligible; P1 = important readability/continuity risk or evidence gap; P2 = presentation polish. A source-confidence blocker to a faithful engineering claim is listed separately, not fabricated as a new animation defect.

## T01 — P1 / VERIFIED timing compression; perceptual impact needs proof

S05–S16, threaded D/C/F/E. OPERATION-EVIDENCE.json confirms repeated slots1.236364–1.78s for most groups (first slots2.472727–3.8s). The shortest feed/turn phase is0.494545s, withdrawal0.123636s (~3frames), final tool-free hold0.037091s (<1frame at24fps). Example D31 at120.372727–121.609091; E2 at214.26–215.59 has0.0399s tool-free hold. These timings are source-code facts, not an automatic “jerk” or FAIL finding. Accepted local10s D and12s F exemplars do not approve these compressed repeated cycles.

Risk: viewer sees the result too briefly before the next fastener/cut. Plan representative integrated motion before altering pacing. If later authorized, clarify the first essential example and shorten already-understood repeats with explicit forward cuts, retaining all counts. No timing edits made here.

Evidence: OPERATION-EVIDENCE.json; SOURCE-EXCERPTS.md (V1 timeline threading and runtime phases); accepted part-first/F delivery records and images. Manual pp6–11.

## T02 — P1 / VERIFIED camera cuts; disorientation severity not yet established

69–228s. There are83 event-local camera discontinuities above1display-unit across a2µs neighborhood, including already accepted incoming69s S04 boundary. This is a review threshold, not a fit tolerance. The24Hz scan gives130 review flags; some are continuous auto-fit camera movement, so do not call them130 bad cuts or P0 defects.

At172.5s (end F8/S12), camera position changes~3676.795units and rotation~178.996°. At131.5s (end D39/S08), position changes~3475.634units/~89.081°. These are explicit macro→wide cuts from the current camera selector, not structural teleportation. Adjacent repeated fasteners also cut without a guaranteed wide orientation shot. Wide mode fits currently visible part bounds and can move while a staged part approaches; it is not universally fixed per shot.

Plan: independently review screen direction, whether the contact is taught before the cut, and retained state. Camera motion can be a deliberate valid cut; no source/geometry fix is justified by these numbers alone. Source: BOUNDARY-AND-EVENT-EVIDENCE.json, CAMERA-REVIEW-FLAGS.json; V1 runtime lines58–64. Actual endpoint PNGs use wide mode and cannot settle this question.

## T03 — P1 / VERIFIED staging windows; physical support remains UNVERIFIED

S07/S08: prepared1/2/5 appear at104.15s, causing one wide auto-fit jump; this is first introduction, not an installed-state reset. Entire rig turns180° at112–113.4s, then frame1 starts moving at113.5s: only0.1s orientation hold. S14: prepared5+A5 travel laterally outside the front posts189.25–190.75, then inward through192.25. S15: return upright203–205; floor starts205.15, only0.15s later. These are existing declared display paths, not OEM-validated lifting/install trajectories.

Relative feet/host transforms and installed K/B state remain constant. At119.4s rail5/A5 anchors are outside macro framing while object.visible remains true; no disappearance is inferred. A future diagnostic should show context through the inversion/late-carrier/floor sequence before a presentation plan is judged comprehensible. Do not invent a support fixture, safe lift or hand access. Evidence: PREPARED-FEET-AND-REORIENTATION.json; EDGE-CASE-EVIDENCE.json; OEM pp7,10,11; V1 runtime52 and body events.

## T04 — P1 / VERIFIED disclosure omission in review renderer, not reopened F geometry

S10 144–154s and S12 164–173s. Accepted F proof explicitly labels “NONLITERAL F / NOT OEM-CONFIRMED”. Existing V2 review-preview caption code instead displays generic illustrative/no-certification text and K22/10; it does not explicitly show the F-specific nonliteral qualification. This is verified by the frozen caption source; no whole-current S10/S12 motion render exists to inspect beyond its programmed captions. Metadata/reports retain F's limitation.

Keep the scoped accepted F geometry/motion decision closed. Any later authorized proof touching F must carry its explicit nonliteral disclosure, and must not turn source “lock firmly” into certified torque/retention. A diagnostic review caption gap is not declared a new OEM mismatch or physical P0. Evidence: ACCEPTED-F-NONLITERAL-CONTEXT.jpg; SOURCE-EXCERPTS.md V2 preview10–25; accepted F decision; assumptions register. No label/source changed.

## T05 — P1 / EVIDENCE GAP, not a demonstrated motion defect

S08 112–132, S13–S15 173–209 and S16 209–228. Current V2 has static endpoints and numerical traces, but no actual complete integrated motion proof of inversion/ten D, all four rail6 placements/late5+foot/return/floor, or both doors/eight E. Prior S08 and S15 clips are isolated representative actions with fixed orientation; old D1 footage uses superseded geometry and clipping. It cannot substitute for current proof. Source/endpoint retention supports state only.

S16 code keeps door pivots at0 throughout the current path; it moves doors/hinge constituents translationally. No current opening/closing limit is established or demonstrated. E1–4 follow door7 contact211.25; E5–8 follow door8 contact220.75. Factory hinge constituents are not new loose inventory. Do not infer impossible fastening merely from a closed endpoint or import old35° swing as current truth. Proposed proof3 observes actual E/tool/head interfaces and first-door persistence. C13/C14 allocation remains a disclosed source hypothesis in proof2.

## T06 — P2 / VERIFIED diagnostic information density

S05–S16 endpoints (e.g. S06 103.9583s, S16 227.9583s) carry debug counters, timestamp, holds and K-specific text. These are useful review graphics, not final production captions. Source: existing V2 endpoint PNGs and preview10–25. Future production should use readable part/hardware callouts and a short completed-connection hold; no graphic cleanup is authorized/performed by this audit. This does not reopen approved materials or introduce a new render.

## Existing blockers to faithful/physical claims — unchanged

- C13/C14 end allocation (S13/S14) remains an unverified hypothesis, not source-confirmed instruction.
- Hidden receivers, retention, torque, dimensions, support and real hand/tool access remain unverified. K22/10 unmeasured; F nonliteral.
- S17/S18 I/J/retention pose-only and S19 N4/door HOLD remain outside this audit and unresolved.
- Raw historical FAIL is preserved; current233 AABB candidates remain154 receiving,77 drive-bounds,2 refined B/B candidates. No new sweep/pair suppression/threshold change.

These prevent faithful engineering or whole-film acceptance. They do not justify inventing a new P0 collision, rejecting accepted local illustrations, or reopening exhausted research.
''')

lines=['# Boundaries, cuts and staging register','',
'Read-only V2 evaluation. Times below are global V2 seconds. At every listed step boundary and analyzed operation event, retained actor local transforms remain unchanged. Whole-rig presentation rotation is distinguished from a local component reset. Numerical results are not a visual cut-approval verdict.','',
'| Boundary | Incoming/outgoing context | Retention / risk |','|---|---|---|']
boundaryNotes={69:'Accepted S04→S05 macro/wide change; do not reopen S04.',85:'13/D7 retained;15 first introduced at85.25.',104:'15/D10 retained;prepared1/2/5 introduced104.15, auto-fit camera change.',112:'Prepared feet retained;180° turn112–113.4, no physical lift claim.',132:'Frames/D10 retained;rear4 introduced132.25.',144:'Rear/C4 retained;F begins144.75, NONLITERAL.',154:'RearF retained;front3 introduced154.25.',164:'Front3/C4 retained;frontF begins164.75, NONLITERAL.',173:'F8 retained;first6 introduced173.25, C allocation hypothesis.',189:'Four6 retained;prepared5/A5 staged route189.25 onward.',203:'Carrier/C6 retained;return upright203–205.',209:'Floor14 retained;firstdoor starts209.25.',228:'Bothdoors/E8 retained;S17 exterior stack is still pose-only.'}
for t,note in boundaryNotes.items():
 r=next(x for x in bound if x['t']==t);lines.append(f"| {t:.6f}s | {note} | No retained local reset; camera delta{r['cameraJump']:.3f}units/{r['cameraAngleDegrees']:.3f}° |")
lines+=['','## Operation-event camera register','',
'The existing V1 CAMERA-CUT-REGISTER.json covers only its actual S01/S04 diagnostic clips; it is not a complete camera-cut ledger for V2. This audit supplies BOUNDARY-AND-EVENT-EVIDENCE.json for all selected body/hardware starts/ends and CAMERA-REVIEW-FLAGS.json for the24Hz scan. No camera authored.','',
f'83 event-local jumps above1unit, including69s;130 frame-sampled review flags. Diagnostic criteria only, not OEM tolerances or automatic defects. All{len(bound)} analyzed event timestamps and all raw entries are retained.','',
'| t | Step | Start / end | Position jump | Rotation jump |','|---|---|---|---|---|']
for r in hard:lines.append(f"| {r['t']:.6f} | {r['sourceStep']} | {','.join(r['eventStarts']+r['eventEnds']+r['bodyStarts']) or 'staging'} | {r['cameraJump']:.3f} display units | {r['cameraAngleDegrees']:.3f}° |")
lines +=['','## Required edge cases','','- Seek: exact repeated hashes pass after forward/backward/camera calls; explicit ±1µs event neighborhoods recorded. Equality criteria1e-8/1e-7 are software comparisons, not collision tolerance changes.','- Offscreen ≠ hidden: at119.4s prepared5/A5 have visible=true despite anchor outside macro frustum. No false disappearance report.','- Feet: all5 host-relative offsets unchanged through preparation, inversion, late carrier approach and return.','- F: source firm-lock intent remains; current action means symbolic initial seating. Explicit nonliteral qualifier required in any future proof.','- Cuts: active target anchors in427 sampled views lie in frustum. Expected tool-first ray hits are not unrelated occlusion defects. This is not a complete pixel/hand-access proof.','- Doors/hinges: current pivot rotation0; two translational placements/E groups. Historical35° demonstration is not current approved motion.','- Repetition: all61 threaded operations exist and retain final state; counts alone do not establish comprehension.']
write('BOUNDARY-AND-CUT-REGISTER.md','\n'.join(lines))

write('TARGETED-PROOF-PLAN.md','''# Targeted motion proof plan — NOT IMPLEMENTED

**Three proposals only. No new render, video, camera, animation or source edits were made.** These are requests for separately bounded future human implementation authority. First capture should use the actual frozen V2 evaluator/time/cameras to reveal its behavior, not silently fix it before review. Any alternate camera, disclosure graphic or timing change must be explicitly scoped/versioned in that future task.

## Proposal1 — preparation / inversion / repeated D teaching

- Source window108–124s,16s,384 native720p24fps frames. S07 tail: A4/A5 and prepared rail5; S08 inversion, both side-frame contacts, first several D operations. Do not imply this samples all10 D.
- Why: first integrated180° reorientation,0.1s post-turn hold, feet host tracking, all prior K/B retention, repeated D cadence and macro cuts. Existing10s S08 exemplar proves none of this full context.
- Required objects: upper module9–13/15 and earlier parts, bothK/B4, prepared1/2/5 andA5; first D30/31/32 and L. Rail5 may leave macro frame but remains present; begin/end with spatial context from actual evaluator. Do not rearrange OEM operations for the camera.
- Observe: outer side-post→module interfaces and exact screw/tool action; source PDFp7 square-pipe orientation. As-is cameras first; if an authorized alternate view is requested later, show the target without moving mechanical paths.
- PASS: preceding installed members persist; correct sequential target/contact/screw/L; no unsupported silent inversion/reset; first essential D legible and repeats understandable; explicit rigid-presentation staging qualification. FAIL/review if a sampled connection is hidden/too fast to interpret or unrelated-solid penetration is actually established. Lack of physical certification remains U, not repaired by plausible imagery.
- Capture estimate:384frames,2fresh192frame jobs; previous local0.165–0.259s/frame gives~63–100s PNG capture plus startup/encode/QA, budget2–3min offline. Estimate only, not benchmark guarantee.

## Proposal2 — last rail6 / late carrier5 / upright floor14

- Source window185–209s,24s,576frames. Includes last6/C12 repeat, all late5+A5 staging and six C, S15 return and floor placement. Earlier rails6 remain present; this is not a new proof of the manufacturer's exact C end allocation.
- Why: late assembly closure/access risk and dependency continuity; old isolated rail proof does not establish whole installed context.0.15s post-return hold may be too short.
- Required objects: all four6, prepared5+fixedA5, both side frames, rear4/front3, earlier C/D/F/K/B; current C12–18/L; then floor14. No new floor fastener/tool.
- Observe: source PDFp10 front carrier tab direction; lateral motion outside side posts then inward approach; contact planes at6/5/frame. Source PDFp11 floor underside→6 supports. Preserve raw receiving uncertainty and explicitly label C13/C14 allocation HYPOTHESIS. No invented hidden receiver/certified access/support rig.
- PASS: all prior rails/screws and A5 retained; actual5 staging readable and no demonstrated unrelated penetration; floor appears only after upright staging, reaches support without new screw/tool; state and orientation understandable. FAIL/review on confirmed reset/wrong joint/visible wrong relation or incomprehensible cut. A generic collision-free proxy cannot certify hand access.
- Estimate:576frames in2×288frame offline jobs;95–149s capture plus startup/encode/QA, budget3–4min. No full-film output.

## Proposal3 — both doors / two E per hinge / retained first door

- Source window209–228s,19s,456frames in2×228 jobs. Full S16 only; do not run S17–S19 or add an opening demonstration.
- Why: no accepted current integrated E fastening motion proof; eight screws and final closed endpoint are insufficient visual evidence. Current static hinge proposal has limited authority.
- Required objects: frame1/2, both doors7/8 with factory hinge constituents, E1–8 and M, floor/prior installed assembly. First door and its four E remain during the second door.
- Observe: actual frame-leaf screw mounting targets, two E for each of four hinges, screwdriver axis and exterior seat. Current cameras as-is first; any proposed alternate macro requires separate scope. No invented hinge screws beyond E8, rotation limits, thread, receiver or support certification.
- PASS: source order/contact before respective E groups, accurate eight-count teaching, explicit tool withdrawal/seat hold, first-door retention; no physical opening/retention claim. FAIL/review if actual leaf/target is concealed or wrong, an established penetration appears, or fast cuts make the operation unreadable. Unresolved actual fastening/hand access remains OPEN.
- Estimate:456frames,75–118s capture plus startup/encode/QA, budget2–3.5min offline.

## Selection trade-off and stopping boundary

Total59s/1416frames proposed across3 clips, each using current absolute timing; no global acceleration or retime. Budgets based on existing V2 PNG timestamps, not a new render. All capture jobs<=288frames reuse existing renderer, no new exporter/cloud/paid assets.

These prioritize evidence absent from current clips. S05/S06 and F compressed repetitions still carry T01/T02/T04; existing accepted exemplars and numerical trace support planning only. These three proofs would NOT grant full S05–S16 motion approval or resolve OEM uncertainties. Review them first before expanding coverage; do not propose extra clips to evade the three-proof cap.

**STOP after Director reviews this audit/plan.** Targeted capture/render and any source/camera/timing/disclosure implementation need a new human-authorized scope. No geometry edits, full278s, Long/Short, audio/mastering or research.
''')

write('ASSUMPTION-AND-HOLD-REGISTER.md','''# Assumptions and source holds — no confidence upgrade

| Item | Status | Scope/evidence | Allowed conclusion / prohibited inference |
|---|---|---|---|
| Source identity | OPEN commercial variant | Local13-page PDF SHA70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29; metadata W114586144/drawers versus visible cubby/mesh-door parts | No drawers added; no commercial variant certification |
| Product/panel dimensions | UNMEASURED | PhaseA U02; acceptedB/C/visual corrections | Display coordinates only; no certified millimetres |
| K22/10 | Accepted unmeasured exterior illustration, S04 CLOSED | Actual S04/V2 decisions | Retain geometry/state; do not reopen or call OEM dimensions |
| F1–8 | NONLITERAL, local accepted proof CLOSED | HumanB reconstruction; actual F decision; T04 | Preserve explicit disclosure; no recovered OEM axis/receiver/retention/torque |
| C13/C14 end ownership | OPEN hypothesis | OEM PDFp10; U04; current C9–18 targets | ExactC4/C6 quantities confirmed; chosen end allocation is illustrative, not source resolved |
| D/E/other receivers | UNVERIFIED | Manual depicts qualitative association; no sections/depths | Existing full shafts/visible interfaces retained; do not create hidden bores/threads or certify grip |
| Final tightening | UNVERIFIED physical action | Manualp2 align before final tightening; p8/p9 S10/S12 firmly-lock intent | Current states are initial symbolic seats; no torque/turn-count guarantee |
| Reorientation/support | PRESENTATION ONLY | S08 112–113.4; S15 203–205 | Rigid member/foot retention verified numerically; no safe lift/fixture/manpower claim |
| Late5 insertion | UNVERIFIED real trajectory/access | Current staged outside-post then depth path; PDFp10 | Source sequence respected, not human tool/hand accessibility certification |
| Hinges/door motion | Limited static visual hypothesis; current pivots0 | LimitedPhaseC and current V2; PDFp11 | Two door placements/E8 illustrative; no certified hinge opening/load/retention |
| I/J and S17/S18 | OPEN, POSE-ONLY | PDFp12 contradictory labels; outside audit | No false fastened state; no new O grip or stud invention |
| S19 N4/door release | HOLD | PDFp13; outside audit | No new pad application, latch release or functional door render |
| Collision record | Historical FAIL preserved / physical UNVERIFIED | Original raw findings and current233 candidates unchanged | No new collision sweep, pair suppression, threshold change or physical PASS |
| Current audit | READ-ONLY/PLANNING | 12step source/manual/image review;3817 numerical samples; existing evidence | No new product/media; not a visual whole-film acceptance |

Prepared/offscreen components are distinguished from missing components. New metadata paths/localStart fields from older timelines are not current animation clocks; use V2 absolute start/end in OPERATION-EVIDENCE. All19 dependencies and source quantities retained. Human is sole final approver of the eventual two films. Product01 and discontinued JULIETTE preserved.

No fresh search/source acquisition, paid service, external site, additional login, production render, audio or source edit. Only existing Assemble handoff is permitted. Browser receipt screenshots document communication, not a new product render.
''')

write('DIRECTOR-REVIEW.md','''# PRODUCT03 — P0 Teaching Continuity Audit V1 / actual completed results

Review ID: PRODUCT03-P0-TEACHING-CONTINUITY-AUDIT-V1-20261023
Milestone: PRODUCT03-P0-TEACHING-CONTINUITY-AUDIT-V1

The human explicitly directed execution of your actual read-only S05–S16 package, not another administrative status. This is the completed audit and proof plan. S04 Integration V2 remains PASS/CLOSED; no milestone reopened.

## Outcome

12/12 source steps reviewed against manual PDFpp6–11, accepted geometry/correction genealogy, frozen V1, accepted part-first/F proofs, accepted V2 source/QA/current endpoint evidence, historicalD1 context and prior collision/uncertainty records. Read-only evaluator analysis covers69–228s at24Hz (3817 samples),18body events and66 accessory operations (61threaded+5feet). No source/runtime/camera/timeline/geometry edits, new renders, videos, audio or research.

No new confirmed P0 assembly/state/solid defect established. This is NOT a physical or visual whole-product PASS. Retained local poses/visibility, finite transforms, deterministic/backward seeking, foot-host offsets and modeled placement-before-current-hardware timing pass, including door7/8 before respective E. Existing raw233 candidates remain intact and physically qualified.

Five P1 findings: timing compression (T01), camera-cut continuity risk (T02), staging/reorientation readability/support limits (T03), loss of explicit F-nonliteral on-screen disclosure in current review-preview source (T04), current integrated motion evidence gaps (T05). T01–T04 cite verified source/timing facts; perceptual defect severity needs actual motion review. T05 is an evidence gap, not fabricated animation failure. One P2 diagnostic information-density item T06. Existing C/IJ/receiver/physical/source blockers remain separate and OPEN.

Repeat threaded slots as low as1.236364s, feed/turn0.494545s, tool-free completed hold0.037091s (<1frame). Event-local camera discontinuities83 (including acceptedincoming69s);24Hz flags130, including auto-fit movement. These counts are not counts of bad cuts/physical collisions. Example F8→wide at172.5s changes~178.996°; retention stays intact. Endpoint screenshots use overview=true and cannot establish motion camera quality.427 sample anchor projections are in-frustum; first hits are active screw/tool, not unrelated geometry. This does not certify pixel readability or hand access.

S16 currently translates both doors/hinge constituents; pivot rotation remains0. Do not mistake historical35° motion or accepted static hinge contacts for current mechanical/opening approval. Prepared5/A5 remain visible in the scene while offscreen in macro views, so no false disappearance finding is made.

## Exactly three future proof proposals — NOT RUN

1.108–124s (16s): prepared feet/rail5, whole-rig inversion, side-frame contacts and first repeated D operations.
2.185–209s (24s): last rail6/C, late5+A5 staged route, C allocation hypothesis, return upright and floor14 without screws.
3.209–228s (19s): both door placements, E8/M interfaces, first-door retention, no swing/S17–S19.

Total59s/1416frames at native720p24fps, proposed as bounded offline chunks<=288frames. Cost estimates use already existing PNG timestamp rates only. No new exporter or media production. Other compressed S05/S06/F cycles remain qualified; three selected samples cannot confer whole-film motion acceptance.

## Evidence integrity and limitations

Six required Markdown reports, complete numerical records, source excerpts with line numbers/hashes, byte-preserved copies of already existing OEM pages/V2 endpoints/approved/historical reference images, and SHA256 manifest are supplied. Every finding identifies step/time/object/source. Existing render provenance is explicit; no new current motion evidence was created. Baseline source/engine118file hashes,938protected paths, historical deliveries and frozen evidence are checked in PROTECTED-ASSET-VERIFICATION.json. Initial audit-helper import-path failure is retained; it was corrected only in this new output helper, with no product source change. Successful numerical execution is separate from unchanged historical software PASS and unperformed physical QA.

## Formal decision requested / STOP

Review the actual reports and evidence ZIP. Decide PASS / REVISION_REQUIRED / FAIL for read-only audit completeness, classification and the three-proof selection, not visual/physical acceptance of unseen motion. Confirm whether these are the right priority windows and retain all source/physical limits. If accepted, close this audit and identify the exact next bounded human scope needed for targeted proof capture. Do not treat your review as authority for new geometry, source/camera/timing edits, new renders, full278s, finalLong/Short, audio/mastering or research.

After reading/recording your complete actual decision, Codex will STOP at this review gate. No duplicate acknowledgement after STOP; human retains final acceptance.
''')

excerptFiles={
'src/products/product03-pet-crate-w114586144/timeline-integration-v1/runtime.ts':[(10,34),(38,65)],
'src/products/product03-pet-crate-w114586144/timeline-integration-v1/timeline.ts':[(8,30),(39,57)],
'src/products/product03-pet-crate-w114586144/s04-integration-v2/runtime.ts':[(9,40)],
'src/products/product03-pet-crate-w114586144/s04-integration-v2/timeline.ts':[(5,29)],
'src/products/product03-pet-crate-w114586144/s04-integration-v2/preview.ts':[(10,26)],
'src/products/product03-pet-crate-w114586144/part-first-sequence-v1/proof.ts':[(6,21)],
}
ls=['# Source excerpts — existing frozen code, no source edits','',
'All line numbers are1-based. These excerpts are evidence, not new implementation instructions. V1 runtime is used by the accepted V2 adapter at t−14 afterS04. Absolute times in the generated audit ledger are authoritative; inherited old metadata fields are not.','']
srcIndex=[]
for fn,ranges in excerptFiles.items():
 f=ROOT/fn;sha=hashlib.sha256(f.read_bytes()).hexdigest();srcIndex.append(dict(path=fn,sha256=sha,ranges=ranges));ls +=[f'## {fn}',f'SHA256: {sha}','']
 a=f.read_text().splitlines()
 for start,end in ranges:ls +=['```text',*['%4d %s'%(i,a[i-1])for i in range(start,min(end,len(a))+1)],'```','']
write('SOURCE-EXCERPTS.md','\n'.join(ls));save('SOURCE-EVIDENCE-INDEX.json',srcIndex)
save('AUDIT-RESULTS.json',dict(reviewID='PRODUCT03-P0-TEACHING-CONTINUITY-AUDIT-V1-20261023',status='READ-ONLY AUDIT COMPLETE — DIRECTOR REVIEW REQUIRED',coverageSteps=[s['id']for s in steps],hardwareOperations=66,threaded=61,bodyEvents=18,numericalSamples=3817,newVerifiedP0=0,P1=['T01','T02','T03','T04','T05'],P2=['T06'],physicalConfidence='UNCHANGED/NOT_CERTIFIED; source holds OPEN',newMotionProofs='NOT RUN',newRenders=0,sourceEdits=0,proofProposals=[dict(id=1,start=108,end=124,seconds=16,frames=384),dict(id=2,start=185,end=209,seconds=24,frames=576),dict(id=3,start=209,end=228,seconds=19,frames=456)],cameraEventJumps=len(hard),cameraFrameFlags=summary['cameraReviewFlags'],S04='PASS/CLOSED unchanged',humanFinalAcceptance='NOT_GRANTED'))
print(json.dumps(dict(reports=6,sourceExcerpts=len(srcIndex),steps=12,P0new=0,P1=5,P2=1,proofProposals=3,newRenders=0),indent=2))
