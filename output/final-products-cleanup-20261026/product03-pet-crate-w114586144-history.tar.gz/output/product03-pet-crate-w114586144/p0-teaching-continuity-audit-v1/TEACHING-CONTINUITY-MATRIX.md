# S05–S16 teaching/continuity matrix

Milestone: PRODUCT03-P0-TEACHING-CONTINUITY-AUDIT-V1. **READ-ONLY AUDIT COMPLETE — DIRECTOR REVIEW REQUIRED.** Baseline: accepted S04 Integration V2,278s. S04 PASS is not reopened.

Evidence classes: **D** local manual image; **S** executable source/numerical trace; **V** existing rendered evidence; **U** not established. A numerical state PASS is not motion/teaching approval. All numeric positions are display units, not OEM measurements.

12/12 steps;14 newly introduced numbered component instances across18 body events;66 accessory operations = D27+C18+F8+E8+A5, including61 threaded cycles and5 foot preparations. Together with the18 earlier accessory units this gives84 initial-seat display states by228s. Source inventory remains20components/100accessories+3tools/19steps.

| Step / V2 time | Local manual PDF/printed | Structural association | Current hardware / tool | Model state | Teaching verdict |
|---|---|---|---|---|---|
| S05 / 69–85s | 6/5 | 13 → retained 9/10 rear edges | D×7 / L | Retained numerically; receivers U | T01/T02; no whole-step motion acceptance |
| S06 / 85–104s | 6/5 | 15 → lower edges of10/11/12 | D×10 / L | Retained numerically; receivers U | T01/T02; motion evidence gap |
| S07 / 104–112s | 7/6 | A1–5 → prepared1/2/5 | A×5 / no tool | Retained numerically; receivers U | T03/T05; wide staging composition needs proof |
| S08 / 112–132s | 7/6 | frames1/2 → retained upper module | D×10 / L | Retained numerically; receivers U | T01/T03/T05; proposed proof1 |
| S09 / 132–144s | 8/7 | rear frame4 → side frames1/2 | C×4 / L | Retained numerically; receivers U | T01/T02; source qualitative, receivers unknown |
| S10 / 144–154s | 8/7 | F1–4 → rear4 / reconstructed13 joint | F×4 / M | Retained numerically; receivers U | T01/T04; do not reopen accepted F geometry |
| S11 / 154–164s | 9/8 | front header3 → side frames1/2 | C×4 / L | Retained numerically; receivers U | T01/T02; no independent motion proof |
| S12 / 164–173s | 9/8 | F5–8 → header3 / reconstructed15 joint | F×4 / M | Retained numerically; receivers U | T01/T02/T04; largest sampled camera cut at172.5 |
| S13 / 173–189s | 10/9 | four rails6 → rear4; opposite ends not yet captured | C×4 / L | Retained numerically; receivers U | T01/T05; proposed proof2. Do not promote C allocation |
| S14 / 189–203s | 10/9 | prepared5+A5 → four6 ends and side posts | C×6 / L | Retained numerically; receivers U | T03/T05; proposed proof2; no certified access/path |
| S15 / 203–209s | 11/10 | floor14 → supports6, no new fastener | none / no tool | Retained numerically; receivers U | T03; proposed proof2; no invented floor screw |
| S16 / 209–228s | 11/10 | doors7/8 and existing hinge constituents → frames1/2 | E×8 / M | Retained numerically; receivers U | T01/T05; proposed proof3. Hinge retention/access remain unverified |

## S05 / 69–85s

Rear-normal Z approach69.25–71.25; front face of13 contacts existing rear edges. D13–19 enter from the exterior rear face, then L.
Contact before D starts71.6 (0.35s hold). Seven sequential D retained.
Evidence: Accepted10s S05 proof shows ONE D13 exemplar, not all7 integrated cycles. New V2 clip39–75 covers panel placement/part of first cycle only.
Assessment: T01/T02; no whole-step motion acceptance.
Local references: evidence/OEM-PDF-P06.png; evidence/EXISTING-V2-S05-endpoint.png; OPERATION-EVIDENCE.json/S05; CONNECTION-TARGET-CROSSWALK.json/step5.
Cadence: first threaded slot3.225000s; shortest repeat1.612500s. Generic tool-free hold is only3% of each slot (0.048375s minimum). No new motion verdict inferred.

## S06 / 85–104s

15 rises85.25–87.25; upper face meets retained edges. D20–29 approach from underside, then L.
Contact before D87.6 (0.35s). Ten D retained.
Evidence: Accepted10s S06 proof shows ONE D20 exemplar. Existing V2 endpoint is static; it does not prove ten rapid operations.
Assessment: T01/T02; motion evidence gap.
Local references: evidence/OEM-PDF-P06.png; evidence/EXISTING-V2-S06-endpoint.png; OPERATION-EVIDENCE.json/S06; CONNECTION-TARGET-CROSSWALK.json/step6.
Cadence: first threaded slot2.890909s; shortest repeat1.445455s. Generic tool-free hold is only3% of each slot (0.043364s minimum). No new motion verdict inferred.

## S07 / 104–112s

1/2/5 introduced as prepared components104.15; A1–5 seat sequentially104.6–110.9. No L/M/O action is authored.
Frames remain prepared untilS08;5+A5 remain staged untilS14. No independent foot teleport found.
Evidence: OEM PDFp7; V2 S07 endpoint; prepared-foot relative transforms.
Assessment: T03/T05; wide staging composition needs proof.
Local references: evidence/OEM-PDF-P07.png; evidence/EXISTING-V2-S07-endpoint.png; OPERATION-EVIDENCE.json/S07; CONNECTION-TARGET-CROSSWALK.json/step7.

## S08 / 112–132s

Whole-rig180° staging112–113.4; left frame approaches113.5–115.5, right115.5–117.5; outer-post D30–39 begin117.9, then L.
All10D after both frames reach modeled contact. Prepared feet follow their host; both K/B pairs persist.
Evidence: Accepted10s S08 proof is one right-side D35 example with a static inverted rig. It does not prove this turnover/ten-operation cadence.
Assessment: T01/T03/T05; proposed proof1.
Local references: evidence/OEM-PDF-P07.png; evidence/EXISTING-V2-S08-endpoint.png; OPERATION-EVIDENCE.json/S08; CONNECTION-TARGET-CROSSWALK.json/step8.
Cadence: first threaded slot2.472727s; shortest repeat1.236364s. Generic tool-free hold is only3% of each slot (0.037091s minimum). No new motion verdict inferred.

## S09 / 132–144s

4 approaches from rear132.25–134.25; ends meet side-frame inner planes. C1–4 from outer side-post faces then L.
C1 starts134.6,0.35s after contact; four C remain installed.
Evidence: OEM PDFp8; corrected frame4/rail proof genealogy; V2 S09 endpoint; no complete current S09 motion clip.
Assessment: T01/T02; source qualitative, receivers unknown.
Local references: evidence/OEM-PDF-P08.png; evidence/EXISTING-V2-S09-endpoint.png; OPERATION-EVIDENCE.json/S09; CONNECTION-TARGET-CROSSWALK.json/step9.
Cadence: first threaded slot3.560000s; shortest repeat1.780000s. Generic tool-free hold is only3% of each slot (0.053400s minimum). No new motion verdict inferred.

## S10 / 144–154s

Previously placed rear/module held. F1–4 sequentially144.75–153.5; M approaches/engages/withdraws. Axis is the explicitly accepted NONLITERAL lateral reconstruction.
No structural reset. This is initial symbolic seating, not proven source “lock firmly” torque.
Evidence: Accepted12s S10 F proof shows ONE exemplar, not this compressed four-cycle integration. PDFp8 firm-lock intent retained as source evidence.
Assessment: T01/T04; do not reopen accepted F geometry.
Local references: evidence/OEM-PDF-P08.png; evidence/EXISTING-V2-S10-endpoint.png; OPERATION-EVIDENCE.json/S10; CONNECTION-TARGET-CROSSWALK.json/step10.
Cadence: first threaded slot3.500000s; shortest repeat1.750000s. Generic tool-free hold is only3% of each slot (0.052500s minimum). No new motion verdict inferred.

## S11 / 154–164s

3 approaches from front154.25–156.25. C5–8 enter external post faces from156.6 with L; header/tab orientation must remain source-consistent.
Existing rear/F state retained; four C installed sequentially.
Evidence: OEM PDFp9 direction inset; V2 S11 endpoint; current source approach/camera rules.
Assessment: T01/T02; no independent motion proof.
Local references: evidence/OEM-PDF-P09.png; evidence/EXISTING-V2-S11-endpoint.png; OPERATION-EVIDENCE.json/S11; CONNECTION-TARGET-CROSSWALK.json/step11.
Cadence: first threaded slot2.760000s; shortest repeat1.380000s. Generic tool-free hold is only3% of each slot (0.041400s minimum). No new motion verdict inferred.

## S12 / 164–173s

F5–8 sequentially164.75–172.5, using M. Front association is accepted NONLITERAL F construction, not a recovered OEM receiver/axis.
Retains header and all earlier parts. Initial-seat display does not certify final tightening.
Evidence: Accepted12s S12 F exemplar; PDFp9 firm-lock intent; V2 endpoint.
Assessment: T01/T02/T04; largest sampled camera cut at172.5.
Local references: evidence/OEM-PDF-P09.png; evidence/EXISTING-V2-S12-endpoint.png; OPERATION-EVIDENCE.json/S12; CONNECTION-TARGET-CROSSWALK.json/step12.
Cadence: first threaded slot3.100000s; shortest repeat1.550000s. Generic tool-free hold is only3% of each slot (0.046500s minimum). No new motion verdict inferred.

## S13 / 173–189s

6-1 approaches173.25–175.25, C9 begins175.45. Further rails179.5–180.75,182.5–183.75,185.5–186.75; C10/11/12 start0.2s after contact. L follows.
Rails retain their local poses through S14/S15. Four C total; chosen rear-end ownership is an explicit HYPOTHESIS.
Evidence: OEM PDFp10; accepted focused rail exterior proof; V2 S13 endpoint; source timing evidence.
Assessment: T01/T05; proposed proof2. Do not promote C allocation.
Local references: evidence/OEM-PDF-P10.png; evidence/EXISTING-V2-S13-endpoint.png; OPERATION-EVIDENCE.json/S13; CONNECTION-TARGET-CROSSWALK.json/step13.
Cadence: first threaded slot3.800000s; shortest repeat1.300000s. Generic tool-free hold is only3% of each slot (0.039000s minimum). No new motion verdict inferred.

## S14 / 189–203s

5 moves laterally outside the front posts189.25–190.75, then inward in depth190.75–192.25. C13–18 begin192.6 with L.
A5 host-relative offset remains fixed. C13–16 → rail6 ends / C17–18 →5 ends is the declared unverified allocation; not an OEM rule.
Evidence: OEM PDFp10 direction inset; old V1 route checkpoints; V2 S14 endpoint; numerical edge cases.
Assessment: T03/T05; proposed proof2; no certified access/path.
Local references: evidence/OEM-PDF-P10.png; evidence/EXISTING-V2-S14-endpoint.png; OPERATION-EVIDENCE.json/S14; CONNECTION-TARGET-CROSSWALK.json/step14.
Cadence: first threaded slot2.828571s; shortest repeat1.414286s. Generic tool-free hold is only3% of each slot (0.042429s minimum). No new motion verdict inferred.

## S15 / 203–209s

Whole rig returns upright203–205. Floor14 lowers205.15–207.15; support contact at modeled underside, then hold to209. No screw/tool.
All earlier members retained. Remaining floor-support/load/lifting details are unverified.
Evidence: OEM PDFp11; accepted6s floor proof is a static upright exemplar, not V2 turnover.
Assessment: T03; proposed proof2; no invented floor screw.
Local references: evidence/OEM-PDF-P11.png; evidence/EXISTING-V2-S15-endpoint.png; OPERATION-EVIDENCE.json/S15; CONNECTION-TARGET-CROSSWALK.json/step15.

## S16 / 209–228s

Door7 approaches209.25–211.25; E1–4 run211.6–218.25 with M. Door8 approaches218.75–220.75; E5–8 run221.1–227.75.
Eight E follow both respective door contacts. First door and E1–4 persist during second. Four hinge groups are factory constituents, not extra OEM parts. Current V2 pivots remain0; no swing demonstrated.
Evidence: OEM PDFp11, accepted limited static hinge hypothesis, V2 S16 endpoint and numerical door/pivot evidence. Old D1 swing is historical, not V2 evidence.
Assessment: T01/T05; proposed proof3. Hinge retention/access remain unverified.
Local references: evidence/OEM-PDF-P11.png; evidence/EXISTING-V2-S16-endpoint.png; OPERATION-EVIDENCE.json/S16; CONNECTION-TARGET-CROSSWALK.json/step16.
Cadence: first threaded slot2.660000s; shortest repeat1.330000s. Generic tool-free hold is only3% of each slot (0.039900s minimum). No new motion verdict inferred.

## Cross-step result

Existing evaluator evaluated at24Hz over69–228s:3,817 samples; finite transforms, installed visibility/local-pose retention, deterministic seek and prepared-foot tracking pass. All modeled relevant target contacts precede current hardware, including door7/8 before their E groups. Zero retained-actor local-pose changes at the analyzed event boundaries. See MOTION-SCAN-SUMMARY.json and CONNECTION-TARGET-CROSSWALK.json. No new collision sweep, images, videos or runtime edits.

Existing step endpoints were made with camera(overview=true). They show product state; they do not establish the macro camera used during current motion. READABILITY-PROXIES.json uses the actual default motion camera: all427 tested anchor projections are inside frustum; first ray hits are the active screw or its tool, not unrelated geometry. This does not certify the whole interface, perceptual clarity, every pixel/time, or hand access.
