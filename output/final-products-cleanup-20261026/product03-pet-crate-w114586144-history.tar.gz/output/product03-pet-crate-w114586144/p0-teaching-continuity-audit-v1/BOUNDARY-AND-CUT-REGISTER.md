# Boundaries, cuts and staging register

Read-only V2 evaluation. Times below are global V2 seconds. At every listed step boundary and analyzed operation event, retained actor local transforms remain unchanged. Whole-rig presentation rotation is distinguished from a local component reset. Numerical results are not a visual cut-approval verdict.

| Boundary | Incoming/outgoing context | Retention / risk |
|---|---|---|
| 69.000000s | Accepted S04→S05 macro/wide change; do not reopen S04. | No retained local reset; camera delta1613.818units/47.199° |
| 85.000000s | 13/D7 retained;15 first introduced at85.25. | No retained local reset; camera delta0.000units/0.000° |
| 104.000000s | 15/D10 retained;prepared1/2/5 introduced104.15, auto-fit camera change. | No retained local reset; camera delta0.000units/0.000° |
| 112.000000s | Prepared feet retained;180° turn112–113.4, no physical lift claim. | No retained local reset; camera delta0.000units/0.000° |
| 132.000000s | Frames/D10 retained;rear4 introduced132.25. | No retained local reset; camera delta0.000units/0.000° |
| 144.000000s | Rear/C4 retained;F begins144.75, NONLITERAL. | No retained local reset; camera delta0.000units/0.000° |
| 154.000000s | RearF retained;front3 introduced154.25. | No retained local reset; camera delta0.000units/0.000° |
| 164.000000s | Front3/C4 retained;frontF begins164.75, NONLITERAL. | No retained local reset; camera delta0.000units/0.000° |
| 173.000000s | F8 retained;first6 introduced173.25, C allocation hypothesis. | No retained local reset; camera delta0.000units/0.000° |
| 189.000000s | Four6 retained;prepared5/A5 staged route189.25 onward. | No retained local reset; camera delta0.000units/0.000° |
| 203.000000s | Carrier/C6 retained;return upright203–205. | No retained local reset; camera delta0.000units/0.000° |
| 209.000000s | Floor14 retained;firstdoor starts209.25. | No retained local reset; camera delta0.000units/0.000° |
| 228.000000s | Bothdoors/E8 retained;S17 exterior stack is still pose-only. | No retained local reset; camera delta0.000units/0.000° |

## Operation-event camera register

The existing V1 CAMERA-CUT-REGISTER.json covers only its actual S01/S04 diagnostic clips; it is not a complete camera-cut ledger for V2. This audit supplies BOUNDARY-AND-EVENT-EVIDENCE.json for all selected body/hardware starts/ends and CAMERA-REVIEW-FLAGS.json for the24Hz scan. No camera authored.

83 event-local jumps above1unit, including69s;130 frame-sampled review flags. Diagnostic criteria only, not OEM tolerances or automatic defects. All117 analyzed event timestamps and all raw entries are retained.

| t | Step | Start / end | Position jump | Rotation jump |
|---|---|---|---|---|
| 69.000000 | S05 | staging | 1613.818 display units | 47.199° |
| 69.250000 | S05 | part-13-1 | 46.739 display units | 0.000° |
| 71.600000 | S05 | hardware-D-13 | 2088.992 display units | 178.996° |
| 74.825000 | S05 | hardware-D-14,hardware-D-13 | 558.000 display units | 0.000° |
| 76.437500 | S05 | hardware-D-15,hardware-D-14 | 558.000 display units | 0.000° |
| 78.050000 | S05 | hardware-D-16,hardware-D-15 | 1130.761 display units | 0.000° |
| 79.662500 | S05 | hardware-D-17,hardware-D-16 | 76.000 display units | 0.000° |
| 81.275000 | S05 | hardware-D-18,hardware-D-17 | 1136.544 display units | 0.000° |
| 82.887500 | S05 | hardware-D-19,hardware-D-18 | 76.000 display units | 0.000° |
| 84.500000 | S05 | hardware-D-19 | 2679.518 display units | 178.996° |
| 85.250000 | S06 | part-15-1 | 35.000 display units | 0.000° |
| 87.600000 | S06 | hardware-D-20 | 1760.153 display units | 132.042° |
| 90.490909 | S06 | hardware-D-21,hardware-D-20 | 265.000 display units | 0.000° |
| 91.936364 | S06 | hardware-D-22,hardware-D-21 | 461.637 display units | 0.000° |
| 93.381818 | S06 | hardware-D-23,hardware-D-22 | 265.000 display units | 0.000° |
| 94.827273 | S06 | hardware-D-24,hardware-D-23 | 461.637 display units | 0.000° |
| 96.272727 | S06 | hardware-D-25,hardware-D-24 | 265.000 display units | 0.000° |
| 97.718182 | S06 | hardware-D-26,hardware-D-25 | 461.637 display units | 0.000° |
| 99.163636 | S06 | hardware-D-27,hardware-D-26 | 265.000 display units | 0.000° |
| 100.609091 | S06 | hardware-D-28,hardware-D-27 | 966.392 display units | 0.000° |
| 102.054545 | S06 | hardware-D-29,hardware-D-28 | 700.000 display units | 0.000° |
| 103.500000 | S06 | hardware-D-29 | 2296.732 display units | 132.042° |
| 104.150000 | S07 | part-1-1,part-2-1,part-5-1 | 1589.737 display units | 0.000° |
| 117.900000 | S08 | hardware-D-30 | 2672.926 display units | 91.088° |
| 120.372727 | S08 | hardware-D-31,hardware-D-30 | 190.000 display units | 0.000° |
| 121.609091 | S08 | hardware-D-32,hardware-D-31 | 190.000 display units | 0.000° |
| 122.845455 | S08 | hardware-D-33,hardware-D-32 | 146.492 display units | 0.000° |
| 124.081818 | S08 | hardware-D-34,hardware-D-33 | 76.000 display units | 0.000° |
| 125.318182 | S08 | hardware-D-35,hardware-D-34 | 1980.639 display units | 180.000° |
| 126.554545 | S08 | hardware-D-36,hardware-D-35 | 190.000 display units | 0.000° |
| 127.790909 | S08 | hardware-D-37,hardware-D-36 | 190.000 display units | 0.000° |
| 129.027273 | S08 | hardware-D-38,hardware-D-37 | 146.492 display units | 0.000° |
| 130.263636 | S08 | hardware-D-39,hardware-D-38 | 76.000 display units | 0.000° |
| 131.500000 | S08 | hardware-D-39 | 3475.634 display units | 89.081° |
| 132.250000 | S09 | part-4-1 | 55.000 display units | 0.000° |
| 134.600000 | S09 | hardware-C-1 | 2303.784 display units | 91.088° |
| 138.160000 | S09 | hardware-C-2,hardware-C-1 | 682.000 display units | 0.000° |
| 139.940000 | S09 | hardware-C-3,hardware-C-2 | 1940.966 display units | 180.000° |
| 141.720000 | S09 | hardware-C-4,hardware-C-3 | 682.000 display units | 0.000° |
| 143.500000 | S09 | hardware-C-4 | 3067.582 display units | 89.081° |
| 144.750000 | S10 | hardware-F-1 | 2138.367 display units | 4.514° |
| 148.250000 | S10 | hardware-F-2,hardware-F-1 | 300.000 display units | 0.000° |
| 150.000000 | S10 | hardware-F-3,hardware-F-2 | 300.000 display units | 0.000° |
| 151.750000 | S10 | hardware-F-4,hardware-F-3 | 300.000 display units | 0.000° |
| 153.500000 | S10 | hardware-F-4 | 2574.993 display units | 4.514° |
| 154.250000 | S11 | part-3-1 | 13.000 display units | 0.000° |
| 156.600000 | S11 | hardware-C-5 | 3018.719 display units | 91.088° |
| 159.360000 | S11 | hardware-C-6,hardware-C-5 | 32.000 display units | 0.000° |
| 160.740000 | S11 | hardware-C-7,hardware-C-6 | 1817.484 display units | 180.000° |
| 162.120000 | S11 | hardware-C-8,hardware-C-7 | 32.000 display units | 0.000° |
| 163.500000 | S11 | hardware-C-8 | 3434.653 display units | 89.081° |
| 164.750000 | S12 | hardware-F-5 | 3271.826 display units | 178.996° |
| 167.850000 | S12 | hardware-F-6,hardware-F-5 | 300.000 display units | 0.000° |
| 169.400000 | S12 | hardware-F-7,hardware-F-6 | 300.000 display units | 0.000° |
| 170.950000 | S12 | hardware-F-8,hardware-F-7 | 300.000 display units | 0.000° |
| 172.500000 | S12 | hardware-F-8 | 3676.795 display units | 178.996° |
| 175.450000 | S13 | hardware-C-9 | 1927.508 display units | 4.514° |
| 179.250000 | S13 | hardware-C-9 | 1927.508 display units | 4.514° |
| 180.950000 | S13 | hardware-C-10 | 2034.686 display units | 4.514° |
| 182.250000 | S13 | hardware-C-10 | 2034.686 display units | 4.514° |
| 183.950000 | S13 | hardware-C-11 | 2161.827 display units | 4.514° |
| 185.250000 | S13 | hardware-C-11 | 2161.827 display units | 4.514° |
| 186.950000 | S13 | hardware-C-12 | 2305.631 display units | 4.514° |
| 188.250000 | S13 | hardware-C-12 | 2305.631 display units | 4.514° |
| 192.600000 | S14 | hardware-C-13 | 2280.998 display units | 178.996° |
| 195.428571 | S14 | hardware-C-14,hardware-C-13 | 233.333 display units | 0.000° |
| 196.842857 | S14 | hardware-C-15,hardware-C-14 | 233.333 display units | 0.000° |
| 198.257143 | S14 | hardware-C-16,hardware-C-15 | 233.333 display units | 0.000° |
| 199.671429 | S14 | hardware-C-17,hardware-C-16 | 1446.740 display units | 90.000° |
| 201.085714 | S14 | hardware-C-18,hardware-C-17 | 1817.202 display units | 180.000° |
| 202.500000 | S14 | hardware-C-18 | 2528.978 display units | 89.081° |
| 209.250000 | S16 | part-7-1 | 61.500 display units | 0.000° |
| 211.600000 | S16 | hardware-E-1 | 1252.923 display units | 4.514° |
| 214.260000 | S16 | hardware-E-2,hardware-E-1 | 16.000 display units | 0.000° |
| 215.590000 | S16 | hardware-E-3,hardware-E-2 | 430.000 display units | 0.000° |
| 216.920000 | S16 | hardware-E-4,hardware-E-3 | 16.000 display units | 0.000° |
| 218.250000 | S16 | hardware-E-4 | 1017.051 display units | 4.514° |
| 218.750000 | S16 | part-8-1 | 55.000 display units | 0.000° |
| 221.100000 | S16 | hardware-E-5 | 1913.454 display units | 4.514° |
| 223.760000 | S16 | hardware-E-6,hardware-E-5 | 16.000 display units | 0.000° |
| 225.090000 | S16 | hardware-E-7,hardware-E-6 | 430.000 display units | 0.000° |
| 226.420000 | S16 | hardware-E-8,hardware-E-7 | 16.000 display units | 0.000° |
| 227.750000 | S16 | hardware-E-8 | 1768.017 display units | 4.514° |

## Required edge cases

- Seek: exact repeated hashes pass after forward/backward/camera calls; explicit ±1µs event neighborhoods recorded. Equality criteria1e-8/1e-7 are software comparisons, not collision tolerance changes.
- Offscreen ≠ hidden: at119.4s prepared5/A5 have visible=true despite anchor outside macro frustum. No false disappearance report.
- Feet: all5 host-relative offsets unchanged through preparation, inversion, late carrier approach and return.
- F: source firm-lock intent remains; current action means symbolic initial seating. Explicit nonliteral qualifier required in any future proof.
- Cuts: active target anchors in427 sampled views lie in frustum. Expected tool-first ray hits are not unrelated occlusion defects. This is not a complete pixel/hand-access proof.
- Doors/hinges: current pivot rotation0; two translational placements/E groups. Historical35° demonstration is not current approved motion.
- Repetition: all61 threaded operations exist and retain final state; counts alone do not establish comprehension.
