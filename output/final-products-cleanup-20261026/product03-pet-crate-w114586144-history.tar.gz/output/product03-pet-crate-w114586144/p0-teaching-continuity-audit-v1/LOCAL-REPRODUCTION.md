# Local reproduction / no rendering

Existing local Node/tsx and Three are used; no package installation or network calls. From repository root:

```sh
node --import tsx output/product03-pet-crate-w114586144/p0-teaching-continuity-audit-v1/audit.ts
node --import tsx output/product03-pet-crate-w114586144/p0-teaching-continuity-audit-v1/edge-cases.ts
```

The helpers only evaluate existing product transforms/cameras and write numerical JSON in this isolated output directory. They do not create a renderer/browser, render frames or modify product/engine sources. The accepted V2 and dependent frozen sources are read. Numerical equality criteria are not mechanical tolerances. Do not rerun after freezing without a new output revision; preserve actual reviewed data.

Read SOURCE-EXCERPTS.md and SOURCE-EVIDENCE-INDEX.json for frozen application-source lines/hashes. READ-ONLY-BASELINE.json records118 source/engine hashes before analysis. PROTECTED-ASSET-VERIFICATION.json records post-analysis unchanged files/proofs and source PDF. Original helper bad-import log retained separately from successful execution. Existing image copies are byte-identical; no fresh motion clips exist for the proposed59s.
