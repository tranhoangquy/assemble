from pathlib import Path
import json,hashlib,zipfile,datetime
P=Path(__file__).resolve().parent;B=P.parent;ROOT=P.parents[2]
def load(f):return json.loads(Path(f).read_text())
def sha(f):
 h=hashlib.sha256()
 with Path(f).open('rb')as s:
  for b in iter(lambda:s.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(n,v):(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
baseline=load(P/'evidence/READ-ONLY-BASELINE.json');changes=[f for f,h in baseline['files'].items()if sha(ROOT/f)!=h];assert not changes
manual=B/'phase-a-v1/source/human-provided-pet-crate-manual.pdf';assert sha(manual)==baseline['manualSha256']=='70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29'
protected=load(B/'phase-a-v1/evidence/protected-baseline.json');assert all((ROOT/f).exists()and sha(ROOT/f)==h for f,h in protected.items());historical=[]
for manifest in B.glob('*/REVIEW-DELIVERY-MANIFEST.json'):
 if manifest.parent==P:continue
 for r in load(manifest):
  f=Path(r['path']);f=f if f.is_absolute()else manifest.parent/f;assert sha(f)==r['sha256'];historical.append(dict(revision=manifest.parent.name,file=f.name,match=True))
frozen=[]
for rev,name in [('f-illustrative-proof-v1','FROZEN-LOCAL-PROOF.json'),('part-first-sequence-v1','FROZEN-FOCUSED-PROOF.json'),('timeline-integration-plan-v1','FROZEN-INTEGRATION-PLAN.json'),('timeline-integration-v1','FROZEN-INTEGRATION-EVIDENCE.json'),('s04-two-bolt-proof-v1','FROZEN-S04-PROOF.json'),('s04-integration-v2','FROZEN-INTEGRATION-V2.json')]:
 for f,h in load(B/rev/name)['files'].items():assert sha(f)==h
 frozen.append(rev)
for r in load(P/'EXISTING-EVIDENCE-MANIFEST.json'):
 assert sha(P/r['artifact'])==r['sha256'];source=Path(r['source']);source=source if source.is_absolute()else ROOT/source;assert sha(source)==r['sha256']
save('PROTECTED-ASSET-VERIFICATION.json',dict(status='PASS',readOnlySourceEngineFiles=len(baseline['files']),sourceChanges=changes,protectedPaths=len(protected),protectedChanges=0,historicalDeliveryFiles=len(historical),frozenProofs=frozen,manualSha256=sha(manual),existingEvidenceByteCopies=len(load(P/'EXISTING-EVIDENCE-MANIFEST.json')),newProductRenders=0,newVideoAudio=0,Product01='UNCHANGED',JULIETTE='UNCHANGED',S04V2='PASS/CLOSED unchanged'))
o=load(P/'OPERATION-EVIDENCE.json');a=load(P/'ANALYSIS-SUMMARY.json');results=load(P/'AUDIT-RESULTS.json');assert [s['number']for s in o['steps']]==list(range(5,17));assert len(o['hardware'])==66
for s in o['steps']:
 for code,count in s['source']['hardware'].items():assert sum(h['id'].split('-')[1]==code and h['step']==s['number']for h in o['hardware'])==count
assert all(a[k]for k in ['finite','retainedVisible','retainedLocal','deterministic','feetFollow']);assert len(results['proofProposals'])==3 and sum(x['seconds']for x in results['proofProposals'])==59
assert all(not r['retainedActorChanges']for r in load(P/'BOUNDARY-AND-EVENT-EVIDENCE.json'))
assert all(r['anchorInFrustum']for v in load(P/'READABILITY-PROXIES.json')for r in v['rows'])
docs=['TEACHING-CONTINUITY-MATRIX.md','P0-P2-FINDINGS.md','BOUNDARY-AND-CUT-REGISTER.md','TARGETED-PROOF-PLAN.md','ASSUMPTION-AND-HOLD-REGISTER.md','DIRECTOR-REVIEW.md'];assert all((P/n).stat().st_size>1000 for n in docs)
save('AUDIT-QA.json',dict(status='PASS — documentary/numerical audit completeness; Director review pending',coverage=12,accessoryOperations=66,threaded=61,numericalSamples=3817,requiredMarkdownFiles=docs,newVerifiedP0=0,P1=5,P2=1,proposals=3,scopeChecks=dict(sourceEdits=0,newRenders=0,newVideos=0,newAudio=0,newResearch=0),physicalQA='NOT RUN; prior source/physical holds unchanged',visualWholeProduct='NOT ACCEPTED',helperExecution='Final numerical and edge-case helpers completed; initial bad relative import path preserved separately. No application source/engine tests or build needed for read-only output-only analysis.'))
save('RESEARCH-AND-EXECUTION-BOUNDARY.json',dict(product03Only=True,localEvidenceOnly=True,externalException='Existing ChatGPTWeb Assemble communication only',rendererInvocations=0,softwareInstalls=0,sourceMutations=0,newGeometryDesign=0,newSourceAcquisition=0,financialActions=0,publishing=0,stop='After actual Director audit decision; do not execute proposed proofs'))
files=sorted({*docs,*[f.name for f in P.glob('*.json')if f.name not in ['PAYLOAD-SHA256.json','REVIEW-DELIVERY-MANIFEST.json']], 'SOURCE-EXCERPTS.md',*[str(f.relative_to(P))for f in (P/'evidence').glob('*')if f.is_file()and f.name!='package.log']})
payload=[dict(path=n,bytes=(P/n).stat().st_size,sha256=sha(P/n))for n in files];save('PAYLOAD-SHA256.json',payload)
z=P/'PRODUCT03-P0-teaching-continuity-audit-v1-review.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED)as a:
 for n in files+['PAYLOAD-SHA256.json']:a.write(P/n,n)
with zipfile.ZipFile(z)as a:assert all(hashlib.sha256(a.read(r['path'])).hexdigest()==r['sha256']for r in payload)
delivery=[z,*[P/n for n in docs]];save('REVIEW-DELIVERY-MANIFEST.json',[dict(path=str(f),bytes=f.stat().st_size,sha256=sha(f))for f in delivery]);(P/'DELIVERY-SHA256.txt').write_text(''.join(f'{sha(f)}  {f.name}\n'for f in delivery))
print(json.dumps(dict(status='READY FOR ACTUAL DIRECTOR REVIEW',zip=z.name,bytes=z.stat().st_size,sha256=sha(z),payloads=len(payload),attachments=len(delivery),sourceFilesUnchanged=len(baseline['files']),protectedPathsUnchanged=len(protected),historicalFilesUnchanged=len(historical),newProductRenders=0),indent=2))
