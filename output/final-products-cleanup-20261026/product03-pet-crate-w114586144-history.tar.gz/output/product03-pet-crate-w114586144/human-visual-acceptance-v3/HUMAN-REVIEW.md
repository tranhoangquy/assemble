# READY FOR HUMAN FINAL REVIEW — NOT YET ACCEPTED

[Long V4 — 278s](PRODUCT03-Long-V4-278s-SILENT-720p.mp4)

[Short V2 — 59s, unchanged](PRODUCT03-Short-V2-59s-SILENT-1080x1920.mp4)

Long V4 changes only C16 camera197.25–200.65s; view arrives198.35 before screw approach198.422286 and remains through tool withdrawal. All8238 native frames outside the camera window are byte-identical to LongV3. ShortV2 is completely byte-identical to its previously reviewed original. No audio, geometry, fastening, count or timing change.

Actual Creative Director proof and final-review responses retained in this package. Review uses actual sampled frames + metadata/integrity/full decode evidence, not a claim of continuous human playback. Director noted the brief orbit is a little quick but acceptable. Human sole final acceptance authority.

All existing mechanical OPEN/HOLD/POSE_ONLY limitations, nonliteral F, unmeasured K, unresolved C13/C14 and I/J, door attachment OPEN, S19 HOLD and historical raw collision FAIL remain. No physical installation, tool access, torque, hinge retention/function or load certification. Previous three visual corrections preserved. See LIMITATIONS.md and QA. No publication authorized.
