# Product03 — Long V3 / Short V2

**READY FOR HUMAN FINAL REVIEW — NOT YET ACCEPTED**

Director đã review nội bộ hai phim sửa và cho phép bàn giao. Chỉ bạn có quyền nghiệm thu cuối cùng. Cả hai bản đều SILENT; không có nhạc/âm thanh và chưa công bố.

- Long V3:278giây,1280×720/30fps,8340frame.
- Short V2:59giây,native1080×1920/30fps,1770frame.

## Ba vấn đề đã xử lý

1. **Bản lề:** giữ đúng8vítE theo manual,2vít trên mỗi lá khung được minh họa. Bỏ các lỗ ở lá phía cửa chưa có bằng chứng; không tự thêm8vít. **Phương pháp liên kết lá với cánh cửa vẫn OPEN; chức năng cửa HOLD.** Phim không tuyên bố cửa đã giữ chắc hay hoạt động được.
2. **Chân A:** sửa đồng nhất A1–A5: thân hướng vào host,đĩa ở ngoài theoS07. Giữ vị trí/host và trình tự; không tự tạo ren/lỗ nhận hoặc xác nhận chịu lực.
3. **Bốn chấm:** là4miếng EVA N1–N4 đang để riêng. Có nhãn **HELD / NOT INSTALLED**, không tự gắn vào cửa.

Vùng xem lại: Long104–112s,189–207s,208.5–228s,262–278s; Short31.7–34.1s,44.6–52.8s,54.27–59s. Cảnh mở Short cũng ghi giới hạn cửa.

Camera/timing giữ nguyên.3138frameLong và891frameShort thuộc vùng chưa sửa giống từngbyte với bản cũ. HaiMP4 qua framecount/PTS/full decode/noaudio/faststart; bằng chứng QA và quyết định thật của Director đi kèm. Review hình ảnh của agent và Director là lấy mẫu, không thay cho việc bạn xem hai phim.

Toàn bộ baseline/phim cũ, manual và lịch sử QA vẫn giữ nguyên. Product01/JULIETTE không đổi. Các giới hạn KUNMEASURED,FNONLITERAL,C13/C14,I/JOPEN,S17/S18POSE_ONLY,S19HOLD,rawcollisionFAIL và đính chínhS14 vẫn có hiệu lực. Xem LIMITATIONS.md.

Không coi Director PASS là HUMAN FINAL ACCEPTANCE hoặc chứng nhận cơ khí.
