# Timeline choices — proposals only

**No choice implemented or silently selected.** Numeric precision below is display-clock arithmetic, not OEM dimensions/tolerances. All active motion paths, durations, tool axes, installed positions and19 OEMdependency order must remain unchanged.

## OptionN — preserve278seconds

| Item | Baseline | Proposed | Donor / downstream consequence |
|---|---|---|---|
|D30tool-freehold|0.074182s|0.25s;end120.548545|+0.175818182s; D31–39shift equally; lastD39end131.675818; trailingstaticwait0.324182; S08end132unchanged|
|C13 tool-freehold|0.084857s|0.25s;end195.593714|+0.165142857s; C14–18shift equally; lastC18end202.665143; trailingstaticwait0.334857; S14end203unchanged|
|S15floor|205.15–207.15motion; holdto209|Same motion; holdto208.375|Donate0.625s of1.85sstaticfloorcontext;1.225sretained|
|S15/S16boundary|209|208.375|S16duration19→19.625s; S16end228 and everylaterboundary unchanged|
|S16intro|0.25s|0.125s|Donate0.125s, positiveinterval; no source clockjump or hidden actor reset|
|Doorcontacts beforefirst E|0.35s each|0.25s each|Donate0.2s total; contact still precedes screw/tool|
|E1/E5tip-aligned waiting|0.266s each|0.141s each|Donate0.25s total from stationary tipwait, not tool travel/feed/withdrawal|
|E2/E6tool-freehold|0.0399s each|0.25s each|Add0.4202s total;6native frames per hold|
|E4→door8handover afterE4end|0.5s|0.7101s|Toolclear0.25s plus0.5s visible pullback fits without hidingdoor8placement|
|S16final staticcontext|0.25s|0.8197s|E8tool clear227.1404→227.3904hold; returnwide227.3904–227.8904; settleto228|

S16balance: −0.125intro −0.2contact −0.25tipwait +0.4202holds +0.2101handover +0.5697finalcontext = **+0.625s**, exactly thefloor-taildonation. No moving phase becomes faster. The proposed fullscene time map must be strictlycontinuous/monotone, with positive intervals; a collapsed interval or independent actorclock is FAIL. TIMING-OPTIONS.json lists every old/new S16subphase for audit.

| Operation | Oldstart–end | ProposedNstart–end | Ntool fullywithdrawn |
|---|---|---|---|
|Door7placement|209.25–211.25|208.5–210.5|—|
|hardware-E-1|211.600000–214.260000|210.750000–213.285000|213.205200|
|hardware-E-2|214.260000–215.590000|213.285000–214.825100|214.575100|
|hardware-E-3|215.590000–216.920000|214.825100–216.155100|216.115200|
|hardware-E-4|216.920000–218.250000|216.155100–217.485100|217.445200|
|hardware-E-5|221.100000–223.760000|220.445200–222.980200|222.900400|
|hardware-E-6|223.760000–225.090000|222.980200–224.520300|224.270300|
|hardware-E-7|225.090000–226.420000|224.520300–225.850300|225.810400|
|hardware-E-8|226.420000–227.750000|225.850300–227.180300|227.140400|
|Door8placement|218.75–220.75|218.1952–220.1952|—|

E1/E3/E5/E7individualtool-freeholds and later D/C repeat holds remain short. Groupcamera continuity and later leaf/group holds expose retainedheads; this is not a claim to have lengthened each screw. Completion verification means visible exterior pose with actual toolwithdrawn, not certifiedtorque/retention. Do not force the existingINITIAL_SEATED flag early during the stretchedpre-endplateau.

### Future diagnostic windows affected — separatehumanpermission

| Proof | ProposedNwindow | Frames24fps | Difference |
|---|---|---:|---|
|P1|108–124|384|Still partialS08; D33notcomplete|
|P2|185–208.5|564|Endbefore newdoor1start,12fewerframes|
|P3|208.5–228|468|Captureentire newdoor1approach,12moreframes|

Total remains59s/1416frames; currentacceptedproofs384/576/456remainimmutable. StartingnewP3at209 would silentlyomit thefirst0.5s of its newdoorapproach: **FAIL**. All noncamera meshes at132/203/228/278must match original canonicalstates. S17–S19,alignment 247–262,showcase 268–278andOPEN/HOLDsemanticsremainunchanged. Camera also must return to the inherited boundaryview at228; donotintroduce a jump into S17.

## OptionE — preserve old waits, approve a modest extension

Leave old waitingintervals intact and addonly D30hold0.175818182s, C13hold0.165142857s, S16hold/transitionbudget1.090400s. Rawextra1.431361039s; roundUPto35frames =1.458333333s at24fps, using0.026972294s ofdeclaredstaticpadding. Newtotal **279.458333333s /6707frames**. No global acceleration or clipping. This is an alternative requiring explicit human durationanddownstreamscope approval, not an automatic fallback.

| Boundary | OptionEglobaltime |
|---|---:|
|S08End|132.175818182|
|S13End_S14Start|189.175818182|
|S14End_S15Start|203.340961039|
|S15End_S16Start|209.340961039|
|S16End_S17Start|229.458333333|
|alignmentStart|248.458333333|
|alignmentEnd|263.458333333|
|S19Start|263.458333333|
|showcaseStart|269.458333333|
|end|279.458333333|

OptionE reschedules everylaterstepandpose-only/HOLDclock after eachinsertedhold. Preserve theirsemantics and paths; do not reuse old globaltimestamps. Futureproof windows would need a fresh mapping to sourceevents and native frame bounds; they are deliberately not authorized or rendered here. No donor is takenfrom alignment, FNONLITERAL, I/J or S19HOLD.

## Cost and controlled order

Actualprior sixchunkcapture elapsed446.04s for1416frames, first attempt. Measuredper window:
- P1: 384frames/82.37s; 0.2145s/frame, includesfreshchunkstartup/capture/validation.
- P2: 576frames/204.77s; 0.3555s/frame, includesfreshchunkstartup/capture/validation.
- P3: 456frames/158.51s; 0.3476s/frame, includesfreshchunkstartup/capture/validation.

These are historicalmeasurements, not benchmarks of untestedcameras. A futureP1 camera-onlypilot is≈82s capture, budget2–4min includingencode/QA. A C13subset192.25–195.75has84frames,≈30–40s capture beforeQA. ProposedN564/468frameP2/P3estimate≈201/163s capture; combinedthreewindows≈446s, budget9–13min includingencode/mediaQA. Content review/human latencyexcluded.

Do not automaticallyrender allvariants: firstP1CAMonly; thenselectedTIME-only ifseparatelyauthorized; optionalGFXonlyonlyifidentityremainsunclear. Existingas-isvideo is thebefore asset andmustnotberecaptured. A combinedthreeproofpasswouldbeanother1416frames/≈7.4mincapture, notincludedinthefirstpilotcost. No full 278srender is proposed for this correctiongate. Currentplanningcost: **0newframes,0rendererinvocations**.
