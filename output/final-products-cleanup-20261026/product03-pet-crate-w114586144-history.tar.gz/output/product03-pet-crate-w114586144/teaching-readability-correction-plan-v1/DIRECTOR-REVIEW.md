# Product03 — Read-only teaching readability plan review

**Review ID: PRODUCT03-TEACHING-READABILITY-CORRECTION-PLAN-V1-20261023**

Human-authorized planning is complete. Please review the actual attached plan, timing options, edge-case matrix and byte-preserved existing evidence. No production source, evaluator, camera, geometry, animation or timing was changed. No runtime evaluation or new rendering occurred. This is a plan review, not a new visual candidate.

The 12-row plan separates camera, timing and graphics. Each row identifies V2 timestamps, actors, inherited source functions, timeline impact, regression risks, future PASS/FAIL criteria and offline cost. One evidence clarification: the original 193.75s C13 frame shows the L tool body; its head/contact patch is hard to read. The whole tool is not absent.

Recommendation: define a common contract, then seek separate human authorization for a **P1 camera-only pilot first**. Do not deploy a generic rule across all steps. Compare selected timing changes independently. Graphics are optional and cannot fix occlusion. The original three MP4s remain the before assets already delivered under PRODUCT03-TARGETED-MOTION-PROOFS-V1-20261023.

- **Option N — 278s proposal:** extend selected D30/C13 and E2/E6 tool-free holds to 0.25s using static waiting intervals. Preserve moving-phase durations and spatial paths. S15/S16 boundary moves from 209 to 208.375s; door 7 starts at 208.5s. Future P2/P3 windows become 185–208.5 / 208.5–228s, with 564/468 frames. All three windows still total 59s / 1416 frames. D31–39 shift locally by +0.175818s and C14–18 by +0.165143s. S08 ends at 132s, S14 at 203s, S16 at 228s; later boundaries stay fixed. These scope/window changes require separate human approval.
- **Option E — alternative 279.458333s:** keep existing waits and add 35 native frames. The plan explicitly recalculates downstream boundaries. No duration choice has been made.
- **Limit:** this budget provides selected essential/hinge-pair verification, not a 0.25s individual hold after every screw. D31/D32, later C screws and E1/E3/E5/E7 still have short individual slots; stable group views are a separate proposal. If every screw requires its own hold, this budget must be revised.

Arithmetic checks pass. New camera visibility, perceived pacing, future determinism and physical fit/access are **NOT RUN**. The proposed camera must show tool withdrawal, preserve installed components, and return to the inherited boundary view before 228s. The plan includes explicit stops if C13 cannot be exposed by camera alone.

Please issue **PLAN PASS / REVISION_REQUIRED / FAIL**. Review whether the static donors and grouped verification are acceptable, and identify decisions that require human scope/duration approval. State any limitations. This read-only milestone does not authorize implementation or rendering. Codex will save the actual complete decision and STOP.

K22/10 remains UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN; S17/S18 POSE-ONLY; S19 pads/door HOLD. Historical raw collision FAILs remain. Product #01, JULIETTE and all frozen assets are unchanged. Human alone grants final film acceptance. The existing Assemble conversation is the sole permitted external channel.
