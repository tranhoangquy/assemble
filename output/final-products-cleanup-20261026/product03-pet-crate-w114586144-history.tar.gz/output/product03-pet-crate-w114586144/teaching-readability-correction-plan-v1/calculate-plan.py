"""Read-only planning arithmetic from already delivered JSON; no imports of production runtime, no renderer."""
from pathlib import Path
from fractions import Fraction as F
import json,datetime,math
P=Path(__file__).resolve().parent;R=P.parent;B=R/'targeted-motion-proofs-v1';A=R/'p0-teaching-continuity-audit-v1'
load=lambda p:json.loads(p.read_text())
def save(n,v):(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
ops=load(A/'OPERATION-EVIDENCE.json');byid={h['id']:h for h in ops['hardware']};hold=F(1,4)
def d(h):return F(str(h['end']))-F(str(h['start']))
def delta(h):return hold-d(h)*F(3,100)
# Exact intent of the source budget ratios; JSON decimals are independently compared below.
D=F('13.6')/11*2;C=F('9.9')/7*2;dr=hold-D*F(3,100);cr=hold-C*F(3,100)
assert abs(float(D)-float(d(byid['hardware-D-30'])))<1e-10 and abs(float(C)-float(d(byid['hardware-C-13'])))<1e-10
rows=[]
for h in ops['hardware']:
 if h['id']in ['hardware-D-30','hardware-C-13','hardware-E-2','hardware-E-6']:
  rows.append({'id':h['id'],'sourceStart':h['start'],'sourceEnd':h['end'],'sourceToolHidden':h['phaseTimes']['toolHidden'],'existingToolFreeHold':float(d(h)*F(3,100)),'proposedVisualToolFreeHold':.25,'addedHold':float(delta(h)),'classification':'Proposed exterior-position/tool-withdrawal hold; not torque/retention certification'})
s16=[];t=F('208.375')
def seg(id,oldstart,oldend,duration,kind):
 global t
 st=t;t+=F(str(duration));s16.append({'id':id,'baselineStart':float(oldstart),'baselineEnd':float(oldend),'proposedStart':float(st),'proposedEnd':float(t),'kind':kind,'duration':float(t-st),'durationDelta':float(t-st-(F(str(oldend))-F(str(oldstart))))});return st,t
seg('S16-introduction',209,'209.25','.125','STATIC_DONOR')
seg('door7-placement','209.25','211.25',2,'MOVING_UNCHANGED_DURATION')
seg('door7-contact-dwell','211.25','211.6','.25','STATIC_DONOR')
newH=[]
for i in range(1,5):
 h=byid[f'hardware-E-{i}'];start=t;oldstart=F(str(h['start']));oldlen=F('2.66')if i==1 else F('1.33');cuts=[F(0),F('.15'),F('.25'),F('.4'),F('.8'),F('.87'),F('.97'),F(1)];phases=['bolt-approach','tip-aligned-wait','tool-approach','feed','rotation-tail','tool-withdrawal','tool-free-visual-hold']
 for j,(a,b)in enumerate(zip(cuts,cuts[1:])):
  amount=oldlen*(b-a);kind='MOVING_UNCHANGED_DURATION'
  if j==1:
   kind='STATIC_UNCHANGED'
   if i==1:amount-=F('.125');kind='STATIC_DONOR'
  if j==6:
   kind='STATIC_UNCHANGED'
   if i==2:amount=hold;kind='STATIC_HOLD_ADDED'
  seg(f'E{i}:{phases[j]}',oldstart+oldlen*a,oldstart+oldlen*b,amount,kind)
 newH.append({'id':h['id'],'start':float(start),'end':float(t),'toolHidden':float(next(s['proposedStart']for s in s16 if s['id']==f'E{i}:tool-free-visual-hold'))})
seg('door-handover-context','218.25','218.75','.7101','STATIC_TRANSITION_BUDGET')
seg('door8-placement','218.75','220.75',2,'MOVING_UNCHANGED_DURATION')
seg('door8-contact-dwell','220.75','221.1','.25','STATIC_DONOR')
for i in range(5,9):
 h=byid[f'hardware-E-{i}'];start=t;oldstart=F(str(h['start']));oldlen=F('2.66')if i==5 else F('1.33')
 for j,(a,b)in enumerate(zip(cuts,cuts[1:])):
  amount=oldlen*(b-a);kind='MOVING_UNCHANGED_DURATION'
  if j==1:
   kind='STATIC_UNCHANGED'
   if i==5:amount-=F('.125');kind='STATIC_DONOR'
  if j==6:
   kind='STATIC_UNCHANGED'
   if i==6:amount=hold;kind='STATIC_HOLD_ADDED'
  seg(f'E{i}:{phases[j]}',oldstart+oldlen*a,oldstart+oldlen*b,amount,kind)
 newH.append({'id':h['id'],'start':float(start),'end':float(t),'toolHidden':float(next(s['proposedStart']for s in s16 if s['id']==f'E{i}:tool-free-visual-hold'))})
seg('S16-end-context','227.75',228,F(228)-t,'STATIC_TRANSITION_BUDGET')
assert t==228
for s in s16:
 if s['kind']=='MOVING_UNCHANGED_DURATION':assert abs(s['durationDelta'])<1e-10
assert all(s['duration']>0 for s in s16)
# Every intended explicit visual hold gets6native frames; upper hinge pairs use retained inter-operation context.
for i in [2,6]:
 h=next(h for h in newH if h['id']==f'hardware-E-{i}');assert abs(h['end']-h['toolHidden']-.25)<1e-9
E4=next(h for h in newH if h['id']=='hardware-E-4');door8=next(s for s in s16 if s['id']=='door8-placement');assert abs(door8['proposedStart']-(E4['toolHidden']+.25)-.5)<1e-9
E8=next(h for h in newH if h['id']=='hardware-E-8');assert E8['toolHidden']+.25+.5<=228
N={'status':'MATHEMATICALLY_BALANCED_PROPOSAL_ONLY_NOT_IMPLEMENTED','duration':278,'fullTimelineFramesAt24':6672,'D30':{'addedHold':float(dr),'newEnd':float(F('120.37272727272727')+dr),'D31Through39Shift':float(dr),'newLastD39End':float(F('131.5')+dr),'tailBefore132':float(F('.5')-dr),'sourceWindow':'117.9–132; D34–39 alsoshift but paths/active durations unchanged; outside originalP1coverage'},'C13':{'addedHold':float(cr),'newEnd':float(F('195.42857142857142')+cr),'C14Through18Shift':float(cr),'newLastC18End':float(F('202.5')+cr),'tailBefore203':float(F('.5')-cr)},'S15':{'floorMotionUnchanged':[205.15,207.15],'oldEnd':209,'newEnd':208.375,'floorRetainedHoldBeforeS16':1.225,'donatedSeconds':.625},'S16':{'oldStart':209,'newStart':208.375,'endUnchanged':228,'oldDuration':19,'newDuration':19.625,'introDuration':.125,'door7ContactDwell':.25,'door8ContactDwell':.25,'E1AndE5TipWait':.141,'E2AndE6ToolFreeHold':.25,'doorHandoverAfterE4':.7101,'endTail':s16[-1]['duration'],'hardware':newH,'segments':s16},'futureReviewWindowsRequireHumanApproval':[{'id':'P1','start':108,'endExclusive':124,'frames':384,'qualification':'Still partialS08; no all10Dclaim'},{'id':'P2','start':185,'endExclusive':208.5,'frames':564},{'id':'P3','start':208.5,'endExclusive':228,'frames':468}],'boundaryIdentity':'All19OEMsteps and quantities retained; S01–S14/S17–S19/alignment/showcase endpoints unchanged, only S15/S16boundary shifts; allmovingphase durations/spatial paths unchanged. Need actualfuture tests; not a generated evaluator.'}
# Duration-expansion alternative leaves original idle intervals intact and addsonly required holds/transition space.
xE2=F('.25')-F('1.33')*F('.03');handover=F('.25')+F('.5')-(F('.5')+F('1.33')*F('.03'));endExtra=F('.25')+F('.5')-(F('.25')+F('1.33')*F('.03'));extraS16=2*xE2+handover+endExtra;rawDelta=dr+cr+extraS16;frames=math.ceil(float(rawDelta)*24-1e-9);pad=F(frames,24)-rawDelta
E={'status':'ALTERNATIVE_ONLY_REQUIRES_HUMAN_DURATION_DECISION','D30AddedHold':float(dr),'C13AddedHold':float(cr),'S16AddedSeconds':float(extraS16),'rawTotalExtension':float(rawDelta),'frameAlignedExtensionFrames':frames,'frameAlignedExtensionSeconds':frames/24,'proposedTotal':float(F(278)+F(frames,24)),'proposedTotalFramesAt24':6672+frames,'extraStaticContextPadding':float(pad),'downstream':{'S08End':float(132+dr),'S13End_S14Start':float(189+dr),'S14End_S15Start':float(203+dr+cr),'S15End_S16Start':float(209+dr+cr),'S16End_S17Start':float(228+F(frames,24)),'alignmentStart':float(247+F(frames,24)),'alignmentEnd':float(262+F(frames,24)),'S19Start':float(262+F(frames,24)),'showcaseStart':float(268+F(frames,24)),'end':float(278+F(frames,24))},'qualification':'No existing static wait is shortened; later timestamps must all be regenerated from versioned map, including OPEN/HOLD stages without changing their pose-only/HOLD semantics. This is larger downstream timing scope. No permission to implement.'}
job=load(B/'CAPTURE-JOB.json');costs=[]
for proof in ['P1','P2','P3']:
 chunks=[v for k,v in job['chunks'].items()if k.startswith(proof)];secs=sum((datetime.datetime.fromisoformat(v['completedAt'])-datetime.datetime.fromisoformat(v['startedAt'])).total_seconds()for v in chunks);nf=sum(len(v['frames'])for v in chunks);costs.append({'proof':proof,'measuredFrames':nf,'measuredCaptureSeconds':secs,'measuredSecondsPerFrame':secs/nf,'source':'Existing completedCAPTURE-JOB.json; includeschunkstartup/capture/framevalidation, not benchmark of proposedcameras'})
save('TIMING-OPTIONS.json',{'primaryDurationNeutral':N,'alternativeDurationExpansion':E,'commonScopeLimit':'Selected first fastener/hingepair completion holds only; D31/D32, laterC and E1/E3/E5/E7 still have short individual slots. Stable grouped cameras preserve readablepreviousheads; do not claim6frame individualholdfor every screw. IfDirectorrequiresindividualholdforall,STOPandrequestnewbudget/scope.','renderMeasurements':costs,'planningOnly':True,'newRuntimeEvaluations':0,'newFrames':0})
save('PLANNING-ARITHMETIC-QA.json',{'status':'PASS — arithmetic only; visual feasibility NOT RUN','durationNeutral278':True,'positiveIntervals':True,'allMovingPhaseDurationsPreserved':True,'E2E6ToolFreeHolds':.25,'E4ToolFreeHoldAndPullback':[.25,.5],'E8ToolFreeHoldAndPullback':[.25,.5],'D30AndC13StaticDonorsPositive':True,'allFutureNativeWindowCounts':sum(w['frames']for w in N['futureReviewWindowsRequireHumanApproval']),'extensionWholeFrames':frames,'fullRenderExecuted':False,'evaluatorExecuted':False,'sourceEdits':0})
print(json.dumps({'neutral':'278s;S15/S16boundary208.375','Ewindows':[s for s in s16 if s['id']in ['door7-placement','door8-placement']],'D':N['D30'],'C':N['C13'],'Ehardware':newH,'alternative':E,'measured':costs},indent=2))
