from pathlib import Path
import json,hashlib,zipfile,datetime
P=Path(__file__).resolve().parent;R=P.parent;ROOT=P.parents[2]
load=lambda f:json.loads(f.read_text())
def sha(f):
 h=hashlib.sha256()
 with f.open('rb')as s:
  for b in iter(lambda:s.read(2**20),b''):h.update(b)
 return h.hexdigest()
def verify(d):
 for n,h in d.items():
  f=Path(n)
  if not f.is_absolute():
   f=ROOT/f if (ROOT/f).is_file()else R/f
  assert sha(f)==h,str(f)
baseline=load(P/'READ-ONLY-BASELINE.json');verify(baseline['sourceFiles']);protected=load(R/'phase-a-v1/evidence/protected-baseline.json');verify(protected)
freezeNames=['f-illustrative-proof-v1/FROZEN-LOCAL-PROOF.json','part-first-sequence-v1/FROZEN-FOCUSED-PROOF.json','timeline-integration-plan-v1/FROZEN-INTEGRATION-PLAN.json','timeline-integration-v1/FROZEN-INTEGRATION-EVIDENCE.json','s04-two-bolt-proof-v1/FROZEN-S04-PROOF.json','s04-integration-v2/FROZEN-INTEGRATION-V2.json','p0-teaching-continuity-audit-v1/FROZEN-READ-ONLY-AUDIT.json','targeted-motion-proofs-v1/FROZEN-MOTION-PROOF-EVIDENCE.json','phase-d-illustrative-v2/FROZEN-BLOCKING-SHA256.json'];frozen=[]
for n in freezeNames:
 f=R/n;d=load(f)['files'];verify(d);frozen.append({'manifest':n,'files':len(d),'manifestSha256':sha(f),'changes':0})
verify(baseline['inputFreezeManifests']);historical=[]
for m in R.glob('*/REVIEW-DELIVERY-MANIFEST.json'):
 if m.parent==P:continue
 for v in load(m):assert sha(Path(v['path']))==v['sha256'];historical.append(v)
manual=R/'phase-a-v1/source/human-provided-pet-crate-manual.pdf';assert sha(manual)=='70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29'
for e in load(P/'EXISTING-EVIDENCE-MANIFEST.json'):assert sha(P/e['path'])==sha(ROOT/e['source'])==e['sha256']
assert sha(R/'CURRENT-PROJECT-STATE.json')==baseline['currentStateSha256Before']
inv=load(R/'phase-a-v1/PARTS-HARDWARE-INVENTORY.json');deps=load(R/'phase-a-v1/ASSEMBLY-DEPENDENCIES.json')['steps'];assert len(deps)==19 and sum(v['quantity']for v in inv['parts'])==20 and sum(v['quantity']for v in inv['hardware'])==103
rows=load(P/'CORRECTION-ROWS.json');assert len(rows)==12
required=['proof','timestamp','evidencedProblem','sourceFunction','proposal','timelineImpact','regressionRisk','passFailVerification','estimatedOfflineCaptureCost'];assert all(all(v.get(k)for k in required)for v in rows)
assert {v['category']for v in rows}=={'CAMERA','TIMING','GRAPHICS'}
opts=load(P/'TIMING-OPTIONS.json');N=opts['primaryDurationNeutral'];assert N['duration']==278 and sum(v['frames']for v in N['futureReviewWindowsRequireHumanApproval'])==1416
assert opts['alternativeDurationExpansion']['proposedTotalFramesAt24']==6707
save=lambda n,v:(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
save('PROTECTED-ASSET-VERIFICATION.json',{'status':'PASS','verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceEngineRendererFiles':len(baseline['sourceFiles']),'sourceChanges':0,'protectedPaths':len(protected),'protectedChanges':0,'historicalDeliveredFiles':len(historical),'historicalChanges':0,'frozenSets':frozen,'manualSha256':sha(manual),'currentStateUnchangedBeforeHandoff':True,'newGeometryAnimationCameraSource':0,'newRendererInvocations':0,'newProductRendersVideoAudio':0,'evidenceHandling':'All images/contact sheets exact existing byte copies; browserreceipt is communication evidence only','Product01':'UNCHANGED','JULIETTE':'UNCHANGED','rawCollisionFAIL':'PRESERVED; no tests/exclusions/threshold changes'})
save('PLAN-QA.json',{'status':'PASS — read-only document completeness and arithmetic only','review':'PRODUCT03-TEACHING-READABILITY-CORRECTION-PLAN-V1-20261023','changeRows':12,'allRequiredTableColumnsPresent':True,'categoriesSeparated':['CAMERA','TIMING','GRAPHICS'],'OEMSteps':19,'componentInstances':20,'hardwareAndTools':103,'sourceInventory':'UNCHANGED; no new inventory or manufacturing claims','durationNeutralArithmetic':'PASS; 278s, positive intervals, moving-phase durations unchanged in proposal','alternativeArithmetic':'279.458333333s/6707nativeframes, proposed only','futureNativeFrames':1416,'newSourceEdits':0,'runtimeEvaluations':0,'rendererInvocations':0,'newProductRendersVideosAudio':0,'existingImageCopies':22,'newCameraVisualQA':'NOT_RUN','futureDeterminism':'NOT_RUN','newPhysicalFitCollisionAccessQA':'NOT_RUN','directorPlanReview':'PENDING_ACTUAL_SUBMISSION','stop':'After actualhandoff/review; no implementation or render'})
# No currently-written log included; immutable payload excludes reviewreceipt added after send.
files={f for f in P.iterdir()if f.is_file()and f.suffix in ['.md','.json','.py']and f.name not in ['PAYLOAD-SHA256.json','REVIEW-DELIVERY-MANIFEST.json','ZIP-VERIFICATION.json']}
files.update(f for f in (P/'evidence').iterdir()if f.is_file())
payload=[{'path':str(f.relative_to(P)),'bytes':f.stat().st_size,'sha256':sha(f)}for f in sorted(files)];save('PAYLOAD-SHA256.json',payload)
z=P/'PRODUCT03-teaching-readability-correction-plan-v1-evidence.zip';assert not z.exists()
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,6)as archive:
 for v in payload:archive.write(P/v['path'],v['path'])
 archive.write(P/'PAYLOAD-SHA256.json','PAYLOAD-SHA256.json')
with zipfile.ZipFile(z)as archive:
 assert archive.testzip()is None and json.loads(archive.read('PAYLOAD-SHA256.json'))==payload
 assert set(archive.namelist())=={v['path']for v in payload}|{'PAYLOAD-SHA256.json'}
 for v in payload:
  b=archive.read(v['path']);assert len(b)==v['bytes']and hashlib.sha256(b).hexdigest()==v['sha256']
save('ZIP-VERIFICATION.json',{'status':'PASS','zip':z.name,'sha256':sha(z),'bytes':z.stat().st_size,'payloadsVerified':len(payload),'newProductMedia':0})
names=['DIRECTOR-REVIEW.md','READABILITY-CORRECTION-PLAN.md','TIMELINE-OPTIONS.md','EDGE-CASES-AND-VERIFICATION.md',z.name,'evidence/CONTACT-SHEET-P1.jpg','evidence/CONTACT-SHEET-P2.jpg','evidence/CONTACT-SHEET-P3.jpg','evidence/P2-frame-000210.png']
delivery=[{'path':str(P/n),'bytes':(P/n).stat().st_size,'sha256':sha(P/n)}for n in names];save('REVIEW-DELIVERY-MANIFEST.json',delivery);(P/'DELIVERY-SHA256.txt').write_text(''.join(f"{v['sha256']}  {Path(v['path']).name}\n"for v in delivery))
print(json.dumps({'status':'READ_ONLY_PLAN_READY_FOR_ACTUAL_REVIEW','rows':len(rows),'zipPayloads':len(payload),'zipSHA256':sha(z),'zipBytes':z.stat().st_size,'attachments':len(delivery),'protectedPaths':len(protected),'historicalFiles':len(historical),'frozenSets':len(frozen),'sourceChanges':0,'newRenders':0},indent=2))
