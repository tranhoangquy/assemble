# Source/function references — read-only

All timestamps in plan tables are V2 global seconds. V2 maps times after69s to V1 time−14. Do not mistake old localStart metadata for the actual clock. Line references below refer to the unchanged hashed files.

## V1R

src/products/product03-pet-crate-w114586144/timeline-integration-v1/runtime.ts

SHA256: `29f525f98457fc2c47f6825882c69e2228d01281d5126a3996d8a55cf1ef333e`

```text
  10  const reset=()=>{m.reset();for(const[o,a]of all){o.position.copy(a.p);o.quaternion.copy(a.q);o.scale.copy(a.s);o.visible=a.v;}};
  11  function partOffset(id:string,t:number){
  12   const list=bodies.filter(b=>b.id===id);let off=new T.Vector3(...(list[0]?.from??[0,0,0]));
  13   for(const b of list){if(t<b.start)break;off.set(...b.from).lerp(new T.Vector3(...b.to),ease(t,b.start,b.contact));}
  14   return off;
```

```text
  16  function setHardware(h:HardwareEvent,t:number){
  17   const obj=r.registry.require(h.id),p=row(h.id),n=new T.Vector3(...(p.outward??[0,0,1])),u=T.MathUtils.clamp((t-h.start)/(h.end-h.start),0,1);
  18   obj.visible=t>=h.start;let gap=0;
  19   if(mode==='guarded'&&['hardware-B-2','hardware-B-4'].includes(h.id)){
  20    obj.position.copy(position.get(h.id)!).addScaledVector(n,55).add(new T.Vector3(0,0,80));
  21    return{...h,progress:u,gap:55,visualState:'HELD_UNINSTALLED_HEAD_COLLISION'};
  22   }
  23   if(h.kind==='threaded'){
  24    gap=h.length+606*(1-ease(u,0,.15))-h.length*ease(u,.4,.8);obj.position.copy(position.get(h.id)!).addScaledVector(n,gap);
  25    const shortStroke=h.id==='hardware-B-1'||h.id==='hardware-B-3',base=h.id==='hardware-B-3'?Math.PI:0;
  26    // B1/B3 can use a bounded sixty-degree visual key stroke away from the divider.
  27    // This is presentation choreography, not a torque/turn-count specification.
  28    obj.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),n);obj.rotateOnAxis(new T.Vector3(0,1,0),base+(shortStroke?Math.PI/3*(.8*ease(u,.4,.8)+.2*ease(u,.8,.87)):Math.PI*(1.5*ease(u,.4,.8)+.5*ease(u,.8,.87))));
  29    if(u>=.25&&u<.97){const tool=r.registry.require(`hardware-${h.tool}-1`),extra=650*(1-ease(u,.25,.4))+650*ease(u,.87,.97);tool.visible=true;
  30     if(h.tool==='L'){tool.quaternion.copy(obj.quaternion).multiply(new T.Quaternion().setFromAxisAngle(new T.Vector3(0,0,1),Math.PI));tool.position.copy(obj.position).addScaledVector(n,66.2+extra);}
  31     else{tool.quaternion.copy(obj.quaternion);tool.position.copy(obj.position).addScaledVector(n,73.3+extra);}
  32    }
  33   }else if(h.kind==='foot'){
  34    const host=r.registry.require(h.host),hostBase=position.get(h.host)!;obj.position.copy(position.get(h.id)!).add(host.position.clone().sub(hostBase)).addScaledVector(n,35*(1-ease(u,0,.8)));obj.rotateOnAxis(new T.Vector3(0,1,0),Math.PI*ease(u,.2,.9));
  35   }else if(h.kind==='bracket')obj.position.copy(position.get(h.id)!).addScaledVector(new T.Vector3(0,-1,0),45*(1-ease(u,0,.85)));
  36   else if(h.kind==='stack')obj.position.copy(position.get(h.id)!).addScaledVector(new T.Vector3(0,0,1),60*(1-ease(u,0,.85)));
  37   else{obj.position.set(760+(Number(h.id.split('-').at(-1))%2)*25,100+Math.floor((Number(h.id.split('-').at(-1))!-1)/2)*25,350);gap=null as unknown as number;}
  38   return{...h,progress:u,gap,visualState:h.kind==='held-pad'?'HELD_STAGED':h.kind==='stack'?'POSED_ONLY_RECEIVER_HOLD':u>=1?'INITIAL_SEATED':u<.15?'STAGED':u<.4?'ALIGNED':'INSERTING_SYMBOLIC'};
```

```text
  40  function evaluate(time:number){
  41   reset();const t=T.MathUtils.clamp(time,0,duration);for(const[,o]of r.registry.entries())o.visible=false;
  42   for(const o of r.root.children)if(o.name.startsWith('presentation-stationary-hinge-'))o.visible=false;
  43   const installed:string[]=[],prepared:string[]=[],active:string[]=[];
  44   for(const id of new Set(bodies.map(b=>b.id))){const events=bodies.filter(b=>b.id===id),first=events[0];if(t<first.start)continue;const o=r.registry.require(id),off=partOffset(id,t);o.visible=true;o.position.copy(position.get(id)!).add(off);
  45    const current=events.filter(b=>b.start<=t).at(-1)!;
  46    if(current.prepared||off.lengthSq()>1e-10){if(id==='part-1-1'||id==='part-2-1'||id==='part-5-1')prepared.push(id);if(t<current.contact)active.push(id);}else installed.push(id);
  47    if(id==='part-7-1'||id==='part-8-1'){const code=id.includes('-7-')?'7':'8',factory=r.root.children.find(o=>o.name===`presentation-stationary-hinge-${code}`)!;factory.visible=true;factory.position.copy(all.get(factory)!.p).add(off);}
  48   }
  49   let currentHardware:ReturnType<typeof setHardware>|null=null;const posed:string[]=[],seated:string[]=[],pending:string[]=[];
  50   for(const h of hardware){if(t<h.start)continue;const st=setHardware(h,t);if(t<h.end)currentHardware=st;if(st.visualState.startsWith('HELD'))pending.push(h.id);else if(h.kind==='stack')posed.push(h.id);else if(t>=h.end)seated.push(h.id);}
  51   // Whole-rig orientation is presentation staging; relative installed state remains.
  52   const inv=ease(t,steps[7].start,steps[7].start+1.4)*(1-ease(t,steps[14].start,steps[14].start+2));m.rig.rotation.x=inv*Math.PI;m.rig.position.y=inv*984;m.rig.updateMatrixWorld(true);
  53   const step=steps.find(st=>t<st.end&&t>=st.start)??(t>=alignment.start&&t<alignment.end?steps[17]:steps.at(-1)!);
  54   const body=bodies.find(b=>t>=b.start&&t<b.contact),stage=t>=alignment.start&&t<alignment.end?'ALIGNMENT / FINAL-RETENTION HOLD — NO TORQUE CLAIM':t>=254?'CANONICAL TARGET / FUNCTIONAL HOLD':currentHardware?`${currentHardware.id} / ${currentHardware.visualState}`:body?`${body.id} / PLACE BEFORE CURRENT FASTENERS`:'RETAINED CONTACT / SOURCE STEP HOLD';
  55   return{time:t,step:step.id,stepNumber:step.number,localTime:t-step.start,stage,installed,prepared,active,hardwareSeated:seated,posedHeld:posed,pending,currentHardware,body,
  56    visible:[...r.registry.entries()].filter(([,o])=>o.visible).map(([id])=>id),holds:holds.filter(h=>h.step<=step.number),mode,conditional:step.number>=4,clippingPlanes:0,physicalConfidence:'NOT_CERTIFIED — raw receiving overlaps remain',completeFilmAuthorized:false};
```

```text
  58  function camera(time:number,overview=false){
  59   const state=evaluate(time),camera=new T.PerspectiveCamera(35,1280/720,.1,20000);
  60   if(!overview&&state.currentHardware?.kind==='threaded'&&!state.currentHardware.visualState.startsWith('HELD')){
  61    const p=row(state.currentHardware.id),center=new T.Vector3(...p.position).applyMatrix4(m.rig.matrixWorld),n=new T.Vector3(...p.outward!).transformDirection(m.rig.matrixWorld),side=new T.Vector3().crossVectors(n,new T.Vector3(0,1,0));if(side.lengthSq()<.1)side.set(1,0,0);side.normalize();center.addScaledVector(n,20);camera.position.copy(center).addScaledVector(n,270).addScaledVector(side,210).add(new T.Vector3(0,145,0));camera.lookAt(center);
  62   }else{
  63    const box=new T.Box3();for(const [id,o]of r.registry.entries())if(o.visible&&id.startsWith('part-'))box.union(new T.Box3().setFromObject(o));const center=box.getCenter(new T.Vector3()),size=box.getSize(new T.Vector3()),distance=Math.max(size.y*2.0,size.x*1.55,1800);camera.position.copy(center).add(new T.Vector3(-.75,.42,1).normalize().multiplyScalar(distance));camera.lookAt(center);
  64   }
  65   camera.updateMatrixWorld(true);return camera;
```

## V1T

src/products/product03-pet-crate-w114586144/timeline-integration-v1/timeline.ts

SHA256: `add22a56feb38e2b3676301fcf345f936f6122f9725dcc6b59aa2a6c752a8514`

```text
   7 export const budgets=[18,13,10,14,16,19,8,20,12,10,10,9,16,14,6,19,10,9,6];
   8 let clock=0;
   9 export const steps=sourceSteps.map((s,i)=>{if(i===18)clock+=15;const row={id:s.id,number:i+1,start:clock,end:clock+budgets[i],duration:budgets[i],source:s};clock=row.end;return row;});
  10 export const duration=264,alignment={start:233,end:248},showcase={start:254,end:264};
  11 export type BodyEvent={id:string;step:number;start:number;contact:number;from:V3;to:V3;prepared?:boolean;note:string};
  12 export type HardwareEvent={id:string;step:number;start:number;end:number;kind:'threaded'|'foot'|'bracket'|'stack'|'held-pad';tool:'L'|'M'|null;host:string;backing?:string;length:number;note:string};
  13 export const bodies:BodyEvent[]=[],hardware:HardwareEvent[]=[];
  14 const s=(n:number)=>steps[n-1];
  15 const row=(id:string)=>placements.find(p=>p.id===id)!;
  16 const body=(n:number,id:string,start:number,contact:number,from:V3,to:V3=[0,0,0],prepared=false,note='Unmeasured visible approach; no certified installation trajectory')=>bodies.push({id,step:n,start:s(n).start+start,contact:s(n).start+contact,from,to,prepared,note});
```

```text
  20 body(7,'part-1-1',.15,.15,[-315,0,0],[-315,0,0],true);body(7,'part-2-1',.15,.15,[315,0,0],[315,0,0],true);body(7,'part-5-1',.15,.15,[820,0,84],[820,0,84],true);
  21 body(8,'part-1-1',1.5,3.5,[-315,0,0]);body(8,'part-2-1',3.5,5.5,[315,0,0]);
  22 body(9,'part-4-1',.25,2.25,[0,0,-110]);body(11,'part-3-1',.25,2.25,[0,0,110]);
  23 // Four rails are placed and fastened in forward order; end allocation stays inferred.
  24 for(let i=0;i<4;i++){const start=i===0?.25:6.5+(i-1)*3;body(13,`part-6-${i+1}`,start,start+(i===0?2:1.25),[0,75,0]);}
  25 // Prepared5 first centers OUTSIDE the side posts; then approaches straight in depth.
  26 body(14,'part-5-1',.25,1.75,[820,0,84],[0,0,84],true,'Declared outside-carcase lateral staging; no OEM path certification');body(14,'part-5-1',1.75,3.25,[0,0,84],[0,0,0]);
  27 body(15,'part-14-1',2.15,4.15,[0,130,0]);body(16,'part-7-1',.25,2.25,[0,0,110]);body(16,'part-8-1',9.75,11.75,[0,0,110]);
```

```text
  35 function add(id:string,n:number,start:number,end:number,kind:HardwareEvent['kind']='threaded'){
  36  const p=row(id),code=id.split('-')[1],length=code==='B'?10:code==='C'||code==='F'?25:code==='D'?44:code==='E'?11:0;
  37  hardware.push({id,step:n,start:s(n).start+start,end:s(n).start+end,kind,tool:kind==='threaded'?('BC D'.replace(/ /g,'').includes(code)?'L':'M'):null,host:p.host!,backing:backing(id),length,note:kind==='stack'?'Exterior source stack posed only; stud/O grip/retention UNVERIFIED':kind==='held-pad'?'HELD: door/retainer release and pad access not validated':'Initial symbolic seating; full shafts, no hidden receiving geometry/torque certification'});
  38 }
  39 function threaded(n:number,start:number,end:number,ids=placements.filter(p=>p.step===n&&/^hardware-[BCDEF]-/.test(p.id)).map(p=>p.id)){
  40  const unit=(end-start)/(ids.length+1);let at=start;ids.forEach((id,i)=>{const d=unit*(i===0?2:1);add(id,n,at,at+d);at+=d;});
  41 }
  42 threaded(1,4.6,17.5);threaded(2,4.3,12.5);threaded(3,2.6,9.5);
  43 for(let i=0;i<2;i++)add(`hardware-K-${i+1}`,4,.25+i*1.5,1.5+i*1.5,'bracket');threaded(4,3.3,13.5);
  44 threaded(5,2.6,15.5);threaded(6,2.6,18.5);
  45 for(let i=0;i<5;i++)add(`hardware-A-${i+1}`,7,.6+i*1.3,1.7+i*1.3,'foot');
  46 threaded(8,5.9,19.5);threaded(9,2.6,11.5);threaded(10,.75,9.5);threaded(11,2.6,9.5);threaded(12,.75,8.5);
  47 for(let i=0;i<4;i++){const b=bodies.find(b=>b.step===13&&b.id===`part-6-${i+1}`)!;add(`hardware-C-${9+i}`,13,b.contact-s(13).start+.2,i===0?6.25:6.5+i*3-.25);}
  48 threaded(14,3.6,13.5);
  49 threaded(16,2.6,9.25,placements.filter(p=>p.step===16&&p.host==='part-1-1').map(p=>p.id));threaded(16,12.1,18.75,placements.filter(p=>p.step===16&&p.host==='part-2-1').map(p=>p.id));
  50 for(const n of [17,18]){const ids=placements.filter(p=>p.step===n).map(p=>p.id),d=(s(n).duration-1)/ids.length;ids.forEach((id,i)=>add(id,n,.25+i*d,.25+(i+1)*d,'stack'));}
```

## V2R

src/products/product03-pet-crate-w114586144/s04-integration-v2/runtime.ts

SHA256: `c14aa08032af7a000d56efedba14564aa7871ff0c3e19e9f1cb450f630e8721f`

```text
   9 export function createRuntime(){
  10  const previous=createV1(),accepted=createProof(),r=accepted.r,rig=accepted.rig;
  11  function evaluate(time:number){
  12   const t=T.MathUtils.clamp(time,0,duration),old=previous.evaluate(mapToV1(t)),inside=t>=41&&t<69;
  13   // Canonical nanosecond local time avoids IEEE subtraction changing visibility
  14   // at an exact 2.7s/7.7s event boundary. This is time precision, not fit tolerance.
  15   const side=t<55?'left':'right',local=t<41?0:t>=69?14:Math.round((t-(side==='left'?41:55))*1e9)/1e9,micro=accepted.evaluate(side,local);
  16   for(const[id,target]of r.registry.entries()){
  17    if(t>=41&&isBK(id)||inside&&id==='hardware-L-1')continue;
  18    const source=previous.r.registry.require(id);target.position.copy(source.position);target.quaternion.copy(source.quaternion);target.scale.copy(source.scale);target.visible=source.visible;
  19   }
  20   // Factory hinge groups are descendants outside the registry. Preserve their
  21   // absolute introduction/offset state alongside the registered source doors.
  22   for(const code of ['7','8']){const name=`presentation-stationary-hinge-${code}`,source=previous.r.root.children.find(o=>o.name===name)!,target=r.root.children.find(o=>o.name===name)!;target.position.copy(source.position);target.quaternion.copy(source.quaternion);target.visible=source.visible;}
  23   rig.position.copy(previous.rig.position);rig.quaternion.copy(previous.rig.quaternion);rig.scale.copy(previous.rig.scale);rig.updateMatrixWorld(true);
  24   const step=steps.find(s=>s.id===old.step)!,seated=old.hardwareSeated.filter(id=>!isBK(id));
  25   if(t>=41){for(const h of hardware.filter(h=>h.step===4&&h.kind==='bracket'&&t>=h.end))seated.push(h.id);seated.push(...micro.seated);}
  26   const current=inside?(micro.active?hardware.find(h=>h.id===micro.active!.id):hardware.find(h=>h.step===4&&h.kind==='bracket'&&t>=h.start&&t<h.end)):old.currentHardware?hardware.find(h=>h.id===old.currentHardware!.id):undefined;
  27   const currentHardware=current?{...current,progress:micro.active&&inside?micro.active.progress:inside?(t-current.start)/(current.end-current.start):old.currentHardware!.progress,gap:inside?micro.active?.gap??r.registry.require(current.id).position.distanceTo(new T.Vector3(...placements.find(p=>p.id===current.id)!.position)):old.currentHardware!.gap,visualState:inside?micro.stage:old.currentHardware!.visualState}:null;
  28   const body=old.body?bodies.find(b=>b.id===old.body!.id&&b.step===old.body!.step&&Math.abs(b.start-old.body!.start-(b.step>=5?14:0))<1e-6):undefined;
  29   return{...old,time:t,localTime:t-step.start,step:step.id,stepNumber:step.number,stage:inside?micro.stage:old.stage,
  30    hardwareSeated:seated,pending:old.pending.filter(id=>!isBK(id)),currentHardware,body,
  31    visible:[...r.registry.entries()].filter(([,o])=>o.visible).map(([id])=>id),holds:holds.filter(h=>h.step<=step.number),warnings,
  32    mode:'S04_INTEGRATION_V2',conditional:step.number>=17,physicalConfidence:'NOT_CERTIFIED — accepted illustrative S04 only; receiving/source holds remain',completeFilmAuthorized:false,
  33    sourceV1Time:mapToV1(t),s04:inside?micro:null};
  34  }
  35  function camera(time:number,overview=false){
  36   const t=T.MathUtils.clamp(time,0,duration);
  37   const camera=t>=41&&t<69&&!overview?accepted.camera(t<55?'left':'right'):previous.camera(mapToV1(t),overview);
  38   evaluate(t);return camera;
```

## V2T

src/products/product03-pet-crate-w114586144/s04-integration-v2/timeline.ts

SHA256: `01cc5366d1fd93e80f45263b7787a2a732d4ac365c0b334c6b8ed5a3a357117d`

```text
   1 import type {AssemblyDefinition,AnimationAction} from '@/types/assembly';
   2 import {AssemblyGraph} from '@/engine/assembly/AssemblyGraph';
   3 import * as v1 from '../timeline-integration-v1/timeline';
   4 import {placements} from '../s04-two-bolt-proof-v1/model';
   5 import {timing} from '../s04-two-bolt-proof-v1/proof';
   6 export {placements};export type HardwareEvent=v1.HardwareEvent;
   7 export const duration=278,alignment={start:247,end:262},showcase={start:268,end:278};
   8 export const steps=v1.steps.map(s=>({...s,start:s.start+(s.number>=5?14:0),end:s.end+(s.number>=4?14:0),duration:s.duration+(s.number===4?14:0)}));
   9 export const bodies=v1.bodies.map(b=>({...b,start:b.start+(b.step>=5?14:0),contact:b.contact+(b.step>=5?14:0)}));
  10 export const hardware:HardwareEvent[]=v1.hardware.map(h=>{
  11  if(h.step!==4)return{...h,start:h.start+(h.step>=5?14:0),end:h.end+(h.step>=5?14:0)};
  12  const code=h.id.split('-')[1],i=Number(h.id.split('-').at(-1)),side=code==='K'?i-1:Math.floor((i-1)/2),offset=41+side*14;
  13  if(code==='K')return{...h,start:offset,end:offset+timing.bracketContact,note:'Exact accepted unmeasured S04 K pose/contact motion; not physical certification'};
  14  const t=i%2?timing.first:timing.second;return{...h,start:offset+t.start,end:offset+t.end,note:'Exact accepted S04 B approach/key/retained pose; illustrative initial seating only'};
  15 });
  16 export const holds=v1.holds.filter(h=>h.step!==4);
  17 export const warnings=['K22/10 UNMEASURED DISPLAY APPROXIMATION','C13/C14 and I/J OPEN','Receiving/retention/torque/support/hand access NOT CERTIFIED'];
  18 export const assembly:AssemblyDefinition={...v1.assembly,id:'product03-s04-integration-v2',sourceNote:'Versioned278s illustrative integration; frozen V1 and accepted S04 sources unchanged',steps:v1.assembly.steps.map(s=>s.id!=='S04'?{...s}:{...s,actions:hardware.filter(h=>h.step===4).flatMap(h=>[
  19  {type:'show',target:h.id,at:h.start-41,source:'image_visible',confidence:'low'},
  20  {type:'move',target:h.id,at:h.start-41,duration:h.end-h.start,to:placements.find(p=>p.id===h.id)!.position,source:'mechanically_inferred',confidence:'low'},
  21 ] as AnimationAction[])})};
  22 export const graph=new AssemblyGraph(assembly);
  23 export const mapToV1=(t:number)=>t<41?t:t<69?41+(t-41)/2:t-14;
```

## V2P

src/products/product03-pet-crate-w114586144/s04-integration-v2/preview.ts

SHA256: `cc3f63a59e67955b658d4862241163147fbcd1898b741f0d75c7ab459dbf7be1`

```text
   9 function label(css:string,text=''){const e=document.createElement('div');e.style.cssText=css;e.textContent=text;document.body.append(e);return e;}
  10 label('position:fixed;left:24px;top:18px;padding:9px;background:#f4f1e9ef;color:#292c2f;font:600 13px Arial','PRODUCT03 / INTEGRATION V2 — ACTUAL 3D EVALUATOR / 278s BUDGET');
  11 const badge=label('position:fixed;right:24px;top:18px;padding:9px;background:#fff3e6ef;color:#805534;font:600 11px Arial');
  12 const stage=label('position:fixed;left:24px;bottom:83px;padding:8px;background:#f4f1e9ef;color:#292c2f;font:600 18px Arial');
  13 const count=label('position:fixed;left:24px;bottom:47px;padding:7px;background:#f4f1e9ef;color:#61594f;font:13px Arial');
  14 label('position:fixed;left:24px;bottom:14px;padding:5px;background:#f4f1e9ef;color:#805534;font:12px Arial','TARGETED REVIEW ONLY · K22/10 UNMEASURED · full shafts/no clipping · receivers, retention, support and physical access NOT CERTIFIED');
  15 const windows=[{id:'A',start:39},{id:'B',start:51},{id:'C',start:63}];
  16 const checkpoints=[...steps.map(s=>({name:`${s.id}-endpoint.png`,label:s.id,time:s.end-1/24})),
  17  ...[41,55,69].flatMap(t=>[-.0001,0,.0001].map((d,i)=>({name:`boundary-${t}-${i}.png`,label:'BOUNDARY',time:t+d}))),
  18  ...[132,278].flatMap(t=>['left','right'].map(side=>({name:`K-${side}-retained-${t}.png`,label:side,time:t}))),
  19  ...windows.flatMap(w=>Array.from({length:288},(_,i)=>({name:`${w.id}-frame-${String(i).padStart(6,'0')}.png`,label:w.id,time:w.start+i/24})))];
  20 window.__MECHANISM_AUDIT_RENDERER__={ready:true,checkpoints,async render(name:string){
  21  const c=checkpoints.find(c=>c.name===name);if(!c)throw Error(name);const s=r.evaluate(c.time);let camera=r.camera(c.time,!name.includes('-frame-'));
  22  if(name.startsWith('K-')){const sign=c.label==='left'?-1:1,target=new T.Vector3(sign*175,894,220).applyMatrix4(r.rig.matrixWorld),offset=new T.Vector3(-sign*100,-100,155).transformDirection(r.rig.matrixWorld).multiplyScalar(Math.hypot(100,100,155));const m=new T.PerspectiveCamera(40,1280/720,.1,10000);m.position.copy(target).add(offset);m.up.set(0,1,0).transformDirection(r.rig.matrixWorld);m.lookAt(target);m.updateMatrixWorld(true);camera=m;}
  23  renderer.render(scene,camera);badge.textContent=s.holds.length?'REMAINING SOURCE / PHYSICAL HOLDS':'ILLUSTRATIVE INTEGRATION / NO PHYSICAL CERTIFICATION';
  24  stage.textContent=`${s.step} / ${s.s04?s.s04.side.toUpperCase()+' / ':''}${s.stage}`;
  25  count.textContent=`t=${s.time.toFixed(4)}s · ${s.installed.length} structural / ${s.prepared.length} prepared · ${s.hardwareSeated.length} initial seats / ${s.posedHeld.length} pose-only / ${s.pending.length} held · B1–B4 retained after S04`;
  26  return{name,time:c.time,state:s,camera:{position:camera.position.toArray(),quaternion:camera.quaternion.toArray()},networkRequests:performance.getEntriesByType('resource').filter(e=>/^https?:/.test(e.name)).map(e=>e.name)};
```

