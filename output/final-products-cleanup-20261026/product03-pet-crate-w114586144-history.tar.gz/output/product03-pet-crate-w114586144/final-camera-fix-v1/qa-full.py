from pathlib import Path
import json,hashlib,subprocess,struct
p=Path(__file__).resolve().parent;old=p.parent/'human-3-image-correction-v1/long-v3-r2';new=p/'capture-r3/full-long-v4'
a=json.loads((old/'COMPLETED-JOB.json').read_text());b=json.loads((new/'COMPLETED-JOB.json').read_text());movie=new/'PRODUCT03-Long-V4-278s-SILENT-720p.mp4'
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
probe=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(movie)]));v=probe['streams'][0];assert len(probe['streams'])==1 and v['codec_name']=='h264' and v['pix_fmt']=='yuv420p' and int(v['nb_read_frames'])==8340 and float(probe['format']['duration'])==278 and [v['width'],v['height']]==[1280,720]
r=subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(movie),'-f','null','-'],capture_output=True);assert r.returncode==0 and not r.stderr
pts=json.loads(subprocess.check_output(['/opt/homebrew/bin/ffprobe','-v','error','-select_streams','v:0','-show_entries','frame=pts_time','-of','json',str(movie)]))['frames'];assert len(pts)==8340 and all(abs(float(f['pts_time'])-i/30)<1e-6 for i,f in enumerate(pts))
# Native PNG comparison, no compression confound. Outside exact bounded camera window.
checks=0;different=[];inside=[]
for i in range(8340):
 f=f'frame-{i:06d}.png';same=sha(Path(a['frameDirectory'])/f)==sha(Path(b['frameDirectory'])/f)
 if 197.25<=i/30<200.65:inside.append({'frame':i,'same':same})
 else:
  checks+=1
  if not same:different.append(i)
assert not different,('Outside-camera native regression',different[:20])
read=lambda f:[json.loads(x)['telemetry'] for x in Path(f).read_text().splitlines()]
aT=read(old/'CAPTURE-TELEMETRY.ndjson');bT=read(new/'CAPTURE-TELEMETRY.ndjson');assert len(aT)==len(bT)==8340
for x,y in zip(aT,bT):
 assert x['time']==y['time'] and x['state']==y['state']
 assert not y['contextLost'] and y['glError']==0 and y['ready']
 if not(197.25<=y['time']<200.65):assert x['camera']==y['camera']
short=p.parent/'human-visual-acceptance-v2/PRODUCT03-Short-V2-59s-SILENT-1080x1920.mp4';assert sha(short)=='9eefb6de6b1159e62ee0fb7968027ede6fb1e7138797c93e3f262598538b59c2'
# MP4 top-level atoms for faststart.
atoms=[]
with movie.open('rb')as f:
 off=0
 while off<movie.stat().st_size:
  f.seek(off);raw=f.read(8);size,kind=struct.unpack('>I4s',raw)
  if size==1:size=struct.unpack('>Q',f.read(8))[0]
  if size==0:size=movie.stat().st_size-off
  atoms.append({'type':kind.decode('ascii'),'offset':off,'size':size});off+=size
assert next(a['offset']for a in atoms if a['type']=='moov')<next(a['offset']for a in atoms if a['type']=='mdat')
report={'status':'PASS','movie':str(movie),'sha256':sha(movie),'nativeResolution':[1280,720],'fps':30,'duration':278,'frames':8340,'audio':False,'fullDecode':'PASS','allPTS':'PASS','faststart':atoms,'outsideCameraWindowNativePNGsIdentical':checks,'outsideDifferences':different,'changedWindowFrames':inside,'all8340SourceTimesStateCounts':'IDENTICAL','outsideCameraTelemetry':'IDENTICAL','contextGuard':'PASS','shortUnchanged':{'path':str(short),'sha256':sha(short)},'limits':'All prior OPEN/HOLD/raw collision FAIL remain; no physical certification'}
(p/'FULL-LONG-V4-QA.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items()if k not in ['changedWindowFrames','faststart']},indent=2))
