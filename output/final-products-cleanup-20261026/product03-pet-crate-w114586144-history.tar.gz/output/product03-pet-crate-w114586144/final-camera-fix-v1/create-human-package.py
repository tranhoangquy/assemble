from pathlib import Path
import json,hashlib,shutil,zipfile
p=Path(__file__).resolve().parent;decision=json.loads((p/'final-director-review/DECISION.json').read_text());assert decision['humanDeliveryAuthorized'] and decision['source']=='ACTUAL_CHATGPT_WEB_RESPONSE'
q=json.loads((p/'FULL-LONG-V4-QA.json').read_text());assert q['status']=='PASS';h=p.parent/'human-visual-acceptance-v3';h.mkdir(exist_ok=False)
long=h/'PRODUCT03-Long-V4-278s-SILENT-720p.mp4';short=h/'PRODUCT03-Short-V2-59s-SILENT-1080x1920.mp4';shutil.copyfile(q['movie'],long);shutil.copyfile(q['shortUnchanged']['path'],short)
assert hashlib.sha256(long.read_bytes()).hexdigest()==q['sha256'];assert hashlib.sha256(short.read_bytes()).hexdigest()==q['shortUnchanged']['sha256']
for name in ['FULL-LONG-V4-QA.json','FINAL-PROTECTED-VERIFICATION.json','TRACE-AND-SCOPE.md','DIRECTOR-FULL-LONG-V4-REVIEW.md','R3-BEFORE-AFTER-SAME-TIME-198500.jpg','C16-FULL-VS-PROOF-NATIVE-QA.json']:shutil.copyfile(p/name,h/name)
shutil.copytree(p/'final-director-review',h/'director-approval');shutil.copyfile(p.parent/'human-3-image-correction-v1/FILM-LIMITATIONS.md',h/'LIMITATIONS.md')
(h/'HUMAN-REVIEW.md').write_text('''# READY FOR HUMAN FINAL REVIEW — NOT YET ACCEPTED

[Long V4 — 278s](PRODUCT03-Long-V4-278s-SILENT-720p.mp4)

[Short V2 — 59s, unchanged](PRODUCT03-Short-V2-59s-SILENT-1080x1920.mp4)

Long V4 changes only C16 camera197.25–200.65s; view arrives198.35 before screw approach198.422286 and remains through tool withdrawal. All8238 native frames outside the camera window are byte-identical to LongV3. ShortV2 is completely byte-identical to its previously reviewed original. No audio, geometry, fastening, count or timing change.

Actual Creative Director proof and final-review responses retained in this package. Review uses actual sampled frames + metadata/integrity/full decode evidence, not a claim of continuous human playback. Director noted the brief orbit is a little quick but acceptable. Human sole final acceptance authority.

All existing mechanical OPEN/HOLD/POSE_ONLY limitations, nonliteral F, unmeasured K, unresolved C13/C14 and I/J, door attachment OPEN, S19 HOLD and historical raw collision FAIL remain. No physical installation, tool access, torque, hinge retention/function or load certification. Previous three visual corrections preserved. See LIMITATIONS.md and QA. No publication authorized.
''')
files={str(f.relative_to(h)):hashlib.sha256(f.read_bytes()).hexdigest()for f in h.rglob('*')if f.is_file()};(h/'SHA256SUMS.txt').write_text('\n'.join(v+'  '+k for k,v in sorted(files.items()))+'\n')
freeze={str(f):hashlib.sha256(f.read_bytes()).hexdigest()for f in h.rglob('*')if f.is_file()};(p.parent/'FROZEN-HUMAN-VISUAL-PACKAGE-V3.json').write_text(json.dumps({'status':'READY FOR HUMAN FINAL REVIEW — NOT YET ACCEPTED','humanFinalAcceptance':False,'files':freeze},indent=2))
with zipfile.ZipFile(p.parent/'PRODUCT03-HUMAN-VISUAL-ACCEPTANCE-V3.zip','x',zipfile.ZIP_DEFLATED)as z:
 for f in h.rglob('*'):
  if f.is_file():z.write(f,str(f.relative_to(h)))
print(h)
