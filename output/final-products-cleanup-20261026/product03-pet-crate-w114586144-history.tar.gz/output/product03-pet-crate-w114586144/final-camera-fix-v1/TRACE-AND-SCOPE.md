# Human final camera fix — C16 only

The actual latest human attachment in Assemble was inspected in its image viewer (54% displayed capture retained, not original PNG bytes). It shows Long V3 4:38, playhead 3:18, MANUAL STEP14/19, C16 Approach. This identifies source N time in [198.422286,198.634429), not one exact subframe from the rounded playhead. C16 is uniquely identified; comparison uses exact 198.500000s on both sides.

Long V3 SHA256 fa9a734012e791587aa3bb6f9c581bc5eb2dc9d9aec0be250ef23e9197a2eea0. S14 C16 begins198.422285714, ends199.836571429. Existing placements: host part5, backing part6 instance4; canonical [350,62,295], outward+Z, transformed by upside-down rig to world contact[350,922,-295]. Tool L. Source function p2p3Camera returns wide after C13 exit195.593714→196.843714, hiding the scale/direction of later C16.

Short V2 is unaffected: its frame5 excerpt uses189.25–192.25s, and never includes C16 or any S14 screw insertion. It must remain byte-identical.

Versioned new camera modifies197.25–200.65s only (C16 plus adjacent transition buffers). Arrives198.35s before C16 start. Fixed exterior close view during entire C16 operation; smooth entry/exit. No pose, geometry, visibility, inventory, clock, captions, material or preceding three corrections changed. Test adjacent C15/C17 for contextual visibility; camera-only proof gate before full LongV4.

K22/10 UNMEASURED; F NONLITERAL; C13/C14 allocation and I/J OPEN; S17/S18 POSE_ONLY; S19 pads/door HOLD; door-side attachment OPEN; historical raw collision FAIL. Macro visibility is not physical-fit/tool-access certification. No audio/publication.
