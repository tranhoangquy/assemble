# PRODUCT03 — LONG V4 / FINAL C16 CAMERA REVIEW

Actual complete Long V4 MP4 attached. SHA256 `2d7e4c511f449b8c8d90338ef992391f989e18e873a338f300773755acdc19a2`.
Native1280×720,30fps,278seconds,8340frames,silentH264/yuv420p. Full decode,allPTS=i/30,faststart PASS.

Only the accepted C16 camera R3 was integrated. Changed camera window197.25–200.65s (102nativeframes); fixed view ready198.35s before C16 approach198.422286s, held through tool withdrawal/end199.836571s. Adjacent C15/C17 orbit accepted in actual proof decision; orbit slightly quick but accepted. Geometry/assembly/clock/quantities/material/captions/previous3fixes untouched. This is illustrative source with all original confidence restrictions.

Complete native regression: 8238 outside-window PNGs byte-identical to frozen LongV3. All8340source times/state-counts unchanged; outside-window camera telemetry identical. Native context/subject guards passed. 42138 protected source/evidence/asset files unchanged. No prior version overwritten. No Short rerender: ShortV2 SHA2569eefb6de6b1159e62ee0fb7968027ede6fb1e7138797c93e3f262598538b59c2 remains unchanged,59s,1770frames.

Actual final MP4 decoded samples cover C15–C17 and adjacent cuts, plus previous feet/hinge/pad corrections. Sampling + full technical decode is not a claim of continuous visual playback. Supporting sampled PNGs/contact sheets and QA are in evidenceZIP. Actual proof response and frozen hashes retained. Scoped source typecheck passed.

Please inspect actual full LongV4/evidence and explicitly issue INTERNAL VISUAL PASS / targeted revision. If PASS authorize renewed HUMAN delivery of LongV4 and UNCHANGED ShortV2 as READY FOR HUMAN FINAL REVIEW — NOT YET ACCEPTED. No routine ACK after final decision.

K22/10UNMEASURED;FNONLITERAL;C13/C14,I/JOPEN;S17/S18POSE_ONLY;S19pads/doorHOLD;door-sideattachmentOPEN;historicalrawcollisionFAIL. No invented bores, threads, retention, torque/access/load/hinge certification. Previous S14falsealarm remains corrected. No audio/publication/outsideInternet/Product01/JULIETTE edits. Human sole final approver.
