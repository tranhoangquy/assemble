from pathlib import Path
import json,subprocess
from PIL import Image,ImageDraw
p=Path(__file__).resolve().parent;q=json.loads((p/'FULL-LONG-V4-QA.json').read_text());movie=Path(q['movie']);d=p/'final-review';d.mkdir(exist_ok=True)
times=[0,104.6,109,190,192.25,196,197.2,197.3,197.5,197.8,198.2,198.35,198.4333333,198.5,198.75,198.9,199.1,199.3,199.55,199.8,199.9,200.1,200.3,200.6,200.6666667,201,202,203,208.5,212,218.8,266,273,277.9666667];frames=sorted(set(round(t*30)for t in times))
# Balanced sum avoids FFmpeg's long-expression parser depth failure.
def expression(a):
 if len(a)==1:return f'eq(n\\,{a[0]})'
 n=len(a)//2;return '('+expression(a[:n])+'+'+expression(a[n:])+')'
subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(movie),'-vf','select='+expression(frames),'-fps_mode','passthrough','-start_number','0','-n',str(d/'decoded-%03d.png')],check=True)
rows=[]
for k,n in enumerate(frames):rows.append({'file':f'decoded-{k:03d}.png','frame':n,'time':n/30})
(d/'SAMPLED-ACTUAL-FRAMES.json').write_text(json.dumps({'source':str(movie),'rows':rows,'method':'Actual final MP4 decode, sampling only; not continuous visual playback'},indent=2))
for page in range((len(rows)+7)//8):
 canvas=Image.new('RGB',(1280,4*385),'#f5f1e8');draw=ImageDraw.Draw(canvas)
 for i,row in enumerate(rows[page*8:(page+1)*8]):
  x=i%2*640;y=i//2*385;canvas.paste(Image.open(d/row['file']).convert('RGB').resize((640,360)),(x,y+25));draw.text((x+10,y+5),f"LONG V4 / actual frame{row['frame']} / {row['time']:.6f}s",fill='black')
 canvas.save(d/f'LONG-V4-ACTUAL-SHEET-{page+1:02}.jpg')
print('Decoded actual final frames',len(frames))
