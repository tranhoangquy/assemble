from pathlib import Path
import json,hashlib,zipfile
p=Path(__file__).resolve().parent;q=json.loads((p/'FULL-LONG-V4-QA.json').read_text());assert q['status']=='PASS'
# Verify all inherited baseline files and newest versioned sources again after capture.
files={}
for n in ['BASELINE-PROTECTED-BASELINE.json','BASELINE-FROZEN-CORRECTION-CANDIDATES.json','BASELINE-FROZEN-HUMAN-VISUAL-PACKAGE-V2.json','PROTECTED-BASELINE.json','VERSIONED-SOURCE-FREEZE.json']:files.update(json.loads((p/n).read_text())['files'])
changed=[]
for n,h in files.items():
 f=Path(n);actual=hashlib.sha256(f.read_bytes()).hexdigest()if f.is_file()else None
 if actual!=h:changed.append({'file':n,'expected':h,'actual':actual})
(p/'FINAL-PROTECTED-VERIFICATION.json').write_text(json.dumps({'status':'PASS'if not changed else'FAIL','checkedUniquePaths':len(files),'changed':changed},indent=2));assert not changed
q['protectedUniquePaths']=len(files)
report=f'''# PRODUCT03 — LONG V4 / FINAL C16 CAMERA REVIEW

Actual complete Long V4 MP4 attached. SHA256 `{q['sha256']}`.
Native1280×720,30fps,278seconds,8340frames,silentH264/yuv420p. Full decode,allPTS=i/30,faststart PASS.

Only the accepted C16 camera R3 was integrated. Changed camera window197.25–200.65s (102nativeframes); fixed view ready198.35s before C16 approach198.422286s, held through tool withdrawal/end199.836571s. Adjacent C15/C17 orbit accepted in actual proof decision; orbit slightly quick but accepted. Geometry/assembly/clock/quantities/material/captions/previous3fixes untouched. This is illustrative source with all original confidence restrictions.

Complete native regression: {q['outsideCameraWindowNativePNGsIdentical']} outside-window PNGs byte-identical to frozen LongV3. All8340source times/state-counts unchanged; outside-window camera telemetry identical. Native context/subject guards passed. {len(files)} protected source/evidence/asset files unchanged. No prior version overwritten. No Short rerender: ShortV2 SHA2569eefb6de6b1159e62ee0fb7968027ede6fb1e7138797c93e3f262598538b59c2 remains unchanged,59s,1770frames.

Actual final MP4 decoded samples cover C15–C17 and adjacent cuts, plus previous feet/hinge/pad corrections. Sampling + full technical decode is not a claim of continuous visual playback. Supporting sampled PNGs/contact sheets and QA are in evidenceZIP. Actual proof response and frozen hashes retained. Scoped source typecheck passed.

Please inspect actual full LongV4/evidence and explicitly issue INTERNAL VISUAL PASS / targeted revision. If PASS authorize renewed HUMAN delivery of LongV4 and UNCHANGED ShortV2 as READY FOR HUMAN FINAL REVIEW — NOT YET ACCEPTED. No routine ACK after final decision.

K22/10UNMEASURED;FNONLITERAL;C13/C14,I/JOPEN;S17/S18POSE_ONLY;S19pads/doorHOLD;door-sideattachmentOPEN;historicalrawcollisionFAIL. No invented bores, threads, retention, torque/access/load/hinge certification. Previous S14falsealarm remains corrected. No audio/publication/outsideInternet/Product01/JULIETTE edits. Human sole final approver.
'''
(p/'DIRECTOR-FULL-LONG-V4-REVIEW.md').write_text(report)
names=['DIRECTOR-FULL-LONG-V4-REVIEW.md','FULL-LONG-V4-QA.json','FINAL-PROTECTED-VERIFICATION.json','CAMERA-POSE-QA.json','PROOF-R3-CAPTURE-QA.json','TRACE-AND-SCOPE.md','VERSIONED-SOURCE-FREEZE.json','TYPECHECK.txt','R3-BEFORE-AFTER-SAME-TIME-198500.jpg','director-review/ACTUAL-DIRECTOR-RESPONSE-DOM.txt','director-review/DECISION.json','capture-r3/full-long-v4/INPUT-FREEZE.json','capture-r3/full-long-v4/OFFLINE-NETWORK-QA.json','capture-r3/full-long-v4/COMPLETED-JOB.json']
names += [str(f.relative_to(p))for f in (p/'final-review').glob('*')if f.is_file()]
manifest={n:hashlib.sha256((p/n).read_bytes()).hexdigest()for n in names};(p/'FULL-EVIDENCE-SHA256.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(p/'PRODUCT03-LONG-V4-CAMERA-EVIDENCE.zip','x',zipfile.ZIP_DEFLATED)as z:
 for n in names+['FULL-EVIDENCE-SHA256.json']:z.write(p/n,n)
print('Full evidence ready',hashlib.sha256((p/'PRODUCT03-LONG-V4-CAMERA-EVIDENCE.zip').read_bytes()).hexdigest())
