# PRODUCT03 — LongV3 / ShortV2 corrected full-film review

REQUIRES DIRECTOR VISUAL REVIEW / HUMAN ACCEPTANCE PENDING. Actual two complete silent native MP4s accompany this report. This integrates only the three human-authorized regions after your actual BOUNDED PROOF PASS.

| Film | Duration / frames / native profile | SHA256 |
|---|---|---|
| Long | 278s / 8340f / 1280×720 /30fps/silent | fa9a734012e791587aa3bb6f9c581bc5eb2dc9d9aec0be250ef23e9197a2eea0 |
| Short | 59s / 1770f / 1080×1920 /30fps/silent | 9eefb6de6b1159e62ee0fb7968027ede6fb1e7138797c93e3f262598538b59c2 |

## Scope and truthful limits

A1–A5 stem faces existing host, disc outside; actor roots/hosts/paths unchanged. Door-side unsupported holes omitted on four leaves; all8 E remain, two per depicted frame leaf. Plain leaves do not establish a bond. Door-side ATTACHMENT OPEN / FUNCTION HOLD is persistent from door introduction and also on Short hook/ending. N1–N4 remain HELD_STAGED, never attached; new native labels identify EVA pads and NOT INSTALLED status. Studio appearance, all cameras, N278 clock, Short59s source edit and all other geometry/materials unchanged.

No threads/bores/receivers/welds or invented screws. Correct A stem still enters the existing solid host mesh: no bore/physical retention certificate. All prior K UNMEASURED, F NONLITERAL, C13/C14/IJ OPEN, S17/S18 POSE_ONLY, S19 pads/door HOLD and historical raw collision FAIL preserved. S14 false alarm remains corrected.

## Actual QA

- Full H264 decode PASS; every PTS i/30, exact8340+1770frames/duration; no audio. Existing shared ExportJobManager, native surfaces, completed native PNG validation/checkpoints and faststart verification.
- All10110 capture telemetry rows: no GL/context errors; subject guards pass. Long18 browser generations, Short8. No capture retries required in final jobs.
- All8340 Long frame times/camera/state-counts match old LongV2 telemetry. All1770 Short source times/shots/actor retention and fastener projections match old ShortV1.
- Native byte equivalence:3138 unchanged early Longframes and891 Shortframes in unchanged assembly windows. Changed A/leaf geometry/labels intentionally differ elsewhere.
- Source count/backwardseek QA:19steps,20numberedparts,103hardware/tools;123registry nodes;3567 actor-root comparisons unchanged.
- Final protected verification:27393unique paths /0changes. Source PDF hash unchanged70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29.
- Scoped source typecheck PASS. Actual native preflights detected label overlap; new immutable Long r2 and portrait r3 entries remove pad occlusion. Drafts/partial1740frameLongjob retained, never reused. Camera/timing untouched.

Actual review evidence includes 86 frames decoded from the FINAL MP4s, all important changed regions and adjacent states, contact sheets and selected original native PNGs. Agent screening is sampled plus full technical decode; no fabricated claim of continuous visual playback or physical certification.

The prior hinge comparison uses different labelled source instants212 vs211; the additional HINGE-BEFORE-AFTER-SAME-SOURCE-212.jpg now aligns both columns exactly at source212.000s/same camera/Estate. Prior evidence remains intact.

## Request

Review both actual complete MP4s and evidence. Please explicitly decide LongV3 and ShortV2 visual PASS or specific bounded revision. If PASS, authorize renewed human delivery of both silent films and QA. Human alone accepts both completed visual films. No audio, publication, new product, external research or paid service. No duplicate acknowledgement after final STOP boundary.
