Product03 Human 3 Image Review Correction
GÓI TRIỂN KHAI — PRODUCT03 HUMAN 3-IMAGE CORRECTION
Trạng thái

HUMAN REVIEW FAIL / LONG V2 + SHORT V1 PICTURE LOCK REOPENED. Human sole final approver. Preserve both originals and all QA/historical evidence. This is a correction requirement, NOT authorization to invent mechanics.

Mục tiêu

Investigate and correct the three exact human screenshots dated 2026-10-25 (14.55.37, 14.55.54, 14.57.00), and re-present intelligible, source-grounded assembly visuals.

Requirement đã chốt
P0 HINGE / DOOR (image 1): inspect OEM 13-page manual, model/actor data, hinge leaves and fastener inventories. Determine which leaf attaches to stationary cage/frame and which to door; verify whether the human-mentioned four screws are shown and accounted for. Current frame-side screw imagery does NOT prove a door connection. Do not assume missing attachment or count without OEM evidence. Render a close proof showing each known interface, or explicitly mark OPEN and do not imply an installed functioning hinge.
P0 BASE (image 2): identify four downward-protruding metallic features in actual scene, exact part IDs, orientations and parent/host. Compare to OEM diagram. Investigate user's suggested reverse orientation. Do not flip bolts/feet merely for visual plausibility; if evidence insufficient, label unresolved and correct misleading framing.
P1 FOUR DOTS (image 3): identify four separate dots from actual scene/asset IDs. Check whether they are N pads staged/HOLD or something else. Explain visually with labels and a clear before/after or HOLD distinction; do not depict them as installed without evidence.
Business Rules

OEM source authority, no invented receiving holes/threads/retention/torque/access. K22/10 UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN; S17/S18 POSE_ONLY; S19 pads/door HOLD; historical raw collision FAIL. The previously corrected S14 false alarm remains corrected.

Acceptance Criteria
Provide source-page crop/reference, current screenshot annotation, actor/asset/quantity mapping and confidence for each finding.
Show explicit accounting of hinge fasteners, door-side/frame-side connection and motion status, without implying functional door if unresolved.
Show correct documented base orientation, or preserve OPEN with unambiguous visual disclosure.
Identify all four dots by model data and clarify whether staged, held or attached.
First deliver short actual native-camera proof clips/stills of each corrected region and before/after comparison; include checks of source poses/quantities and protected files.
Director reviews bounded proofs before full Long/Short rerenders. After proof PASS, update BOTH affected films, QA and human package, then submit to human again.
Edge Cases bắt buộc

Door appears suspended or hinges fastened to only one side; missing/duplicated bolts; backside occlusion; wrong screw-head direction; feet penetrate floor; four N pads appear as installed when held; source ambiguous; close-up misrepresents actual retention.

Ràng buộc

Local production only, existing Assemble communication permitted; no other Internet, third-party services, publishing or payment. Do not alter Product01/JULIETTE, frozen versions or historical evidence. No audio.

Không được thay đổi

Source-backed quantities, accepted N278s timing unless separately justified and approved, source manual, historical QA/failure records, OPEN/HOLD statuses absent new OEM evidence.

Câu hỏi còn mở

OEM actual hinge leaf/fastener allocation? Exact identity/orientation of four protrusions? Exact identity and intended placement of four dots? If OEM cannot resolve, escalate concise evidence-grounded alternatives to Director/human, never fabricate.

Quy trình

Codex investigate -> bounded proof -> deliver actual files in Assemble -> Director review -> repair Long/Short -> QA -> renewed human visual acceptance. No routine human stop unless genuine source/business decision.