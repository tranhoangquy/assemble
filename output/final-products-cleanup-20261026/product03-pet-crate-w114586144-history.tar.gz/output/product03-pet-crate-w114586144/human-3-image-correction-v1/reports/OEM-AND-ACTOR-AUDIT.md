# Product03 — human three-image correction / bounded proof review

Human REVIEW FAIL supersedes LongV2/ShortV1 internal locks for acceptance. Originals remain immutable. Only these three regions reopened. No audio or publication.

## Source and image identity

Authoritative human-supplied PDF: 13 pages, SHA256 70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29. Printed p2–12 correspond to PDF p3–13. No new Internet research.

The three exact images were located and visually inspected as human attachments in the existing Assemble conversation: dated 2026-10-25 14.55.37 / 14.55.54 / 14.57.00. Local evidence preserves browser-viewer captures and annotations. These are captures of the actual attachments at displayed 55%, NOT original uploaded PNG bytes. A browser Download wait timed out at10000ms; Downloads access returned macOS Operation not permitted even with sandbox escalation. No original-image checksum is claimed. The generated Director image in that conversation was excluded as source evidence. The attached directive was read in its document viewer and saved as rendered-text transcription, not represented as byte-identical download.

## 1 / P0 — hinge, both leaves, E accounting

**Documented:** PDF p1 lists E ×8, Ø4*11L. PDF p3 already depicts two hinge constituents with each numbered door 7/8. PDF p11 S16 shows two loose E entering one leaf of each of four hinges. The other leaf is depicted alongside the door; its attachment method is not sectioned or specified. This supports two E per depicted installation interface, not four additional loose E per hinge. Sixteen E would contradict the source inventory.

**Actual scene:** 4 hinge groups, one upper/lower per door. The legacy factory builder creates two drilled leaves per hinge, each with two round holes. In the accepted timeline the outer leaf and end knuckles are in `presentation-stationary-hinge-7/8`; the inner leaf and middle knuckle are descendants of door7/8. All8 E are installed only on the stationary frame-side leaves:

| Interface | E actors | Host / status |
|---|---|---|
| door7 / frame1 lower | E1,E2 | part-1-1; source-confirmed loose count, unmeasured coordinates |
| door7 / frame1 upper | E3,E4 | part-1-1; same qualification |
| door8 / frame2 lower | E5,E6 | part-2-1; same qualification |
| door8 / frame2 upper | E7,E8 | part-2-1; same qualification |

**Correction:** omit the eight unsupported round holes on the four door-side constituent leaves, retaining existing external leaf envelope, barrel, relative poses and all E actors. No new screws, welding beads, receiving bores, adhesive or connectors. A plain leaf is a reduced-detail exterior representation, not evidence of a bond. The proof explicitly labels door-side attachment **OPEN**. E trajectories and targets are unchanged. All four interfaces are shown; the first pair includes actual insertion/tool withdrawal. No door rotation. Source association is CONFIRMED; exact frame/door mating, factory retention, receiving details and functional hinge remain **OPEN/HOLD**. The scene graph parenting does not certify retention.

## 2 / P0 — protrusions are A feet, not newly discovered screws

Human image2 is S14 near194s, with the whole assembly inverted. In that particular view three A silhouettes are visible; rear corner feet are occluded. Do not claim four unobstructed observed items simply because feedback says four. The scene contains A1–A5, source p7 S7:

| Actors | Host | Canonical root / outward |
|---|---|---|
| A1,A2 | frame1 | (-585,3,-286),(-585,3,286); (0,-1,0) |
| A3,A4 | frame2 | (585,3,-286),(585,3,286); (0,-1,0) |
| A5 | rail5 centre | (0,3,286); (0,-1,0) |

Registry parent is the common hardware root; host tracking is evaluated explicitly. Display coordinates are NOT OEM measurements.

**Demonstrable defect:** the A prototype stem is built in local+Y while the legacy placement quaternion points local+Y toward cabinet-world−Y. Thus its stem protrudes away from its host, below the disc in the upright product; inversion makes the same defect point upward in image2. PDF p7 S7 inset explicitly shows the stem toward the frame end and the disc outside. This is direct orientation evidence.

**Correction:** reverse only the existing A constituent stem offset around the existing disc centre; keep all five actor root paths, hosts, quantities, disc geometry/materials, insertion timing and parent rig reorientation. The stem now faces cabinet-world+Y into the host, with the disc outside. No thread/receiver geometry or new foot. All five must use the same correction, including A5 following rail5. No physical retention, engagement depth, floor/load/access certification. The studio renderer has no installed floor collision surface, so no physical floor-clearance PASS is claimed. Native upright proof shows the disc at the lowest point, not the shaft.

## 3 / P1 — four dots are N1–N4, HELD_STAGED

Actual source evaluator places N1=(785,100,350), N2=(760,100,350), N3=(785,125,350), N4=(760,125,350). They are four separate registered cylindrical EVA-pad meshes. The four-dot cluster at right in image3/source273s matches these actor projections. All four are visible; no pad is in an installed state. They remain separate from the doors.

PDF p1 identifies N×4 Ø19*3; p13 S19 depicts two pads per door and a peel-off liner, with selection wording. **Confirmed accessory identity/count and broad depicted location; exact placement/access/optional interpretation remain OPEN.** No new pad placement or door opening in this revision.

Correction is visual disclosure: four legible individual N1–N4 labels in the proof; a separate HOLD presentation and explicit not-installed notice. Before shows the rejected wide four-dot image; after includes the native close-up and status distinction. Nothing is silently attached or removed from inventory.

## Proof and gate

Native1280×720/30fps, silent. Hinge16s/480f; base10s/300f; pads8s/240f. Editorial before/after cuts and source-time labels are explicit; these are bounded review exhibits, not added OEM operations or time changes to N278s. Existing ExportJobManager handles native capture/checkpoints/encoding. No full-film render before explicit Director proof decision.

Requested decision: accept these limited corrections/disclosures for integration into LongV3 + ShortV2, or specify a bounded revision. In particular decide whether reduced-detail door leaf plus persistent OPEN is truthful enough for illustrative films. If actual retained/functioning door proof is required, local source does not establish its fastening method; do not authorize fabricated extra screws/welds. Human alone accepts both resulting films.

K22/10 UNMEASURED; F NONLITERAL; C13/C14 and I/J OPEN; S17/S18 POSE_ONLY; S19 pads/door HOLD; raw collision FAIL remain. S14 false alarm correction preserved; no renewed exporter/GPU failure allegation.
