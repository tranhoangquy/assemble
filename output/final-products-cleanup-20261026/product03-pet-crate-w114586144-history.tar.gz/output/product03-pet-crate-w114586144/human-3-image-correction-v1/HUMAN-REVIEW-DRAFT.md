# Product03 — Bản sửa ba vấn đề human phát hiện

Bản LongV3 278 giây / ShortV2 59 giây, silent. Đang chờ review đầy đủ của Director; chưa có HUMAN FINAL ACCEPTANCE.

Chỉ sửa ba vùng:

1. Bản lề: giữ đúng8 vít E theo manual, không tự thêm8 vít. Bỏ các lỗ ở lá phía cửa chưa có bằng chứng. **Phương pháp giữ lá vào cánh cửa vẫn OPEN; không minh họa cửa hoạt động.**
2. Chân A1–A5: sửa thân hướng vào khung, đĩa ở ngoài theo S07; không đổi trình tự hoặc host.
3. Bốn chấm: xác định là4 miếng EVA N1–N4 đang để riêng, **HELD / NOT INSTALLED**; có nhãn giải thích.

Khi xem lại, tập trung Long khoảng104–112s,189–207s,208.5–228s và262–278s; Short31.7–34.1s,44.6–52.8s và54.27–59s. Hook Short cũng ghi rõ giới hạn bản lề.

Các cảnh còn lại được giữ nguyên. Bản cũ và toàn bộ bằng chứng vẫn tồn tại; không thay Product01/JULIETTE. Xem FILM-LIMITATIONS.md để biết các giới hạn nguồn, raw collision FAIL và bản đính chính S14.

Chỉ human có quyền nghiệm thu cuối cùng cả hai phim. Director PASS không thay cho quyết định này.
