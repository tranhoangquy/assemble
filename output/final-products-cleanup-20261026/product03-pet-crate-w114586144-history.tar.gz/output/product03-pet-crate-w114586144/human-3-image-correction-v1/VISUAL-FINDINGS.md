# Actual bounded proof findings

- Hinge: two E per stationary leaf are visible, with plain reduced-detail door leaf and explicit attachment OPEN. Four interfaces shown; door never rotates. No additional loose E claimed. This does not certify the unknown door-side attachment.
- Base: direct before/after of actual source194s camera shows the reversed stem corrected toward the host, with outside disc. Upright continuation203–207s retained. A5 follows rail5. No claimed bore/load/access certificate.
- Pads: actual N1–N4 cluster is shown separately with individual inventory/status labels, including not-yet-staged during phased introduction. All remain uninstalled. Final four are visible together.
- Review clips have explicit before/after cuts and source timestamps. They are not a continuous OEM assembly segment and are not new motion instructions. Agent visual QA used native keyframes plus full technical decode, not claimed continuous playback.
- Do not reinterpret source-parent association or zero visible gap as physical retention. Source limits and historical collision FAIL remain.
