# F numerical access comparison

All measurements are current provisional-model display units. None is an OEM dimension or proof of actual product installation. No geometry or installed transform was modified for this read-only study.

|Candidate / stage|Qty|Face normal proposed|Head-plane gap|60-unit centreline before head|25-unit shaft/backing ray|Disposition|
|---|---:|---|---|---|---|---|
|A lower face /S10|4|−Y|0|Blocked41 units before head|Backing mesh hit at18|Reject current straight path|
|A lower face /S12|4|−Y|0|Blocked32 units before head|Backing mesh hit at18|Reject current straight path|
|B outside face /S10|4|−Z|0|Centreline clear|No wood on axis;Y744 below wood bottom753|Cannot select merely because clear|
|B outside face /S12|4|+Z|0|Centreline clear|No wood on axis;Y744 below wood bottom753|Cannot select merely because clear|
|B inside face /S10|4|+Z|0|Centreline clear|No wood on axis|Same unresolved backing/source problem|
|B inside face /S12|4|−Z|0|Centreline clear|No wood on axis|Same unresolved backing/source problem|

The same8 source F units are tested under3 alternatives;24 diagnostic rows are not24 installed screws. All existing same-OEM host submeshes participate in ray tests. No obstacles or pairs are excluded to produce a PASS.

The current panel/head coordinates are existing accepted display proposals. CandidateB would require another visible overlap/placement reconstruction before a backing target exists. Choosing that reconstruction solely to make a ray hit would not establish OEM truth.

A centreline-clear result does not certify full shaft/head/driver/hand clearance. A backing hit does not establish an existing bore or thread. Raw symbolic shaft/stock penetration remains unresolved and is not a collision PASS.
