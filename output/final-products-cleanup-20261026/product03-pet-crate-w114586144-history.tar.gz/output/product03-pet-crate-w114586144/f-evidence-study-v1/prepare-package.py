from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,zipfile,shutil
ROOT=Path(__file__).resolve().parents[3];B=ROOT/'output/product03-pet-crate-w114586144';P=Path(__file__).resolve().parent
def load(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(n,v):(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',21)
small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17)
big=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',27)

# Schematic from actual current model coordinates, not a manufacturer drawing.
im=Image.new('RGB',(1600,1100),'#f4f1e9');d=ImageDraw.Draw(im)
d.text((25,15),'F / TWO INTERPRETATIONS — CURRENT UNMEASURED MODEL SECTION',font=big,fill='#292c2f')
d.text((25,55),'Diagnostic Y/Z sections at X−450. No receiving hole, thread or installation is depicted.',font=font,fill='#805534')
for column,rear in enumerate([True,False]):
 x0=25+column*790;y0=150;w=740;h=720;zmin=-365 if rear else 205;zmax=-205 if rear else 365
 def xy(z,y):return(x0+(z-zmin)/(zmax-zmin)*w,y0+(800-y)/140*h)
 def rectangle(z1,y1,z2,y2,color):
  z1=max(zmin,z1);z2=min(zmax,z2);y1=max(660,y1);y2=min(800,y2)
  if z1<z2 and y1<y2:
   a=xy(z1,y2);b=xy(z2,y1);d.rectangle((*a,*b),fill=color,outline='#292c2f',width=2)
 def line(z1,y1,z2,y2,color,width=4):d.line((xy(z1,y1),xy(z2,y2)),fill=color,width=width)
 def arrow(z1,y1,z2,y2,color):
  line(z1,y1,z2,y2,color);a=xy(z2,y2)
  if y1==y2:
   sign=1 if z2>z1 else-1;d.polygon([a,(a[0]-sign*12,a[1]-7),(a[0]-sign*12,a[1]+7)],fill=color)
  else:d.polygon([a,(a[0]-7,a[1]+12),(a[0]+7,a[1]+12)],fill=color)
 title='S10 / rear4 → proposed13'if rear else'S12 / front3 → proposed15'
 d.text((x0,110),title,font=big,fill='#292c2f')
 for y in [675,694 if rear else 703,712 if rear else 721,735,744,753,771]:
  a=xy(zmin,y);d.line((a,xy(zmax,y)),fill='#d6d0c5',width=1);d.text((a[0]+3,a[1]-20),f'Y{y}',font=small,fill='#625b50')
 zc=-286 if rear else 286
 rectangle(zc-9,694 if rear else 703,zc+9,712 if rear else 721,'#6b747b')
 rectangle(zc-9,735,zc+9,753,'#40474e')
 rectangle(-295 if rear else -69,753,-277 if rear else 295,984 if rear else 771,'#ba916c')
 arrow(zc,675,zc,735,'#1a6e91');line(zc,735,zc,760,'#1a6e91',3)
 face=-295 if rear else 295;out=-1 if rear else 1
 arrow(face+out*60,744,face,744,'#c36932');line(face,744,face-out*25,744,'#c36932',3)
 px,py=xy(zc,694 if rear else 703);d.ellipse((px-9,py-9,px+9,py+9),outline='#ba3434',width=4)
 d.text((x0+10,895),'A lower face: backing hit; approach blocked.',font=font,fill='#1a6e91')
 d.text((x0+10,928),'B outside face: clear centreline; no backing.',font=font,fill='#a4552a')
 d.text((x0+10,961),'Wood startsY753; B axisY744 is9 units below it.',font=small,fill='#625b50')
d.text((25,1010),'Grey = existing frame bands; brown = accepted provisional wood; arrows = tested candidate axes ONLY.',font=font,fill='#292c2f')
d.text((25,1048),'Neither interpretation is selected. Clear rays do not prove a receiver, tool clearance or OEM installation.',font=font,fill='#805534')
im.save(P/'01-F-INTERPRETATION-COMPARISON.jpg',quality=94)

# Original whole-page context and callout labels, no inferred global axes drawn on OEM pages.
im=Image.new('RGB',(1400,1100),'white');d=ImageDraw.Draw(im)
for col,page in enumerate([8,9]):
 a=Image.open(B/f'phase-a-v1/evidence/pages/page-{page:02d}.png').convert('RGB');a.thumbnail((680,965));im.paste(a,(col*700+10,70));
 d.text((col*700+15,12),f'LOCAL OEM PDF p{page} / '+('S9–S10'if page==8 else'S11–S12'),font=font,fill='black')
 d.text((col*700+15,1035),'Context + detail inset; no global axis calibration.',font=small,fill='#805534')
im.save(P/'02-OEM-FULL-PAGE-CONTEXT.jpg',quality=95)
shutil.copyfile(B/'phase-a-v1/source/human-provided-pet-crate-manual.pdf',P/'human-provided-pet-crate-manual.pdf')

data=load(P/'NUMERICAL-ACCESS-MATRIX.json')
assert data['summary']['lowerFace']['obstructed']==8
assert data['summary']['outsideLAP']['missingBacking']==8 and data['summary']['insideLAP']['missingBacking']==8
assert all(r['externalSeatingGap'] is not None and abs(r['externalSeatingGap'])<1e-6 for r in data['rows'])
facts=[
 {'fact':'F quantity4 atS10 and4 atS12','source':'PDF p8 S10 andp9 S12 quantity boxes','confidence':'CONFIRMED'},
 {'fact':'F inventory cross-drive pointed screw Ø4×25L,8 units','source':'PDF p1 inventory','confidence':'CONFIRMED'},
 {'fact':'Rear4/module association andfront3/module association','source':'PDF p8/p9 whole-page context','confidence':'DOCUMENTED_ASSOCIATION; exact backing ownership inferred'},
 {'fact':'Firm tightening follows alignment instruction','source':'PDF p2 foreword andp8/p9 Lock the screws firmly','confidence':'CONFIRMED'},
 {'fact':'Global product-space normal±Y/±Z','source':'Independent insets and perspective figures have no common coordinate calibration or sectioned stack','confidence':'UNRESOLVED'},
 {'fact':'Exact through-face, panel overlap, hole coordinates, receiver construction','source':'No dimensional/sectional view in supplied PDF','confidence':'UNKNOWN'},
 {'fact':'A source-confirmed human tool path','source':'Screwdriver sketch indicates tool type; no envelope or handling/access dimensions','confidence':'UNKNOWN'},
]
save('SOURCE-FACTS.json',facts)
lines=['# F numerical access comparison','',
 'All measurements are current provisional-model display units. None is an OEM dimension or proof of actual product installation. No geometry or installed transform was modified for this read-only study.','',
 '|Candidate / stage|Qty|Face normal proposed|Head-plane gap|60-unit centreline before head|25-unit shaft/backing ray|Disposition|',
 '|---|---:|---|---|---|---|---|',
 '|A lower face /S10|4|−Y|0|Blocked41 units before head|Backing mesh hit at18|Reject current straight path|',
 '|A lower face /S12|4|−Y|0|Blocked32 units before head|Backing mesh hit at18|Reject current straight path|',
 '|B outside face /S10|4|−Z|0|Centreline clear|No wood on axis;Y744 below wood bottom753|Cannot select merely because clear|',
 '|B outside face /S12|4|+Z|0|Centreline clear|No wood on axis;Y744 below wood bottom753|Cannot select merely because clear|',
 '|B inside face /S10|4|+Z|0|Centreline clear|No wood on axis|Same unresolved backing/source problem|',
 '|B inside face /S12|4|−Z|0|Centreline clear|No wood on axis|Same unresolved backing/source problem|',
 '', 'The same8 source F units are tested under3 alternatives;24 diagnostic rows are not24 installed screws. All existing same-OEM host submeshes participate in ray tests. No obstacles or pairs are excluded to produce a PASS.',
 '', 'The current panel/head coordinates are existing accepted display proposals. CandidateB would require another visible overlap/placement reconstruction before a backing target exists. Choosing that reconstruction solely to make a ray hit would not establish OEM truth.',
 '', 'A centreline-clear result does not certify full shaft/head/driver/hand clearance. A backing hit does not establish an existing bore or thread. Raw symbolic shaft/stock penetration remains unresolved and is not a collision PASS.']
(P/'ACCESS-MATRIX.md').write_text('\n'.join(lines)+'\n')

protected=load(B/'phase-a-v1/evidence/protected-baseline.json');assert all((ROOT/f).exists()and sha(ROOT/f)==h for f,h in protected.items())
accepted=[]
for revision in['rail-fit-correction-v1','p0-connections-v1']:
 fp=load(B/revision/'SOURCE-FINGERPRINTS.json')['files'];assert all(sha(ROOT/f)==h for f,h in fp.items())
 for row in load(B/revision/'REVIEW-DELIVERY-MANIFEST.json'):
  f=Path(row['path']);f=f if f.is_absolute()else B/revision/f;assert sha(f)==row['sha256'];accepted.append({'revision':revision,'file':f.name,'match':True})
save('QA-PRESERVATION.json',{'status':'SOURCE_INSUFFICIENT; truthful bounded result','tests':'24 candidate rows; all seating queries0; A8 obstructed; B16 missing backing; source facts classified',
 'protectedPaths':len(protected),'changes':0,'acceptedSourceFingerprints':'ALL MATCH','acceptedDeliverables':accepted,
 'newGeometry':'NONE','newRenderAnimationVideoAudio':'NONE','source':'Local13-page PDF only','Internet':'No general access; authorized Assemble handoff only',
 'unresolved':'F axis/receiving relationship; no installation certification'})
(P/'DIRECTOR-REVIEW.md').write_text('''# PRODUCT03 — F EVIDENCE STUDY V1

Review ID: PRODUCT03-F-EVIDENCE-STUDY-V1-20261021

Outcome: INSUFFICIENT SOURCE TO SELECT F INTERPRETATION. F remains unresolved. This is the bounded local comparison requested by your actual PARTIAL PASS — F ACCESS HOLD decision. No new geometry, assembly motion, render, video or audio was created. Accepted provisional corrections are untouched.

## Evidence and result

Re-examined local PDF p8–p9 whole-page context, detail insets, p1 inventory and alignment-before-tightening instructions. Source confirms F8 total,4 rear and4 front, cross-drive Ø4×25L and firm tightening after alignment. It does not supply a calibrated global normal, sectional stack, receiving-face coordinate or tool envelope. No normal is elevated from perspective plausibility to OEM fact.

The comparison diagram is a schematic of current model coordinates atX−450, explicitly not an OEM drawing. The original whole pages and13-page PDF are included. Numerical access matrix contains24 diagnostic rows testing the same8 F units under lower/outside/inside alternatives.

- Lower-face−Y candidate: all8 exterior heads seat, and intended wood is hit18 units after the head. All8 straight approaches intersect existing lower frame/lattice submeshes,41 units before rear heads and32 before front heads. It remains rejected as a complete installation path in the provisional model.
- Front/rear-face LAP alternatives: the24? No—the16 diagnostic exterior/inside-face candidates have clear centreline approaches, but all miss the proposed wood on axis. Their centreY744 is9 display units below the current wood bottom753. A clear ray does not supply a receiver or justify moving a panel into a new lap relationship.
- No obstacles, stock, source order or contact pairs were removed. No holes, threads, receivers or certified tool access were invented. No F insertion/tightening sequence has been rendered.

## Boundary and decision requested

The supplied local source cannot distinguish the alternatives reliably enough to select a literal F installation. Please record the truthful insufficiency and retain F HOLD. If no further source-supported interpretation exists, the next action is a HUMAN SCOPE DECISION, not another geometry/path search or full render.

Concrete choices for the human:
1. Supply/authorize acquisition of SKU-matched physical evidence of the F face, stack, receiving point and tool access. No contact, research or acquisition will start without separate permission.
2. Explicitly authorize a declared nonliteral illustrative F fastening reconstruction with reviewed visible geometry changes and persistent uncertainty labeling; no claim of manufacturer-exact axis, hidden receivers or certification. This changes the assembly-truth boundary and cannot be authorized by the Director alone.

Until a human decision, preserve accepted exterior corrections and stop F insertion, complete PhaseD rerender, final Long/Short and audio. Product01/JULIETTE and938 protected paths match; both accepted revision source fingerprints and deliverables remain unchanged. No general Internet, external source or paid service was used.
'''.replace('the24? No—the16','the16'))

files=['DIRECTOR-REVIEW.md','ACCESS-MATRIX.md','NUMERICAL-ACCESS-MATRIX.json','SOURCE-FACTS.json','QA-PRESERVATION.json','01-F-INTERPRETATION-COMPARISON.jpg','02-OEM-FULL-PAGE-CONTEXT.jpg','human-provided-pet-crate-manual.pdf']
manifest=[{'path':n,'bytes':(P/n).stat().st_size,'sha256':sha(P/n)}for n in files];save('PAYLOAD-SHA256.json',manifest)
z=P/'PRODUCT03-F-evidence-study-v1-review.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED)as a:
 for n in files+['PAYLOAD-SHA256.json']:a.write(P/n,n)
with zipfile.ZipFile(z)as a:assert all(hashlib.sha256(a.read(row['path'])).hexdigest()==row['sha256']for row in manifest)
delivery=[z,P/'DIRECTOR-REVIEW.md',P/'01-F-INTERPRETATION-COMPARISON.jpg',P/'02-OEM-FULL-PAGE-CONTEXT.jpg']
save('REVIEW-DELIVERY-MANIFEST.json',[{'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f)}for f in delivery])
(P/'DELIVERY-SHA256.txt').write_text(''.join(f'{sha(f)}  {f.name}\n'for f in delivery))
print(json.dumps({'zip':z.name,'sha256':sha(z),'payloads':len(files),'result':'INSUFFICIENT SOURCE — F HOLD'},indent=2))
