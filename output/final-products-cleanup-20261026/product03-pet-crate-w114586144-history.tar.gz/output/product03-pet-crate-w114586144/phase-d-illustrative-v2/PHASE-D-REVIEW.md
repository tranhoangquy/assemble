# Product03 — controlled illustrative assembly blocking V2

Review ID: PRODUCT03-PHASE-D-ILLUSTRATIVE-V2-20261021. **REQUIRES DIRECTOR REVIEW.** Human approved the new controlled illustrative mode after limited Phase C, and requested a somewhat faster pace. This changes the representation boundary, not the source evidence or engineering confidence. Only the existing Assemble review channel is authorized online.

## V2 response to the actual Director decision

V1's19-step structure, counts, semantic pacing and S1 teaching were accepted; camera/labeling/final presentation required revision. This V2 changes only scoped visual communication and presentation timing:

- Larger active-region medium views for side-frame joining, front/rear fastener bands, floor rails, floor14 and doors. Prepared subassemblies remain visible or explicitly labeled while framing excludes them from unrelated action bounds.
- Wide and macro approach directions use the same exterior side. A compact location map appears during details; medium context returns before the next step. No perpetual orbit or mechanical-path change to expose a joint.
- Macro holds improved for K/B, F manual-tool indications and the E hinge. Side frames join sequentially within the existing S8 window.
- One consistent bottom title/ID line and progress indicator; short hypothesis chips at the upper right. Long engineering notes remain in this report. The final hero hides the location map, uses closer framing and retains an uncluttered floor.
- S13 andS14 each lose1s of trailing idle time (8→7). Those2s move to final function/closure (8→10), retaining158s. No global speed multiplier or OEM-step omission.
- No new physical/source confidence, material, hidden geometry or hardware count change.

## Actual implementation and outputs

A complete deterministic19-step OEM-order illustrative timeline, using existing ProductEngine geometry/registry and typed AssemblyDefinition/AssemblyGraph. No new engine, exporter, assembly schema or catalog registration.20 component instances +100 illustrated hardware/accessory units; L/M/O remain3 separate tools, never installed product parts. All source quantities reconcile under the still-provisional S18 I/J disposition. The actual full blocking MP4 is native1280×720,8fps,158s/1264 frames,silent. It is a lightweight Director preview, not a final production Long or portrait Short. The archive includes the actual video,24 diagnostic stills represented by4 contact sheets plus1 actual V1/V2 camera comparison, numeric timeline/placement ledger, QA and byte hashes. Diagnostic macro stills can use a separate inspection camera; the full MP4 contains actual timed close-ups as well.

Source PDF SHA256 `70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29`. The documentary19-step order is unchanged. No additional public research or physical evidence was acquired. Source product identity remains metadata-only; no drawers/slides are added.

## Faster pacing without losing chronology

S1 teaches both side10 connections and all4 D in14s (prior Phase C used16s for a partial one-end approach). Repetitions shorten through authored durations, not a global playback speed multiplier. First drive/connection close-up stays readable; later repeated fasteners shorten. S4 K/B, first A/C/F, side-frame D, E hinge and latch stack get macro moments with wide context/pullback. L and M show representative manual-tool indications without hand-access/torque certification. All previously introduced components/hardware remain visible in forward assembly; tools may withdraw.

| OEM step | Global seconds | Duration | PDF page |
|---|---|---|---|
| S01 | 0–14 | 14s | 4 |
| S02 | 14–22 | 8s | 4 |
| S03 | 22–29 | 7s | 5 |
| S04 | 29–38 | 9s | 5 |
| S05 | 38–45 | 7s | 6 |
| S06 | 45–53 | 8s | 6 |
| S07 | 53–61 | 8s | 7 |
| S08 | 61–71 | 10s | 7 |
| S09 | 71–78 | 7s | 8 |
| S10 | 78–84 | 6s | 8 |
| S11 | 84–90 | 6s | 9 |
| S12 | 90–95 | 5s | 9 |
| S13 | 95–102 | 7s | 10 |
| S14 | 102–109 | 7s | 10 |
| S15 | 109–117 | 8s | 11 |
| S16 | 117–129 | 12s | 11 |
| S17 | 129–136 | 7s | 12 |
| S18 | 136–142 | 6s | 12 |
| S19 | 142–148 | 6s | 13 |

After148s, a10-second illustrative function/closure review completes the158s timeline. Source S19's open-door pad work is represented.35° door display and90° exterior tab release are animation choices, not OEM motion limits, latch certification or a recovered mechanism. No music/audio or final mastering.

## Source facts versus disclosed staging/placement hypotheses

- Source quantities, IDs,19-step order, global alignment-before-final-tightening and S10/S12 tightening checkpoints are retained. Structural paths and exact coordinates are display-unit approximations. No engineering dimensions/torque/turn count asserted.
- S7-prepared rail5+A remains visibly staged and labeled for S14. Side frames are prepared then integrated at S8; rails6 persist from S13 into S14. No disappearance/reinstallation. The whole retained assembly reorients together for the source's inverted stage and returns upright before floor14. These are presentation motions, not validated human lifting/support procedures. A flat review stage is shown early; no human support/access certification.
- C13 rear-end/C14 opposite rail6 ends plus two rail5 ends is now animated **only as an explicitly labeled visual allocation hypothesis** under the human-approved illustrative mode. It remains unconfirmed by physical evidence. This does not resolve the unlocated sixth S14 callout.
- J upper/I lower remain a source-conflict hypothesis. Source exterior stack H/tab/G is shown symbolically, with no invented concealed stud, capture, bore or thread. Tab profile differences and exact placement remain approximate.
- Some S5/S6/S8 individual D backing targets and other fastener placements are approximate source-associated exterior positions, not recovered receiving coordinates. The detailed placement ledger retains those caveats. No hidden geometry is created to justify them.

## Explicit fastener representation convention

Screw/bolt approaches and exterior head seating are illustrative. Existing threadless shafts remain in scene geometry, but their portions beyond each exterior host-face plane are graphically omitted. No concealed bore, insert, receiving carrier or thread is modeled. This is an opaque exterior illustration convention, not an actual swept-volume insertion or proof of engagement. It intentionally does **not** produce a physical collision PASS: raw fastener/host volume overlap is expected in this symbolic model and remains disclosed. No collision exclusion or tolerance was changed to claim a mechanical result. The user explicitly allowed controlled illustrative animation; the previous physical-proof blockers stay in the evidence register.

## Scoped visual fit and hierarchy changes

Only this new isolated revision applies the prior static external-hinge hypothesis. Door centerZ302→286; existing hinge leaves/barrels move to exterior faces as in C. Existing pieces are partitioned into frame-side leaf/end knuckles and door-side leaf/middle knuckle to support the illustrative door rig; no hidden pin added. The frozen B/C implementations are unchanged.

After the depth alignment, the old door top intersected header3 by6 display units. Door centerY408→400 yields2-unit visual gaps to header3 and floor14. This is a demonstrated display geometry correction, not an OEM tolerance. Existing center A carrier is translated11 display units down to meet the foot. H/tab/G visual stack surfaces are placed at296.5/298.1/299.6 displayZ to avoid floating exterior surfaces. These changes,35° door pose and90° tab release remain documented visual proposals, not physical fit or factory construction facts.

## Validation and preservation

19 graph steps /240 show+move operations, no missing dependency or cycle.20 source components and100 hardware/accessories plus3 inventory tools.3/3 targeted tests PASS; 633 sampled states retained previous product/hardware visibility and finite transforms. Arbitrary/backward seeks produce matching state hashes. Current source/scripts typecheck PASS with explicit config. Raw initial diagnostics and prior historical root failures retained; no root-wide PASS claimed.

1264 contiguous native PNGs validated, zero missing/invalid; MP4 full decode PASS, one video stream and no audio. Offline renderer records0 attempted network requests. Existing renderer plus local ffmpeg pattern reused.938 protected manifest paths changed0; prior B/C actual review payload hashes still match. No Product01 or discontinued JULIETTE changes; no approved/rejected historical output overwritten.

## Director decision requested

Watch the actual complete blocking MP4 and inspect pacing, first-connection teaching, retained chronology, macros, staging labels, illustrative function and assumptions. Return PASS / REVISION_REQUIRED with bounded visual revisions and distinguish this human-authorized illustration from a physical assembly certificate. If accepted, specify the next visual production milestone and its scope; do not independently override human security or expand to paid services, new evidence acquisition or uncertified mechanical claims. Final Long/Short films and sound are not produced by this blocking package; human alone finally accepts the eventual two completed films.
