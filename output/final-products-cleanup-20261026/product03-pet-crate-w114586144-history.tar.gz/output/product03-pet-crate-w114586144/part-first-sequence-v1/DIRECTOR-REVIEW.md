# PRODUCT03 — PART FIRST / SCREW SECOND / TOOL LAST

Review ID: PRODUCT03-PART-FIRST-SEQUENCE-V1-20261022

Human revision: material was moving through visible screws in the historical40s proof. The human now explicitly requests: place the panel/rail and establish contact; retain it; bring the screw to the target; bring the tool, fasten and withdraw. This overrides the previous local acceptance of that ordering. This package corrects the five focused clips, not the complete158s film.

## Actual outputs and sequence

Actual46s720p24fps silent compilation: S02/S05/S06/S08 each10s + S15 six seconds. Individual MP4s and original PNG evidence are in the ZIP. Before images are extracted from the actual immutable40s MP4, not invented recreations.

For each D exemplar:0–0.5 identify;0.5–2.5 place;2.5–3.25 contact hold;3.25–4.25 bring screw until tip touches the exterior;4.25–4.75 alignment hold;4.75–5.75 bringL;5.75–7.75 symbolic insertion/rotation;7.75–8.25 exterior seating;8.25–9.25 withdraw;9.25–10 installed hold. Structural parts remain fixed after2.5. New hardware stays hidden until contact is complete. Screw/key enter from outside the camera and key hides only after leaving it; no on-screen visibility pop. S15 adds no fastener/tool, consistent with the manual.

The5 clips are isolated, labeled exemplars; remaining repeated fasteners are not falsely installed at a cut. S02 retains the previously completed first divider/D7–8; S08 retains the left side/D30–34. Prepared feet follow their moving parent side. No previously installed part resets within a clip. Support/reorientation/human hand access is not certified or demonstrated.

## Necessary visible corrections — explicit assumptions

- Latest accepted nonliteralF geometry is the baseline. All20 part meshes/transforms andF8 meshes/transforms match it exactly. Earlier40s source, acceptedF clips, rejected versions and evidence stay immutable.
- D has a visible hex drive; local manualp1 listsL M4. UseL, not Phillips screwdriverM. ExistingD39 visible drive mouths change from3.741 to4.2 across-flats display units, and existingL becomes a4-across-flats hex profile. Outer heads/full shafts remain. Actual mesh checks:0.1 modeled side margin;0.85 tip/backing clearance.0.2 slot allowance and tool proportions are visual assumptions, NOT OEM tolerances. No hidden receiving hole/thread is added.
- Actual sweep exposed D35 crossing retainedD11 atS8. Four repeated rail-axis locationsD30/32/35/37 now moveZ±230→±190 on the SAME existing rail and wood backing. Full shafts remain. Old raw results retain the four D/D candidates; new per-mesh checks against all other hardware have0 candidates. These coordinates are nonliteral visual proposals, not OEM receiving points. D35/D15 transient AABB warning is also preserved in the initial raw audit; it disappears after the correction.

## QA and limits

All five clips:0 premature new screws/tools,0 part-to-retained-hardware intersections,0 installed-part drift,0 unrelated tool candidates; arbitrary/backward seek repeats.1,109 AABB time samples include endpoints.77 near exterior seating checks pass;13 retained face contacts have gap0;36 wood pairs have0 positive-volume overlaps;10S8 backing rays reach their declared wood targets.19 source-step counts remain unchanged under the open I/J interpretation.2 focused tests and scoped TypeScript pass.

Raw shaft/solid-stock intersections remain in the delivered classification, explicitly UNMODELED RECEIVER / NOT PHYSICAL PASS. Key/concave-drive AABB candidates are retained and resolved separately by actual visible-drive mesh fit. No bores, hidden receivers, threads, torque or real access/fit certification is invented. C13/C14 andI/J remain OPEN; whole-productP0/PhaseD acceptance remains open.

Initial screenshot timeout after476 captures is preserved. The476 original PNGs decode and have hashes;10 reference frames are pixel-identical to fresh final stills. Source stayed frozen. Only missing628 frames were rendered in3 fresh offline continuation jobs. Initial failed job has no completed state manifest: do not mislabel it complete. All1,104 final PNGs decode and are contiguous; all MP4s fully decode and contain no audio. Offline jobs aborted all network requests;0 attempted requests.938 protected paths, all previous review deliveries and accepted source/frozenF records match. Product01/JULIETTE unchanged.

## Decision requested

Please inspect the ACTUAL46s MP4 and byte-preserving ZIP. Decide PASS / REVISION_REQUIRED / FAIL for the human's PART→CONTACT→SCREW→TOOL ordering, visible key operation, retained state and declaredS8/drive corrections. This is a focused review milestone; no complete158s rerender, finalLong/Short/audio has started. Do not turn this visual proof into physical/OEM certification or whole-product acceptance. Human alone accepts eventual finished films. Close the focused proof if adequate and identify any remaining gate precisely; no new research, purchases or general Internet is authorized.
