from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import hashlib,json,subprocess,zipfile,shutil
P=Path(__file__).resolve().parent;B=P.parent;ROOT=P.parents[2]
def load(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(n,v):(P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def run(c):return subprocess.run(c,check=True,capture_output=True,text=True).stdout
groups=['S02','S05','S06','S08','S15'];lengths=[10,10,10,10,6]
recovery=load(P/'evidence/PARTIAL-FRAME-RECOVERY.json')
assert all(sha(ROOT/f)==h for f,h in recovery['identityAtRecovery'].items())
for row in recovery['preservedFrames']:assert sha(P/'frames'/row['name'])==row['sha256']
completed=[]
for folder,n in [('resume-S05-S06',244),('resume-S08',240),('resume-S15',144)]:
 d=P/folder;manifest=load(d/'selected-diagnostic-manifest.json');assert len(manifest)==n
 net=load(d/'offline-network.json');assert net['offline'] and not net['attemptedRequests']
 for row in manifest:
  assert not row['networkRequests'];src=d/row['name'];dst=P/'frames'/row['name'];assert not dst.exists()
  shutil.copyfile(src,dst);completed.append(row)
save('evidence/RESUMED-ACTUAL-STATE-MANIFEST.json',completed)
frameRows=[]
for g,duration in zip(groups,lengths):
 expected=[f'{g}-frame-{i:06d}.png' for i in range(duration*24)]
 assert sorted(f.name for f in (P/'frames').glob(g+'-frame-*.png'))==expected
 cameras=[r['camera'] for r in completed if r['name'].startswith(g+'-')]
 if cameras:assert all(c==cameras[0] for c in cameras)
 for name in expected:
  f=P/'frames'/name
  with Image.open(f) as im:im.load();assert im.size==(1280,720)
  frameRows.append(dict(name=name,bytes=f.stat().st_size,sha256=sha(f)))
assert len(frameRows)==1104
save('VIDEO-FRAME-MANIFEST.json',frameRows)

audit=load(P/'SEQUENCE-RAW-AUDIT.json');drive=load(P/'VISIBLE-DRIVE-FIT.json');reg=load(P/'CONTACT-AND-BACKING-REGRESSION.json');baseline=load(P/'BASELINE-AND-PLACEMENT-DELTAS.json')
for r in audit['result']:
 assert all(r[k]==0 for k in ['earlyScrew','earlyTool','retentionFailures','structuralDrift','entryVisible','exitVisible','headGap']) and r['deterministic']
 assert r['maxToolAxisError']<1e-6
 assert not any(c['kind'].startswith('PART_') or c['kind']=='KEY_VS_INSTALLED_CANDIDATE' or(c['kind']=='SCREW_VS_INSTALLED_CANDIDATE' and c['b'].startswith('hardware-')) for c in r['rawCandidates'])
assert drive['minHexSidePlaneMargin']>.09999 and drive['tipToBackingGap']>.84999
assert all(r['gap'] is not None and abs(r['gap'])<1e-5 for r in load(P/'ALL-77-EXTERIOR-SEATING.json'))
assert all(abs(r['gap'])<1e-5 for r in reg['contacts']) and not any(r['positiveVolume'] for r in reg['woodPairs'])
assert all(r['distance'] is not None for r in reg['backing'])
assert all(r['meshMatch'] and r['positionMatch'] and r['orientationMatch'] for r in baseline['unchanged'])
assert len(baseline['placementChanges'])==4
assert not load(P/'S8-FOUR-AXIS-REGRESSION.json')['after']
assert all(r['hardware']==r['actual'] for r in load(P/'ALL-19-STEP-COUNTS.json'))
classified=[]
for r in audit['result']:
 for c in r['rawCandidates']:
  if c['kind']=='KEY_VS_DRIVE_AABB_CANDIDATE':meaning='Concave visible-drive AABB candidate; actual straight hex section fits visible recess with0.1 model margin and0.85 backing clearance.'
  elif c['kind']=='SCREW_VS_INSTALLED_CANDIDATE':meaning='RAW SOLID SHAFT/STOCK INTERSECTION — receiving geometry omitted; symbolic insertion only, NOT a physical collision PASS.'
  else:meaning='UNEXPECTED — requires review'
  classified.append(dict(group=r['group'],**c,classification=meaning))
save('RAW-CANDIDATE-CLASSIFICATION.json',classified)

media=[]
for g,duration in zip(groups,lengths):
 path=P/f'PRODUCT03-{g}-part-first-proof-v1-720p.mp4'
 run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-framerate','24','-i',str(P/'frames'/(g+'-frame-%06d.png')),'-frames:v',str(duration*24),'-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-an','-movflags','+faststart',str(path)])
 media.append(path)
concat=P/'evidence/concat.txt';concat.write_text(''.join("file '../"+f.name+"'\n" for f in media))
combined=P/'PRODUCT03-part-first-sequence-proof-v1-720p.mp4'
run(['/opt/homebrew/bin/ffmpeg','-n','-v','error','-f','concat','-safe','0','-i',str(concat),'-c','copy','-movflags','+faststart',str(combined)])
media.append(combined);mediaQA=[]
for f,duration in zip(media,lengths+[46]):
 data=json.loads(run(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(f)]));assert len(data['streams'])==1
 s=data['streams'][0];assert s['codec_type']=='video' and s['width']==1280 and s['height']==720 and s['r_frame_rate']=='24/1' and int(s['nb_read_frames'])==duration*24
 assert abs(float(data['format']['duration'])-duration)<.001
 run(['/opt/homebrew/bin/ffmpeg','-v','error','-i',str(f),'-f','null','-'])
 mediaQA.append(dict(file=f.name,bytes=f.stat().st_size,sha256=sha(f),duration=duration,frames=duration*24,audioStreams=0,fullDecode='PASS'))
save('MEDIA-QA.json',dict(media=mediaQA,decodedPNGs=1104,recoveredFromTimeout=True,retainedFrames=476,resumedFrames=628,partialManifestQualification='Initial failed job lacks completed state manifest;10 exact fresh-still pixel checks plus capture log and frame hashes support reuse.',offline='Three fresh continuation jobs: all requests aborted;0 attempted requests'))

font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',21);small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17);big=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',27)
for i,sub in enumerate([groups[:2],groups[2:4]],1):
 im=Image.new('RGB',(1920,1220),'#f4f1e9');d=ImageDraw.Draw(im);d.text((22,10),'ACTUAL OLD40s VIDEO / CORRECTED PART-FIRST PROOF',font=big,fill='#292c2f')
 for row,g in enumerate(sub):
  for col,path in enumerate([P/f'evidence/{g}-actual-old-video.png',P/f'review-stills-final/{g}-place.png']):
   y=70+row*565;a=Image.open(path).convert('RGB').resize((960,540));im.paste(a,(col*960,y));d.text((col*960+15,y-25),g+' / '+('ACTUAL OLD MP4; NEW SCREW ALREADY VISIBLE' if col==0 else 'NEW PART MOTION; CURRENT SCREW HIDDEN'),font=small,fill='#805534')
 d.text((22,1200),'Before = extracted original video. After = latest acceptedF geometry + declared new sequencing/drive/S8 corrections.',font=small,fill='#805534')
 im.save(P/f'{i:02d}-BEFORE-AFTER.jpg',quality=94)
im=Image.new('RGB',(1920,1250),'#f4f1e9');d=ImageDraw.Draw(im);d.text((22,8),'PLACE → CONTACT HOLD → SCREW TIP → KEY L',font=big,fill='#292c2f')
for row,g in enumerate(groups[:4]):
 for col,stage in enumerate(['place','contact','screw','tool']):
  y=70+row*285;im.paste(Image.open(P/f'review-stills-final/{g}-{stage}.png').convert('RGB').resize((480,270)),(col*480,y));d.text((col*480+10,y-22),g+' / '+stage.upper(),font=small,fill='#805534')
d.text((22,1222),'S15 floor remains a support-only operation: no new screw/tool. All clips are separate, clearly labeled exemplars.',font=small,fill='#805534')
im.save(P/'03-FOUR-STAGE-SEQUENCE.jpg',quality=95)

protected=load(B/'phase-a-v1/evidence/protected-baseline.json');assert all((ROOT/f).exists() and sha(ROOT/f)==h for f,h in protected.items())
historical=[]
for manifest in B.glob('*/REVIEW-DELIVERY-MANIFEST.json'):
 if manifest.parent==P:continue
 for r in load(manifest):
  f=Path(r['path']);f=f if f.is_absolute() else manifest.parent/f;assert sha(f)==r['sha256'];historical.append(dict(revision=manifest.parent.name,file=f.name,match=True))
sources=[]
for revision in ['rail-fit-correction-v1','p0-connections-v1','f-illustrative-proof-v1']:
 for f,h in load(B/revision/'SOURCE-FINGERPRINTS.json')['files'].items():assert sha(ROOT/f)==h;sources.append(f)
for f,h in load(B/'f-illustrative-proof-v1/FROZEN-LOCAL-PROOF.json')['files'].items():assert sha(f)==h
for f,h in load(B/'phase-d-illustrative-v2/FROZEN-BLOCKING-SHA256.json')['files'].items():assert sha(ROOT/f if f.startswith('src/') else B/f)==h
assert sha(B/'phase-d-illustrative-v2/PRODUCT03-illustrative-assembly-blocking-v2-720p.mp4')=='0b1948907daaea92ec8cad5a7edd239fde7f11a12ebf6f6c7dfc8c32334456bc'
save('PROTECTED-ASSET-VERIFICATION.json',dict(status='PASS',paths=len(protected),changes=0,historicalDeliveries=historical,acceptedSourceChecks=len(sources),F_localProof='All frozen files match',old158s='UNCHANGED',Product01='UNCHANGED',JULIETTE='UNCHANGED'))
src=ROOT/'src/products/product03-pet-crate-w114586144/part-first-sequence-v1';save('SOURCE-FINGERPRINTS.json',dict(files={str(f.relative_to(ROOT)):sha(f) for f in src.glob('*.ts')},genericRenderer=sha(ROOT/'scripts/render-mechanism-diagnostics.ts')))
save('QA-SUMMARY.json',dict(review='PRODUCT03-PART-FIRST-SEQUENCE-V1-20261022',result='TECHNICAL VISUAL-SEQUENCE CHECKS PASS; DIRECTOR REVIEW REQUIRED',clips=5,duration=46,inventory='20 components;100 hardware/accessories +3 tools;19 steps;I/J provisional conflict OPEN',earlyScrew=0,earlyTool=0,partVsVisibleHardwareCrossings=0,retainedPartDrift=0,unexpectedToolPaths=0,deterministic=True,driveGeometry=drive,sourceScope='Illustrative exterior only; raw receiving overlaps preserved; no mechanical certification',fullFilmProduction='NOT RUN'))
(P/'DIRECTOR-REVIEW.md').write_text('''# PRODUCT03 — PART FIRST / SCREW SECOND / TOOL LAST

Review ID: PRODUCT03-PART-FIRST-SEQUENCE-V1-20261022

Human revision: material was moving through visible screws in the historical40s proof. The human now explicitly requests: place the panel/rail and establish contact; retain it; bring the screw to the target; bring the tool, fasten and withdraw. This overrides the previous local acceptance of that ordering. This package corrects the five focused clips, not the complete158s film.

## Actual outputs and sequence

Actual46s720p24fps silent compilation: S02/S05/S06/S08 each10s + S15 six seconds. Individual MP4s and original PNG evidence are in the ZIP. Before images are extracted from the actual immutable40s MP4, not invented recreations.

For each D exemplar:0–0.5 identify;0.5–2.5 place;2.5–3.25 contact hold;3.25–4.25 bring screw until tip touches the exterior;4.25–4.75 alignment hold;4.75–5.75 bringL;5.75–7.75 symbolic insertion/rotation;7.75–8.25 exterior seating;8.25–9.25 withdraw;9.25–10 installed hold. Structural parts remain fixed after2.5. New hardware stays hidden until contact is complete. Screw/key enter from outside the camera and key hides only after leaving it; no on-screen visibility pop. S15 adds no fastener/tool, consistent with the manual.

The5 clips are isolated, labeled exemplars; remaining repeated fasteners are not falsely installed at a cut. S02 retains the previously completed first divider/D7–8; S08 retains the left side/D30–34. Prepared feet follow their moving parent side. No previously installed part resets within a clip. Support/reorientation/human hand access is not certified or demonstrated.

## Necessary visible corrections — explicit assumptions

- Latest accepted nonliteralF geometry is the baseline. All20 part meshes/transforms andF8 meshes/transforms match it exactly. Earlier40s source, acceptedF clips, rejected versions and evidence stay immutable.
- D has a visible hex drive; local manualp1 listsL M4. UseL, not Phillips screwdriverM. ExistingD39 visible drive mouths change from3.741 to4.2 across-flats display units, and existingL becomes a4-across-flats hex profile. Outer heads/full shafts remain. Actual mesh checks:0.1 modeled side margin;0.85 tip/backing clearance.0.2 slot allowance and tool proportions are visual assumptions, NOT OEM tolerances. No hidden receiving hole/thread is added.
- Actual sweep exposed D35 crossing retainedD11 atS8. Four repeated rail-axis locationsD30/32/35/37 now moveZ±230→±190 on the SAME existing rail and wood backing. Full shafts remain. Old raw results retain the four D/D candidates; new per-mesh checks against all other hardware have0 candidates. These coordinates are nonliteral visual proposals, not OEM receiving points. D35/D15 transient AABB warning is also preserved in the initial raw audit; it disappears after the correction.

## QA and limits

All five clips:0 premature new screws/tools,0 part-to-retained-hardware intersections,0 installed-part drift,0 unrelated tool candidates; arbitrary/backward seek repeats.1,109 AABB time samples include endpoints.77 near exterior seating checks pass;13 retained face contacts have gap0;36 wood pairs have0 positive-volume overlaps;10S8 backing rays reach their declared wood targets.19 source-step counts remain unchanged under the open I/J interpretation.2 focused tests and scoped TypeScript pass.

Raw shaft/solid-stock intersections remain in the delivered classification, explicitly UNMODELED RECEIVER / NOT PHYSICAL PASS. Key/concave-drive AABB candidates are retained and resolved separately by actual visible-drive mesh fit. No bores, hidden receivers, threads, torque or real access/fit certification is invented. C13/C14 andI/J remain OPEN; whole-productP0/PhaseD acceptance remains open.

Initial screenshot timeout after476 captures is preserved. The476 original PNGs decode and have hashes;10 reference frames are pixel-identical to fresh final stills. Source stayed frozen. Only missing628 frames were rendered in3 fresh offline continuation jobs. Initial failed job has no completed state manifest: do not mislabel it complete. All1,104 final PNGs decode and are contiguous; all MP4s fully decode and contain no audio. Offline jobs aborted all network requests;0 attempted requests.938 protected paths, all previous review deliveries and accepted source/frozenF records match. Product01/JULIETTE unchanged.

## Decision requested

Please inspect the ACTUAL46s MP4 and byte-preserving ZIP. Decide PASS / REVISION_REQUIRED / FAIL for the human's PART→CONTACT→SCREW→TOOL ordering, visible key operation, retained state and declaredS8/drive corrections. This is a focused review milestone; no complete158s rerender, finalLong/Short/audio has started. Do not turn this visual proof into physical/OEM certification or whole-product acceptance. Human alone accepts eventual finished films. Close the focused proof if adequate and identify any remaining gate precisely; no new research, purchases or general Internet is authorized.
''')
files=['DIRECTOR-REVIEW.md','HUMAN-AUTHORIZATION.json','QA-SUMMARY.json','MEDIA-QA.json','SEQUENCE-RAW-AUDIT.json','RAW-CANDIDATE-CLASSIFICATION.json','S8-FOUR-AXIS-REGRESSION.json','VISIBLE-DRIVE-FIT.json','BASELINE-AND-PLACEMENT-DELTAS.json','ALL-77-EXTERIOR-SEATING.json','CONTACT-AND-BACKING-REGRESSION.json','ALL-19-STEP-COUNTS.json','ACTUAL-BEFORE-VIDEO-FRAMES.json','PROTECTED-ASSET-VERIFICATION.json','SOURCE-FINGERPRINTS.json',*[f.name for f in media],'01-BEFORE-AFTER.jpg','02-BEFORE-AFTER.jpg','03-FOUR-STAGE-SEQUENCE.jpg','evidence/tests.log','evidence/typecheck-complete.log','evidence/INITIAL-S8-CROSSING-AUDIT.json']
for g in groups[:4]:files.extend([f'review-stills-final/{g}-{s}.png' for s in ['place','contact','screw','tool','seated']])
files+=['review-stills-final/S15-contact.png']
manifest=[dict(path=n,bytes=(P/n).stat().st_size,sha256=sha(P/n)) for n in files];save('PAYLOAD-SHA256.json',manifest)
z=P/'PRODUCT03-part-first-sequence-v1-review.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED) as a:
 for n in files+['PAYLOAD-SHA256.json']:a.write(P/n,n)
with zipfile.ZipFile(z) as a:assert all(hashlib.sha256(a.read(r['path'])).hexdigest()==r['sha256'] for r in manifest)
delivery=[z,combined,P/'DIRECTOR-REVIEW.md',P/'01-BEFORE-AFTER.jpg',P/'02-BEFORE-AFTER.jpg',P/'03-FOUR-STAGE-SEQUENCE.jpg']
save('REVIEW-DELIVERY-MANIFEST.json',[dict(path=str(f.resolve()),bytes=f.stat().st_size,sha256=sha(f)) for f in delivery]);(P/'DELIVERY-SHA256.txt').write_text(''.join(f'{sha(f)}  {f.name}\n' for f in delivery))
print(json.dumps(dict(zip=z.name,sha256=sha(z),payloads=len(manifest),combined=mediaQA[-1],result='REQUIRES DIRECTOR REVIEW'),indent=2))
