from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import hashlib,json,shutil,zipfile
b=Path(__file__).resolve().parent;root=b.parents[2];base=b.parent;a=base/'phase-a-v1';frames=b/'final-frames';d=b/'review-files';d.mkdir(exist_ok=True);stage=b/'archive-content';stage.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
font=lambda n:ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',n)
v=json.loads((b/'VALIDATION.json').read_text());dur=v['duration'];fps=8;fs=sorted(frames.glob('frame-*.png'));assert len(fs)==dur*fps
validated=[]
for i,p in enumerate(fs):
 assert p.name==f'frame-{i:06d}.png'
 with Image.open(p) as im:assert im.size==(1280,720);im.verify()
 validated.append({'frame':i,'sha256':sha(p)})
(b/'FRAME-VALIDATION.json').write_text(json.dumps({'status':'PASS','count':len(fs),'native':[1280,720],'fps':fps,'duration':dur,'missing':0,'invalid':0,'frames':validated},indent=2)+'\n')
def sheet(names,out):
 im=Image.new('RGB',(1600,480*((len(names)+1)//2)),'#eeeae2');dr=ImageDraw.Draw(im)
 for i,n in enumerate(names):
  x=i%2*800;y=i//2*480;im.paste(Image.open(frames/n).convert('RGB').resize((800,450)),(x,y+30));dr.text((x+15,y+5),n.replace('.png',''),font=font(18),fill='#302d29')
 assert max(im.size)<=2048;im.save(stage/out,quality=94,subsampling=0)
for group,ids in [(1,range(1,7)),(2,range(7,13)),(3,range(13,20))]:sheet([f'S{i:02d}-endpoint.png' for i in ids],f'0{group}-OEM-STEPS.jpg')
sheet(['first-joint-macro.png','bracket-macro.png','hinge-macro.png','final-open.png','final-closed.png'],'04-CONNECTIONS-AND-FUNCTION.jpg')
video=b/'PRODUCT03-illustrative-assembly-blocking-v1-720p.mp4';assert video.is_file();probe=json.loads((b/'ffprobe.json').read_text());assert len(probe['streams'])==1 and probe['streams'][0]['codec_type']=='video';assert int(probe['streams'][0]['nb_frames'])==len(fs);assert abs(float(probe['format']['duration'])-dur)<1e-6;assert not (b/'full-decode.log').read_text().strip();shutil.copyfile(video,stage/video.name)
protected=json.loads((a/'evidence/protected-baseline.json').read_text());changed=[p for p,h in protected.items() if not (root/p).is_file() or sha(root/p)!=h];assert not changed
prior=[]
for name in ['phase-b-v1','phase-b-v2','phase-c-v1','phase-c-v1-integrity-r1']:
 for row in json.loads((base/name/'REVIEW-DELIVERY-MANIFEST.json').read_text()):prior.append({'path':row['path'],'match':sha(row['path'])==row['sha256']})
assert all(x['match'] for x in prior)
network=json.loads((frames/'offline-network.json').read_text());assert not network['attemptedRequests']
assert '3 passed (3)' in (b/'test-reviewed.log').read_text();assert not (b/'typecheck-validation.log').read_text().strip()
qa={'revision':'PRODUCT03-PHASE-D-ILLUSTRATIVE-V1-20261020','human_authorization':'Human explicitly approved controlled illustrative continuation and faster pacing; HUMAN-AUTHORIZATION.json','technical':{'OEM_graph_steps':19,'graph_operations':240,'missing_dependencies':0,'cycles':0,'parts':20,'hardware_accessories':100,'tools_in_inventory':3,'tools_installed':0,'tests':'3/3 PASS','source_scripts_typecheck':'PASS; explicit config excludes historical output snapshots','root_typecheck':'NOT_RUN for this revision; earlier raw failures retained, no repository-wide PASS claimed','retention':v['retention'],'finite_transforms':v['finiteTransforms'],'deterministic_seek':v['determinism']['status'],'time_samples':v['samples']},'video':{'type':'Whole Phase D illustrative blocking review; NOT final Long/Short master','width':1280,'height':720,'fps':fps,'frames':len(fs),'duration':dur,'codec':'h264','audio_streams':0,'native_png_validation':'PASS','full_decode':'PASS','sha256':sha(video)},'pacing':'Semantic durations: S1 teaches in14s, repeats5–10s; no global video speed-up or dropped OEM step','offline_network':network,'protection':{'paths_checked':938,'changed':changed,'prior_B_C_review_payloads_match':True},'mechanical':'NOT_CERTIFIED; no physical collision/fit/tool/support PASS claimed','known_limits':v['rawGeometryLimits'],'director':'REQUIRES_ACTUAL_REVIEW','next_scope':'No final films or audio mastered at this milestone; request bounded next-phase decision'}
(b/'PHASE-D-QA.json').write_text(json.dumps(qa,indent=2)+'\n');shutil.copyfile(b/'PHASE-D-QA.json',stage/'PHASE-D-QA.json');shutil.copyfile(b/'VALIDATION.json',stage/'VALIDATION.json');shutil.copyfile(b/'HUMAN-AUTHORIZATION.json',stage/'HUMAN-AUTHORIZATION.json')
table='| OEM step | Global seconds | Duration | PDF page |\n|---|---|---|---|\n'
for s in v['endpointCoverage']:table+=f"| {s['id']} | {s['start']}–{s['end']} | {s['end']-s['start']}s | {s['sourcePdf']} |\n"
report=f'''# Product03 — controlled illustrative assembly blocking V1

Review ID: PRODUCT03-PHASE-D-ILLUSTRATIVE-V1-20261020. **REQUIRES DIRECTOR REVIEW.** Human approved the new controlled illustrative mode after limited Phase C, and requested a somewhat faster pace. This changes the representation boundary, not the source evidence or engineering confidence. Only the existing Assemble review channel is authorized online.

## Actual implementation and outputs

A complete deterministic19-step OEM-order illustrative timeline, using existing ProductEngine geometry/registry and typed AssemblyDefinition/AssemblyGraph. No new engine, exporter, assembly schema or catalog registration.20 component instances +100 illustrated hardware/accessory units; L/M/O remain3 separate tools, never installed product parts. All source quantities reconcile under the still-provisional S18 I/J disposition. The actual full blocking MP4 is native1280×720,8fps,{dur}s/{len(fs)} frames,silent. It is a lightweight Director preview, not a final production Long or portrait Short. The archive includes the actual video,24 diagnostic stills represented by4 contact sheets, numeric timeline/placement ledger, QA and byte hashes. Diagnostic macro stills can use a separate inspection camera; the full MP4 contains actual timed close-ups as well.

Source PDF SHA256 `70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29`. The documentary19-step order is unchanged. No additional public research or physical evidence was acquired. Source product identity remains metadata-only; no drawers/slides are added.

## Faster pacing without losing chronology

S1 teaches both side10 connections and all4 D in14s (prior Phase C used16s for a partial one-end approach). Repetitions shorten through authored durations, not a global playback speed multiplier. First drive/connection close-up stays readable; later repeated fasteners shorten. S4 K/B, first A/C/F, side-frame D, E hinge and latch stack get macro moments with wide context/pullback. L and M show representative manual-tool indications without hand-access/torque certification. All previously introduced components/hardware remain visible in forward assembly; tools may withdraw.

{table}
After150s, an8-second illustrative function/closure review completes the158s timeline. Source S19's open-door pad work is represented.35° door display and90° exterior tab release are animation choices, not OEM motion limits, latch certification or a recovered mechanism. No music/audio or final mastering.

## Source facts versus disclosed staging/placement hypotheses

- Source quantities, IDs,19-step order, global alignment-before-final-tightening and S10/S12 tightening checkpoints are retained. Structural paths and exact coordinates are display-unit approximations. No engineering dimensions/torque/turn count asserted.
- S7-prepared rail5+A remains visibly staged and labeled for S14. Side frames are prepared then integrated at S8; rails6 persist from S13 into S14. No disappearance/reinstallation. The whole retained assembly reorients together for the source's inverted stage and returns upright before floor14. These are presentation motions, not validated human lifting/support procedures. A flat review stage is shown early; no human support/access certification.
- C13 rear-end/C14 opposite rail6 ends plus two rail5 ends is now animated **only as an explicitly labeled visual allocation hypothesis** under the human-approved illustrative mode. It remains unconfirmed by physical evidence. This does not resolve the unlocated sixth S14 callout.
- J upper/I lower remain a source-conflict hypothesis. Source exterior stack H/tab/G is shown symbolically, with no invented concealed stud, capture, bore or thread. Tab profile differences and exact placement remain approximate.
- Some S5/S6/S8 individual D backing targets and other fastener placements are approximate source-associated exterior positions, not recovered receiving coordinates. The detailed placement ledger retains those caveats. No hidden geometry is created to justify them.

## Explicit fastener representation convention

Screw/bolt approaches and exterior head seating are illustrative. Existing threadless shafts remain in scene geometry, but their portions beyond each exterior host-face plane are graphically omitted. No concealed bore, insert, receiving carrier or thread is modeled. This is an opaque exterior illustration convention, not an actual swept-volume insertion or proof of engagement. It intentionally does **not** produce a physical collision PASS: raw fastener/host volume overlap is expected in this symbolic model and remains disclosed. No collision exclusion or tolerance was changed to claim a mechanical result. The user explicitly allowed controlled illustrative animation; the previous physical-proof blockers stay in the evidence register.

## Scoped visual fit and hierarchy changes

Only this new isolated revision applies the prior static external-hinge hypothesis. Door centerZ302→286; existing hinge leaves/barrels move to exterior faces as in C. Existing pieces are partitioned into frame-side leaf/end knuckles and door-side leaf/middle knuckle to support the illustrative door rig; no hidden pin added. The frozen B/C implementations are unchanged.

After the depth alignment, the old door top intersected header3 by6 display units. Door centerY408→400 yields2-unit visual gaps to header3 and floor14. This is a demonstrated display geometry correction, not an OEM tolerance. Existing center A carrier is translated11 display units down to meet the foot. H/tab/G visual stack surfaces are placed at296.5/298.1/299.6 displayZ to avoid floating exterior surfaces. These changes,35° door pose and90° tab release remain documented visual proposals, not physical fit or factory construction facts.

## Validation and preservation

19 graph steps /240 show+move operations, no missing dependency or cycle.20 source components and100 hardware/accessories plus3 inventory tools.3/3 targeted tests PASS; {v['samples']} sampled states retained previous product/hardware visibility and finite transforms. Arbitrary/backward seeks produce matching state hashes. Current source/scripts typecheck PASS with explicit config. Raw initial diagnostics and prior historical root failures retained; no root-wide PASS claimed.

{len(fs)} contiguous native PNGs validated, zero missing/invalid; MP4 full decode PASS, one video stream and no audio. Offline renderer records0 attempted network requests. Existing renderer plus local ffmpeg pattern reused.938 protected manifest paths changed0; prior B/C actual review payload hashes still match. No Product01 or discontinued JULIETTE changes; no approved/rejected historical output overwritten.

## Director decision requested

Watch the actual complete blocking MP4 and inspect pacing, first-connection teaching, retained chronology, macros, staging labels, illustrative function and assumptions. Return PASS / REVISION_REQUIRED with bounded visual revisions and distinguish this human-authorized illustration from a physical assembly certificate. If accepted, specify the next visual production milestone and its scope; do not independently override human security or expand to paid services, new evidence acquisition or uncertified mechanical claims. Final Long/Short films and sound are not produced by this blocking package; human alone finally accepts the eventual two completed films.
'''
(b/'PHASE-D-REVIEW.md').write_text(report);(stage/'PHASE-D-REVIEW.md').write_text(report);shutil.copyfile(stage/'PHASE-D-REVIEW.md',d/'PHASE-D-REVIEW.md')
# Store local reviewed implementation as text snapshots; do not add executable historical copies.
snap=b/'evidence/reviewed-source';snap.mkdir(exist_ok=True)
for p in (root/'src/products/product03-pet-crate-w114586144/phase-d-illustrative-v1').glob('*.ts'):shutil.copyfile(p,snap/(p.name+'.txt'))
(stage/'CONTENTS-SHA256.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(stage.iterdir()) if p.name!='CONTENTS-SHA256.txt'))
archive=d/'PRODUCT03-PhaseD-illustrative-review-v1.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(stage.iterdir()):z.write(p,p.name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in stage.iterdir():assert z.read(p.name)==p.read_bytes()
for p in stage.glob('*.jpg'):shutil.copyfile(p,d/p.name)
(d/'DELIVERY-SHA256.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(d.iterdir()) if p.name!='DELIVERY-SHA256.txt'))
(b/'REVIEW-DELIVERY-MANIFEST.json').write_text(json.dumps([{'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(d.iterdir())],indent=2)+'\n')
print(json.dumps({'files':len(list(d.iterdir())),'frames':len(fs),'duration':dur,'videoSha256':sha(video),'archiveSha256':sha(archive),'protected_changed':changed},indent=2))
