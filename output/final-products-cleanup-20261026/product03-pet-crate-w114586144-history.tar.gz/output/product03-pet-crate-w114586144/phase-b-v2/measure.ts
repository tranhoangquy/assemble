import * as T from 'three';
import {createPrototype} from '../../../src/products/product03-pet-crate-w114586144/prototype-v2/model';
import {writeFileSync} from 'node:fs';
const r=createPrototype();r.root.updateMatrixWorld(true);const parts=[...r.registry.entries()].filter(([id])=>id.startsWith('part-')).map(([id,o])=>{const b=new T.Box3().setFromObject(o);return{id,position:o.position.toArray(),bounds:{min:b.min.toArray(),max:b.max.toArray()}}});
writeFileSync(new URL('./GEOMETRY-LEDGER.json',import.meta.url),JSON.stringify({units:'Unmeasured display units; not OEM millimetres',parts,doorAndHingeReview:{door7to8FrameGap:12,outerDoorFrameToSidePostProjectedXGap:4,hingeCenters:[[-569,631,294.5],[-569,185,294.5],[569,631,294.5],[569,185,294.5]],warning:'Axis/leaf seating and mating remain unverified. Barrel radius3.3 lies partly within door frame envelope; no physical fit PASS. Isolated hinge view exposes constituent shape only.'}},null,2));
