from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,shutil
from datetime import datetime
b=Path(__file__).resolve().parent;root=b.parents[2];v1=b.parent/'phase-b-v1';a=b.parent/'phase-a-v1';st=b/'stills-reviewed';d=b/'review-files';d.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
font=lambda n:ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',n)
files=list(st.glob('*.png'));assert len(files)==25
for p in files:
 with Image.open(p) as im:assert im.size==(1280,720);im.verify()
def sheet(rows,name):
 out=Image.new('RGB',(1920,570*((len(rows)+1)//2)),'#ede9e1');dr=ImageDraw.Draw(out)
 for i,(p,label) in enumerate(rows):
  x=i%2*960;y=i//2*570;im=Image.open(p).convert('RGB').resize((960,540));out.paste(im,(x,y));dr.rectangle((x,y,x+960,y+32),fill='#eeeae2');dr.text((x+18,y+6),label,font=font(18),fill='#302d29')
 out.save(d/name,quality=93,subsampling=0)
for src,dest in [('01-crafted-overall.png','01-Crafted-Frame-V2.jpg'),('02-quiet-oak-overall.png','02-Quiet-Oak-V2.jpg')]:Image.open(st/src).convert('RGB').save(d/dest,quality=95,subsampling=0)
sheet([(st/n,l) for n,l in [('03-front-identity.png','V2 / front'),('04-rear-identity.png','V2 / rear'),('05-exploded-20-components.png','V2 / 20 labeled component instances'),('06-upper-module.png','V2 / upper module'),('13-parts-inventory.png','V2 / separate source components'),('14-floor-supports.png','V2 / C allocation remains unresolved')]],'03-GEOMETRY-V2.jpg')
sheet([(v1/'stills-reviewed/07-wood-crafted.png','V1 / Crafted wood'),(st/'07-wood-crafted.png','V2 / stronger fibers and pore relief'),(v1/'stills-reviewed/08-metal-lattice.png','V1 / frame and mesh'),(st/'08-metal-lattice.png','V2 / edge separation and cool fill'),(st/'15-wood-quiet-oak.png','V2 / Quiet Oak alternate'),(st/'06-upper-module.png','V2 / panel-oriented grain')],'04-MATERIAL-BEFORE-AFTER.jpg')
sheet([(v1/'stills-reviewed/09-screw-C-D.png','V1 / C and D full body'),(st/'09-screw-C-D.png','V2 / C and D full body'),(st/'21-socket-drives-C-D.png','V2 / socket head recesses'),(st/'22-cross-drives-E-F.png','V2 / E and F cross drives'),(st/'23-nut-washer-G-H.png','V2 / G nut and H split washer'),(st/'24-retaining-tabs-I-J.png','V2 / I and J silhouette only, engagement unknown')],'05-HARDWARE-MACROS.jpg')
sheet([(st/'17-hinge-left-upper.png','V2 / left upper hinge context'),(st/'18-hinge-left-lower.png','V2 / left lower hinge context'),(st/'19-hinge-right-upper.png','V2 / right upper hinge context'),(st/'20-hinge-right-lower.png','V2 / right lower hinge context'),(v1/'stills-reviewed/10-hinge-detail.png','V1 / hinge context'),(st/'25-hinge-external-study.png','V2 / isolated hinge leaves; NOT installed-fit proof')],'06-HINGE-REVIEW.jpg')
protected=json.loads((a/'evidence/protected-baseline.json').read_text());changed=[p for p,h in protected.items() if not (root/p).is_file() or sha(root/p)!=h]
# V1 source and review files must also remain byte-identical.
frozen={}
for p in (root/'src/products/product03-pet-crate-w114586144/prototype-v1').glob('*.ts'):
 frozen[p.name]=sha(p)==sha(v1/'evidence/reviewed-source'/p.name)
net=json.loads((st/'offline-network.json').read_text());man=json.loads((st/'diagnostic-manifest.json').read_text());assert all(x['registeredPartInstances']==20 and x['registeredHardwareUnits']==103 and not x['networkResourceRequests'] for x in man)
qa={'revision':'PRODUCT03-PHASE-B-V2-20261020','recorded_at':datetime.now().isoformat(),'components':20,'hardware_and_tools':103,'source_part_types':15,'source_dimensions':'UNKNOWN','stills':25,'render':'Actual Three.js WebGL 1280x720 static stills; existing renderer, no new exporter','targeted_tests':{'status':'PASS 3/3','log':'test-results-recheck.log','initial_run':'2/3 passed; finite-mesh test exceeded default5s during concurrent render; retained raw timeout; sequential recheck 15s timeout passed in5.05s'},'typecheck_source_scripts':'PASS — typecheck-source-final.log (explicit config excludes immutable output history)','root_typecheck':'Historical V1 full check remains FAIL: 50 diagnostics exclusively preserved JULIETTE output snapshots. No root PASS claimed; no historical files changed. See V1 typecheck-full-final.log. Not rerun after source-only changes.','network':net,'protected':{'paths_checked':len(protected),'changed':changed,'status':'PASS' if not changed else 'FAIL'},'V1_source_unchanged':frozen,'physical_fit':'NOT_VALIDATED; visible hinge/frame embedding still unresolved','C13_C14':'UNRESOLVED, no receiving geometry added','S18_I_J':'WORKING_HYPOTHESIS_ONLY','phase_C':'NOT_AUTHORIZED','animation_audio_video':'NOT_RUN','director_status':'REQUIRES_DIRECTOR_REVIEW'}
assert not changed and all(frozen.values()) and not net['attemptedRequests']
(b/'PHASE-B-V2-QA.json').write_text(json.dumps(qa,indent=2)+'\n');shutil.copyfile(b/'PHASE-B-V2-QA.json',d/'PHASE-B-V2-QA.json')
materials={'status':'CREATIVE_PROPOSAL; not OEM species/material certification','primary':'Crafted Frame','alternate':'Quiet Oak','crafted':{'wood':'#77533b','frame':'#292c2f','steel':'#a3a9ac'},'quiet_oak':{'wood':'#b19a76','frame':'#484a45','steel':'#b4b7b4'},'wood':{'roughness':.54,'bumpScale_display_units':.10,'texture':[512,256],'seed':'code*3+instance','grainOrientation':'Long panel axis X, or Z for side/divider boards; no end-grain species claim','periodic_noise':True,'clamped_pixels':True},'frame':{'roughness':.34,'metalness':.62},'steel':{'roughness':.24,'metalness':.82},'light':'Local RoomEnvironment + warm key/cool side area fill; no downloaded assets','geometry':'Product positions/topology unchanged; wood UV orientation revised only'}
(b/'MATERIAL-CONFIG.json').write_text(json.dumps(materials,indent=2)+'\n')
report='''# Product03 — Phase B V2 review

Review ID: PRODUCT03-PHASE-B-V2-20261020. Actual static prototype revision. **REQUIRES DIRECTOR REVIEW**. Phase C, animation, audio and Long/Short remain NOT AUTHORIZED by the human.

The actual V1 Director response was read in Assemble and recorded locally, distinct from human-supplied instructions. It selected Crafted Frame, retained Quiet Oak, and requested six targeted improvements. This package responds within Phase B only.

## Implemented revisions

1. Crafted Frame remains primary; Quiet Oak alternate. Stronger procedural wood fiber contrast, pore relief and panel variation; all pixel values clamped; periodic maps avoid seams. Long-axis grain UV now uses Z for side/divider panels and X for long horizontal boards. No wood species or OEM finish claim.
2. Frame roughness .45→.34, metalness .50→.62; steel roughness .28→.24, metalness .76→.82. Local warm/cool studio lighting and brighter rim/fill distinguish tube, mesh and brace. Local environment intensity .70→1.0. No downloaded textures/HDR.
3. Dedicated actual WebGL macro views show C/D socket recesses, E/F cross recesses, G hex nut, H split washer and I/J retaining-tab silhouettes. Full-body screws remain threadless; no receiving bores or new mechanical parts.
4. All four hinge locations have close context views, plus an isolated constituent view exposing both leaves and barrel. This intentionally reveals limitations instead of certifying fit.
5. Three-quarter hero framing increased from .72 to .83 vertical fit factor. Exploded component labels now use 20 ordered external leader labels with instance IDs; no change to assembly order or physical paths.
6. All source uncertainties remain open. No C allocation, I/J identity, contact or tool-access confidence upgrade is derived from renders.

## Evidence and geometry limits

Source is the same human-supplied13-page PDF, SHA256 `70873d55959072bdd1e702030262548c52f4667a208bc9d2ced8b2e4d781bd29`. Metadata commercial identity remains unverified. The inventory depicts three open cubbies and two mesh doors, with no drawers/slides.

20 components /15 numbered IDs and103 A–O units (100 installed/accessory units +3 tools) are preserved. Hardware is predominantly displayed loose, not falsely fitted to unknown receivers. Hinge/handle/mesh constituents do not add OEM IDs. V1 source and prior outputs remain immutable. V2 has a separate source/output namespace.

All coordinates are arbitrary display units. The nominal1200×1000×620 display envelope is not a manufacturer measurement. All dimensions, panel thicknesses, wire pitches, aperture sizes and material parameters remain VISUAL_APPROXIMATION. Product geometry/topology/positions have not changed from V1; wood UV orientation and presentation changed.

Closed visual measurements: door7/8 projected frame gap12 display units; outer door-frame/side-post X gap4 display units. Hinge centers: X±569, Y185/631, Z294.5. These are reproducible mesh coordinates, not OEM dimensions or tolerances. Hinge leaf/barrel parts partly embed in the current door/frame envelopes: the isolated view is a shape study, not evidence that the installed interface works. No seating/axis/fastener/access solution is invented. A source-grounded connection proof remains blocked at these unknowns; no Phase C sequence is attempted. Human hand/tool clearance and motion limits are UNKNOWN.

## Unresolved register (retained, no resolution claimed)

- S18: inset I versus summary J contradiction. J upper / I lower remains a working hypothesis only. I/J prototypes share a stylized external silhouette; their actual shape differences, receiving studs and locking action remain unknown.
- S13 C4 / S14 C6: quantities reconcile, but exact per-end allocation is unresolved. V1 source annotation localizes nine visible C callout regions; sixth S14 unit remains count-only/unlocated. No fabricated tenth point, receiver or completed fastening is added.
- Overall/panel/hardware dimensions, concealed bores/threads, D backing ownership, supported inversion, tightening access and final seating remain unknown. Alignment-before-final-tightening instruction remains mandatory for future supported sequencing.
- Hinge contacts, axes, movement limits, floor seating, pad action, load/pet fit/capacity and material chemistry remain unverified. All15 Phase A uncertainties remain in force. This visual revision cannot close the physical evidence gate.

## Actual delivery and QA

25 native1280×720 WebGL stills, 2 hero JPEGs and4 comparison/contact sheets. These are rendered scene pixels, not generative illustrations. Macro plates retain captions and show V1/V2 comparisons. `PHASE-B-V2-QA.json` records actual test outcomes and limitations. `REVIEW-SHA256.txt` hashes all8 payload files. The material parameters and numeric geometry ledger are preserved locally; key values are reproduced in this report.

3/3 targeted inventory/reset/finite-mesh tests PASS after a bounded sequential recheck: initial concurrent run exceeded default5s on the per-vertex test; raw timeout preserved, recheck at15s timeout passed in5.05s. Source/scripts TypeScript PASS with explicit review config. The historical root check remains FAIL with50 diagnostics in preserved JULIETTE output source snapshots; no repository-wide PASS is claimed or history edited.

938 protected manifest paths:0 changed. V1 source hashes match frozen reviewed source. Offline Chromium context, blocked service workers and aborted requests report0 attempted network requests. No new exporter/catalog/schema, video, audio, external assets, paid services or general Internet use. Only this authorized Assemble review handoff uses the Internet.

## Decision requested

Please inspect actual files and return PASS / REVISION_REQUIRED / BLOCKED for Phase B V2, distinguishing visual approval from unresolved physical fit. If further static prototype revisions are needed, specify bounded Phase B changes. If Phase B passes, stop at the human boundary: Phase C and all production still require separate explicit human authorization. Director approval is internal; human alone accepts both eventual films.
'''
(b/'PHASE-B-V2-REVIEW.md').write_text(report);(d/'PHASE-B-V2-REVIEW.md').write_text(report)
snap=b/'evidence/reviewed-source';snap.mkdir(parents=True,exist_ok=True)
for p in (root/'src/products/product03-pet-crate-w114586144/prototype-v2').glob('*.ts'):shutil.copyfile(p,snap/p.name)
payload=sorted(d.iterdir());(d/'REVIEW-SHA256.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in payload))
(b/'REVIEW-DELIVERY-MANIFEST.json').write_text(json.dumps([{'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(d.iterdir())],indent=2)+'\n')
print(json.dumps({'files':len(list(d.iterdir())),'stills':len(files),'protected':qa['protected'],'V1_unchanged':frozen},indent=2))
